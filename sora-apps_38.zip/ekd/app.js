/* EKDNist — 大学駅伝のデータと分析 */
'use strict';
const LS = { cfg: 'ekd-cfg', idx: 'ekd-idx', ui: 'ekd-ui' };
const $ = (s, el) => (el || document).querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function lsGet(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
function cfg() { const c = lsGet(LS.cfg, {}); return { url: c.url || (window.EKD_CONFIG && window.EKD_CONFIG.gasUrl) || '', pass: c.pass || '', push: c.push || null }; }
function setCfg(k, v) { const c = lsGet(LS.cfg, {}); c[k] = v; lsSet(LS.cfg, c); }
const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const F = EK.fmt, S = EK.short;
const LSADJ = 'ekd-adj';
EK.ADJ = lsGet(LSADJ, {});
const st = { view: 'home', args: [], M: null, dbs: {}, idx: lsGet(LS.idx, null), msg: {}, cache: {}, ui: Object.assign({ rs: 'hakone', rleg: 1, rmode: 'leg', rall: false, rg: 0, runi: true, es: 'hakone', women: false, pts: 'hakone' }, lsGet(LS.ui, {})), loading: 0, err: '' };
const saveUi = () => lsSet(LS.ui, st.ui);

/* ---------- storage for the race databases (IndexedDB; falls back to memory) ---------- */
const IDB = (() => {
  let dbp = null;
  const open = () => dbp || (dbp = new Promise((res, rej) => { try { const r = indexedDB.open('ekdnist', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); } catch (e) { rej(e); } }));
  const tx = (mode, fn) => open().then(db => new Promise((res, rej) => { const t = db.transaction('kv', mode), s = t.objectStore('kv'), q = fn(s); t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); }));
  return { get: k => tx('readonly', s => s.get(k)).catch(() => null), set: (k, v) => tx('readwrite', s => s.put(v, k)).catch(() => null), keys: () => tx('readonly', s => s.getAllKeys()).catch(() => []), clear: () => tx('readwrite', s => s.clear()).catch(() => null) };
})();

/* ---------- GAS ---------- */
function gasUrl(params) { const u = new URL(cfg().url); Object.entries(params || {}).forEach(([k, v]) => { if (v !== '' && v != null) u.searchParams.set(k, v); }); u.searchParams.set('t', Date.now()); return u.toString(); }
async function gasGet(params) { const r = await fetch(gasUrl(params)); if (!r.ok) throw new Error('HTTP ' + r.status); const j = await r.json(); if (j && j.ok === false) throw new Error(j.error || 'エラー'); return j; }
async function post(body) {
  const c = cfg(); if (!c.url) throw new Error('GAS の URL が未設定です'); if (!c.pass) throw new Error('合言葉が未設定です');
  const r = await fetch(c.url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(Object.assign({ pass: c.pass }, body)) });
  const j = await r.json(); if (!j.ok) throw new Error(j.error === 'auth' ? '合言葉が違います' : j.error || 'エラー'); return j;
}

/* ---------- loading ---------- */
let rebuildT = null;
function rebuild() { clearTimeout(rebuildT); rebuildT = setTimeout(() => { const t0 = performance.now(); EK.NAMES = (st.idx && st.idx.en) || {}; st.M = EK.build(st.dbs); st.M.pf = {}; st.buildMs = Math.round(performance.now() - t0); st.cache = {}; render(); }, 30); }
async function boot() {
  const keys = await IDB.keys();
  for (const k of keys) { if (!/^db:/.test(k)) continue; const d = await IDB.get(k); if (d && d.E) st.dbs[d.key] = d; }
  // the 2026 season results ship with the app, so it is useful before the data source is connected
  Object.values(window.EKD_SEED || {}).forEach(d => { const have = st.dbs[d.key]; if (!have || (have.E || []).length < d.E.length) st.dbs[d.key] = d; });
  EK.NAMES = (st.idx && st.idx.en) || {};
  st.M = EK.build(st.dbs); st.M.pf = {};
  route(); render();
  refresh();
}
async function refresh(force) {
  const c = cfg(); if (!c.url) return;
  st.loading++; render();
  try {
    const idx = await gasGet({});
    if (idx && idx.series) { st.idx = idx; lsSet(LS.idx, idx); st.err = ''; }
    const need = (idx.series || []).filter(s => s.ver && (!st.dbs[s.key] || String(st.dbs[s.key].ver) !== String(s.ver) || force));
    for (const s of need) {
      try { const d = await gasGet({ v: 'db', s: s.key, ver: force ? '' : (st.dbs[s.key] || {}).ver }); if (d && d.E) { st.dbs[s.key] = d; await IDB.set('db:' + s.key, d); } }
      catch (e) { st.err = s.name + ': ' + e.message; }
    }
    const namesChanged = JSON.stringify(idx.en || {}) !== JSON.stringify(EK.NAMES || {});
    if (need.length || namesChanged) rebuild();
  } catch (e) { st.err = '読み込めませんでした: ' + e.message; }
  st.loading--; render();
  watchLive();
}
let liveT = null;
/* while a race is on: the index every 30 s (it carries the 月陸 lines), the race data whenever it changed */
function watchLive() {
  clearTimeout(liveT);
  const on = st.idx && ((st.idx.live && st.idx.live.active) || (st.idx.racing || []).length); if (!on || !cfg().url) return;
  liveT = setTimeout(() => { if (document.visibilityState === 'visible') refresh(); else watchLive(); }, 30e3);
}
const P = id => { const M = st.M; if (!M.pf[id]) M.pf[id] = EK.profile(M, id); return M.pf[id]; };
const memo = (k, fn) => { if (!(k in st.cache)) st.cache[k] = fn(); return st.cache[k]; };

/* ---------- small helpers ---------- */
const SER = () => st.M.series;
const SNAME = { hakone: '箱根駅伝', izumo: '出雲駅伝', zen: '全日本大学駅伝', yosen: '箱根駅伝予選会', zsel: '全日本 関東選考会', morinomiya: '杜の都駅伝', fujisan: '富士山女子駅伝', kwj: '関東大学女子駅伝', oga: '男鹿駅伝',
  tokai: '東海学生駅伝', kansai: '丹後大学駅伝', kyushu: '九州学生駅伝', hokushinetsu: '北信越学生駅伝', chushikoku: '中国四国学生駅伝', tohoku: '東北学生駅伝', hokkaido: '北海道学生駅伝' };
const sName = k => (SER()[k] || {}).name || SNAME[k] || (((st.idx && st.idx.series) || []).find(x => x.key === k) || {}).name || '大会';
const sShort = k => sName(k).replace(/駅伝$/, '').replace(/^全日本大学$/, '全日本').replace('箱根予選会', '予選会');
const JOB = { hs: '測定点別成績（箱根）', er: 'ekiden-results.com', splits: '定点（月陸）', backfill: 'ほぼニート（過去）', live: '速報', hkIndex: '箱根の大会一覧', hakone: '箱根の公式記録', news: 'ニュース', wiki: 'Wikipedia', build: 'データの作成' };
const nm = r => { const P = st.M.runners[r.p]; return P ? P.dn || P.nm : r.nm; };
const EVN = { '5000m': '5000m', '10000m': '10000m', half: 'ハーフ', '3000msc': '3000mSC' };
const md = d => { const x = new Date(d); return (x.getMonth() + 1) + '/' + x.getDate(); };
const partLabel = r => r.track ? `${EVN[r.ev] || r.ev} ${F(r.t)}${r.t % 1 ? '.' + String(Math.round(r.t % 1 * 100)).padStart(2, '0') : ''}` : r.leg ? `${sShort(r.s)}${r.leg}区` : `${sShort(r.s)}`;
const hurtTag = c => c && c.injured ? ` <span class="tag hurt" title="${esc(c.last.note || '')}">${c.last.kind === 'absent' ? '欠場' : 'ケガ'}</span>` : '';
const formWhy = f => f.parts.slice(0, 2).map(p => `${partLabel(p.r)}（${md(p.r.d)}）`).join('・');
const enIf = n => { const e = EK.en(n); return e ? e.name : n; };
const nmGuess = r => { const P = st.M.runners[r.p]; return !!(P && P.dnGuess); };
const GROUPS = [['男子', ['hakone', 'izumo', 'zen', 'yosen', 'zsel', 'oga']], ['女子', ['morinomiya', 'fujisan', 'kwj']], ['地区学連', ['hokkaido', 'tohoku', 'hokushinetsu', 'tokai', 'kansai', 'chushikoku', 'kyushu']]];
const allSeries = () => { const idx = (st.idx && st.idx.series) || []; const keys = new Set(Object.keys(SER()).concat(idx.map(s => s.key)).filter(k => k !== 'track')); return GROUPS.map(([g, ks]) => [g, ks.filter(k => keys.has(k))]).filter(x => x[1].length); };
const sMeta = k => ((st.idx && st.idx.series) || []).find(s => s.key === k) || { key: k, name: sName(k) };
const dev = d => d == null ? '<span class="mute">—</span>' : `<span class="dv ${d >= 65 ? 'd5' : d >= 58 ? 'd4' : d >= 50 ? 'd3' : d >= 42 ? 'd2' : 'd1'}">${d.toFixed(1)}</span>`;
const gr = r => r.g ? `<span class="gr${r.gi ? ' gi' : ''}" title="${r.y}年の大会のときの学年${r.gi ? '（入学年から推定）' : ''}">${r.g > 4 ? 'M' + (r.g - 4) : r.g}</span>` : '';
const mv = r => { if (!r.pcr || !r.cr) return ''; const d = r.pcr - r.cr; return d > 0 ? `<span class="up">↑${d}</span>` : d < 0 ? `<span class="dn">↓${-d}</span>` : '<span class="mute">→</span>'; };
const fmtD = s => { if (!s) return ''; const d = new Date(s); return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`; };
const ago = ms => { const m = Math.round((Date.now() - ms) / 6e4); if (m < 1) return 'たった今'; if (m < 60) return m + '分前'; const h = Math.round(m / 60); if (h < 24) return h + '時間前'; return Math.round(h / 24) + '日前'; };
const rlink = (r, txt) => `<a class="rn${!txt && nmGuess(r) ? ' en' : ''}" href="#runner/${encodeURIComponent(r.p)}"${!txt && nmGuess(r) ? ` title="${esc(st.M.runners[r.p].kana)}（カタカナから変換）"` : ''}>${esc(txt || nm(r))}</a>`;
const ulink = (u, short) => `<a class="un" href="#univ/${encodeURIComponent(u)}">${esc(short ? S(u) : u)}</a>`;
const sec = (t, sub, right) => `<div class="sh"><h2>${esc(t)}</h2>${sub ? `<span class="sub">${esc(sub)}</span>` : ''}${right || ''}</div>`;
const chips = (items, cur, attr) => `<div class="chips">${items.map(([k, n]) => `<button class="chip ${String(k) === String(cur) ? 'on' : ''}" data-${attr}="${esc(k)}">${esc(n)}</button>`).join('')}</div>`;
const empty = t => `<p class="empty">${esc(t)}</p>`;
const ord = n => n ? n + '位' : '—';
const seriesChips = (cur, attr, filter) => allSeries().map(([g, ks]) => { ks = ks.filter(k => !filter || filter(k)); return ks.length ? `<div class="cg"><span class="cgl">${g}</span>${chips(ks.map(k => [k, sName(k)]), cur, attr)}</div>` : ''; }).join('');

/* ---------- charts (inline SVG) ---------- */
const PAL = ['#d63b22', '#e08a00', '#2563d9', '#16884f', '#8b3fd9', '#d6337f', '#0e9fb3', '#7a8a00', '#b4581a', '#5b6b85'];
function bumpChart(ed, hl) {
  const B = ed.bump.filter(b => b.ranks.some(x => x)); if (!B.length || ed.legs.length < 2) return '';
  const n = ed.legs.length, maxR = Math.max(...B.flatMap(b => b.ranks.filter(Boolean))), W = 360, H = Math.max(180, maxR * 13 + 30), pl = 8, pr = 64, pt = 16, pb = 18;
  const X = i => pl + i * (W - pl - pr) / (n - 1), Y = r => pt + (r - 1) * (H - pt - pb) / Math.max(1, maxR - 1);
  const top = B.slice().sort((a, b) => (a.ranks[n - 1] || 99) - (b.ranks[n - 1] || 99));
  const color = {}; top.slice(0, 10).forEach((b, i) => { color[b.u] = PAL[i]; });
  const lines = top.slice().reverse().map(b => {
    const pts = b.ranks.map((r, i) => r ? [X(i), Y(r)] : null), c = hl ? (b.u === hl ? '#d63b22' : '#d5d9de') : (color[b.u] || '#d5d9de'), w = hl ? (b.u === hl ? 3 : 1.2) : color[b.u] ? 2 : 1.2;
    let d = ''; pts.forEach((p, i) => { if (!p) return; d += (d && pts[i - 1] ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); });
    const last = pts.filter(Boolean).pop();
    return `<path d="${d}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linejoin="round"/>` + (last && (color[b.u] || b.u === hl) ? `<text x="${last[0] + 5}" y="${last[1] + 3.5}" class="cl" fill="${c}">${esc(S(b.u))}</text>` : '');
  }).join('');
  const ax = ed.legs.map((_, i) => `<text x="${X(i)}" y="${H - 4}" class="ca" text-anchor="middle">${i + 1}</text>`).join('');
  return `<figure class="ch"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="順位の推移">${[1, 5, 10, 15, 20].filter(r => r <= maxR).map(r => `<line x1="${pl}" x2="${W - pr}" y1="${Y(r)}" y2="${Y(r)}" class="gl"/>`).join('')}${lines}${ax}</svg><figcaption>区間ごとの通過順位（区間タイムの累計から計算）</figcaption></figure>`;
}
function devChart(runs) {
  const R = runs.filter(r => r.dev != null); if (R.length < 2) return '';
  const W = 360, H = 150, pl = 26, pr = 8, pt = 10, pb = 22, t0 = R[0].d, t1 = R[R.length - 1].d || t0 + 1;
  const lo = Math.min(35, ...R.map(r => r.dev)) - 2, hi = Math.max(70, ...R.map(r => r.dev)) + 2;
  const X = d => pl + (t1 === t0 ? 0.5 : (d - t0) / (t1 - t0)) * (W - pl - pr), Y = v => pt + (hi - v) / (hi - lo) * (H - pt - pb);
  const col = { hakone: '#d63b22', izumo: '#2563d9', zen: '#e08a00', yosen: '#16884f' };
  const path = R.map((r, i) => (i ? 'L' : 'M') + X(r.d).toFixed(1) + ' ' + Y(r.dev).toFixed(1)).join('');
  const yrs = []; for (let y = new Date(t0).getFullYear() + 1; y <= new Date(t1).getFullYear(); y++) yrs.push(y);
  return `<figure class="ch"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="区間偏差値の推移">${[40, 50, 60, 70].filter(v => v > lo && v < hi).map(v => `<line x1="${pl}" x2="${W - pr}" y1="${Y(v)}" y2="${Y(v)}" class="gl${v === 50 ? ' g50' : ''}"/><text x="${pl - 4}" y="${Y(v) + 3}" class="ca" text-anchor="end">${v}</text>`).join('')}
    ${yrs.map(y => { const x = X(Date.UTC(y, 0, 1)); return x > pl && x < W - pr ? `<text x="${x}" y="${H - 6}" class="ca" text-anchor="middle">${y}</text>` : ''; }).join('')}
    <path d="${path}" fill="none" stroke="#c3c8cf" stroke-width="1.2"/>${R.map(r => `<circle cx="${X(r.d).toFixed(1)}" cy="${Y(r.dev).toFixed(1)}" r="${r.award ? 5 : 3.6}" fill="${col[r.s] || '#8b3fd9'}" stroke="${r.award ? '#c99a1e' : '#fff'}" stroke-width="2"><title>${esc(sName(r.s) + ' ' + (r.leg ? r.leg + '区' : '個人') + ' ' + r.dev.toFixed(1))}</title></circle>`).join('')}</svg>
    <figcaption>${Object.keys(col).filter(k => R.some(r => r.s === k)).map(k => `<i style="background:${col[k]}"></i>${sName(k)}`).join(' ')}${R.some(r => !col[r.s]) ? ' <i style="background:#8b3fd9"></i>そのほか' : ''} ・ 金の縁は区間賞</figcaption></figure>`;
}
function barList(items, o) {
  o = o || {}; if (!items.length) return '';
  const lo = o.lo != null ? o.lo : 30, hi = o.hi != null ? o.hi : 75;
  return `<div class="bars">${items.map(x => { const w = Math.max(2, Math.min(100, (x.v - lo) / (hi - lo) * 100)); return `<div class="br"><span class="bl">${esc(x.k)}</span><span class="bt"><span class="bf ${x.v >= 58 ? 'hi' : x.v < 45 ? 'lo' : ''}" style="width:${w}%"></span><span class="b50" style="left:${(50 - lo) / (hi - lo) * 100}%"></span></span><span class="bv">${x.v.toFixed(1)}<small>${x.n ? ' ×' + x.n : ''}</small></span></div>`; }).join('')}</div>`;
}
function rankHistory(hist) {
  const H0 = hist.filter(h => h.rank); if (H0.length < 2) return '';
  const W = 360, Hh = 140, pl = 24, pr = 8, pt = 10, pb = 22, n0 = H0[0].n, n1 = H0[H0.length - 1].n, maxR = Math.max(10, ...H0.map(h => h.rank));
  const X = n => pl + (n1 === n0 ? 0.5 : (n - n0) / (n1 - n0)) * (W - pl - pr), Y = r => pt + (r - 1) / (maxR - 1) * (Hh - pt - pb);
  let d = '', prev = null; H0.forEach(h => { d += (prev != null && h.n - prev <= 1 ? 'L' : 'M') + X(h.n).toFixed(1) + ' ' + Y(h.rank).toFixed(1); prev = h.n; });
  return `<figure class="ch"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="順位の推移">${[1, 10, 20].filter(r => r <= maxR).map(r => `<line x1="${pl}" x2="${W - pr}" y1="${Y(r)}" y2="${Y(r)}" class="gl${r === 10 ? ' g50' : ''}"/><text x="${pl - 4}" y="${Y(r) + 3}" class="ca" text-anchor="end">${r}</text>`).join('')}
    <path d="${d}" fill="none" stroke="#d63b22" stroke-width="1.8"/>${H0.map(h => `<circle cx="${X(h.n).toFixed(1)}" cy="${Y(h.rank).toFixed(1)}" r="${h.rank === 1 ? 3.6 : 2.2}" fill="${h.rank === 1 ? '#c99a1e' : '#d63b22'}"><title>第${h.n}回 ${h.rank}位</title></circle>`).join('')}
    <text x="${pl}" y="${Hh - 6}" class="ca">第${n0}回</text><text x="${W - pr}" y="${Hh - 6}" class="ca" text-anchor="end">第${n1}回</text></svg><figcaption>総合順位（点線の10位までがシード圏）</figcaption></figure>`;
}

/* ---------- views ---------- */
function setupPanel() { return `<section class="card note-card"><b>データの取得先をつなぐと、箱根の第1回からの全データ・速報・ニュースが入ります</b><p>今は 2025-26 年度の箱根・出雲・全日本・予選会の結果だけを内蔵しています。</p><a class="btn" href="#settings">設定を開く</a></section>`; }
function homeView() {
  const M = st.M, idx = st.idx || {}, c = cfg();
  let h = '';
  if (!c.url) h += setupPanel();
  if (installEv && !standalone) h += `<section class="card note-card"><b>EKDNist をアプリとして入れる</b><div class="row"><button class="btn" data-act="install">インストール</button></div></section>`;
  (idx.racing || []).forEach(x => { const e = (SER()[x.s] || { E: [] }).E.find(z => z.n === x.n); h += racingCard(x, e); });
  if (idx.live) h += liveBlock(idx.live, true);
  if ((idx.cal || []).length) h += sec('次の大会') + `<div class="cal">${idx.cal.slice(0, 4).map(x => { const days = Math.ceil((Date.parse(x.d) - Date.now()) / 864e5); return `<div class="cd"><b>${esc(sName(x.s))}</b><span>${x.d.slice(5).replace('-', '/')}</span><em>${days <= 0 ? '今日' : 'あと' + days + '日'}</em>${x.note ? `<small>${esc(x.note)}</small>` : ''}</div>`; }).join('')}</div>`;
  // latest results across series
  const latest = Object.values(M.series).flatMap(db => db.E.filter(e => e.T && e.T.length).map(e => ({ db, e }))).sort((a, b) => b.e.dms - a.e.dms).slice(0, 4);
  if (latest.length) h += sec('最近の結果') + latest.map(({ db, e }) => { const T = e.T.filter(t => t[1]).sort((a, b) => a[1] - b[1]).slice(0, 3); return `<a class="card res" href="#race/${db.key}/${e.n}"><div class="rh"><b>${esc(db.name)}</b><span>第${e.n}回 ・ ${esc(fmtD(e.d))}</span></div><ol>${T.map(t => `<li><span class="rk">${t[1]}</span>${esc(db.U[t[0]])}<span class="tm">${F(t[2])}</span></li>`).join('')}</ol></a>`; }).join('');
  // the aces right now: track times and this season's races, newest weigh most
  const aces = memo('aces', () => EK.aces(M, { women: false, limit: 10 }));
  if (aces.length) h += sec('今のエース', '直近のトラック記録と今季のレースから見た「今の調子」（偏差値）', '<a class="more" href="#runner">もっと見る</a>') + `<div class="tw"><table class="t"><tr><th></th><th>選手</th><th>大学</th><th>調子</th><th>主な根拠</th></tr>${aces.map((x, i) => `<tr><td class="rk">${i + 1}</td><td><a class="rn" href="#runner/${encodeURIComponent(x.p)}">${esc(x.P.dn || x.P.nm)}</a>${hurtTag(x.cond)}</td><td>${ulink(x.P.u, 1)}</td><td>${dev(x.f.val)}</td><td class="mute">${esc(formWhy(x.f))}</td></tr>`).join('')}</table></div>`;
  const fld = memo('field', () => EK.hakoneField(M));
  if (fld && fld.teams.length) h += sec(`箱根駅伝 第${fld.next}回 予想`, '今の戦力で最適な区間配置をしたときの総合タイム', '<a class="more" href="#predict">全チーム</a>') + `<div class="tw"><table class="t">${fld.teams.slice(0, 5).map((T, i) => `<tr><td class="rk">${i + 1}</td><td>${ulink(T.univ)}</td><td class="tm">${F(T.total)}</td><td class="mute">${i ? '+' + F(T.total - fld.teams[0].total) : ''}</td></tr>`).join('')}</table></div>`;
  const news = (idx.news || []).slice(0, 6);
  if (news.length) h += sec('ニュース', '', '<a class="more" href="#news">すべて</a>') + newsList(news);
  if (idx.crawl && idx.crawl.hakone && idx.crawl.hakone.total && idx.crawl.hakone.done < idx.crawl.hakone.total) { const k = idx.crawl.hakone; h += `<p class="note">箱根駅伝の公式記録を取り込み中: ${k.done} / ${k.total} 大会${k.cur ? `（第${k.cur}回を読んでいます）` : ''}。新しい大会から順に入ります。</p>`; }
  return h + errHtml();
}
function racingCard(x, e) {
  const ed = e && memo('ed' + x.s + x.n, () => EK.edition(st.M, x.s, x.n));
  const lastLeg = ed && ed.legs.length, lead = ed && lastLeg ? ed.legs[lastLeg - 1].filter(r => r.cr && !r.op).sort((a, b) => a.cr - b.cr).slice(0, 5) : [];
  return `<a class="card live" href="#race/${x.s}/${x.n}"><div class="lh"><span class="dot"></span><b>${esc(sName(x.s))} 第${x.n}回</b><span class="sub">${lastLeg ? lastLeg + '区まで' : '開始待ち'}</span></div>
    ${lead.length ? `<ol class="lead">${lead.map(r => `<li><span class="rk">${r.cr}</span>${esc(S(r.u))}<span class="tm">${F(ed.e._cum && ed.e._cum[ed.db.U.indexOf(r.u)] ? ed.e._cum[ed.db.U.indexOf(r.u)].t : null)}</span></li>`).join('')}</ol>` : ''}<p class="src">区間ごとの記録: ほぼニートの資格取得日記（${idxAgo()}に確認）</p></a>`;
}
function idxAgo() { return st.idx && st.idx.updated ? ago(st.idx.updated) : '—'; }
function liveBlock(L, compact) {
  const legs = (L.legs || []).slice().sort((a, b) => b.leg - a.leg);
  if (!legs.length) return `<section class="card live"><div class="lh"><span class="dot"></span><b>${esc(L.title || '速報')}</b></div><p class="note">まだ記事に行がありません。</p></section>`;
  const cur = legs[0], lines = compact ? cur.lines.slice(0, 5) : null;
  return `<section class="card live"><div class="lh"><span class="dot${L.active ? '' : ' off'}"></span><b>${esc(String(L.title || '').replace(/【テキスト速報】/, ''))}</b><span class="sub">${L.at ? ago(L.at) : ''}</span></div>
    ${(L.winners || []).length ? `<div class="lw">${L.winners.slice().sort((a, b) => a.leg - b.leg).map(w => `<span>${w.leg}区 <b>${esc(enIf(w.nm))}</b>（${esc(S(w.u))}）${F(w.t)}${w.rec ? ' <em class="new">区間新</em>' : ''}</span>`).join('')}</div>` : ''}
    ${compact ? `<h4>${cur.leg}区 ${esc(cur.label || '')}${cur.km ? `（${cur.km}km）` : ''}</h4><ul class="ll">${lines.map(l => `<li><span>${l.km != null ? l.km + 'km' : ''}</span>${esc(l.text)}</li>`).join('')}</ul><a class="more" href="#live">すべての行</a>`
      : legs.map(g => `<h4>${g.leg}区 ${esc(g.label || '')}${g.km ? `（${g.km}km）` : ''}</h4><ul class="ll">${g.lines.map(l => `<li><span>${l.km != null ? l.km + 'km' : ''}</span>${esc(l.text)}</li>`).join('')}</ul>`).join('')}
    <p class="src">出典: <a href="${esc(L.url)}" target="_blank" rel="noopener">月陸Online テキスト速報</a>（速報値）</p></section>`;
}
function liveView() { const L = st.idx && (st.idx.live || null); return L ? liveBlock(L, false) : empty('いま行われている大会の速報はありません。レース当日は自動で表示されます。'); }

function raceListView() {
  const k = st.ui.es, db = SER()[k];
  let h = seriesChips(k, 'es');
  if (!db || !db.E.length) {
    const W = db ? EK.winners(st.M, k) : [];
    return h + (W.length ? winnersTable(k, W) : empty('この大会のデータはまだありません。設定 →「URLから取り込む」か、司書（定期タスク）が集めます。'));
  }
  const W = EK.winners(st.M, k), eds = {}; db.E.forEach(e => { eds[e.n] = e; });
  const rows = W.length ? W : db.E.slice().reverse().map(e => ({ n: e.n, y: e.y }));
  h += `<div class="tw"><table class="t eds"><tr><th>回</th><th>年</th><th>優勝</th><th>タイム</th><th>データ</th></tr>${rows.map(w => { const e = eds[w.n], stt = e ? (e.L ? '全区間' : e.I ? '個人まで' : e.T ? '総合' : '') : ''; return `<tr${e ? ` data-go="race/${k}/${w.n}"` : ''} class="${e ? 'lnk' : ''}"><td>${w.n}</td><td class="mute">${w.y || ''}</td><td>${w.cancel ? '<span class="mute">中止</span>' : w.u ? esc(w.u) : '<span class="mute">—</span>'}</td><td class="tm">${F(w.t)}</td><td>${stt ? `<span class="tag ${e.st === 'live' ? 'live' : e.L || e.I ? 'full' : ''}">${stt}</span>` : ''}</td></tr>`; }).join('')}</table></div>`;
  return h;
}
const HK_FIN = ['鶴見中継所', '戸塚中継所', '平塚中継所', '小田原中継所', '芦ノ湖（往路ゴール）', '小田原中継所', '平塚中継所', '戸塚中継所', '鶴見中継所', '大手町（復路ゴール）'];
const HK_START = ['大手町（往路スタート）', '鶴見中継所', '戸塚中継所', '平塚中継所', '小田原中継所', '芦ノ湖（復路スタート）', '小田原中継所', '平塚中継所', '戸塚中継所', '鶴見中継所'];
const finName = (k, L) => k === 'hakone' ? HK_FIN[L - 1] : L === ((SER()[k] || {}).legs || 0) ? 'フィニッシュ' : '中継所';
const startName = (k, L) => k === 'hakone' ? HK_START[L - 1] : L === 1 ? 'スタート' : '中継所';
const segName = (x, k, L) => `${x.from ? x.fromL || x.from + 'km' : startName(k, L)} → ${x.fin ? finName(k, L) : x.toL || x.to + 'km'}（${(x.to - x.from).toFixed(1)}km）${x.old ? '・旧コース' : ''}`;
function segRanking(g, k, L) {
  let list = g.list; if (st.ui.runi) { const seen = {}; list = list.filter(x => { if (seen[x.r.p]) return false; seen[x.r.p] = 1; return true; }); }
  const dist = g.to - g.from;
  return sec('歴代ランキング', `${L}区 ${segName(g, k, L)} ・ ${g.list.length}件`) +
    `<div class="tw"><table class="t legt"><tr><th></th><th>選手</th><th>大学</th><th>タイム</th><th>大会</th></tr>${list.slice(0, 100).map((x, i) => `<tr class="${x.r.award ? 'aw' : ''}"><td class="rk">${i + 1}</td><td>${rlink(x.r)}${gr(x.r)}</td><td>${ulink(x.r.u, 1)}</td><td class="tm">${F(x.t)}<small>${EK.pace(x.t / dist)}</small>${x.est ? '<small class="est">推定</small>' : ''}</td><td class="mute"><a href="#race/${k}/${x.r.n}">第${x.r.n}回</a> ${x.r.y} ・ 区間${x.r.op ? 'OP' : (x.r.lr || '') + '位'}</td></tr>`).join('')}</table></div>`;
}
const kmLabel = (km, label) => label ? `${label} ${km}km` : km + 'km';
const kmL = (km, label) => label ? `${esc(label)}<small class="mute"> ${km}km</small>` : km + 'km';
function segTable(r) {
  const SG = EK.segments(r); if (!SG.length) return '';
  return `<div class="tw"><table class="t seg"><tr><th>区切り</th><th>通過</th><th>この区切り</th><th>ペース</th></tr>${SG.map(x => `<tr><td>${x.from ? x.from + 'km' : 'スタート'} → ${x.fin ? 'フィニッシュ' : kmL(x.to, x.toL)}</td><td class="tm s">${F(x.at)}</td><td class="tm s">${F(x.t)}<small>${(x.to - x.from).toFixed(1)}km</small></td><td class="tm s">${EK.pace(x.pace)}</td></tr>`).join('')}</table></div>`;
}
function splitSection(s, n, leg) {
  const SP = st.M.splits.filter(x => x.s === s && x.n === n && x.leg === leg); if (!SP.length) return '';
  const lead = SP.filter(x => !x.r), runs = Array.from(new Set(SP.filter(x => x.r).map(x => x.r)));
  let h = sec('定点', s === 'hakone' ? '測定点別成績から。上が通過タイム（その地点での順位）、下は前の地点からのタイム' : '月陸Online のテキスト速報に出た通過タイム。区切りごとのタイムとペースは、そこから計算');
  if (runs.length >= 5) {
    const P = []; SP.filter(x => x.r).forEach(x => { if (!P.some(p => p.km === x.km && p.label === x.label)) P.push({ km: x.km, label: x.label }); }); P.sort((a, b) => a.km - b.km);
    const fin = runs[0].km;
    runs.sort((a, b) => (a.op ? 999 : a.lr || 998) - (b.op ? 999 : b.lr || 998) || a.t - b.t);
    h += `<div class="tw"><table class="t legt spm"><tr><th>選手</th>${P.map(p => `<th>${esc(p.label || '')}<small>${p.km}km</small></th>`).join('')}<th>${esc(finName(s, leg))}<small>${fin ? fin + 'km' : ''}</small></th></tr>${runs.map(r => { let prev = null; const cells = P.map(p => { const x = r.splits.find(y => y.km === p.km && y.label === p.label); if (!x) return '<td></td>'; const c = `<td class="tm s">${F(x.t)}${x.rk ? `<span class="mute">(${x.rk})</span>` : ''}<small>${prev != null ? '+' + F(x.t - prev) : ''}</small></td>`; prev = x.t; return c; }).join(''); return `<tr><td>${rlink(r)}${gr(r)}<small class="mute">${esc(S(r.u))}</small></td>${cells}<td class="tm s">${F(r.t)}<span class="mute">(${r.op ? 'OP' : r.lr || ''})</span><small>${prev != null ? '+' + F(r.t - prev) : ''}</small></td></tr>`; }).join('')}</table></div>`;
  } else runs.forEach(r => { h += `<p class="segh">${rlink(r)}${gr(r)} <span class="mute">${esc(S(r.u))}</span> <b class="tm">${F(r.t)}</b></p>` + segTable(r); });
  if (lead.length) h += `<p class="segh">先頭集団</p><div class="tw"><table class="t">${lead.sort((a, b) => a.km - b.km).map(x => `<tr><td>${kmL(x.km, x.label)}</td><td class="tm s">${F(x.t)}</td><td class="tm s">${EK.pace(x.t / x.km)}</td></tr>`).join('')}</table></div>`;
  return h;
}
function winnersTable(k, W) { return `<div class="tw"><table class="t"><tr><th>回</th><th>年</th><th>優勝</th><th>タイム</th></tr>${W.map(w => `<tr><td>${w.n}</td><td class="mute">${w.y || ''}</td><td>${w.cancel ? '<span class="mute">中止</span>' : esc(w.u || '—')}</td><td class="tm">${F(w.t)}</td></tr>`).join('')}</table></div>`; }
function raceView(k, n) {
  n = +n; const ed = memo('ed' + k + n, () => EK.edition(st.M, k, n));
  if (!ed) return empty('この大会のデータはありません');
  const db = ed.db, e = ed.e, top = ed.teams.find(t => t.rank === 1), hk = k === 'hakone';
  let h = `<div class="ph"><a class="back" href="#race">‹ 大会</a><h1>${esc(db.name)} <span>第${n}回</span>${e.st === 'live' ? ' <span class="tag live">速報中</span>' : ''}</h1><p class="mute">${esc(fmtD(e.d) || e.y)}${e.dist ? ` ・ ${e.dist.length}区間 ${e.dist.reduce((a, b) => a + b, 0).toFixed(1)}km` : ''}</p></div>`;
  if (ed.teams.length) {
    h += sec(k === 'yosen' ? 'チーム順位' : '総合順位', k === 'yosen' ? '上位10人の合計タイム・10位までが本戦へ' : '') + `<div class="tw"><table class="t"><tr><th></th><th>大学</th><th>総合</th>${hk ? '<th>往路</th><th>復路</th>' : ''}<th>差</th></tr>${ed.teams.map(t => `<tr class="${k === 'yosen' && t.rank && t.rank <= 10 ? 'pass' : ''}${hk && t.rank === 10 ? ' seedline' : ''}"><td class="rk">${t.op ? '<span class="mute">OP</span>' : t.rank || ''}</td><td>${ulink(t.u)}</td><td class="tm">${F(t.t)}</td>${hk ? `<td class="tm s">${F(t.out)}</td><td class="tm s">${F(t.ret)}</td>` : ''}<td class="mute tm s">${top && t.t && t !== top ? '+' + F(t.t - top.t) : ''}</td></tr>`).join('')}</table></div>`;
  }
  if (ed.legs.length) {
    h += bumpChart(ed);
    const L = Math.min(st.ui.eleg || 1, ed.legs.length);
    h += sec('区間成績') + chips(ed.legs.map((_, i) => [i + 1, (i + 1) + '区']), L, 'eleg');
    const runs = ed.legs[L - 1], S0 = ed.stats[L - 1], km = runs[0] && runs[0].km;
    h += `<p class="note">${km ? km + 'km ・ ' : ''}${S0 ? `平均 ${F(S0.mean)} ・ 区間賞との差の中央値 +${F(S0.med - S0.best)}` : ''}${!runs[0] || runs[0].cmp ? '' : ' ・ 現行コースより前の大会'}</p>`;
    h += `<div class="tw"><table class="t legt"><tr><th></th><th>選手</th><th>大学</th><th>タイム</th><th>偏差値</th><th>通過</th></tr>${runs.map(r => `<tr class="${r.award ? 'aw' : ''}"><td class="rk">${r.op ? '<span class="mute">OP</span>' : r.lr || ''}</td><td>${rlink(r)}${gr(r)}</td><td>${ulink(r.u, 1)}</td><td class="tm">${F(r.t)}${r.pace ? `<small>${EK.pace(r.pace)}</small>` : ''}</td><td>${dev(r.dev)}</td><td class="tm s">${r.op ? '' : (r.cr || '') + ' ' + mv(r)}</td></tr>`).join('')}</table></div>`;
    h += splitSection(k, n, L);
    const aw = ed.legs.map((rs, i) => ({ leg: i + 1, r: rs.filter(r => r.lr === 1 && !r.op) }));
    h += sec('区間賞') + `<div class="tw"><table class="t">${aw.map(a => a.r.map(r => `<tr><td>${a.leg}区</td><td>${rlink(r)}${gr(r)}</td><td>${ulink(r.u, 1)}</td><td class="tm">${F(r.t)}</td><td>${dev(r.dev)}</td></tr>`).join('')).join('')}</table></div>`;
  }
  if (ed.awards.length) h += sec('区間賞') + `<div class="tw"><table class="t">${ed.awards.sort((a, b) => a.leg - b.leg).map(r => `<tr><td>${r.leg}区${r.km ? `<small class="mute"> ${r.km}km</small>` : ''}</td><td>${rlink(r)}${gr(r)}</td><td>${ulink(r.u, 1)}</td><td class="tm">${F(r.t)}${r.rec ? ' <em class="new">区間新</em>' : ''}</td></tr>`).join('')}</table></div><p class="note">この大会は総合順位と区間賞のみです。全区間の記録が入ると、ここに全選手が並びます。</p>`;
  if (ed.indiv.length) h += sec('個人成績', `${ed.indiv.length}人`) + `<div class="tw"><table class="t"><tr><th></th><th>選手</th><th>大学</th><th>タイム</th><th>偏差値</th></tr>${ed.indiv.map(r => `<tr><td class="rk">${r.lr}</td><td>${rlink(r)}${gr(r)}</td><td>${ulink(r.u, 1)}</td><td class="tm">${F(r.t)}</td><td>${dev(r.dev)}</td></tr>`).join('')}</table></div>`;
  if ((e.src || []).length) h += `<p class="src">出典: ${e.src.map(u => `<a href="${esc(u)}" target="_blank" rel="noopener">${esc(SRC_NAME(u))}</a>`).join(' ・ ')}</p>`;
  return h;
}

function recordsView() {
  const k = st.ui.rs, db = SER()[k], M = st.M;
  let h = seriesChips(k, 'rs');
  const modes = [['leg', '区間'], ['grade', '学年別'], ['total', '総合'], ['wins', '優勝'], ['award', '区間賞'], ['rec', '区間記録']];
  if (st.ui.rmode === 'split') st.ui.rmode = 'leg';   // 定点は「区間」の中（地点から地点まで）に移した
  h += chips(modes, st.ui.rmode, 'rmode');
  if (!db) return h + empty('この大会のデータはまだありません');
  const m = st.ui.rmode;
  if (m === 'leg' || m === 'grade') {
    if (!db.legs) {
      const all = M.runs.filter(r => r.s === k && r.leg === 0 && r.t).sort((a, b) => a.t - b.t).slice(0, 50);
      return h + sec('個人タイム 歴代ランキング', '取り込み済みの大会から') + rankTable(all, true);
    }
    const L = Math.min(st.ui.rleg, db.legs);
    h += chips(Array.from({ length: db.legs }, (_, i) => [i + 1, (i + 1) + '区']), L, 'rleg');
    if (m === 'leg') {   // 定点間: 「スタート → 蒲田（15.2km）」「蒲田 → 鶴見中継所（6.1km）」
      const SG = memo(`sg${k}${L}`, () => { const A = EK.segAll(M, k, L); if (A) return A.groups; const G = EK.segBests(M, k, L), since = EK.since(M, k, L); G.forEach(x => { x.old = since > 1 && Math.max(...x.list.map(y => y.r.n)) < since; }); return G; });
      if (SG.length) {
        const g = SG.find(x => x.key === st.ui.rseg);
        h += `<p class="note" style="margin:6px 0 2px">定点間（地点から地点まで）</p>${chips([['', '区間全体']].concat(SG.map(x => [x.key, segName(x, k, L)])), g ? g.key : '', 'rseg')}`;
        if (g) return h + `<div class="opts"><label><input type="checkbox" data-opt="runi" ${st.ui.runi ? 'checked' : ''}> 1人1記録</label></div>` + segRanking(g, k, L) + `<p class="note">${k === 'hakone' ? '「箱根駅伝・区間・測定点別成績」（hakonesaijo.sakura.ne.jp）' : '月陸Online のテキスト速報'}の通過タイムから計算。区切りは今の定点。測っていた地点が今と違う年の選手は、前後の実測の地点のあいだを「その区間で何km地点なら区間タイムの何割か」（新しい大会の選手の平均。坂でのペースの変化も入る）で割り振って、今の定点の通過タイムに直しています（右下に「推定」）。区間のコースそのものが今と違う大会は、地点が対応しないので入りません。</p>`;
      }
    }
    const eras = EK.eras(M, k, L), cur = eras[0];
    h += `<div class="opts"><label><input type="checkbox" data-opt="runi" ${st.ui.runi ? 'checked' : ''}> 1人1記録</label></div>`;
    if (m === 'grade') h += chips([[1, '1年'], [2, '2年'], [3, '3年'], [4, '4年']], st.ui.rg || 1, 'rg');
    const g = m === 'grade' ? (st.ui.rg || 1) : 0;
    const rows = memo(`rk${k}${L}${st.ui.runi}${g}`, () => EK.legRanking(M, k, L, { conv: true, unique: st.ui.runi, g, limit: 100 }));
    h += sec(`${L}区 歴代${g ? ' ' + g + '年生' : ''}ランキング`, `全期間${cur && cur.km ? '・' + cur.label : ''}・名前の横の数字はその大会のときの学年`) + rankTable(rows);
    const LF = EK.legFactors(M, k, L).filter(x => x.f !== 1);
    if (LF.length) h += `<details class="how"><summary>前のコースのタイムの直し方（推定）</summary><p>コースが違う大会のタイムは、今のコースならどれくらいかに直して並べています（タイムの右下に「推定」、大会の欄に実際のタイム）。直し方: コースが変わる直前と直後の大会（それぞれ3大会まで）の区間タイムの中央値の比を掛けます。同じ時期の選手層で比べるので、距離だけでなく坂や道の違いも入ります。両側のデータがないときは距離の比（リーゲルの式）で。</p><div class="tw"><table class="t">${LF.map(x => `<tr><td>${x.from <= 1 ? '第' + x.to + '回以前' : '第' + x.from + '〜' + x.to + '回'}</td><td class="tm s">${x.f ? '×' + x.f.toFixed(3) : '直せない（データなし）'}</td><td class="mute">${esc(x.how || '')}</td></tr>`).join('')}</table></div></details>`;
    if (m === 'grade') h += `<p class="note">学年は公式記録の表記。出雲・全日本で学年が載っていない選手は、別の大会の学年から推定しています（薄い数字）。</p>`;
    return h;
  }
  if (m === 'total') {
    const TE = EK.totalEras(M, k), tk = eraKey(TE, st.ui.tera), te = tk === 'all' ? null : TE[+tk] || null;
    const rows = EK.totalRanking(M, k, { era: te || undefined, all: tk === 'all', limit: 50 });
    return h + (TE.length > 1 ? chips(TE.map((e, i) => [i, e.label]), tk, 'tera') : '') + sec('総合タイム 歴代ランキング', te ? te.label : '全大会') + `<div class="tw"><table class="t"><tr><th></th><th>大学</th><th>タイム</th><th>大会</th><th>順位</th></tr>${rows.map((r, i) => `<tr data-go="race/${k}/${r.n}" class="lnk"><td class="rk">${i + 1}</td><td>${ulink(r.u)}</td><td class="tm">${F(r.t)}</td><td class="mute">第${r.n}回 ${r.y}</td><td>${ord(r.rank)}</td></tr>`).join('')}</table></div>`;
  }
  if (m === 'wins') {
    const W = EK.winners(M, k), C = EK.winCounts(M, k);
    return h + sec('優勝回数') + `<div class="tw"><table class="t">${C.map((c, i) => `<tr><td class="rk">${i + 1}</td><td>${ulink(c.u)}</td><td><b>${c.n}</b>回</td><td class="mute">最近 第${c.last.n}回（${c.last.y}）</td></tr>`).join('')}</table></div>` + sec('歴代優勝', `${W.length}大会`) + winnersTable(k, W);
  }
  if (m === 'award') {
    const A = EK.awardCounts(M, k);
    return h + sec('区間賞の数（大学）', '取り込み済みの大会から') + `<div class="tw"><table class="t">${A.univ.slice(0, 30).map((x, i) => `<tr><td class="rk">${i + 1}</td><td>${ulink(x.u)}</td><td><b>${x.n}</b></td></tr>`).join('')}</table></div>` +
      sec('区間賞を2回以上') + `<div class="tw"><table class="t">${A.runners.slice(0, 40).map(x => { const r = x.runs[0]; return `<tr><td>${rlink(r)}</td><td>${ulink(r.u, 1)}</td><td><b>${x.runs.length}</b></td><td class="mute">${x.runs.map(z => `${z.n}回${z.leg}区`).join(' ')}</td></tr>`; }).join('')}</table></div>`;
  }
  if (m === 'split') {
    if (!db.legs) return h + empty('区間のある大会だけです');
    const L = Math.min(st.ui.rleg, db.legs);
    h += chips(Array.from({ length: db.legs }, (_, i) => [i + 1, (i + 1) + '区']), L, 'rleg');
    const sv = st.ui.spv === 'seg' ? 'seg' : 'pt';
    h += chips([['pt', '地点の通過タイム'], ['seg', '地点から地点まで']], sv, 'spv');
    const G = memo(`sp${k}${L}${sv}`, () => sv === 'seg' ? EK.segBests(M, k, L) : EK.splitBests(M, k, L));
    if (!G.length) return h + empty('この区間の定点はまだありません（箱根は測定点別成績、ほかの大会は月陸Online のテキスト速報から少しずつ集めています）');
    const gi = Math.min(+st.ui.spi || 0, G.length - 1), g = G[gi];
    const name = x => sv === 'seg' ? segName(x, k, L) : kmLabel(x.km, x.label);
    h += chips(G.map((x, i) => [i, name(x)]), gi, 'spi');
    h += `<div class="opts"><label><input type="checkbox" data-opt="runi" ${st.ui.runi ? 'checked' : ''}> 1人1記録</label></div>`;
    let list = g.list; if (st.ui.runi) { const seen = {}; list = list.filter(x => { const p = sv === 'seg' ? x.r.p : x.p || x.u + x.nm; if (!p || seen[p]) return !p; seen[p] = 1; return true; }); }
    const dist = sv === 'seg' ? g.to - g.from : g.km;
    h += sec('歴代ランキング', `${L}区 ${name(g)}（${dist.toFixed(1)}km）・ ${g.list.length}件 ・ ${sv === 'seg' ? '2つの地点の通過タイムの差' : '区間スタートからの通過タイム'}`);
    h += `<div class="tw"><table class="t legt"><tr><th></th><th>選手</th><th>大学</th><th>タイム</th><th>大会</th></tr>${list.slice(0, 50).map((x, i) => { const r = sv === 'seg' ? x.r : x.r; return `<tr><td class="rk">${i + 1}</td><td>${r ? rlink(r) + gr(r) : x.nm ? esc(x.nm) : '<span class="mute">先頭集団</span>'}</td><td>${r ? ulink(r.u, 1) : x.u ? ulink(x.u, 1) : ''}</td><td class="tm">${F(x.t)}<small>${EK.pace(x.t / dist)}</small></td><td class="mute"><a href="#race/${k}/${r ? r.n : x.n}">第${r ? r.n : x.n}回</a> ${r ? r.y : x.y}${sv === 'pt' && x.rk ? ' ・ ' + x.rk + '位通過' : ''}</td></tr>`; }).join('')}</table></div>`;
    return h + `<p class="note">箱根は「箱根駅伝・区間・測定点別成績」（hakonesaijo.sakura.ne.jp）、ほかの大会は月陸Online のテキスト速報から。地点は名前と距離で分けているので、場所が変わった地点の記録は混ざりません。</p>`;
  }
  if (m === 'rec') {
    const R = (db.H.REC || []), T = db.H.TOP || {};
    let x = '';
    if (db.legs) { x += sec('区間記録', 'コース（距離）ごとに分けています。取り込み済みの大会の最速') + `<div class="tw"><table class="t"><tr><th>区間</th><th>コース</th><th>記録</th><th>選手</th><th>大学</th><th>大会</th></tr>${Array.from({ length: db.legs }, (_, i) => { const E = EK.eras(M, k, i + 1); const list = E.length ? E : [null]; return list.map((era, j) => { const b = EK.legRanking(M, k, i + 1, { era: era || undefined, all: !era, limit: 1 })[0]; if (!b) return ''; return `<tr class="${j ? 'old' : ''}"><td>${j ? '' : (i + 1) + '区'}</td><td class="mute cs">${era ? (era.to == null ? (j ? '' : '現行 ') + (era.from > 1 ? era.from + '回〜' : '') : era.from <= 1 ? '〜' + era.to + '回' : era.from + '〜' + era.to + '回') + (era.km ? ' ' + era.km + 'km' : '') : ''}</td><td class="tm">${F(b.t)}</td><td>${rlink(b)}${gr(b)}</td><td>${ulink(b.u, 1)}</td><td class="mute cs">第${b.n}回</td></tr>`; }).join(''); }).join('')}</table></div>`; }
    if (R.length) x += sec('区間記録（Wikipedia）') + `<div class="tw"><table class="t">${R.map(r => `<tr><td>${esc(r[6] || r[0] + '区')}</td><td class="tm">${F(r[1])}</td><td>${esc(r[2])}</td><td>${esc(S(r[3]))}</td><td class="mute">${r[4] ? '第' + r[4] + '回' : ''}${r[5] ? ' ' + r[5] : ''}</td></tr>`).join('')}</table></div>`;
    Object.keys(T).slice(0, 12).forEach(key => { x += sec(key.split('|')[0] + '区 歴代10傑', key.split('|')[1] || 'Wikipedia') + `<div class="tw"><table class="t">${T[key].map(r => `<tr><td class="rk">${r[0] || ''}</td><td class="tm">${F(r[1])}</td><td>${esc(r[2])}</td><td>${esc(S(r[3]))}</td><td class="mute">${r[4] ? '第' + r[4] + '回' : ''}</td></tr>`).join('')}</table></div>`; });
    return h + (x || empty('区間記録はまだありません'));
  }
  return h;
}
function eraKey(eras, v) { return !eras.length && v === 'all' ? 'all' : eras[+v] ? String(+v) : '0'; }
function rankTable(rows, indiv) {
  if (!rows.length) return empty('データがまだありません');
  return `<div class="tw"><table class="t legt"><tr><th></th><th>選手</th><th>大学</th><th>タイム</th><th>大会</th></tr>${rows.map((r, i) => `<tr class="${r.award ? 'aw' : ''}"><td class="rk">${i + 1}</td><td>${rlink(r)}${gr(r)}</td><td>${ulink(r.u, 1)}</td><td class="tm">${F(r.t)}${r.pace ? `<small>${EK.pace(r.pace)}</small>` : ''}${r.est ? `<small class="est" title="実際は${F(r.t0)}">推定</small>` : ''}</td><td class="mute"><a href="#race/${r.s}/${r.n}">第${r.n}回</a> ${r.y}${indiv ? '' : ' ・ ' + (r.lr ? r.lr + '位' : '')}${r.est ? `<small>実際 ${F(r.t0)}</small>` : ''}</td></tr>`).join('')}</table></div>`;
}

function runnerListView() {
  const M = st.M, q = st.ui.q || '';
  let h = `<div class="search"><input id="q" type="search" placeholder="選手名で検索（例: 黒田、キピエゴ）" value="${esc(q)}" autocomplete="off"></div>`;
  if (q.trim()) {
    const R = EK.search(M, q, 40);
    return h + (R.length ? `<div class="tw"><table class="t">${R.map(p => `<tr data-go="runner/${encodeURIComponent(p.id)}" class="lnk"><td><b>${esc(p.dn || p.nm)}</b>${p.dn && p.dn !== p.nm ? `<small class="mute"> ${esc(p.kana || '')}</small>` : ''}</td><td>${esc(S(p.u))}</td><td class="mute">${p.runs.length}レース ・ 最終 ${new Date(p.last).getFullYear()}</td></tr>`).join('')}</table></div>` : empty('見つかりませんでした'));
  }
  h += chips([[0, '男子'], [1, '女子']], st.ui.women ? 1 : 0, 'women');
  const A = memo('acesAll' + st.ui.women, () => EK.aces(M, { women: !!st.ui.women, limit: 100 }));
  h += sec('今の調子ランキング', '直近240日のトラック記録・レースを、新しいものほど重く（トラックは特に重く）見た偏差値') + (A.length ? `<div class="tw"><table class="t"><tr><th></th><th>選手</th><th>大学</th><th>調子</th><th>主な根拠</th></tr>${A.map((x, i) => `<tr data-go="runner/${encodeURIComponent(x.p)}" class="lnk"><td class="rk">${i + 1}</td><td>${esc(x.P.dn || x.P.nm)}${hurtTag(x.cond)}</td><td>${esc(S(x.P.u))}</td><td>${dev(x.f.val)}</td><td class="mute">${esc(formWhy(x.f))}</td></tr>`).join('')}</table></div>` : empty('直近の記録がまだありません'));
  return h;
}
function runnerView(id) {
  const M = st.M, Pr = M.runners[id]; if (!Pr) return empty('選手が見つかりません');
  const pf = P(id), last = Pr.runs[Pr.runs.length - 1];
  let h = `<div class="ph"><a class="back" href="#runner">‹ 選手</a><h1>${esc(Pr.dn || Pr.nm)}</h1>${Pr.kana ? `<p class="mute">${esc(Pr.kana)}${Pr.dnGuess ? '（英語表記はカタカナからの変換。正式なつづりは司書が調べて直します）' : ''}</p>` : ''}<p>${ulink(Pr.u)}${!EK.active(Pr) ? ' ・ 卒業' : pf.grade ? ` ・ ${pf.grade}年` : ''}${Pr.entry ? ` ・ ${Pr.entry}年度入学` : ''}${Pr.rid ? ` ・ <a href="https://www.hakone-ekiden.jp/record/person.php?rid=${Pr.rid}" target="_blank" rel="noopener">箱根公式</a>` : ''}</p></div>`;
  h += `<div class="kpi"><div><span>平均偏差値</span><b>${pf.avg != null ? pf.avg.toFixed(1) : '—'}</b></div><div><span>直近</span><b>${pf.cur != null ? pf.cur.toFixed(1) : '—'}</b></div><div><span>最高</span><b>${pf.best ? pf.best.dev.toFixed(1) : '—'}</b><small>${pf.best ? esc(sShort(pf.best.s)) + (pf.best.leg ? pf.best.leg + '区' : '') : ''}</small></div><div><span>区間賞</span><b>${pf.awards}</b></div><div><span>順位変動</span><b>${pf.move != null ? (pf.move > 0 ? '+' : '') + pf.move.toFixed(1) : '—'}</b><small>${pf.moves ? pf.moves + '区間平均' : ''}</small></div></div>`;
  const cond = EK.condition(M, id);
  if (cond) h += `<section class="card ${cond.injured ? 'hurt-card' : ''}"><b>${cond.injured ? (cond.last.kind === 'absent' ? '欠場の報道あり' : 'ケガ・故障の報道あり') + '（予想のオーダーから外しています）' : '報道'}</b>${cond.list.slice(0, 3).map(x => `<p class="note">${esc(x.date)} ${esc(x.note || '')} <a href="${esc(x.src)}" target="_blank" rel="noopener">出典</a></p>`).join('')}</section>`;
  const fm = memo('form' + id, () => EK.form(M, id));
  if (fm) h += sec('今の調子', fm.stale ? `直近240日の記録がないので古い記録から（最後は${fm.days}日前）` : `直近の${fm.n}件から。トラックは重く、古いものほど軽く`) +
    `<div class="form"><b>${dev(fm.val)}</b><div class="tw"><table class="t">${fm.parts.slice(0, 6).map(p => `<tr><td>${esc(partLabel(p.r))}${p.r.meet ? `<small class="mute"> ${esc(p.r.meet)}</small>` : ''}</td><td class="mute">${md(p.r.d)}</td><td>${dev(p.dev)}</td><td class="mute">${Math.round(p.share * 100)}%</td></tr>`).join('')}</table></div></div>`;
  const tr = memo('tr' + id, () => EK.traits(M, id));
  if (tr && pf.ndev >= 2) h += sec('能力の内訳', 'この選手の平均との差（＋が得意）。レースが少ない項目は0に近く出ます') + `<div class="bars">${['speed', 'stamina', 'up', 'down', 'clutch', 'steady'].map(k => { const v = tr[k] || 0, w = Math.min(50, Math.abs(v) / 8 * 50); return `<div class="br"><span class="bl">${EK.TRAIT_JA[k]}</span><span class="bt"><span class="bf ${v >= 1.5 ? 'hi' : v <= -1.5 ? 'lo' : ''}" style="left:${v >= 0 ? 50 : 50 - w}%;width:${w}%"></span><span class="b50" style="left:50%"></span></span><span class="bv">${v > 0 ? '+' : ''}${v.toFixed(1)}</span></div>`; }).join('')}</div>`;
  if (pf.labels.length) h += sec('走りの特徴') + `<ul class="feat">${pf.labels.map(l => `<li class="${l.good ? 'good' : ''}"><b>${esc(l.k)}</b>${l.v ? `<span>${esc(l.v)}</span>` : ''}</li>`).join('')}</ul>`;
  else if (pf.ndev < 2) h += `<p class="note">特徴の判定には、偏差値が出せるレースが2つ以上必要です。</p>`;
  h += devChart(Pr.runs);
  const tagOrder = ['上り', '下り', '平地', '起伏', 'エース', 'スタート', 'アンカー', '往路', '復路', 'ロング', '中距離', '短距離', 'ハーフ', '10000m'];
  const tg = tagOrder.filter(t => pf.byTag[t]).map(t => ({ k: t, v: pf.byTag[t].avg, n: pf.byTag[t].n }));
  if (tg.length >= 2) h += sec('区間タイプ別', '区間偏差値の平均（縦線が50）') + barList(tg);
  const bs = Object.keys(pf.byS).map(k => ({ k: sName(k), v: pf.byS[k].avg, n: pf.byS[k].n }));
  if (bs.length >= 2) h += sec('大会別') + barList(bs);
  const bg = Object.keys(pf.byG).sort().map(k => ({ k, v: pf.byG[k].avg, n: pf.byG[k].n }));
  if (bg.length >= 2) h += sec('学年別') + barList(bg);
  const retired = !EK.active(Pr);
  if (retired) h += `<p class="note">卒業した選手です（今季のランキングと予想には入りません）。</p>`;
  if (!Pr.women && M.series.hakone && !retired) {
    const pr = memo('pl' + id, () => EK.predictLegs(M, id));
    if (pr.length) { const best = pr.slice().sort((a, b) => a.rank - b.rank)[0]; h += sec('箱根の区間ごとの予想', `今の調子（区間の距離に近い種目を重く）に上り・下りの得意不得意を足し、直近の箱根3大会の区間の分布に当てはめた値`) + `<div class="tw"><table class="t"><tr><th>区間</th><th>予想タイム</th><th>前回なら</th><th>適性</th><th>根拠</th><th>あなたの評価</th></tr>${pr.map(x => { const a = (EK.ADJ[id] || {})[x.leg] || 0; return `<tr class="${x === best ? 'aw' : ''}"><td>${x.leg}区${x.km ? `<small class="mute"> ${x.km}km</small>` : ''}</td><td class="tm">${F(x.t)}${x.rec ? `<small>記録比 ${(x.t / x.rec * 100).toFixed(1)}%</small>` : ''}</td><td>${x.rank}位<small class="mute">/${x.of}</small></td><td>${dev(x.est)}</td><td class="mute">${esc((x.why || []).slice(0, 2).join('・'))}</td><td class="adj"><button class="aj ${a > 0 ? 'on' : ''}" data-adj="${esc(id)}|${x.leg}|1" aria-label="${x.leg}区に向いている">◎</button><button class="aj ${a < 0 ? 'on no' : ''}" data-adj="${esc(id)}|${x.leg}|-1" aria-label="${x.leg}区に向いていない">×</button></td></tr>`; }).join('')}</table></div><p class="note">◎＝この区間に向いている、×＝向いていない。あなたの評価は予想オーダーにも反映されます（この端末に保存）。</p>`; }
  }
  const TR = Pr.runs.filter(r => r.track);
  if (TR.length) h += sec('トラック・ロードの記録', `${TR.length}`) + `<div class="tw"><table class="t"><tr><th>種目</th><th>記録</th><th>日付</th><th>大会</th><th>偏差値</th></tr>${TR.slice().reverse().map(r => `<tr><td>${esc(EVN[r.ev] || r.ev)}</td><td class="tm">${esc(partLabel(r).replace(/^\S+\s/, ''))}</td><td class="mute">${new Date(r.d).getFullYear()}/${md(r.d)}</td><td class="mute">${esc(r.meet || '')}</td><td>${dev(r.dev)}</td></tr>`).join('')}</table></div>`;
  h += sec('全レース', `${Pr.runs.filter(r => !r.track).length}・数字はそのときの学年`) + `<div class="tw"><table class="t legt"><tr><th>大会</th><th>区間</th><th>タイム</th><th>順位</th><th>偏差値</th><th>記録比</th><th>通過</th></tr>${Pr.runs.filter(r => !r.track).slice().reverse().map(r => `<tr class="${r.award ? 'aw' : ''}"><td><a href="#race/${r.s}/${r.n}">${esc(sShort(r.s))} ${r.y}</a>${gr(r)}</td><td>${r.leg ? r.leg + '区' : '個人'}${r.km ? `<small class="mute"> ${r.km}km</small>` : ''}</td><td class="tm">${F(r.t)}${r.pace ? `<small>${EK.pace(r.pace)}</small>` : ''}</td><td>${r.op ? 'OP' : r.lr ? r.lr + '位' : ''}</td><td>${dev(r.dev)}</td><td class="tm s">${r.recPct ? r.recPct.toFixed(1) + '%' : ''}</td><td class="tm s">${r.op ? '' : (r.cr || '') + ' ' + mv(r)}</td></tr>`).join('')}</table></div><p class="note">記録比 = そのタイム ÷ 同じコースの区間記録（取り込み済みの大会の最速）。100%が区間記録。</p>`;
  const withSp = Pr.runs.filter(r => r.splits && r.splits.length);
  if (withSp.length) h += sec('定点通過', '月陸Online のテキスト速報から。区切りごとのタイムとペース') + withSp.slice().reverse().map(r => `<p class="segh"><a href="#race/${r.s}/${r.n}">${esc(sShort(r.s))} ${r.y}</a> ${r.leg}区 <b class="tm">${F(r.t)}</b></p>` + segTable(r)).join('');
  const sim = memo('sim' + id, () => EK.similar(M, id, 6));
  if (sim.length) h += sec('似たタイプの選手', '水準・上り下り・距離・順位の上げ下げ・伸び方・安定感が近い順') + `<div class="tw"><table class="t">${sim.map(x => { const o = M.runners[x.id]; return `<tr data-go="runner/${encodeURIComponent(x.id)}" class="lnk"><td><b>${esc(o.dn || o.nm)}</b>${EK.active(o) ? '' : '<small class="mute"> 卒業</small>'}</td><td>${esc(S(o.u))}</td><td class="mute">${(a => a[0] === a[1] ? a[0] : a.join('–'))([new Date(o.runs[0].d).getFullYear(), new Date(o.last).getFullYear()])}</td><td>${dev(x.pf.avg)}</td><td class="mute">${x.why.join('・')}</td></tr>`; }).join('')}</table></div>`;
  h += `<p class="note">区間偏差値 = その大会のその区間を走った全員のタイムの中での位置（平均50・標準偏差10）。年や気象が違っても比べられます。${Pr.runs.some(r => r.gi) ? '薄い学年は入学年からの推定です。' : ''}</p>`;
  return h;
}

function univListView() {
  const M = st.M, q = st.ui.uq || '';
  const U = memo('univs', () => Object.values(M.univ).filter(u => !/選抜|連合/.test(u.name)).map(u => { const hk = EK.winners(M, 'hakone').filter(w => w.u === u.name).length; return { name: u.name, n: u.runs.length, hk, last: Math.max(...u.runs.map(r => r.d)), s: Object.keys(u.series) }; }).sort((a, b) => b.hk - a.hk || b.last - a.last || b.n - a.n));
  const L = q ? U.filter(u => EK.norm(u.name).indexOf(EK.norm(q)) >= 0 || EK.norm(S(u.name)).indexOf(EK.norm(q)) >= 0) : U;
  return `<div class="search"><input id="uq" type="search" placeholder="大学名で検索" value="${esc(q)}" autocomplete="off"></div><div class="tw"><table class="t">${L.slice(0, 120).map(u => `<tr data-go="univ/${encodeURIComponent(u.name)}" class="lnk"><td><b>${esc(u.name)}</b></td><td class="mute">${u.s.map(k => esc(sShort(k))).join(' ')}</td><td>${u.hk ? `箱根V${u.hk}` : ''}</td></tr>`).join('')}</table></div>`;
}
function univView(u) {
  const M = st.M, U = M.univ[u]; if (!U) return empty('大学が見つかりません');
  const ss = Object.keys(U.series), k = ss.indexOf(st.ui.us) >= 0 ? st.ui.us : (ss.indexOf('hakone') >= 0 ? 'hakone' : ss[0]);
  const R = memo('ur' + u + k, () => EK.univRecords(M, u, k));
  let h = `<div class="ph"><a class="back" href="#univ">‹ 大学</a><h1>${esc(u)}</h1></div>` + chips(ss.map(x => [x, sName(x)]), k, 'us');
  if (R) {
    h += `<div class="kpi"><div><span>優勝</span><b>${R.wins.length}</b></div><div><span>3位以内</span><b>${R.top3}</b></div><div><span>10位以内</span><b>${R.top10}</b></div><div><span>出場</span><b>${R.apps}</b><small>取り込み済み</small></div><div><span>区間賞</span><b>${R.awards}</b></div></div>`;
    if (R.wins.length) h += `<p class="note">優勝: ${R.wins.map(w => `第${w.n}回（${w.y}）`).join('、')}</p>`;
    h += rankHistory(R.hist);
    if (R.legs.length) h += sec('区間別の大学記録', '各区間の現行コース') + `<div class="tw"><table class="t legt"><tr><th>区間</th><th>選手</th><th>タイム</th><th>大会</th></tr>${R.legs.map(L => L.best ? `<tr><td>${L.leg}区</td><td>${rlink(L.best)}${gr(L.best)}</td><td class="tm">${F(L.best.t)}</td><td class="mute"><a href="#race/${k}/${L.best.n}">第${L.best.n}回</a> ${L.best.lr ? L.best.lr + '位' : ''}</td></tr>` : `<tr><td>${L.leg}区</td><td colspan="3" class="mute">—</td></tr>`).join('')}</table></div>`;
    if (R.best) h += sec('総合の大学記録', `第${R.best.n}回（${R.best.y}） ${F(R.best.t)} ${R.best.rank ? R.best.rank + '位' : ''}`) + (R.members.some(Boolean) ? `<div class="tw"><table class="t">${R.members.map((r, i) => r ? `<tr><td>${i + 1}区</td><td>${rlink(r)}${gr(r)}</td><td class="tm">${F(r.t)}</td><td>${r.lr ? r.lr + '位' : ''}</td></tr>` : '').join('')}</table></div>` : '');
  }
  // current roster: this academic year and last
  const ay = EK.academicNow();
  const roster = Object.values(M.runners).filter(p => p.u === u && p.runs.some(r => r.ay >= ay - 1) && EK.active(p)).map(p => ({ p, pf: P(p.id), g: p.entry != null ? ay - p.entry + 1 : null })).sort((a, b) => (b.pf.cur || 0) - (a.pf.cur || 0));
  if (roster.length) h += sec(`${ay}年度の選手`, '直近のレースほど重く見た区間偏差値の順') + `<div class="tw"><table class="t">${roster.map(x => `<tr data-go="runner/${encodeURIComponent(x.p.id)}" class="lnk"><td><b>${esc(x.p.dn || x.p.nm)}</b>${x.g ? `<span class="gr">${x.g}</span>` : ''}</td><td>${dev(x.pf.cur)}</td><td class="mute">${x.pf.labels.slice(0, 2).map(l => esc(l.k)).join('・')}</td></tr>`).join('')}</table></div>`;
  const fld = memo('field', () => EK.hakoneField(M)), T = fld && fld.teams.find(t => t.univ === u);
  if (T) h += sec(`箱根 第${fld.next}回 予想オーダー`, `予想 ${F(T.total)} ・ ${fld.teams.indexOf(T) + 1}位相当`) + orderTable(T);
  return h;
}
function orderTable(T) { return `${T.entry ? '<p class="note">発表されたエントリーで予想しています。</p>' : ''}${(T.hurt || []).length ? `<p class="note">ケガ・欠場の報道で外した選手: ${T.hurt.map(x => `<a href="#runner/${encodeURIComponent(x.id)}">${esc(x.nm)}</a>（${esc(x.why.date)}）`).join('、')}</p>` : ''}<div class="tw"><table class="t"><tr><th>区間</th><th>選手</th><th>予想</th><th>調子</th><th>根拠</th></tr>${T.order.map(o => `<tr><td>${o.leg}区${o.fixed ? '<small class="mute"> 発表</small>' : ''}</td><td>${o.id ? `<a class="rn" href="#runner/${encodeURIComponent(o.id)}">${esc(o.nm)}</a>` : `<span class="mute">${esc(o.nm)}</span>`}${o.g ? `<span class="gr">${o.g}</span>` : ''}</td><td class="tm">${F(o.t)}</td><td>${dev(o.est)}</td><td class="mute">${esc((o.why || []).slice(0, 2).join('・'))}</td></tr>`).join('')}</table></div>${(T.bench || []).length ? `<p class="note">控え: ${T.bench.map(b => `<a href="#runner/${encodeURIComponent(b.id)}">${esc(b.nm)}</a>${b.g ? '(' + b.g + ')' : ''}`).join('、')}</p>` : ''}${T.short ? `<p class="note">記録のある選手が${(T.legs || 10) - T.short}人のため、残り${T.short}区間は控えめな値（偏差値42）で計算しています。</p>` : ''}`; }

function predictView() {
  const M = st.M, ps = EK.PREDICT_SERIES.indexOf(st.ui.ps) >= 0 ? st.ui.ps : 'hakone';
  let h = chips(EK.PREDICT_SERIES.filter(k => M.series[k]).map(k => [k, sName(k)]), ps, 'ps');
  const fld = memo('pred' + ps, () => EK.predictRace(M, ps));
  if (!fld || !fld.teams.length) return h + empty(sName(ps) + 'のデータが入ると予想できます');
  const top = fld.teams[0], hk = ps === 'hakone', women = !!(M.series[ps] || {}).women;
  const sub = hk ? `前回のシード10校${fld.haveYosen ? ' ＋ 予選会通過10校' : '（予選会の結果待ち）'}` : `${fld.date ? fld.date.slice(0, 4) + '年' + (+fld.date.slice(5, 7)) + '月ごろ ・ ' : ''}前回（第${fld.from}回）の出場校 ・ ${women ? '女子' : '男子'}の選手だけで予想`;
  h += `<div class="ph"><h1>${esc(sName(ps))} 第${fld.next}回 予想</h1><p class="mute">${sub}</p></div>`;
  h += `<div class="tw"><table class="t"><tr><th></th><th>大学</th><th>予想</th><th>差</th><th></th></tr>${fld.teams.map((T, i) => `<tr data-open="${esc(ps + '|' + T.univ)}" class="lnk ${hk && i === 9 ? 'seedline' : ''}"><td class="rk">${i + 1}</td><td>${esc(T.univ)}</td><td class="tm">${F(T.total)}</td><td class="tm s mute">${i ? '+' + F(T.total - top.total) : ''}</td><td class="mute">${hk ? (T.seed ? 'シード' : '予選会') : ''}${T.short ? `${hk ? ' ・ ' : ''}不足${T.short}` : ''}</td></tr>${st.ui.open === ps + '|' + T.univ ? `<tr class="sub"><td colspan="5">${orderTable(T)}</td></tr>` : ''}`).join('')}</table></div>`;
  const lastN = (M.series[ps].E.filter(e => e.L && e.L.length && e.st !== 'live').sort((a, b) => b.n - a.n)[0] || {}).n;
  if (lastN) {
    const B = memo('bt' + ps + lastN, () => EK.backtest(M, ps, lastN));
    if (B && B.runners) h += sec(`答え合わせ（第${lastN}回）`, '前回の大会を、前日までに分かっていたことだけで予想して、実際の結果と比べたもの') +
      `<div class="kpi"><div><span>選手の予想タイムの誤差</span><b>${B.maePct.toFixed(1)}%</b><small>平均${Math.round(B.mae)}秒（${B.runners}人）</small></div><div><span>全員を平均と見た場合</span><b>${Math.round(B.base)}秒</b><small>この差が予想の力</small></div><div><span>区間内の順位の当たり</span><b>${B.legCorr.toFixed(2)}</b><small>順位相関（1が完全）</small></div>${B.teams ? `<div><span>チーム順位の当たり</span><b>${B.teamCorr.toFixed(2)}</b><small>${B.teams}校の順位相関</small></div><div><span>優勝</span><b>${B.winner.hit ? '的中' : '外れ'}</b><small>予想 ${esc(S(B.winner.pred || ''))} / 実際 ${esc(S(B.winner.actual || ''))}</small></div>` : ''}</div>` +
      (B.order ? `<details class="how"><summary>チームの予想と実際</summary><div class="tw"><table class="t"><tr><th>予想</th><th>大学</th><th>予想タイム</th><th>実際</th><th>実際のタイム</th></tr>${B.order.map(o => `<tr><td class="rk">${o.pred}</td><td>${esc(S(o.u))}</td><td class="tm s">${F(o.t)}</td><td class="rk">${o.actual}</td><td class="tm s">${F(o.at)}</td></tr>`).join('')}</table></div><p class="note">全体のタイムは天候で毎年ずれます（その年の平均のずれ ${B.bias > 0 ? '+' : ''}${Math.round(B.bias)}秒）。順位の当たりのほうが予想の良し悪しを表します。予想に出てこない選手（前の記録がない1年生など）は比べられません。</p></details>` : '');
  }
  h += `<details class="how"><summary>計算のしかた</summary><p>1. 各選手の全レースを「区間偏差値」（その区間を走った全員の中での位置）にする。トラックの記録も同じ物差しにして、新しいものほど重く見る（今の調子）。<br>2. 大会の日までの伸び（学年ごとの平均的な成長）を足す。<br>3. 区間ごとに求められるもの（${hk ? '1区は勝負強さ、5区は上りなど' : ps === 'zen' ? '7区・8区はスタミナ、2区はエースなど' : ps === 'izumo' ? '2区はスピード、6区はスタミナなど' : '最長区間はスタミナ、短い区間はスピードなど'}）を、その選手の得意不得意から足し引きする。同じ区間を走って上位だった選手は少し上げる。<br>4. 直近3大会のその区間のタイム分布（年々速くなる流れも含めて）に当てはめて、予想タイムにする。<br>5. 大会の時点で在学している${women ? '女子' : '男子'}選手から、総合タイムが一番速くなる組み合わせを探す。留学生は1人まで。ケガ・欠場の報道がある選手は外す。${hk ? '山の経験や1年生の起用のしかたなど監督の考え方は、誰をどこに置くかの判断にだけ使い、予想タイムには入れない（過去の大会で確かめると、タイムの予想は良くならなかったため）。' : ''}</p><p>重みや減り方の値は、箱根（第100〜102回）・出雲・全日本・杜の都・富士山の直近の大会を、前日までの情報だけで予想して実際と比べ、いちばん当たる値に決めています。古い記録も長く効く（約600日で1/e）・記録の少ない選手は控えめ（偏差値44寄り）、という結果でした。記録のない新入生は入りません。</p></details>`;
  return h;
}

function newsList(items) { return `<ul class="news">${items.map(n => `<li><button class="nw" data-read="${esc(n.id)}"><b>${esc(n.t)}</b><span>${esc(n.s || '')} ・ ${ago(n.d)}</span></button></li>`).join('')}</ul>`; }
function newsView() { const N = (st.idx && st.idx.news) || []; return N.length ? newsList(N) : empty(cfg().url ? 'ニュースはまだありません' : 'データの取得先をつなぐとニュースが入ります'); }

/* ---------- settings ---------- */
function pushProblem() { if (isIOS && !standalone) return 'iPhone では Safari の共有 →「ホーム画面に追加」から開くと設定できます。'; if (!('serviceWorker' in navigator) || !('PushManager' in window)) return 'このブラウザは通知に対応していません。'; return ''; }
function b64uToBytes(s) { const b = atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)); return Uint8Array.from(b, ch => ch.charCodeAt(0)); }
async function pushEnable(types) {
  if ((await Notification.requestPermission()) !== 'granted') throw new Error('通知が許可されませんでした。端末の設定で EKDNist の通知を許可してください。');
  const reg = await navigator.serviceWorker.ready, key = (await gasGet({ v: 'vapid' })).key;
  let sub = await reg.pushManager.getSubscription(); if (sub) await sub.unsubscribe();
  sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64uToBytes(key) });
  await post({ action: 'push-sub', sub: sub.toJSON(), types, label: (isIOS ? 'iPhone' : /Android/.test(navigator.userAgent) ? 'Android' : 'PC') });
  setCfg('push', { endpoint: sub.endpoint, types }); await writeSwConf();
}
async function pushDisable() { const p = cfg().push; try { const reg = await navigator.serviceWorker.ready, sub = await reg.pushManager.getSubscription(); if (sub) await sub.unsubscribe(); } catch (e) {} if (p) try { await post({ action: 'push-unsub', endpoint: p.endpoint }); } catch (e) {} setCfg('push', null); }
async function writeSwConf() { try { const c = await caches.open('ekd-conf'); await c.put('./__conf', new Response(JSON.stringify({ url: cfg().url }), { headers: { 'Content-Type': 'application/json' } })); } catch (e) {} }
const PT = [['live', '速報（開始・区間新）'], ['result', '大会結果'], ['data', 'データの取り込み完了']];
function settingsView() {
  const c = cfg(), pp = c.push, prob = pushProblem(), idx = st.idx || {};
  const msg = k => st.msg[k] ? `<p class="msg ${st.msg[k][1] ? 'bad' : ''}">${esc(st.msg[k][0])}</p>` : '';
  let h = `<div class="ph"><h1>設定</h1></div>`;
  if (!standalone) h += `<section class="card"><h3>アプリとしてインストール</h3>${installEv ? '<div class="row"><button class="btn" data-act="install">EKDNist をインストール</button></div>' : ''}<p class="note">「すでにインストールされています」と出るときは、<a href="../">sora apps の一覧</a>を1つのアプリとして入れてください（いまの Chrome は同じサイトのアプリを1つしか入れられないため）。ホーム画面のアイコンを長押しすると EKDNist へ直接行けます。</p>${msg('install')}</section>`;
  h += `<section class="card"><h3>データの取得先</h3><label>GAS ウェブアプリの URL<input id="s-url" type="url" value="${esc(c.url)}" placeholder="https://script.google.com/macros/s/…/exec"></label><label>合言葉<input id="s-pass" type="password" value="${esc(c.pass)}"></label><div class="row"><button class="btn" data-act="save">保存して読み込む</button><button class="btn ghost" data-act="refresh">今すぐ更新（GAS側）</button></div>${msg('save')}</section>`;
  h += `<section class="card"><h3>通知</h3>${prob ? `<p class="note">${esc(prob)}</p>` : `${PT.map(([k, n]) => `<label class="ck"><input type="checkbox" data-pt="${k}" ${!pp || !pp.types || pp.types[k] !== false ? 'checked' : ''}> ${n}</label>`).join('')}<div class="row">${pp ? '<button class="btn" data-act="push-on">通知の種類を保存</button><button class="btn ghost" data-act="push-test">テスト</button><button class="btn ghost" data-act="push-off">オフにする</button>' : '<button class="btn" data-act="push-on">この端末で通知を受け取る</button>'}</div>`}${msg('push')}</section>`;
  const opts = SERIES_KEYS().map(k => `<option value="${k}">${esc(sName(k))}</option>`).join('');
  h += `<section class="card"><h3>URL から取り込む</h3><p class="note">区間ごとの表（区間順位・選手・大学・タイム）が並んだページの URL を入れると、その大会の全選手を取り込みます。</p><label>大会<select id="i-s">${opts}</select></label><label>回<input id="i-n" type="number" min="1" max="200" inputmode="numeric"></label><label>URL<input id="i-url" type="url" placeholder="https://"></label><div class="row"><button class="btn" data-act="import">取り込む</button></div>${msg('import')}</section>`;
  const sv = (idx.series || []).filter(s => s.eds && s.eds.length);
  h += `<section class="card"><h3>データの状況</h3>${idx.crawl && idx.crawl.hakone ? `<p>箱根駅伝 公式記録: ${idx.crawl.hakone.done} / ${idx.crawl.hakone.total} 大会</p>` : ''}<div class="tw"><table class="t">${(sv.length ? sv : Object.values(SER()).map(d => ({ key: d.key, name: d.name, eds: d.E.map(e => [e.n, e.y, e.st]) }))).map(s => `<tr><td>${esc(s.name)}</td><td>${s.eds.length}大会</td><td class="mute">全区間 ${s.eds.filter(e => e[2] === 'full').length}</td></tr>`).join('')}</table></div>
    ${idx.status ? `<p class="note">${Object.keys(idx.status).map(k => `${esc(JOB[k] || k)}: ${idx.status[k].ok ? 'OK' : '<span class="bad">' + esc(idx.status[k].error || 'NG') + '</span>'}`).join(' ・ ')}</p>` : ''}
    <p class="note">端末内の計算: ${st.M ? Object.keys(st.M.runners).length : 0}人・${st.M ? st.M.runs.length : 0}走 ${st.buildMs ? `（${st.buildMs}ms）` : ''} ・ 最終更新 ${idx.updated ? ago(idx.updated) : '—'}</p><div class="row"><button class="btn ghost" data-act="reload-db">端末のデータを入れ直す</button></div>${msg('db')}</section>`;
  if (st.libKey) h += `<section class="card"><h3>司書（Claude の定期タスク）用</h3><p class="note">箱根以外の大会の全区間データを、Claude が公開ページから調べて送るための鍵です。会話で Claude に渡してください。</p><pre class="key">GAS URL: ${esc(st.libUrl || c.url)}\n司書キー: ${esc(st.libKey)}</pre></section>`;
  return h;
}
const SRC_NAME = u => /hakonesaijo/.test(u) ? '箱根駅伝・区間・測定点別成績' : /ekiden-results/.test(u) ? '駅伝リザルト' : /neet-shikakugets/.test(u) ? 'ほぼニートの資格取得日記' : /hakone-ekiden\.jp/.test(u) ? '箱根駅伝 公式記録' : /rikujyokyogi/.test(u) ? '月陸Online' : /the-ans\.jp/.test(u) ? 'THE ANSWER' : /wikipedia/.test(u) ? 'Wikipedia' : u.replace(/^https?:\/\/(www\.)?/, '').split('/')[0];
const SERIES_KEYS = () => allSeries().flatMap(g => g[1]).concat(['hakone', 'izumo', 'zen', 'yosen', 'morinomiya', 'fujisan', 'kwj', 'oga']).filter((k, i, a) => a.indexOf(k) === i);
async function syncPrefs() { const c = cfg(); if (!c.url || !c.pass) return; try { const j = await post({ action: 'prefs-get', endpoint: c.push && c.push.endpoint }); st.libKey = j.librarianKey; st.libUrl = j.url; if (st.view === 'settings') render(); } catch (e) {} }

/* ---------- reader ---------- */
const rdEl = document.createElement('div'); rdEl.className = 'reader'; rdEl.hidden = true; document.body.appendChild(rdEl);
async function openReader(id) {
  const n = ((st.idx && st.idx.news) || []).find(x => x.id === id); if (!n) return;
  rdEl.hidden = false; document.documentElement.classList.add('rd-open');
  rdEl.innerHTML = `<div class="rd"><button class="x" data-act="close-rd" aria-label="閉じる">×</button><p class="mute">${esc(n.s || '')} ・ ${ago(n.d)}</p><h1>${esc(n.t)}</h1><p class="mute">読み込み中…</p></div>`;
  let d = null; try { d = await gasGet({ v: 'read', id }); } catch (e) {}
  rdEl.innerHTML = `<div class="rd"><button class="x" data-act="close-rd" aria-label="閉じる">×</button><p class="mute">${esc(n.s || '')} ・ ${ago(n.d)}</p><h1>${esc(n.t)}</h1>${d && d.ok ? d.paras.map(p => p.t === 'h' ? `<h3>${esc(p.x)}</h3>` : `<p>${esc(p.x)}</p>`).join('') : `<p class="note">本文を読み込めませんでした。</p>`}<p><a class="btn ghost" href="${esc(n.u)}" target="_blank" rel="noopener">元の記事を開く</a></p></div>`;
}
function closeReader() { rdEl.hidden = true; rdEl.innerHTML = ''; document.documentElement.classList.remove('rd-open'); }

/* ---------- shell ---------- */
const TABS = [['home', 'ホーム'], ['race', '大会'], ['records', '記録'], ['runner', '選手'], ['univ', '大学'], ['predict', '予想']];
function errHtml() { return st.err ? `<p class="msg bad">${esc(st.err)}</p>` : ''; }
function route() { const h = decodeURIComponent(location.hash.replace(/^#/, '')), p = h.split('/'); st.view = p[0] || 'home'; st.args = p.slice(1); }
function render() {
  if (!st.M) return;
  const v = st.view, a = st.args;
  const body = v === 'race' && a.length >= 2 ? raceView(a[0], a[1]) : v === 'race' ? raceListView() : v === 'records' ? recordsView() : v === 'runner' && a[0] ? runnerView(a.join('/')) : v === 'runner' ? runnerListView()
    : v === 'univ' && a[0] ? univView(a.join('/')) : v === 'univ' ? univListView() : v === 'predict' ? predictView() : v === 'news' ? newsView() : v === 'live' ? liveView() : v === 'settings' ? settingsView() : homeView();
  const tab = v === 'news' || v === 'live' ? 'home' : v;
  const focus = document.activeElement && document.activeElement.id, pos = focus && document.activeElement.selectionStart;
  $('#app').innerHTML = `<header class="top"><a class="logo" href="#home" aria-label="EKDNist ホーム"><span>EKDN</span>ist</a>${st.loading ? '<span class="spin" aria-label="更新中"></span>' : ''}${st.idx && st.idx.live && st.idx.live.active ? '<a class="lv" href="#live">LIVE</a>' : ''}<a class="gear${v === 'settings' ? ' on' : ''}" href="#settings" aria-label="設定"><svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M19.4 13a7.5 7.5 0 0 0 0-2l2.1-1.6-2-3.4-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3.3h-4l-.4 2.7a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.4L6.6 11a7.5 7.5 0 0 0 0 2l-2.1 1.6 2 3.4 2.5-1a7.4 7.4 0 0 0 1.7 1l.4 2.7h4l.4-2.7a7.4 7.4 0 0 0 1.7-1l2.5 1 2-3.4zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" transform="translate(-1 0)"/></svg></a></header>
    <main class="g">${body}</main><nav class="tabs">${TABS.map(([k, n]) => `<a href="#${k}" class="${tab === k ? 'on' : ''}">${n}</a>`).join('')}</nav>`;
  if (focus) { const el = document.getElementById(focus); if (el) { el.focus(); try { el.setSelectionRange(pos, pos); } catch (e) {} } }
}
window.addEventListener('hashchange', () => { route(); if (st.view === 'settings') syncPrefs(); render(); scrollTo(0, 0); });
document.addEventListener('click', async e => {
  const aj = e.target.closest('[data-adj]');
  if (aj) { const [pid, leg, v] = aj.dataset.adj.split('|'); const cur = (EK.ADJ[pid] || {})[leg]; EK.ADJ[pid] = EK.ADJ[pid] || {}; if (String(cur) === v) delete EK.ADJ[pid][leg]; else EK.ADJ[pid][leg] = +v; lsSet(LSADJ, EK.ADJ); st.cache = {}; st.M.pf = {}; render(); return; }
  const t = e.target.closest('[data-rseg],[data-spv],[data-spi],[data-ps],[data-rera],[data-tera],[data-es],[data-rs],[data-rmode],[data-rleg],[data-rg],[data-eleg],[data-us],[data-women],[data-go],[data-open],[data-act],[data-read]');
  if (!t) return;
  const d = t.dataset;
  if ('rseg' in d) { st.ui.rseg = d.rseg; } else if (d.spv) { st.ui.spv = d.spv; st.ui.spi = 0; } else if (d.spi) { st.ui.spi = +d.spi; } else if (d.ps) { st.ui.ps = d.ps; st.ui.open = ''; } else if (d.es) { st.ui.es = d.es; } else if (d.rs) { st.ui.rs = d.rs; st.ui.rseg = ''; st.ui.rleg = 1; st.ui.rera = '0'; st.ui.tera = '0'; } else if (d.rmode) { st.ui.rmode = d.rmode; } else if (d.rleg) { st.ui.rleg = +d.rleg; st.ui.rera = '0'; st.ui.spi = 0; st.ui.rseg = ''; } else if (d.rera) { st.ui.rera = d.rera; } else if (d.tera) { st.ui.tera = d.tera; } else if (d.rg) { st.ui.rg = +d.rg; } else if (d.eleg) { st.ui.eleg = +d.eleg; } else if (d.us) { st.ui.us = d.us; } else if (d.women) { st.ui.women = d.women === '1'; }
  else if (d.go) { if (e.target.closest('a')) return; location.hash = d.go; return; }
  else if (d.open) { st.ui.open = st.ui.open === d.open ? '' : d.open; }
  else if (d.read) { openReader(d.read); return; }
  else if (d.act) { await act(d.act); return; }
  saveUi(); render();
});
document.addEventListener('change', e => { const o = e.target.dataset && e.target.dataset.opt; if (o) { st.ui[o] = e.target.checked; saveUi(); render(); } });
let qT = null;
document.addEventListener('input', e => { if (e.target.id === 'q' || e.target.id === 'uq') { const k = e.target.id, v = e.target.value; clearTimeout(qT); qT = setTimeout(() => { st.ui[k] = v; render(); }, 180); } });
async function act(a) {
  const say = (k, m, bad) => { st.msg[k] = [m, bad]; render(); };
  try {
    if (a === 'close-rd') return closeReader();
    if (a === 'install') return doInstall();
    if (a === 'save') { setCfg('url', $('#s-url').value.trim()); setCfg('pass', $('#s-pass').value); say('save', '保存しました。読み込んでいます…'); await writeSwConf(); await refresh(); syncPrefs(); say('save', st.err || '読み込みました', !!st.err); }
    if (a === 'refresh') { say('save', 'GAS 側で更新しています（1分ほど）…'); const r = await post({ action: 'refresh' }); await refresh(); say('save', `更新しました（${r.pages || 0}ページ、${Math.round((r.ms || 0) / 1000)}秒）`); }
    if (a === 'push-on') { const types = {}; document.querySelectorAll('[data-pt]').forEach(x => { types[x.dataset.pt] = x.checked; }); await pushEnable(types); say('push', 'この端末で通知を受け取ります'); }
    if (a === 'push-off') { await pushDisable(); say('push', 'オフにしました'); }
    if (a === 'push-test') { const p = cfg().push; const r = await post({ action: 'push-test', endpoint: p && p.endpoint }); say('push', r.ok ? 'テスト通知を送りました' : r.error, !r.ok); }
    if (a === 'import') { const s = $('#i-s').value, n = +$('#i-n').value, url = $('#i-url').value.trim(); if (!n || !url) return say('import', '回と URL を入れてください', true); say('import', '取り込んでいます…'); const r = await post({ action: 'import-url', s, n, url }); await refresh(); say('import', `${sName(s)} 第${n}回: ${r.teams}チーム・${r.runs}走を取り込みました${(r.checks || []).length ? '（合計が発表と違うチーム: ' + r.checks.join('、') + '）' : ''}`); }
    if (a === 'reload-db') { await IDB.clear(); st.dbs = {}; Object.values(window.EKD_SEED || {}).forEach(d => { st.dbs[d.key] = d; }); rebuild(); await refresh(true); say('db', '入れ直しました'); }
  } catch (err) { const k = a.indexOf('push') === 0 ? 'push' : a === 'import' ? 'import' : a === 'reload-db' ? 'db' : 'save'; say(k, err.message || String(err), true); }
}
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
/* in-page install: Chrome 154–156 on Android refuses a second app from the same site in its menu, but this route checks the app's own scope */
let installEv = null;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEv = e; if (st.view === 'settings' || st.view === 'home') render(); });
window.addEventListener('appinstalled', () => { installEv = null; st.msg.install = ['インストールしました。ホーム画面かアプリ一覧から開けます。']; render(); });
async function doInstall() { if (!installEv) return; installEv.prompt(); const r = await installEv.userChoice.catch(() => null); installEv = null; if (r && r.outcome === 'dismissed') st.msg.install = ['インストールを取りやめました', true]; render(); }
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && st.idx && Date.now() - (st.lastRefresh || 0) > 5 * 6e4) { st.lastRefresh = Date.now(); refresh(); } });
boot();
