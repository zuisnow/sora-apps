// hub only: answers for the app list itself; every app folder keeps its own service worker
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.mode!=='navigate'||!/\/sora-apps\/(index\.html)?$/.test(u.pathname))return;
  e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open('hub').then(x=>x.put('./',c));return r;}).catch(()=>caches.match('./')));});
