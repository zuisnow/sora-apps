# sora apps

自分用アプリ置き場。画面（PWA）は GitHub Pages、データは Google Apps Script（GAS）。
GitHub はリポジトリ 1 つ、GAS はアプリごとに別プロジェクト。

```
/                 アプリ一覧（index.html）
/ekiden/          駅伝監督（PWA）
/news/            BMERadar（PWA）
  config.js       それぞれのアプリがつなぐ GAS の URL を書く場所
/gas/             GAS に貼るコード（GitHub Pages では使わない）
  ekiden/         駅伝用プロジェクト：セーブの保存・読み込み
  news/           BMERadar用プロジェクト：収集・配信・朝のメール・しおり同期
```

GAS を分けているので、ニュースのコードを直している途中で壊しても駅伝のセーブには影響しない。
GAS の 1 日の利用上限は Google アカウント単位なので、分けても無料枠は変わらない。

## 1. GitHub Pages で公開する（zip をそのまま上げる方式）

1. リポジトリ `sora-apps` に `sora-apps.zip` を **解凍せずに** アップロードする（Add file → Upload files）。
   同じ名前の zip を上げ直すと上書きされる。
2. 初回だけ `.github/workflows/deploy.yml` を作る（Add file → Create new file に名前ごと入力し、中身を貼る）。
3. 初回だけ Settings → Pages → Source を「GitHub Actions」にする。
4. Actions タブで緑のチェックが付けば公開完了（1〜2分）。`https://<ユーザー名>.github.io/sora-apps/`

zip の中身を GitHub 上で展開しないので、フォルダ構成が崩れない。リポジトリに残っている古いファイルは無視される。

## 2. GAS プロジェクトを作る（アプリごとに 1 回ずつ）

https://script.google.com で「新しいプロジェクト」を作り、

| | 駅伝監督 | BMERadar |
|---|---|---|
| プロジェクト名（例） | `ekiden-save` | `bme-radar` |
| 貼るコード | `gas/ekiden/Code.gs` | `gas/news/Code.gs` |
| Drive にできるフォルダ | `ekiden-data` | `bme-radar-data` |
| setup で起きること | 合言葉の登録 | 合言葉の登録＋1時間ごとの収集＋毎朝のメール＋初回の収集（2〜4分） |

1. 最初からある `コード.gs` の中身を全部消して、表の「貼るコード」を貼り付ける。
2. 先頭近くの `PASS_PHRASE` を自分だけの合言葉に書き換える。
   BMERadarは `APP_URL` に `https://<ユーザー名>.github.io/sora-apps/news/` を入れておくと、メールの最後にアプリへのリンクが付く。
3. 関数選択で `setup` を選んで「実行」。権限の確認が出たら許可する
   （「このアプリは確認されていません」→「詳細」→「（安全でないページ）に移動」）。
   BMERadarは「外部サービスへの接続」「メールの送信」「Drive」の許可を求められる。
4. 右上「デプロイ」→「新しいデプロイ」→ 種類「ウェブアプリ」
   - 次のユーザーとして実行：自分
   - アクセスできるユーザー：全員
5. 表示された「ウェブアプリ URL」（`…/exec` で終わる）をコピーする。

> コードを直したときは「デプロイを管理」→ 鉛筆 →「バージョン：新バージョン」で更新すると URL が変わらない。

## 3. アプリと GAS をつなぐ

- アプリの「設定」に URL と合言葉を入れる。合言葉は config.js には書かない（リポジトリは公開されるため）。
- URL だけは `ekiden/config.js`・`news/config.js` の `gasUrl: ''` に書いておくこともできる。

### 駅伝監督
- 「設定 → クラウド保存」で合言葉を入れて「接続を確認」。
- 「進めるたびに自動で保存する」を ON にしておくと、練習を進めたり大会が終わるたびに保存される。
- 別の端末ではタイトル画面の「クラウドから続き」で再開できる。バックアップは日ごとに 5 日分。

### BMERadar
- 画面は「今日／BCI／新着／しおり／傾向／設定」。
- 集めるもの（`gas/news/Code.gs` 先頭の `SOURCES`、約 70 か所）
  - ニュース：Google ニュース検索（英語・日本語）、MedTech Dive、Fierce MedTech、MassDevice、Medical Design & Outsourcing、Medgadget、MobiHealthNews、STAT、IEEE Spectrum、Neuroscience News、ScienceDaily、EurekAlert!、MONOist
  - 論文：Nature Biomedical Engineering、npj Digital Medicine、Journal of Neural Engineering、PubMed（主要誌と分野別の検索）、arXiv、bioRxiv
  - 承認・規制：FDA 510(k)・PMA・クラスIリコール・プレスリリース、PMDA、厚生労働省
  - 臨床試験：ClinicalTrials.gov に新しく登録された医療機器の試験
  - 企業・資金：資金調達・買収のニュース、BCI 企業（Neuralink、Synchron、Precision など）の資金・評価額のニュース
  - 大学・研究機関：アプリの設定「注目する大学・研究機関」に入れた大学（最初は国内外 35 か所）を Google ニュースで 2 時間おきに検索。記事に大学名の印が付く。
  - 大学・研究機関：BCI の研究発表（英語・日本語）、MIT News、理化学研究所、東京農工大学、大学ジャーナル、JST、学会・AMED・NIH の公募
- BCI に関わる記事には「BCI」の印が付き、BCI タブに集まる（14 日分）。
- 株価：設定の銘柄を 15 分ごとに取得（Yahoo Finance、だめなら Stooq）。1M／6M／1Y の推移と関連記事が見られる。Neuralink などの非上場企業は株価がないので、資金調達・提携の記事で動きを追う。
- 日本語訳：英語の見出しを GAS 内蔵の Google 翻訳（無料）で訳す。設定で表示の仕方を変えられる。
- Claude の日本語まとめ：毎朝 Claude のスケジュールタスクが `?v=brief-input` を読んでまとめを書き、`brief-save` で GAS に送る。「今日」「BCI」の先頭と朝のメールに出る。
  - Claude のクラウド環境から GAS に届くように、claude.ai（ブラウザ）の 設定 → Capabilities（機能）で、許可するドメインに `script.google.com` と `script.googleusercontent.com` を追加しておく。
  - アプリの「設定 → Claude の日本語まとめ → Claude に渡す設定文をコピー」で出る文を Claude に送ると、タスクを作ってくれる。
- 記事はアプリ内のリーダーで開く。GAS が記事のページから本文と画像を取り出し（Google ニュースのリンクは元の記事に変換、PubMed は要旨、ClinicalTrials.gov は試験の概要）、「日本語」を押すと本文を訳す。有料記事などで取り出せないときは要約と「元のページで読む」を出す。設定でオフにできる。
- 同じ話題を複数の媒体が報じたら 1 つにまとめ、「ほか N 件の報道」で開ける。
- 直近 30 日は高速に、それより前は月ごとのファイルに残り、検索の「過去1年分から探す」で引ける。
- 取得できない収集元は「設定 → 収集元」に赤字で出る。チェックを外せば止まる。

### コードを差し替えたとき（BMERadar）
1. GAS の Code.gs を全部消して新しいものを貼り、`PASS_PHRASE` を前と同じ合言葉に書き換える。
2. `setup` をもう一度実行する（新しい定期実行が登録される。翻訳の許可を求められたら許可）。
3. 「デプロイ」→「デプロイを管理」→ 鉛筆 →「バージョン：新バージョン」→「デプロイ」。URL は変わらない。

## 4. スマホのホーム画面に追加

- iPhone：Safari で `…/ekiden/` や `…/news/` を開き、共有 →「ホーム画面に追加」
- Android：Chrome で開き、メニュー →「アプリをインストール」

一度開けばオフラインでも使える（クラウド保存とニュースの更新はネット接続が必要）。

## 更新するとき

ファイルを差し替えて GitHub にアップロードすると、次にアプリを開いたときに自動で新しい版に切り替わる。
GAS のコードを差し替えたときは、上の「新バージョン」でデプロイし直す。
