/**
 * EKDNist — 大学駅伝のデータと分析（Google Apps Script ウェブアプリ。/ekdnist/ の PWA がここから読みます）
 *
 * 集めるもの
 *   箱根駅伝     公式サイトの記録ページ（第1回〜）を少しずつ読み、全大会・全区間・全選手を取り込みます。
 *   速報         月陸Online の「テキスト速報」を、レース中は5分ごとに読みます。「大会結果」が出たら総合順位と区間賞を取り込みます。
 *   歴代         出雲・全日本・女子・地区学連などの歴代優勝と区間記録は Wikipedia の表から。
 *   全区間の成績  箱根以外の全選手の記録は、区間ごとの表があるページの URL から取り込むか（import-url）、
 *                「司書」（Claude の定期タスク）が調べて送ります（import）。
 *   ニュース      月陸Online・Bing ニュース。アプリ内で本文を読めます。
 *
 * 箱根の公式サイトには 2.5 秒以上の間隔をあけ、1回に読むのは最大24ページです（全大会で約1,100ページ、半日ほどで揃います）。
 *
 *   GET  (no params)                 索引（大会一覧・速報・ニュース・通知）
 *   GET  ?v=db&s=<series>&ver=<ver>  大会シリーズ1つの全データ（コンパクト形式）
 *   GET  ?v=live                     速報        GET ?v=read&id=<news id>  本文
 *   GET  ?v=todo&key=<司書キー>       足りないデータの一覧（司書用）
 *   GET  ?v=vapid / ?v=push-latest
 *   POST {pass, action:'prefs-get'|'refresh'|'import-url'|'push-sub'|'push-unsub'|'push-test'}
 *   POST {key,  action:'import'|'hist'|'import-url'}      司書から
 *
 * はじめて: PASS_PHRASE を書き換え → setup() を実行 → デプロイ > 新しいデプロイ > ウェブアプリ（自分として実行 / 全員）。
 * checkHakone() は公式サイトの1大会を読んだ結果を、checkWiki() は Wikipedia の表の読み取り結果をログに出します。
 */
const PASS_PHRASE = 'ここを自分だけの合言葉に変える';
const APP_NAME = 'EKDNist';
const DATA_FOLDER = 'ekdnist-data';
const HK = 'https://www.hakone-ekiden.jp/record/';
const HK_GAP_MS = 2500, HK_MAX_PER_RUN = 24;
const NEET_FEED = 'https://blog.neet-shikakugets.com/feed';   // ほぼニートの資格取得日記: 区間ごとの全選手・通過順位をレース中から更新している
/* past results on the same blog, read one page every 20 minutes: [series, 回, year, date, path] */
const NEET = 'https://blog.neet-shikakugets.com/';
const NEET_BACKFILL = [
  ['izumo', 37, 2025, '2025-10-13', 'izumo-ekiden-2025'], ['zen', 57, 2025, '2025-11-02', 'zennihon-daigaku-ekiden-2025'], ['izumo', 36, 2024, '2024-10-14', 'izumo-ekiden-2024'], ['zen', 56, 2024, '2024-11-03', 'nihon-daigaku-ekiden-2024'],
  ['izumo', 35, 2023, '2023-10-09', 'izumo-ekiden-2023'], ['zen', 55, 2023, '2023-11-05', 'zennihon-daigaku-ekiden-2023'], ['izumo', 34, 2022, '2022-10-10', 'izumo-ekiden-2022'], ['zen', 54, 2022, '2022-11-06', 'zennihon-daigaku-ekiden-2022'],
  ['izumo', 33, 2021, '2021-10-10', 'izumo-ekiden-2021'], ['zen', 53, 2021, '2021-11-07', 'nihon-daigaku-ekiden-2021'], ['zen', 52, 2020, '2020-11-01', 'nihon-daigaku-ekiden-2020'],
  ['izumo', 31, 2019, '2019-10-14', 'izumo-ekiden-2019'], ['zen', 51, 2019, '2019-11-03', 'nihon-daigaku-ekiden-2019'], ['izumo', 30, 2018, '2018-10-08', 'izumo-ekiden-20181008-results'], ['zen', 50, 2018, '2018-11-04', 'zennihon-daigaku-ekiden-20181104-results'],
  ['izumo', 29, 2017, '2017-10-09', 'izumo-ekiden-20171009-results'], ['zen', 49, 2017, '2017-11-05', 'zennihon-daigaku-ekiden-20171105-results'], ['izumo', 28, 2016, '2016-10-10', 'izumo-ekiden-20161010-results'], ['zen', 48, 2016, '2016-11-06', 'zennihon-daigaku-ekiden-20161106-results'],
  ['izumo', 27, 2015, '2015-10-12', 'izumo-ekiden-20151012-results'], ['zen', 47, 2015, '2015-11-01', 'zennihon-daigaku-ekiden-20151101-results'],
  ['morinomiya', 43, 2025, '2025-10-26', 'daigaku-joshi-ekiden-2025'], ['morinomiya', 42, 2024, '2024-10-27', 'daigaku-joshi-ekiden-2024'], ['morinomiya', 41, 2023, '2023-10-29', 'daigaku-joshi-ekiden-2023'],
  ['morinomiya', 40, 2022, '2022-10-30', 'daigaku-joshi-ekiden-2022'], ['morinomiya', 39, 2021, '2021-10-31', 'daigaku-joshi-ekiden-2021'], ['morinomiya', 37, 2019, '2019-10-27', 'daigaku-joshi-ekiden-results-2019'],
  ['fujisan', 13, 2025, '2025-12-30', 'fujisan-joshi-ekiden-2015-results'], ['fujisan', 11, 2023, '2023-12-30', 'fujisan-joshi-ekiden-2023'], ['fujisan', 10, 2022, '2022-12-30', 'fujisan-joshi-ekiden-2022'],
  ['fujisan', 9, 2021, '2021-12-30', 'fujisan-joshi-ekiden-2021'], ['fujisan', 8, 2020, '2020-12-30', 'fujisan-joshi-ekiden-2020'], ['fujisan', 7, 2019, '2019-12-30', 'fujisan-joshi-ekiden-results-2019']
];
function neetBackfill_(st) {
  const nb = st.nb = st.nb || { done: {} };
  if (nb.at && Date.now() - nb.at < 20 * 6e4) return 'paced';
  const S0 = {}, job = NEET_BACKFILL.filter(function (j) { if (nb.done[j[0] + j[1]]) return false; const S = S0[j[0]] = S0[j[0]] || loadSeries_(j[0]), e = S.eds[j[1]]; return !(e && e.status === 'full'); })[0];
  if (!job) return 'all done';
  nb.at = Date.now();
  try { const r = importUrl_(job[0], job[1], NEET + job[4], { year: job[2], date: job[3] }); nb.done[job[0] + job[1]] = Date.now(); st.dirty = st.dirty || {}; st.dirty[job[0]] = 1; return r; }
  catch (e) { if (!/HTTP 5|429|403|休んで/.test(e.message)) nb.done[job[0] + job[1]] = -1; throw e; }
}
const GT_FEEDS = ['https://www.rikujyokyogi.co.jp/feed', 'https://www.rikujyokyogi.co.jp/?s=%E3%83%86%E3%82%AD%E3%82%B9%E3%83%88%E9%80%9F%E5%A0%B1&feed=rss2', 'https://www.rikujyokyogi.co.jp/?s=%E5%A4%A7%E4%BC%9A%E7%B5%90%E6%9E%9C+%E9%A7%85%E4%BC%9D&feed=rss2'];
const NEWS_SOURCES = [
  { id: 'gt', name: '月陸Online', kind: 'rss', url: 'https://www.rikujyokyogi.co.jp/feed' },
  { id: 'bn-ekiden', name: 'Bing ニュース', kind: 'bing', q: '大学駅伝' },
  { id: 'bn-hakone', name: 'Bing ニュース', kind: 'bing', q: '箱根駅伝' },
  { id: 'bn-izumo', name: 'Bing ニュース', kind: 'bing', q: '出雲駅伝 OR 全日本大学駅伝 OR 杜の都駅伝 OR 富士山女子駅伝' }
];

/* 大会シリーズ. dist = 現行コースの区間距離 (km), since = 現行コースになった回（歴代ランキングはここから） */
const SERIES = [
  { key: 'hakone', name: '箱根駅伝', full: '東京箱根間往復大学駅伝競走', legs: 10, dist: [21.3, 23.1, 21.4, 20.9, 20.8, 20.8, 21.3, 21.4, 23.1, 23.0], openRe: /連合|選抜/,
    since: [55, 59, 55, 93, 93, 82, 59, 55, 59, 75], month: 1, nOff: 1924,
    // コース: [始まりの回, 終わりの回, 距離km]（新しい順）。歴代ランキングはここで区切って選べる
    eras: [[[55, null, 21.3], [1, 54]], [[59, null, 23.1], [1, 58]], [[55, null, 21.4], [1, 54]], [[93, null, 20.9], [82, 92, 18.5], [1, 81]], [[93, null, 20.8], [90, 92, 23.2], [82, 89, 23.4], [1, 81]],
      [[82, null, 20.8], [1, 81]], [[59, null, 21.3], [1, 58]], [[55, null, 21.4], [1, 54]], [[59, null, 23.1], [1, 58]], [[75, null, 23.0], [1, 74]]],
    totalEras: [[93, null, 217.1], [82, 92], [1, 81]],
    tags: [['平地', 'スタート'], ['エース', '起伏'], ['平地'], ['平地'], ['上り', '山'], ['下り', '山'], ['平地'], ['起伏'], ['エース', '平地'], ['平地', 'アンカー']],
    wiki: ['東京箱根間往復大学駅伝競走'] },
  { key: 'izumo', name: '出雲駅伝', full: '出雲全日本大学選抜駅伝競走', legs: 6, dist: [8.0, 5.8, 8.5, 6.2, 6.4, 10.2], since: 27, month: 10, nOff: 1988,
    eras: [0, 1, 2, 3, 4, 5].map(function (i) { return [[27, null, [8.0, 5.8, 8.5, 6.2, 6.4, 10.2][i]], [21, 26], [13, 20], [1, 12]]; }), totalEras: [[27, null, 45.1], [21, 26, 44.5], [13, 20, 44.0], [1, 12]],
    tags: [['スタート'], ['平地'], ['エース'], ['平地'], ['平地'], ['アンカー']], wiki: ['出雲全日本大学選抜駅伝競走'] },
  { key: 'zen', name: '全日本大学駅伝', full: '全日本大学駅伝対校選手権大会', legs: 8, dist: [9.5, 11.1, 11.9, 11.8, 12.4, 12.8, 17.6, 19.7], since: [50, 50, 50, 50, 50, 50, 50, 22], month: 11, openRe: /学連選抜|連合/, nOff: 1968,
    eras: [[[50, null, 9.5], [22, 49, 14.6], [1, 21]], [[50, null, 11.1], [22, 49, 13.2], [1, 21]], [[50, null, 11.9], [22, 49, 9.5], [1, 21]], [[50, null, 11.8], [22, 49, 14.0], [1, 21]],
      [[50, null, 12.4], [24, 49, 11.6], [1, 23]], [[50, null, 12.8], [24, 49, 12.3], [1, 23]], [[50, null, 17.6], [22, 49, 11.9], [1, 21]], [[22, null, 19.7], [1, 21]]],
    totalEras: [[50, null, 106.8], [24, 49], [1, 23]],
    tags: [['スタート'], ['エース'], ['平地'], ['平地'], ['平地'], ['平地'], ['エース'], ['アンカー']], wiki: ['全日本大学駅伝対校選手権大会', '全日本大学駅伝対校選手権大会の記録一覧'] },
  { key: 'yosen', name: '箱根駅伝予選会', full: '東京箱根間往復大学駅伝競走予選会', legs: 0, indivKm: 21.0975, month: 10, nOff: 1923, wiki: ['東京箱根間往復大学駅伝競走予選会'] },
  { key: 'zsel', name: '全日本 関東選考会', full: '全日本大学駅伝対校選手権大会 関東学生陸上競技連盟推薦校選考会', legs: 0, indivKm: 10, month: 6, wiki: [] },
  { key: 'morinomiya', name: '杜の都駅伝', full: '全日本大学女子駅伝対校選手権大会', women: true, legs: 6, month: 10, nOff: 1982, wiki: ['全日本大学女子駅伝対校選手権大会'] },
  { key: 'fujisan', name: '富士山女子駅伝', full: '全日本大学女子選抜駅伝競走', women: true, legs: 7, month: 12, wiki: ['全日本大学女子選抜駅伝競走', '富士山女子駅伝'] },
  { key: 'kwj', name: '関東大学女子駅伝', full: '関東大学女子駅伝対校選手権大会', women: true, legs: 6, month: 10, wiki: ['関東大学女子駅伝対校選手権大会', '関東大学女子駅伝'] },
  { key: 'oga', name: '男鹿駅伝', full: '男鹿駅伝競走大会', legs: 7, month: 6, wiki: ['男鹿駅伝競走大会', '男鹿駅伝'] },
  { key: 'tokai', name: '東海学生駅伝', full: '東海学生駅伝対校選手権大会', region: true, month: 12, wiki: ['東海学生駅伝対校選手権大会'] },
  { key: 'kansai', name: '丹後大学駅伝', full: '関西学生対校駅伝競走大会', region: true, month: 11, wiki: ['丹後大学駅伝', '関西学生対校駅伝競走大会'] },
  { key: 'kyushu', name: '九州学生駅伝', full: '九州学生駅伝対校選手権大会', region: true, month: 10, wiki: ['九州学生駅伝対校選手権大会'] },
  { key: 'hokushinetsu', name: '北信越学生駅伝', full: '北信越学生駅伝対校選手権大会', region: true, month: 10, wiki: ['北信越学生駅伝対校選手権大会'] },
  { key: 'chushikoku', name: '中国四国学生駅伝', full: '中国四国学生駅伝対校選手権大会', region: true, month: 11, wiki: ['中国四国学生駅伝対校選手権大会'] },
  { key: 'tohoku', name: '東北学生駅伝', full: '東北学生駅伝対校選手権大会', region: true, month: 10, wiki: ['東北学生駅伝対校選手権大会'] },
  { key: 'hokkaido', name: '北海道学生駅伝', full: '北海道学生駅伝対校選手権大会', region: true, month: 9, wiki: ['北海道学生駅伝対校選手権大会'] }
];
// トラックの記録（5000m・10000m・ハーフ）: 大会ではないが、選手の「今の調子」に使う
SERIES.push({ key: 'track', name: 'トラック', full: 'トラック・ロードの記録', track: true, legs: 0, wiki: [] });
const SERIES_BY = {}; SERIES.forEach(function (s) { SERIES_BY[s.key] = s; });

/* ========== setup / triggers ========== */
function setup() {
  if (!PASS_PHRASE || PASS_PHRASE.indexOf('ここを') === 0) throw new Error('PASS_PHRASE を書き換えてから実行してください');
  PropertiesService.getScriptProperties().setProperty('PASS', PASS_PHRASE);
  dataFolder_(); librarianKey_(); vapid_();
  applySeed_();
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'tick' || t.getHandlerFunction() === 'liveTick') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('tick').timeBased().everyMinutes(5).create();
  ScriptApp.newTrigger('liveTick').timeBased().everyMinutes(1).create();   // does nothing unless a race is on
  const r = tick(true);
  Logger.log('準備完了: ' + JSON.stringify(r));
  Logger.log('司書キー: ' + librarianKey_() + '（URL は「デプロイを管理」の /exec で終わるもの）');
}
function librarianSetup() { Logger.log('EKDNist 司書セットアップ\nGAS URL: 「デプロイを管理」に出ている /exec で終わる URL（エディタから実行すると /dev の URL しか取れません）\n司書キー: ' + librarianKey_()); }
const JOBS = [   // [key, every (ms), function]
  ['hkIndex', 20 * 36e5, function (st) { return hkIndex_(st); }],
  ['news', 50 * 6e4, function (st) { return updateNews_(st); }],
  ['wiki', 4 * 36e5, function (st) { return updateWiki_(st); }]
];
function tick(force) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(3000)) return { busy: true };
  const t0 = Date.now(), log = {};
  FETCH_N_ = 0; HK_N_ = 0; HK_LAST_ = 0;
  try {
    const st = readJson_('state.json', { at: {}, status: {}, hk: {}, live: null, seen: {} });
    st.at = st.at || {}; st.status = st.status || {}; st.hk = st.hk || {}; st.seen = st.seen || {};
    safe_(st, 'live', function () { log.live = updateLive_(st, force === true); });
    JOBS.forEach(function (j) {
      if (!(force === true || !st.at[j[0]] || Date.now() - st.at[j[0]] > j[1])) return;
      safe_(st, j[0], function () { log[j[0]] = j[2](st); st.at[j[0]] = Date.now(); });
    });
    safe_(st, 'backfill', function () { log.backfill = neetBackfill_(st); });
    if (spent_(st) < 35 * 6e4) safe_(st, 'hakone', function () { log.hakone = crawlHakone_(st); });   // the official-record crawl stops for the day after 35 minutes
    safe_(st, 'build', function () { log.build = buildDirty_(st); });
    st.updated = Date.now();
    spend_(st, Date.now() - t0);
    writeJson_('state.json', st);
    buildIndex_(st);
    log.pages = FETCH_N_; log.ms = Date.now() - t0;
    return log;
  } finally { lock.releaseLock(); }
}
/* Apps Script on a free account may run triggers for 90 minutes a day: keep count */
function spend_(st, ms) { const d = Utilities.formatDate(new Date(), 'Asia/Tokyo', 'yyyy-MM-dd'); if (!st.day || st.day.d !== d) st.day = { d: d, ms: 0 }; st.day.ms += ms; }
function spent_(st) { const d = Utilities.formatDate(new Date(), 'Asia/Tokyo', 'yyyy-MM-dd'); return st.day && st.day.d === d ? st.day.ms : 0; }
function safe_(st, key, fn) {
  try { fn(); st.status[key] = { ok: true, at: Date.now() }; }
  catch (e) { st.status[key] = { ok: false, at: Date.now(), error: String(e && e.message || e).slice(0, 160) }; Logger.log(key + ': ' + (e && e.stack || e)); }
}

/* ========== fetching ========== */
let FETCH_N_ = 0, HK_N_ = 0, HK_LAST_ = 0;
function fetchText_(url, opt) {
  opt = opt || {};
  const blog = /neet-shikakugets\.com/.test(url), props = PropertiesService.getScriptProperties();
  if (blog && +(props.getProperty('NEET_PAUSE') || 0) > Date.now()) throw new Error('ほぼニートの資格取得日記は少し休んでから読みます');
  FETCH_N_++;
  const r = UrlFetchApp.fetch(url, { muteHttpExceptions: true, followRedirects: true, headers: opt.headers || {} });
  const code = r.getResponseCode();
  if (code === 404 && opt.allow404) return null;
  if (blog && (code >= 500 || code === 429 || code === 403)) props.setProperty('NEET_PAUSE', String(Date.now() + 40 * 6e4));   // the site said no: leave it alone for 40 minutes
  if (code === 429) throw new Error('アクセスが多すぎると言われました (429)。次の回にまた読みます: ' + url.replace(/^https?:\/\//, '').slice(0, 60));
  if (code >= 400) throw new Error('HTTP ' + code + ' ' + url.replace(/^https?:\/\//, '').slice(0, 80));
  const ct = String((r.getHeaders() || {})['Content-Type'] || (r.getHeaders() || {})['content-type'] || '');
  let cs = (ct.match(/charset=([\w-]+)/i) || [])[1];
  if (!cs) { const head = r.getContentText('ISO-8859-1').slice(0, 3000); cs = (head.match(/<meta[^>]+charset\s*=\s*["']?([\w-]+)/i) || [])[1] || 'UTF-8'; }
  if (/shift_jis|sjis|x-sjis/i.test(cs)) cs = 'Shift_JIS';
  try { return r.getContentText(cs); } catch (e) { return r.getContentText(); }
}
function hk_(path) {
  if (HK_N_ >= HK_MAX_PER_RUN) throw new Error('budget');
  const wait = HK_LAST_ + HK_GAP_MS - Date.now(); if (HK_LAST_ && wait > 0) Utilities.sleep(wait);
  HK_N_++; HK_LAST_ = Date.now();
  return fetchText_(HK + path);
}

/* ========== storage: one file per series ========== */
function seriesFile_(key) { return 's_' + key + '.json'; }
function loadSeries_(key) { return readJson_(seriesFile_(key), { key: key, eds: {}, hist: {} }); }
function saveSeries_(S, st) { S.at = Date.now(); writeJson_(seriesFile_(S.key), S); if (st) { st.dirty = st.dirty || {}; st.dirty[S.key] = 1; } }
function markDirty_(key) { const st = readJson_('state.json', { at: {}, status: {}, hk: {} }); st.dirty = st.dirty || {}; st.dirty[key] = 1; writeJson_('state.json', st); }
/* merge an edition: full leg data wins over sums, never lose fields that are already there */
function mergeEdition_(S, ed) {
  const old = S.eds[ed.n] || {};
  const out = Object.assign({}, old, ed);
  ['teams', 'legs', 'indiv', 'awards', 'dist'].forEach(function (k) {
    const a = old[k], b = ed[k], size = function (x) { return !x ? 0 : k === 'legs' ? x.reduce(function (s, l) { return s + (l ? l.length : 0); }, 0) : x.length; };
    const official = function (x) { return k === 'legs' && x && x.some(function (l) { return (l || []).some(function (r) { return r.rid; }); }); };
    out[k] = official(a) && !official(b) && size(a) >= size(b) * 0.9 ? a : size(b) >= size(a) ? b : a;
    if (!out[k]) delete out[k];
  });
  out.src = Array.from(new Set([].concat(old.src || [], ed.src || []))).slice(0, 8);
  out.status = (out.legs && out.legs.some(function (l) { return l && l.length; })) || (out.indiv && out.indiv.length > 20) ? 'full' : out.teams && out.teams.length ? 'result' : out.status || 'winner';
  if (ed.live) out.status = 'live'; else if (ed.live === false) delete out.live;
  S.eds[ed.n] = out;
  return out;
}
function applySeed_() {
  Object.keys(SEED_EDS).forEach(function (k) {
    const S = loadSeries_(k); let ch = 0;
    SEED_EDS[k].forEach(function (ed) { if (!S.eds[ed.n] || S.eds[ed.n].status !== 'full') { mergeEdition_(S, ed); ch++; } });
    const H = SEED_HIST[k]; if (H && !(S.hist.winners || []).length) { S.hist = Object.assign({}, H, S.hist || {}); ch++; }
    if (ch) saveSeries_(S); markDirty_(k);
  });
}

/* ========== 箱根駅伝 公式記録 ========== */
function hkIndex_(st) {
  const html = hk_('tournaments.php'), list = hkTournaments(html), rows = hkWinnerRows(html);
  if (!list.length) throw new Error('大会一覧が読めませんでした（ページの形が変わったかもしれません）');
  st.hk.idx = list; st.hk.at = Date.now();
  const S = loadSeries_('hakone');
  S.hist.winners = rows.length ? rows : S.hist.winners || [];
  saveSeries_(S, st);
  const done = st.hk.done || {};
  // newest first; the latest edition is read again for two weeks after the race (the site fills it in over a few days)
  st.hk.q = list.map(function (x) { return x.n; }).filter(function (n) { return !done[n]; });
  const last = list[0];
  if (last && done[last.n] && Date.now() - done[last.n] < 14 * 864e5 && new Date().getMonth() === 0) st.hk.q.unshift(last.n);
  return { editions: list.length, todo: st.hk.q.length };
}
/* 大会一覧の表から歴代優勝（優勝校・総合・往路・復路） */
function hkWinnerRows(html) {
  const out = [];
  htmlTables(html).forEach(function (T) {
    T.rows.forEach(function (r) {
      const c0 = r.findIndex(function (c) { return hrefParam(c, 'tn') != null; }); if (c0 < 0) return;
      const m = hankaku(r[c0].t).match(/第\s*(\d+)\s*回\s*[（(]\s*(\d{4})/); if (!m) return;
      const ui = r.findIndex(function (c) { return hrefParam(c, 'university_id') != null; });
      const ts = r.slice(Math.max(ui, c0) + 1).map(function (c) { return parseTime(c.t); }).filter(function (x) { return x != null; });
      out.push({ n: +m[1], year: +m[2], u: ui >= 0 ? univCanon(r[ui].t) : '', t: ts[0] || null, out: ts[1] || null, ret: ts[2] || null });
    });
  });
  return out.sort(function (a, b) { return a.n - b.n; });
}
function crawlHakone_(st) {
  const idx = st.hk.idx; if (!idx || !idx.length) return 'no index yet';
  const tn = {}; idx.forEach(function (x) { tn[x.n] = x; });
  st.hk.done = st.hk.done || {};
  let S = null, got = 0;
  try {
    while (HK_N_ < HK_MAX_PER_RUN) {
      let cur = st.hk.cur;
      if (!cur) { const n = (st.hk.q || []).shift(); if (n == null) break; cur = st.hk.cur = { n: n, step: 0, legs: [] }; }
      const x = tn[cur.n]; if (!x) { st.hk.cur = null; continue; }
      if (cur.step === 0) { cur.teams = hkDetail(hk_('tournament-detail.php?tn=' + x.tn)); cur.step = 1; got++; continue; }
      if (cur.step <= 10) { cur.legs[cur.step - 1] = hkSection(hk_('tournament-section.php?tn=' + x.tn + '&section=' + cur.step)); cur.step++; got++; if (cur.step <= 10) continue; }
      // edition complete
      S = S || loadSeries_('hakone');
      mergeEdition_(S, { n: cur.n, year: x.year, date: x.year + '-01-02', teams: cur.teams, legs: cur.legs, src: [HK + 'tournament-detail.php?tn=' + x.tn] });
      st.hk.done[cur.n] = Date.now(); st.hk.cur = null;
    }
  } catch (e) { if (String(e.message) !== 'budget') throw e; }
  if (S) saveSeries_(S, st);
  return { pages: got, left: (st.hk.q || []).length + (st.hk.cur ? 1 : 0) };
}
/* ログ確認用: 最新大会の1区と5区、大会詳細を読んでみる */
function checkHakone() {
  HK_N_ = 0;
  const list = hkTournaments(hk_('tournaments.php'));
  Logger.log('大会一覧: ' + list.length + '件 ' + JSON.stringify(list.slice(0, 3)));
  if (!list.length) return;
  const x = list[0], d = hkDetail(hk_('tournament-detail.php?tn=' + x.tn));
  Logger.log('第' + x.n + '回 チーム: ' + d.length + '件 ' + JSON.stringify(d.slice(0, 3)));
  [1, 5].forEach(function (k) { const s = hkSection(hk_('tournament-section.php?tn=' + x.tn + '&section=' + k)); Logger.log(k + '区: ' + s.length + '人 ' + JSON.stringify(s.slice(0, 3))); });
}

/* ========== 月陸Online: 速報と大会結果 ========== */
function jstHour_() { return +Utilities.formatDate(new Date(), 'Asia/Tokyo', 'H'); }
function jstDay_() { return +Utilities.formatDate(new Date(), 'Asia/Tokyo', 'u'); }   // 1 = Mon … 7 = Sun
function updateLive_(st, force) {
  const now = Date.now(), L = st.live, h = jstHour_(), raceHours = h >= 7 && h <= 17;
  const weekendOrHoliday = jstDay_() >= 6 || isRaceDay_(new Date());
  const scanEvery = (raceHours && weekendOrHoliday) ? 4.5 * 6e4 : 30 * 6e4;
  const out = {};
  if (force || !st.at.gtScan || now - st.at.gtScan > scanEvery || (L && L.active)) {
    st.at.gtScan = now;
    let items = [];
    GT_FEEDS.forEach(function (u, i) { if (i > 0 && !(force || raceHours)) return; try { items = items.concat(parseFeed(fetchText_(u))); } catch (e) { out.feedErr = String(e.message).slice(0, 80); } });
    const seen = {};
    items = items.filter(function (it) { if (seen[it.link]) return false; seen[it.link] = 1; return true; });
    items.forEach(function (it) {
      const s = seriesOf(it.title), d = parseDate(it.date, 0);
      if (!s || !d || now - d > 12 * 36e5) return;
      if (/テキスト速報/.test(it.title) && (!st.live || st.live.url !== it.link)) {
        if (!st.live || !st.live.active || now - (st.live.started || 0) > 10 * 36e5) {
          st.live = { active: true, url: it.link, title: it.title, s: s, n: editionOf(it.title), started: d, legs: [], winners: [] };
          notify_('live', { title: SERIES_BY[s].name + ' 速報', body: it.title.replace(/【テキスト速報】/, '') + ' が始まりました', url: './#live', tag: 'ekd-live' });
        }
      }
      if (/大会結果|大会成績|個人成績/.test(it.title) && !st.seen[it.link]) {
        st.seen[it.link] = now;
        try { out.result = importResultArticle_(st, it, s); } catch (e) { out.resultErr = String(e.message).slice(0, 100); }
      }
    });
    // ほぼニートの資格取得日記: the post is updated through the race, and its feed date moves with it
    try {
      parseFeed(fetchText_(NEET_FEED)).forEach(function (it) {
        const info = neetTitle(it.title), d = parseDate(it.date, 0); if (!info || !d) return;
        const n = info.n || nOf_(info.s, info.year); if (!n) return;
        const key = 'neet2:' + it.link;
        if (st.seen[key] && st.seen[key] >= d) return;
        if (now - d < 10 * 36e5) { st.neetLive = st.neetLive || {}; st.neetLive[it.link] = { s: info.s, n: n, year: info.year, until: now + 8 * 36e5, title: it.title }; }
        else if (now - d > 60 * 864e5) return;
        try { out.neet = importNeet_(st, it.link, info.s, n, info.year, now - d < 10 * 36e5); st.seen[key] = d; } catch (e) { out.neetErr = String(e.message).slice(0, 100); }
      });
    } catch (e) { out.neetFeedErr = String(e.message).slice(0, 80); }
    Object.keys(st.seen).forEach(function (k) { if (now - st.seen[k] > 40 * 864e5) delete st.seen[k]; });
  }
  pollNeetLive_(st, out);
  PropertiesService.getScriptProperties().setProperty('LIVE_ON', (st.live && st.live.active) || Object.keys(st.neetLive || {}).length ? '1' : '');
  if (st.live && st.live.active) { refreshGtLive_(st); out.liveLegs = (st.live.legs || []).length; }
  return finishLive_(out);
}
function finishLive_(out) { return out; }
function refreshGtLive_(st) {
  const now = Date.now();
  {
    const lv = st.live, g = gtLive(fetchText_(lv.url));
    const known = {}; (lv.winners || []).forEach(function (w) { known[w.leg + '|' + w.nm] = 1; });
    g.winners.forEach(function (w) {
      if (known[w.leg + '|' + w.nm]) return;
      if (w.rec) notify_('live', { title: '区間新 ' + SERIES_BY[lv.s].name + ' ' + w.leg + '区', body: w.nm + '（' + univShort(w.u) + '） ' + fmtTime(w.t), url: './#live', tag: 'ekd-rec-' + w.leg });
    });
    lv.legs = g.legs; lv.winners = g.winners; lv.at = now;
    if (now - lv.started > 10 * 36e5 || lv.done) lv.active = false;
    writeJson_('live.json', lv); cachePut_('live', JSON.stringify(lv));
  }
}

/* 毎分（レース中だけ働く）: 月陸のテキスト速報とほぼニートの記事を読み直す */
function liveTick() {
  if (PropertiesService.getScriptProperties().getProperty('LIVE_ON') !== '1') return 'idle';
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) return 'busy';
  const t0 = Date.now();
  FETCH_N_ = 0;
  try {
    const st = readJson_('state.json', { at: {}, status: {}, hk: {}, seen: {} }), out = {};
    st.status = st.status || {}; st.at = st.at || {};
    safe_(st, 'live', function () {
      if (st.live && st.live.active) refreshGtLive_(st);
      pollNeetLive_(st, out);
      PropertiesService.getScriptProperties().setProperty('LIVE_ON', (st.live && st.live.active) || Object.keys(st.neetLive || {}).length ? '1' : '');
    });
    if (st.dirty && Object.keys(st.dirty).length) { buildDirty_(st); }
    spend_(st, Date.now() - t0);
    writeJson_('state.json', st); buildIndex_(st);
    return out;
  } finally { lock.releaseLock(); }
}
function pollNeetLive_(st, out) {
  const now = Date.now(), L = st.neetLive || {};
  Object.keys(L).forEach(function (url) {
    const x = L[url];
    if (now > x.until || x.done) { delete L[url]; return; }
    try { const r = importNeet_(st, url, x.s, x.n, x.year, true); out.neetLive = r; if (r && r.complete && now - (x.completeAt || now) > 30 * 6e4) x.done = true; if (r && r.complete && !x.completeAt) x.completeAt = now; }
    catch (e) { out.neetLiveErr = String(e.message).slice(0, 100); }
  });
  st.neetLive = L;
}
function nOf_(s, year) {
  const c = SERIES_BY[s]; if (!c || !year) return null;
  if (c.nOff) return year - c.nOff;
  const W = (loadSeries_(s).hist || {}).winners || [], w = W.filter(function (x) { return x.year === year; })[0];
  return w ? w.n : null;
}
/* 1記事 → その大会（区間ごとの全選手・通過順位・チーム順位）。中身が変わったときだけ保存し、区間新と新しい区間の首位を通知 */
function importNeet_(st, url, s, n, year, live) {
  const html = fetchText_(url), r = neetResult(html), legNos = Object.keys(r.legs).map(Number).sort(function (a, b) { return a - b; });
  if (!legNos.length && !r.teams.length) return { s: s, n: n, empty: true };
  const sig = strHash(JSON.stringify([r.legs, r.teams]));
  st.neetSig = st.neetSig || {};
  const total = (SERIES_BY[s] || {}).legs || 0, complete = !!total && legNos.length >= total;
  if (st.neetSig[url] === sig) return { s: s, n: n, legs: legNos.length, same: true, complete: complete };
  const prevLegs = st.neetSig[url + '#legs'] || 0;
  st.neetSig[url] = sig; st.neetSig[url + '#legs'] = legNos.length;
  const legs = []; for (let i = 1; i <= legNos[legNos.length - 1]; i++) legs.push(r.legs[i] || []);
  const dist = []; Object.keys(r.km).forEach(function (k) { dist[k - 1] = r.km[k]; });
  const S0 = loadSeries_(s), had = S0.eds[n];
  const res = importEdition_(s, { n: n, year: year, date: had && had.date || (year && (SERIES_BY[s].month === 1 ? year + '-01-02' : '')) || '', legs: legs, teams: r.teams, dist: dist.length === total ? dist : null, src: [url], live: !!live && !complete }, 'neet');
  // notifications while the race is on: a new leg finished (its winner), and every 区間新
  if (live && legNos.length > prevLegs) {
    const leg = legNos[legNos.length - 1], runs = r.legs[leg] || [], top = runs.filter(function (x) { return x.lr === 1; });
    const lead = runs.filter(function (x) { return x.cr === 1; })[0];
    if (top.length) notify_('live', { title: SERIES_BY[s].name + ' ' + leg + '区', body: '区間賞 ' + top.map(function (x) { return x.nm + '（' + univShort(x.u) + '）' + fmtTime(x.t) + (x.rec ? ' 区間新' : ''); }).join('・') + (lead ? ' / 首位 ' + univShort(lead.u) : ''), url: './#race/' + s + '/' + n, tag: 'ekd-leg-' + s + '-' + leg });
  }
  if (complete && !(had && had.status === 'full' && !had.live)) {
    const w = r.teams.filter(function (t) { return t.rank === 1; })[0];
    if (w) notify_('result', { title: SERIES_BY[s].name + ' 結果', body: '優勝 ' + w.u + ' ' + fmtTime(w.t) + (w.rec ? '（' + w.rec + '）' : ''), url: './#race/' + s + '/' + n, tag: 'ekd-result-' + s });
  }
  st.dirty = st.dirty || {}; st.dirty[s] = 1;
  return Object.assign(res, { complete: complete, legs: legNos.length });
}
/* ログ確認用: ほぼニートの資格取得日記のフィードと、いちばん新しい大学駅伝の記事の読み取り */
function checkNeet() {
  const items = parseFeed(fetchText_(NEET_FEED));
  Logger.log('フィード: ' + items.length + '件 ' + items.slice(0, 5).map(function (x) { return x.title + ' ' + x.date; }).join(' / '));
  const it = items.filter(function (x) { return neetTitle(x.title); })[0];
  if (!it) { Logger.log('大学駅伝の結果記事はいまフィードにありません'); return; }
  const info = neetTitle(it.title), r = neetResult(fetchText_(it.link));
  Logger.log(it.title + ' → ' + JSON.stringify(info) + ' 第' + (info.n || nOf_(info.s, info.year)) + '回');
  Logger.log('区間: ' + Object.keys(r.legs).map(function (k) { return k + '区' + r.legs[k].length + '人'; }).join(' ') + ' / チーム ' + r.teams.length);
  const k = Object.keys(r.legs)[0]; if (k) Logger.log(JSON.stringify(r.legs[k].slice(0, 3)));
  if (!r.teams.length) Logger.log('チーム結果の行（読めなかったので見本）: ' + articleLines(fetchText_(it.link)).filter(function (l) { return /\d:\d\d:\d\d/.test(l); }).slice(0, 4).join(' / '));
  Logger.log(JSON.stringify(r.teams.slice(0, 3)));
}
/* 大会結果の記事 → その大会の総合順位・区間賞（・個人成績） */
function importResultArticle_(st, it, s) {
  const r = gtResult(fetchText_(it.link)), n = editionOf(it.title);
  if (!n || (!r.teams.length && !r.indiv.length && !r.awards.length)) return 'nothing to read';
  const S = loadSeries_(s), d = new Date(parseDate(it.date, Date.now()));
  const dm = hankaku(it.title).match(/(\d{4})年(\d{1,2})月(\d{1,2})日/);
  const date = dm ? dm[1] + '-' + ('0' + dm[2]).slice(-2) + '-' + ('0' + dm[3]).slice(-2) : Utilities.formatDate(d, 'Asia/Tokyo', 'yyyy-MM-dd');
  const ed = { n: n, year: +date.slice(0, 4), date: date, src: [it.link] };
  if (r.teams.length) ed.teams = r.teams.concat(r.open.map(function (o) { return { u: o.u, t: o.t, op: true, rank: null }; }));
  if (r.awards.length) { ed.awards = r.awards; const km = []; r.awards.forEach(function (a) { if (a.km) km[a.leg - 1] = a.km; }); if (km.length) ed.dist = km; }
  if (r.indiv.length) ed.indiv = (S.eds[n] && S.eds[n].indiv || []).length > r.indiv.length ? S.eds[n].indiv : r.indiv;
  const prev = S.eds[n];
  mergeEdition_(S, ed); saveSeries_(S, st);
  if (st.live && st.live.s === s) { st.live.done = true; st.live.active = false; }
  if (!prev || !prev.teams || !prev.teams.length) {
    const w = (r.teams[0] || {});
    if (w.u) notify_('result', { title: SERIES_BY[s].name + ' 結果', body: '優勝 ' + w.u + ' ' + fmtTime(w.t) + (w.rec ? '（' + w.rec + '）' : '') + (r.awards.some(function (a) { return a.rec; }) ? ' / 区間新 ' + r.awards.filter(function (a) { return a.rec; }).length : ''), url: './#race/' + s + '/' + n, tag: 'ekd-result-' + s });
  }
  return { s: s, n: n, teams: r.teams.length, awards: r.awards.length, indiv: r.indiv.length };
}
/* 例年の日程（祝日・週末の判定に使うだけ） */
function nthWeekday_(y, m, wd, k) { const d = new Date(y, m - 1, 1); const off = (wd - d.getDay() + 7) % 7; return new Date(y, m - 1, 1 + off + 7 * (k - 1)); }
function isRaceDay_(d) {
  const y = d.getFullYear(), md = (d.getMonth() + 1) * 100 + d.getDate();
  if (md === 102 || md === 103 || md === 1230) return true;
  const izumo = nthWeekday_(y, 10, 1, 2);
  return d.getMonth() === izumo.getMonth() && d.getDate() === izumo.getDate();
}
function calendar_() {
  const now = new Date(), y = now.getFullYear(), out = [];
  const add = function (s, d, note) { if (d.getTime() > now.getTime() - 864e5) out.push({ s: s, d: Utilities.formatDate(d, 'Asia/Tokyo', 'yyyy-MM-dd'), note: note || '' }); };
  [y, y + 1].forEach(function (Y) {
    add('hakone', new Date(Y, 0, 2), '往路 1/2・復路 1/3');
    add('yosen', nthWeekday_(Y, 10, 6, 3), '例年の日程から推定');
    add('izumo', nthWeekday_(Y, 10, 1, 2), 'スポーツの日');
    add('zen', nthWeekday_(Y, 11, 0, 1), '例年の日程から推定');
    add('morinomiya', (function () { const d = new Date(Y, 10, 0); d.setDate(d.getDate() - d.getDay()); return d; })(), '例年の日程から推定');
    add('fujisan', new Date(Y, 11, 30), '');
  });
  return out.sort(function (a, b) { return a.d < b.d ? -1 : 1; }).slice(0, 6);
}

/* ========== Wikipedia: 歴代優勝・区間記録 ========== */
const WIKI = 'https://ja.wikipedia.org/w/api.php';
function wikiApi_(params) {
  const q = Object.keys(params).map(function (k) { return k + '=' + encodeURIComponent(params[k]); }).join('&');
  return JSON.parse(fetchText_(WIKI + '?format=json&formatversion=2&' + q, { headers: { 'Api-User-Agent': 'EKDNist/1.0 (personal Google Apps Script)' } }));
}
function wikiResolve_(titles) {
  const j = wikiApi_({ action: 'query', titles: titles.join('|'), redirects: 1 });
  const pages = ((j.query || {}).pages || []).filter(function (p) { return !p.missing && !p.invalid; });
  return pages.map(function (p) { return p.title; });
}
function wikiTables_(title) {
  const j = wikiApi_({ action: 'parse', page: title, prop: 'text', redirects: 1 });
  return htmlTables(((j.parse || {}).text) || '');
}
function updateWiki_(st) {
  st.wiki = st.wiki || {};
  const due = SERIES.filter(function (s) { return s.wiki && s.wiki.length; }).sort(function (a, b) { return (st.wiki[a.key] || 0) - (st.wiki[b.key] || 0); })[0];
  if (!due) return 'none';
  st.wiki[due.key] = Date.now();
  const titles = wikiResolve_(due.wiki);
  if (!titles.length) return due.key + ': ページなし';
  let winners = [], recs = [], tops = {};
  titles.forEach(function (t) {
    const T = wikiTables_(t), w = wikiWinners(T), r = wikiLegRecords(T);
    if (w.filter(function (x) { return x.u; }).length > winners.filter(function (x) { return x.u; }).length) winners = w;
    recs = recs.concat(r.recs); Object.keys(r.tops).forEach(function (k) { if (!tops[k] || tops[k].length < r.tops[k].length) tops[k] = r.tops[k]; });
  });
  const S = loadSeries_(due.key);
  S.hist = S.hist || {};
  if (due.key !== 'hakone' && winners.filter(function (x) { return x.u; }).length >= ((S.hist.winners || []).filter(function (x) { return x.u; }).length)) S.hist.winners = winners;
  if (recs.length) S.hist.recs = recs;
  if (Object.keys(tops).length) S.hist.tops = tops;
  S.hist.wiki = titles; S.hist.wikiAt = Date.now();
  saveSeries_(S, st);
  return { s: due.key, pages: titles.length, winners: winners.length, recs: recs.length, tops: Object.keys(tops).length };
}
/* ログ確認用: 1シリーズの Wikipedia の表をどう読んだか */
function checkWiki(key) {
  const s = SERIES_BY[key || 'zen'], titles = wikiResolve_(s.wiki);
  Logger.log(s.name + ' → ' + JSON.stringify(titles));
  titles.forEach(function (t) {
    const T = wikiTables_(t);
    Logger.log(t + ': 表 ' + T.length + ' 個');
    T.slice(0, 40).forEach(function (x, i) { Logger.log('#' + i + ' [' + (x.head || '').slice(0, 30) + '] ' + x.rows.slice(0, 2).map(function (r) { return r.map(function (c) { return c.t.slice(0, 12); }).join(' | '); }).join(' // ')); });
    const w = wikiWinners(T), r = wikiLegRecords(T);
    Logger.log('歴代優勝 ' + w.length + '件: ' + JSON.stringify(w.slice(0, 3)) + ' … ' + JSON.stringify(w.slice(-2)));
    Logger.log('区間記録 ' + r.recs.length + '件: ' + JSON.stringify(r.recs.slice(0, 3)) + ' / 歴代10傑の表 ' + Object.keys(r.tops).join(', '));
  });
}

/* ========== 取り込み（司書 / URL） ========== */
function cleanRun_(r) {
  const t = typeof r.t === 'number' ? r.t : parseTime(r.t);
  return { nm: String(r.nm || r.name || '').trim().slice(0, 40), u: univCanon(r.u || r.univ || ''), g: r.g == null || r.g === '' ? null : Math.max(1, Math.min(9, +r.g || 0)) || null,
    t: t, lr: r.lr == null ? null : +r.lr || null, cr: r.cr == null ? null : +r.cr || null, op: !!r.op || OPEN_TEAM.test(String(r.u || '')), note: String(r.note || '').slice(0, 20) };
}
function importEdition_(s, ed, srcLabel) {
  if (!SERIES_BY[s]) throw new Error('unknown series ' + s);
  const n = +ed.n; if (!n || n < 1 || n > 300) throw new Error('bad edition number');
  let e = { n: n, year: +ed.year || null, date: String(ed.date || '').slice(0, 10), src: [].concat(ed.src || srcLabel || []).slice(0, 4) };
  if (ed.legs && ed.legs.length) {
    const legMap = {}; ed.legs.forEach(function (runs, i) { legMap[i + 1] = (runs || []).map(cleanRun_).filter(function (r) { return r.nm && r.u; }); });
    e = editionFromLegs(legMap, Object.assign({ openRe: SERIES_BY[s].openRe }, e));
    if (ed.teams && ed.teams.length) {   // keep the official order and 往路/復路 when they are given
      const given = {}; ed.teams.forEach(function (t) { given[univCanon(t.u)] = t; });
      const allRanked = e.teams.every(function (t) { return t.op || (given[t.u] && given[t.u].rank != null); });
      e.teams.forEach(function (t) { const g = given[t.u]; if (g) { if (g.rank != null && allRanked) t.rank = +g.rank; if (g.out) t.out = parseTime(g.out) || +g.out; if (g.ret) t.ret = parseTime(g.ret) || +g.ret; if (g.t) { const gt = typeof g.t === 'number' ? g.t : parseTime(g.t); if (gt && Math.abs(gt - t.t) > 2) t.check = gt; } } });
      e.teams.sort(function (a, b) { return (a.rank || 999) - (b.rank || 999) || a.t - b.t; });
    }
  } else if (ed.teams && ed.teams.length) {
    e.teams = ed.teams.map(function (t) { return { u: univCanon(t.u), rank: t.rank == null ? null : +t.rank, t: typeof t.t === 'number' ? t.t : parseTime(t.t), op: !!t.op || (SERIES_BY[s].openRe || OPEN_TEAM).test(univCanon(t.u)) }; });
  }
  if (ed.indiv && ed.indiv.length) e.indiv = ed.indiv.map(function (r, i) { const c = cleanRun_(r); c.rk = +r.rk || i + 1; return c; }).filter(function (r) { return r.nm && r.t; });
  if (ed.dist && ed.dist.length) e.dist = ed.dist.map(Number);
  if (ed.name) e.name = String(ed.name).slice(0, 60);
  e.live = !!ed.live; if (e.live) e.liveUntil = Date.now() + 8 * 36e5;
  const S = loadSeries_(s), out = mergeEdition_(S, e);
  saveSeries_(S); markDirty_(s);
  return { s: s, n: n, status: out.status, teams: (out.teams || []).length, runs: (out.legs || []).reduce(function (a, l) { return a + (l || []).length; }, 0), indiv: (out.indiv || []).length,
    checks: (out.teams || []).filter(function (t) { return t.check; }).map(function (t) { return t.u + ' 合計' + fmtTime(t.t) + ' / 発表' + fmtTime(t.check); }) };
}
function importUrl_(s, n, url, meta) {
  if (!/^https:\/\//.test(url)) throw new Error('https の URL を指定してください');
  const html = fetchText_(url);
  if (/neet-shikakugets\.com/.test(url)) { const r = neetResult(html), L = Object.keys(r.legs).sort(function (a, b) { return a - b; }); if (!L.length) throw new Error('区間ごとの表が見つかりませんでした');
    return importEdition_(s, Object.assign({ n: n, legs: L.map(function (k) { return r.legs[k]; }), teams: r.teams, src: [url] }, meta || {})); }
  const legs = importTables(html);
  if (!Object.keys(legs).length) throw new Error('区間ごとの表が見つかりませんでした');
  return importEdition_(s, Object.assign({ n: n, legs: Object.keys(legs).sort(function (a, b) { return a - b; }).map(function (k) { return legs[k]; }), src: [url] }, meta || {}));
}
/* 司書へ: 足りないもの（新しい大会から） */
function todo_() {
  const out = [];
  SERIES.forEach(function (s) {
    if (s.key === 'hakone' || s.track) return;   // 箱根は公式サイトから自動で揃う
    const S = loadSeries_(s.key), eds = S.eds || {}, W = (S.hist && S.hist.winners) || [];
    const known = {}; W.forEach(function (w) { if (!w.cancel) known[w.n] = w.year; }); Object.keys(eds).forEach(function (n) { known[n] = eds[n].year; });
    const ns = Object.keys(known).map(Number).sort(function (a, b) { return b - a; });
    ns.forEach(function (n) { const e = eds[n]; if (!e || e.status !== 'full') out.push({ s: s.key, name: s.name, full: s.full, n: n, year: known[n] || null, have: e ? e.status : 'none', legs: s.legs || 0, indiv: !s.legs }); });
    if (!ns.length) out.push({ s: s.key, name: s.name, full: s.full, n: null, year: null, have: 'none', legs: s.legs || 0, indiv: !s.legs, note: '歴代の回数が未取得。最新回から' });
  });
  out.sort(function (a, b) { return (b.year || 0) - (a.year || 0); });
  const N = readJson_('names.json', {}), need = {}, ay = new Date().getFullYear() - 5;
  SERIES.forEach(function (sr) { const S = loadSeries_(sr.key); Object.keys(S.eds || {}).forEach(function (n) { const e = S.eds[n]; if ((e.year || 0) < ay) return;
    (e.legs || []).concat([e.indiv || []]).forEach(function (runs) { (runs || []).forEach(function (r) { if (!isKatakanaName(r.nm)) return;
      const keys = nameKeys(r.nm); if (keys.some(function (k) { return N[k + '|' + r.u] || N[k]; })) return; need[keys[keys.length - 1] + '|' + r.u] = r.nm; }); }); }); });
  const T = loadSeries_('track'), recent = (T.marks || []).filter(function (m) { return Date.now() - Date.parse(m.date || 0) < 120 * 864e5; }).length;
  return { ok: true, track_recent_marks: recent, names_needed: Object.keys(need).slice(0, 80).map(function (k) { return { key: k, kana: need[k] }; }), now: Date.now(), series: SERIES.map(function (s) { return { key: s.key, name: s.name, full: s.full, legs: s.legs || 0, women: !!s.women }; }), todo: out.slice(0, 60),
    format: 'POST {key, action:"import", s, ed:{n, year, date:"YYYY-MM-DD", legs:[[{nm,u,g,t:"27:45",lr}] /*1区*/, …], teams:[{u,rank,t}], indiv:[{rk,nm,u,g,t}], src:["URL"]}}' };
}

/* ========== ニュース ========== */
function updateNews_(st) {
  const store = readJson_('news.json', { items: [] }), byId = {};
  store.items.forEach(function (x) { byId[x.id] = x; });
  let added = 0;
  NEWS_SOURCES.forEach(function (src) {
    try {
      const url = src.kind === 'bing' ? 'https://www.bing.com/news/search?format=rss&mkt=ja-JP&setlang=ja&q=' + encodeURIComponent(src.q) : src.url;
      parseFeed(fetchText_(url)).forEach(function (it) {
        if (src.kind === 'bing') { const m = String(it.link).match(/[?&]url=([^&]+)/); if (m) it.link = decodeURIComponent(m[1]); }
        const n = newsItem(it, { name: src.kind === 'bing' ? (it.source || src.name) : src.name }); if (!n || byId[n.id]) return;
        if (!n.d || Date.now() - n.d > 7 * 864e5) return;
        byId[n.id] = n; added++;
      });
    } catch (e) { Logger.log('news ' + src.id + ': ' + e); }
  });
  const items = Object.keys(byId).map(function (k) { return byId[k]; }).filter(function (x) { return Date.now() - x.d < 30 * 864e5; }).sort(function (a, b) { return b.d - a.d; }).slice(0, 200);
  writeJson_('news.json', { at: Date.now(), items: items });
  return added;
}
function readNews_(id) {
  const n = readJson_('news.json', { items: [] }).items.filter(function (x) { return x.id === id; })[0];
  if (!n) return { ok: false, error: 'not found' };
  const key = 'rd_' + id, hit = cacheGet_(key); if (hit) return JSON.parse(hit);
  let art = null, err = '';
  try { art = extractArticle(fetchText_(n.u), n.u); } catch (e) { err = String(e.message || e); }
  const out = { ok: !!(art && art.paras && art.paras.length), id: id, t: n.t, u: n.u, s: n.s, d: n.d, paras: art ? art.paras : [], img: art ? art.image : '', error: err };
  if (out.ok) cachePut_(key, JSON.stringify(out));
  return out;
}

/* ========== 通知 ========== */
const PUSH_TYPES = ['live', 'result', 'data'];
function notify_(type, msg) {
  if (!msg) return;
  const ev = readJson_('events.json', { list: [] });
  ev.list.unshift({ type: type, title: msg.title, body: msg.body, url: msg.url || './', at: Date.now(), tag: msg.tag || 'ekd-' + type });
  ev.list = ev.list.slice(0, 60); writeJson_('events.json', ev);
  const subs = readJson_('subs.json', { list: [] });
  const keep = subs.list.filter(function (s) { if (s.types && s.types[type] === false) return true; try { return !sendPush_(s).gone; } catch (e) { return true; } });
  if (keep.length !== subs.list.length) { subs.list = keep; writeJson_('subs.json', subs); }
}
function pushLatest_() { const e = readJson_('events.json', { list: [] }).list[0]; return e ? { ok: true, title: e.title, body: e.body, url: e.url, tag: e.tag } : { ok: true, title: APP_NAME, body: '新しい情報があります', url: './', tag: 'ekd' }; }

/* ========== アプリ向けのデータ ========== */
function buildDirty_(st) {
  const d = st.dirty || {}, done = [];
  Object.keys(d).forEach(function (k) { if (!SERIES_BY[k]) return; const S = loadSeries_(k), db = compactDb(S, SERIES_BY[k]); writeJson_('db_' + k + '.json', db); st.ver = st.ver || {}; st.ver[k] = db.ver; st.meta = st.meta || {}; st.meta[k] = db.E.map(function (e) { return [e.n, e.y, e.st]; }); done.push(k); });
  st.dirty = {};
  if (done.length && st.hk && (st.hk.q || []).length === 0 && !st.hk.cur && !st.hk.announced && st.hk.idx) { st.hk.announced = Date.now(); notify_('data', { title: APP_NAME, body: '箱根駅伝 第1回〜第' + st.hk.idx[0].n + '回の全区間データが揃いました', url: './#records' }); }
  return done;
}
function buildIndex_(st) {
  const news = readJson_('news.json', { items: [] }).items.slice(0, 80), ev = readJson_('events.json', { list: [] }).list.slice(0, 20);
  const series = SERIES.map(function (s) {
    const S = (st.meta || {})[s.key] || loadSeriesMeta_(s.key);
    return { key: s.key, name: s.name, full: s.full, women: !!s.women, region: !!s.region, legs: s.legs || 0, ver: (st.ver || {})[s.key] || 0, eds: S };
  });
  const hk = st.hk || {}, total = (hk.idx || []).length, done = Object.keys(hk.done || {}).length;
  const live = readJson_('live.json', null);
  const idx = { ok: true, now: Date.now(), updated: st.updated || Date.now(), series: series, live: live && (live.active || Date.now() - (live.at || 0) < 36e5) ? live : null, lastLive: live ? { s: live.s, n: live.n, title: live.title, at: live.at } : null,
    en: readJson_('names.json', {}),
    racing: Object.keys(st.neetLive || {}).map(function (u) { const x = st.neetLive[u]; return { s: x.s, n: x.n, title: x.title, url: u }; }),
    news: news, events: ev, cal: calendar_(), crawl: { hakone: { done: done, total: total, cur: hk.cur ? hk.cur.n : null } }, status: st.status };
  writeJson_('index.json', idx); cachePut_('index', JSON.stringify(idx));
  return idx;
}
function loadSeriesMeta_(key) { const db = readJson_('db_' + key + '.json', null); return db ? db.E.map(function (e) { return [e.n, e.y, e.st]; }) : []; }

/* ========== web endpoints ========== */
function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    switch (p.v) {
      case 'db': {
        const k = String(p.s || ''); if (!SERIES_BY[k]) return json_({ ok: false, error: 'unknown series' });
        const db = readJson_('db_' + k + '.json', null); if (!db) return json_({ ok: true, key: k, empty: true, ver: 0, E: [], U: [], R: [], H: {} });
        if (p.ver && String(db.ver) === String(p.ver)) return json_({ ok: true, key: k, same: true, ver: db.ver });
        return json_(Object.assign({ ok: true }, db));
      }
      case 'live': { let b = cacheGet_('live'); if (!b) b = JSON.stringify(readJson_('live.json', { active: false })); return ContentService.createTextOutput(b).setMimeType(ContentService.MimeType.JSON); }
      case 'read': return json_(readNews_(String(p.id || '')));
      case 'todo': if (String(p.key || '') !== librarianKey_()) return json_({ ok: false, error: 'auth' }); return json_(todo_());
      case 'vapid': return json_({ ok: true, key: vapid_().pub });
      case 'push-latest': return json_(pushLatest_());
    }
    let body = cacheGet_('index');
    if (!body) { body = JSON.stringify(readJson_('index.json', { ok: true, empty: true, series: [] })); cachePut_('index', body); }
    return ContentService.createTextOutput(body).setMimeType(ContentService.MimeType.JSON);
  } catch (err) { return json_({ ok: false, error: String(err && err.message || err) }); }
}
function doPost(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'bad request' }); }
  try {
    if (req.key) {
      if (req.key !== librarianKey_()) return json_({ ok: false, error: 'auth' });
      switch (req.action) {
        case 'import': return json_(Object.assign({ ok: true }, importEdition_(String(req.s), req.ed || {}, 'librarian')));
        case 'import-url': return json_(Object.assign({ ok: true }, importUrl_(String(req.s), +req.n, String(req.url || ''), req.meta)));
        case 'track': {   // [{nm, u, g, ev:"10000m"|"5000m"|"half", t:"28:05.12", date:"YYYY-MM-DD", meet, src}]
          const T = loadSeries_('track'), have = {}; T.marks = T.marks || [];
          T.marks.forEach(function (m) { have[normName(m.nm) + '|' + m.u + '|' + m.ev + '|' + m.date] = 1; });
          let k = 0;
          (req.marks || []).slice(0, 1500).forEach(function (m) {
            const ev = trackEvent(m.ev), t = markTime(m.t), u = univCanon(m.u || ''), nm = nfkc(m.nm || '').trim(), date = String(m.date || '').slice(0, 10);
            if (!ev || !t || !u || !nm || !/^\d{4}-\d\d-\d\d$/.test(date)) return;
            const key = normName(nm) + '|' + u + '|' + ev + '|' + date; if (have[key]) return; have[key] = 1;
            T.marks.push({ nm: nm, u: u, g: +m.g || null, ev: ev, t: t, date: date, meet: String(m.meet || '').slice(0, 40), src: String(m.src || '').slice(0, 200), w: !!m.women }); k++;
          });
          saveSeries_(T); markDirty_('track'); return json_({ ok: true, added: k, total: T.marks.length });
        }
        case 'status': {   // [{nm, u, kind:"injury"|"recovered"|"absent"|"note", note, date:"YYYY-MM-DD", src}]  ケガ・故障・欠場の報道
          const T = loadSeries_('track'), have = {}; T.status = T.status || [];
          T.status.forEach(function (x) { have[normName(x.nm) + '|' + x.u + '|' + x.kind + '|' + x.date] = 1; });
          let k = 0;
          (req.items || []).slice(0, 300).forEach(function (x) {
            const kind = /^(injury|recovered|absent|note)$/.test(x.kind) ? x.kind : null, u = univCanon(x.u || ''), nm = nfkc(x.nm || '').trim(), date = String(x.date || '').slice(0, 10);
            if (!kind || !u || !nm || !/^\d{4}-\d\d-\d\d$/.test(date) || !/^https?:\/\//.test(String(x.src || ''))) return;
            const key = normName(nm) + '|' + u + '|' + kind + '|' + date; if (have[key]) return; have[key] = 1;
            T.status.push({ nm: nm, u: u, kind: kind, note: String(x.note || '').slice(0, 120), date: date, src: String(x.src).slice(0, 200) }); k++;
          });
          saveSeries_(T); markDirty_('track'); return json_({ ok: true, added: k, total: T.status.length });
        }
        case 'names': {   // {"キピエゴ|山梨学院大学": "Brian Kipyego", …}  official English spellings of foreign students
          const N = readJson_('names.json', {}); let k = 0;
          Object.keys(req.names || {}).slice(0, 300).forEach(function (key) { const v = String(req.names[key] || '').trim().slice(0, 60); const kk = String(key).split('|'); if (!v || !/^[A-Za-z][A-Za-z .'-]+$/.test(v)) return; N[normName(kk[0]) + (kk[1] ? '|' + univCanon(kk[1]) : '')] = v; k++; });
          writeJson_('names.json', N); const st = readJson_('state.json', {}); buildIndex_(st); return json_({ ok: true, saved: k, total: Object.keys(N).length });
        }
        case 'hist': {
          const S = loadSeries_(String(req.s)); if (!SERIES_BY[S.key]) return json_({ ok: false, error: 'unknown series' });
          if (req.winners && req.winners.length) S.hist.winners = req.winners.map(function (w) { return { n: +w.n, year: +w.year || null, u: univCanon(w.u), t: typeof w.t === 'number' ? w.t : parseTime(w.t), u2: univCanon(w.u2 || ''), u3: univCanon(w.u3 || ''), cancel: !!w.cancel }; }).filter(function (w) { return w.n; });
          if (req.recs && req.recs.length) S.hist.recs = req.recs.map(function (r) { return { leg: +r.leg, t: typeof r.t === 'number' ? r.t : parseTime(r.t), nm: String(r.nm || ''), u: univCanon(r.u || ''), n: +r.n || null, year: +r.year || null }; });
          saveSeries_(S); markDirty_(S.key); return json_({ ok: true, winners: (S.hist.winners || []).length, recs: (S.hist.recs || []).length });
        }
      }
      return json_({ ok: false, error: 'unknown action' });
    }
    if (!checkPass_(req.pass)) return json_({ ok: false, error: 'auth' });
    switch (req.action) {
      case 'prefs-get': { const subs = readJson_('subs.json', { list: [] }).list, me = subs.filter(function (x) { return x.endpoint === req.endpoint; })[0];
        return json_({ ok: true, librarianKey: librarianKey_(), url: ScriptApp.getService().getUrl(), push: { devices: subs.length, registered: !!me, types: me ? me.types : null, tick: ScriptApp.getProjectTriggers().some(function (t) { return t.getHandlerFunction() === 'tick'; }) } }); }
      case 'refresh': { const r = tick(true); return json_(r.busy ? { ok: false, error: 'busy' } : Object.assign({ ok: true }, r)); }
      case 'import-url': { const r = importUrl_(String(req.s), +req.n, String(req.url || ''), req.meta); const lock = LockService.getScriptLock(); if (lock.tryLock(20000)) { try { const st = readJson_('state.json', {}); buildDirty_(st); writeJson_('state.json', st); buildIndex_(st); } finally { lock.releaseLock(); } } return json_(Object.assign({ ok: true }, r)); }
      case 'push-sub': {
        if (!req.sub || !/^https:\/\//.test(req.sub.endpoint || '')) return json_({ ok: false, error: 'bad subscription' });
        const subs = readJson_('subs.json', { list: [] }), types = {};
        PUSH_TYPES.forEach(function (t) { types[t] = !(req.types && req.types[t] === false); });
        subs.list = subs.list.filter(function (x) { return x.endpoint !== req.sub.endpoint; }).concat([{ endpoint: req.sub.endpoint, types: types, label: String(req.label || '').slice(0, 30), at: Date.now() }]).slice(-10);
        writeJson_('subs.json', subs); return json_({ ok: true, count: subs.list.length });
      }
      case 'push-unsub': { const subs = readJson_('subs.json', { list: [] }); subs.list = subs.list.filter(function (x) { return x.endpoint !== req.endpoint; }); writeJson_('subs.json', subs); return json_({ ok: true }); }
      case 'push-test': {
        const s = readJson_('subs.json', { list: [] }).list.filter(function (x) { return x.endpoint === req.endpoint; })[0];
        if (!s) return json_({ ok: false, error: 'この端末は登録されていません' });
        const ev = readJson_('events.json', { list: [] }); ev.list.unshift({ type: 'test', title: APP_NAME, body: 'テスト通知です', url: './', at: Date.now(), tag: 'ekd-test' }); writeJson_('events.json', ev);
        const r = sendPush_(s); return json_({ ok: r.ok, code: r.code, error: r.ok ? '' : '通知サービスに断られました (' + r.code + ')' });
      }
    }
    return json_({ ok: false, error: 'unknown action' });
  } catch (err) { return json_({ ok: false, error: String(err && err.message || err) }); }
}
function librarianKey_() {
  const props = PropertiesService.getScriptProperties();
  let k = props.getProperty('LIB_KEY');
  if (!k) { k = Utilities.getUuid().replace(/-/g, ''); props.setProperty('LIB_KEY', k); }
  return k;
}

/* ======================================================================
 * EKDNist — page readers (pure functions: no network, no storage)
 *   htmlTables      any HTML table → rows of cells (rowspan / colspan filled in)
 *   hk*             箱根駅伝 公式サイトの記録ページ (hakone-ekiden.jp/record/)
 *   gt*             月陸Online の「テキスト速報」「大会結果」記事
 *   wiki*           Wikipedia の歴代優勝・区間記録の表
 *   importTables    区間ごとの成績表が並ぶページ（区間順位・選手・大学・タイム）
 * ====================================================================== */

/* ---------- text and numbers ---------- */
const ZEN_DIGITS = /[０-９：．]/g;
function hankaku(s) { return String(s == null ? '' : s).replace(ZEN_DIGITS, function (c) { return c === '：' ? ':' : c === '．' ? '.' : String.fromCharCode(c.charCodeAt(0) - 0xFEE0); }); }
function cellText(html) { return decodeEntities(String(html || '').replace(/<br\s*\/?>/gi, ' ').replace(/<(script|style)\b[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ')).replace(/[\s　]+/g, ' ').trim(); }
/* "1時間7分16秒" "59分47秒" "2:04:20" "27:45" "1:00:39" → seconds */
function parseTime(s) {
  s = hankaku(s).replace(/\s+/g, ''); let m;
  if ((m = s.match(/(\d+)時間(\d+)分(\d+)秒/))) return +m[1] * 3600 + +m[2] * 60 + +m[3];
  if ((m = s.match(/(\d+)時間(\d+)分/)) && !/秒/.test(s)) return +m[1] * 3600 + +m[2] * 60;
  if ((m = s.match(/(\d+)分(\d+)秒/))) return +m[1] * 60 + +m[2];
  if ((m = s.match(/(\d+):(\d\d):(\d\d)/))) return +m[1] * 3600 + +m[2] * 60 + +m[3];
  if ((m = s.match(/(\d+):(\d\d)(?![:\d])/))) return +m[1] * 60 + +m[2];
  return null;
}
function fmtTime(t) {
  if (t == null || !isFinite(t)) return '';
  t = Math.round(t); const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
  return h ? h + ':' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s : m + ':' + (s < 10 ? '0' : '') + s;
}
const NAME_VARIANTS = { '髙': '高', '﨑': '崎', '𣘺': '橋', '槗': '橋', '𠮷': '吉', '邊': '辺', '邉': '辺', '濵': '浜', '瀨': '瀬', '德': '徳', '惠': '恵', '曻': '昇', '靑': '青', '冨': '富', '晴': '晴', '桒': '桑', '舘': '館', '嶋': '島', '嵜': '崎', '﨔': '欅', '隆': '隆', 'ヶ': 'ケ' };
function nfkc(s) { s = String(s == null ? '' : s); try { return s.normalize('NFKC'); } catch (e) { return s; } }
function normName(s) {
  s = nfkc(s).replace(/[\s　・.．･]/g, '');
  return s.split('').map(function (c) { return NAME_VARIANTS[c] || c; }).join('').replace(/[︀-️]/g, '');
}
function isKatakanaName(s) { return /^[゠-ヿ\s　・.．A-Za-zＡ-Ｚ]+$/.test(nfkc(s).trim()); }
/* foreign students appear as "S.キップケメイ", "シャドラック キップケメイ" or just "キップケメイ": match on any long token */
function nameKeys(s) {
  s = nfkc(s).trim();
  if (!isKatakanaName(s)) return [normName(s)];
  const toks = s.split(/[\s　・.．]+/).filter(function (t) { return t.length >= 3 && /[゠-ヿ]/.test(t); });
  return toks.length ? toks.map(normName) : [normName(s)];
}

/* ---------- universities: one spelling for every short form ---------- */
const UNIV_ABBR = {
  '青学大': '青山学院大学', '青学': '青山学院大学', '國學院大': '國學院大學', '国学院大': '國學院大學', '國學院大学': '國學院大學', '国学院大学': '國學院大學', '国學院大學': '國學院大學',
  '駒大': '駒澤大学', '駒沢大': '駒澤大学', '駒澤大': '駒澤大学', '駒沢大学': '駒澤大学', '早大': '早稲田大学', '中大': '中央大学', '順大': '順天堂大学', '日大': '日本大学',
  '神大': '神奈川大学', '中央学大': '中央学院大学', '中央学院大': '中央学院大学', '山梨学大': '山梨学院大学', '山梨学院大': '山梨学院大学', '大東大': '大東文化大学', '大東文化大': '大東文化大学',
  '東農大': '東京農業大学', '東京農大': '東京農業大学', '東京農業大': '東京農業大学', '専大': '専修大学', '日体大': '日本体育大学', '法大': '法政大学', '国士大': '国士舘大学', '国士舘大': '国士舘大学',
  '明大': '明治大学', '武蔵野学大': '武蔵野学院大学', '麗沢大': '麗澤大学', '麗澤大': '麗澤大学', '拓大': '拓殖大学', '明学大': '明治学院大学', '流経大': '流通経済大学', '亜大': '亜細亜大学',
  '芝工大': '芝浦工業大学', '芝浦工大': '芝浦工業大学', '慶大': '慶應義塾大学', '慶應大': '慶應義塾大学', '慶応大': '慶應義塾大学', '慶應義塾大': '慶應義塾大学', '東経大': '東京経済大学',
  '東大': '東京大学', '東工大': '東京工業大学', '関大': '関西大学', '関学大': '関西学院大学', '関西学院大': '関西学院大学', '京産大': '京都産業大学', '京都産業大': '京都産業大学',
  '立命大': '立命館大学', '立命館大': '立命館大学', '大経大': '大阪経済大学', '大阪経済大': '大阪経済大学', '広経大': '広島経済大学', '広島経済大': '広島経済大学', '北大': '北海道大学',
  '皇学館大': '皇學館大学', '皇學館大': '皇學館大学', '愛知工大': '愛知工業大学', '志學館大': '志學館大学', '志学館大': '志學館大学', '名城大': '名城大学', '筑波大': '筑波大学',
  '東洋大': '東洋大学', '創価大': '創価大学', '城西大': '城西大学', '帝京大': '帝京大学', '東海大': '東海大学', '神奈川大': '神奈川大学', '立教大': '立教大学', '東京国際大': '東京国際大学',
  '駿河台大': '駿河台大学', '上武大': '上武大学', '平成国際大': '平成国際大学', '育英大': '育英大学', '関東学院大': '関東学院大学', '立正大': '立正大学', '桜美林大': '桜美林大学', '一橋大': '一橋大学',
  '日本薬科大': '日本薬科大学', '信州大': '信州大学', '札幌学院大': '札幌学院大学', '金沢学院大': '金沢学院大学', '第一工科大': '第一工科大学', '東北大': '東北大学', '岐阜協立大': '岐阜協立大学',
  '日本文理大': '日本文理大学', '第一工大': '第一工科大学', '環太平洋大': '環太平洋大学', '大阪体育大': '大阪体育大学', '大体大': '大阪体育大学', '鹿屋体大': '鹿屋体育大学', '鹿屋体育大': '鹿屋体育大学',
  '仙台大': '仙台大学', '東北福祉大': '東北福祉大学', '新潟医福大': '新潟医療福祉大学', '新潟医療福祉大': '新潟医療福祉大学', '中京大': '中京大学', '愛院大': '愛知学院大学', '愛知学院大': '愛知学院大学',
  '星槎道都大': '星槎道都大学', '白鷗大': '白鷗大学', '白鴎大': '白鷗大学', '城西国際大': '城西国際大学', '松山大': '松山大学', '名城': '名城大学', '大阪学院大': '大阪学院大学', '佛教大': '佛教大学', '仏教大': '佛教大学',
  '日女体大': '日本女子体育大学', '日本女子体育大': '日本女子体育大学', '東農': '東京農業大学', '玉川大': '玉川大学', '大東': '大東文化大学', '拓殖大': '拓殖大学', '東京国際': '東京国際大学',
  '武庫川女大': '武庫川女子大学', '武庫川女子大': '武庫川女子大学', '京都光華女子大': '京都光華女子大学', '大阪芸大': '大阪芸術大学', '立命館': '立命館大学', '天理大': '天理大学',
  '福岡大': '福岡大学', '至学館大': '至学館大学', '環太平洋': '環太平洋大学', '松山': '松山大学', '東北学院大': '東北学院大学', '帝京科学大': '帝京科学大学', '日本体育大': '日本体育大学'
};
const OPEN_TEAM = /連合|オープン|ＯＰ|^OP$|混成/;   // 出雲の「学連選抜」「アイビーリーグ選抜」は順位がつくので入れない
function univCanon(s) {
  s = String(s || '').replace(/[\s　]/g, '').replace(/\(.*?\)|（.*?）/g, '');
  if (!s) return '';
  if (UNIV_ABBR[s]) return UNIV_ABBR[s];
  if (s === 'アイビー') return 'アイビーリーグ選抜';
  if (/選抜|連合/.test(s)) return s;
  if (/大学院$/.test(s)) return s;
  if (/大$/.test(s)) return s + '学';
  return s.replace(/国学院大學|國學院大学/, '國學院大學').replace(/駒沢大学/, '駒澤大学');
}
const UNIV_SHORT = (function () { const o = {}; Object.keys(UNIV_ABBR).forEach(function (k) { const v = UNIV_ABBR[k]; if (/大$/.test(k) && (!o[v] || k.length < o[v].length)) o[v] = k; }); o['國學院大學'] = '國學院大'; o['駒澤大学'] = '駒大'; o['神奈川大学'] = '神奈川大'; return o; })();
function univShort(s) { return UNIV_SHORT[s] || String(s || '').replace(/大学$|大學$/, '大'); }

/* ---------- any HTML table ---------- */
/* Each table comes with the nearest heading before it (head) and the text just before it (pre),
   so a page with one table per leg ("1区（9.5km）" above each) can be read. */
function htmlTables(html) {
  html = String(html || '');
  const out = [];
  let s = html, guard = 0;
  const inner = /<table\b(?:(?!<table\b)[\s\S])*?<\/table>/i;
  let m;
  while ((m = s.match(inner)) && guard++ < 400) {
    const at = m.index, before = s.slice(Math.max(0, at - 20000), at);
    const hs = before.match(/<h[1-6]\b[^>]*>[\s\S]*?<\/h[1-6]>/gi), cap = m[0].match(/<caption\b[^>]*>([\s\S]*?)<\/caption>/i);
    const tail = cellText(before.replace(/<table\b[\s\S]*$/i, '').slice(-900)).slice(-160);
    out.push({ head: hs ? cellText(hs[hs.length - 1]) : '', caption: cap ? cellText(cap[1]) : '', pre: tail, rows: tableRows(m[0]) });
    s = s.slice(0, at) + '<div data-t="' + out.length + '"></div>' + s.slice(at + m[0].length);
  }
  return out;
}
function tableRows(tbl) {
  const rows = [], spans = [];
  const trs = String(tbl).match(/<tr\b[\s\S]*?(?=<tr\b|<\/table>)/gi) || [];
  trs.forEach(function (tr) {
    const row = [];
    const cells = tr.match(/<(td|th)\b[^>]*>[\s\S]*?(?=<\/?(?:td|th)\b|<\/tr>|$)/gi) || [];
    let col = 0;
    const take = function () { while (spans[col] && spans[col].left > 0) { row[col] = spans[col].cell; spans[col].left--; col++; } };
    cells.forEach(function (c) {
      take();
      const open = c.match(/^<(td|th)\b([^>]*)>/i), at = open[2] || '';
      const cs = Math.max(1, Math.min(20, +((at.match(/colspan\s*=\s*["']?(\d+)/i) || [])[1] || 1)));
      const rs = Math.max(1, Math.min(60, +((at.match(/rowspan\s*=\s*["']?(\d+)/i) || [])[1] || 1)));
      const body = c.slice(open[0].length);
      const hrefs = []; body.replace(/<a\b[^>]*href\s*=\s*["']([^"']+)["']/gi, function (_, h) { hrefs.push(decodeEntities(h)); return _; });
      const cell = { t: cellText(body), h: hrefs, th: open[1].toLowerCase() === 'th', b: /<(b|strong)\b/i.test(body) };
      for (let k = 0; k < cs; k++) { row[col] = cell; if (rs > 1) spans[col] = { left: rs - 1, cell: cell }; col++; }
    });
    take();
    for (let k = col; k < spans.length; k++) if (spans[k] && spans[k].left > 0) { row[k] = spans[k].cell; spans[k].left--; }
    if (row.length) rows.push(row.map(function (x) { return x || { t: '', h: [], th: false }; }));
  });
  return rows;
}
/* header labels → column index */
function headerMap(rows, want) {
  for (let i = 0; i < Math.min(rows.length, 4); i++) {
    const r = rows[i], map = {};
    let hit = 0;
    Object.keys(want).forEach(function (k) {
      for (let j = 0; j < r.length; j++) if (want[k].test(r[j].t)) { if (map[k] == null) { map[k] = j; hit++; } break; }
    });
    if (hit >= 2) { map._row = i; return map; }
  }
  return null;
}
function hrefParam(cell, name) {
  for (let i = 0; i < (cell.h || []).length; i++) { const m = cell.h[i].match(new RegExp('[?&]' + name + '=(\\d+)')); if (m) return +m[1]; }
  return null;
}
function intOf(s) { const m = hankaku(s).match(/\d+/); return m ? +m[0] : null; }

/* ======================================================================
 * 箱根駅伝 公式記録 (https://www.hakone-ekiden.jp/record/)
 * ====================================================================== */
/* 大会一覧 → [{n, year, tn}] (tn is the site's own id: 第102回 = tn 106) */
function hkTournaments(html) {
  const seen = {}, out = [];
  String(html || '').replace(/tournament-detail\.php\?tn=(\d+)["'][^>]*>([\s\S]*?)<\/a>/gi, function (_, tn, txt) {
    const t = hankaku(cellText(txt)), m = t.match(/第\s*(\d+)\s*回\s*[（(]\s*(\d{4})/);
    if (m && !seen[m[1]]) { seen[m[1]] = 1; out.push({ n: +m[1], year: +m[2], tn: +tn }); }
    return _;
  });
  if (!out.length) htmlTables(html).forEach(function (T) {
    T.rows.forEach(function (r) {
      const tn = r.map(function (c) { return hrefParam(c, 'tn'); }).filter(function (x) { return x; })[0], t = hankaku(r.map(function (c) { return c.t; }).join(' ')), m = t.match(/第\s*(\d+)\s*回\s*[（(]\s*(\d{4})/);
      if (tn && m && !seen[m[1]]) { seen[m[1]] = 1; out.push({ n: +m[1], year: +m[2], tn: tn }); }
    });
  });
  return out.sort(function (a, b) { return b.n - a.n; });
}
/* 大会詳細 → チーム順位と総合・往路・復路 */
function hkDetail(html) {
  const teams = [];
  htmlTables(html).forEach(function (T) {
    const H = headerMap(T.rows, { rank: /順位/, univ: /大学|チーム/, total: /総合/, out: /往路/, ret: /復路/ });
    T.rows.forEach(function (r, i) {
      if (H && i <= H._row) return;
      const ui = r.findIndex(function (c) { return hrefParam(c, 'university_id') != null; });
      if (ui < 0) return;
      const rk = r[H && H.rank != null ? H.rank : 0].t, times = r.slice(ui + 1).map(function (c) { return parseTime(c.t); });
      const tm = function (k, d) { return H && H[k] != null ? parseTime(r[H[k]].t) : times[d]; };
      teams.push({ rank: /^\d+$/.test(hankaku(rk)) ? +hankaku(rk) : null, op: /参考|OP|オープン/.test(rk) || OPEN_TEAM.test(r[ui].t), note: /^\d+$/.test(hankaku(rk)) ? '' : rk,
        u: univCanon(r[ui].t), uid: hrefParam(r[ui], 'university_id'), t: tm('total', 0), out: tm('out', 1), ret: tm('ret', 2) });
    });
  });
  return teams;
}
/* 大会×区間 → その区間の全選手（区間順位・大学・学年・氏名・タイム・チームの最終総合順位）
   (the site's 総合順位 column is the team's final place, not the running order; the app works the running order out from the times) */
function hkSection(html) {
  const runs = [];
  htmlTables(html).forEach(function (T) {
    const H = headerMap(T.rows, { lr: /区間順位|^順位$/, univ: /大学|チーム/, runner: /選手|氏名/, t: /タイム|記録/, fr: /総合順位/ });
    T.rows.forEach(function (r, i) {
      if (H && i <= H._row) return;
      const ri = r.findIndex(function (c) { return hrefParam(c, 'rid') != null; });
      if (ri < 0) return;
      const ui = r.findIndex(function (c) { return hrefParam(c, 'university_id') != null; });
      const who = hankaku(r[ri].t), gm = who.match(/^(院)?\s*(\d)\s*年\s*(.+)$/);
      const lrT = hankaku(r[H && H.lr != null ? H.lr : 0].t), tCell = H && H.t != null ? r[H.t] : r.slice(ri + 1).filter(function (c) { return parseTime(c.t) != null; })[0];
      const frT = H && H.fr != null ? hankaku(r[H.fr].t) : hankaku((r[r.length - 1] || {}).t);
      runs.push({ lr: /^\d+$/.test(lrT) ? +lrT : null, op: /参考|OP|オープン/.test(lrT) || (ui >= 0 && OPEN_TEAM.test(r[ui].t)),
        u: ui >= 0 ? univCanon(r[ui].t) : '', uid: ui >= 0 ? hrefParam(r[ui], 'university_id') : null,
        rid: hrefParam(r[ri], 'rid'), nm: (gm ? gm[3] : who).trim(), g: gm ? (gm[1] ? 4 + +gm[2] : +gm[2]) : null,
        t: tCell ? parseTime(tCell.t) : null, fr: /^\d+$/.test(frT) ? +frT : null, note: tCell && parseTime(tCell.t) == null ? tCell.t : '' });
    });
  });
  return runs;
}

/* ======================================================================
 * 月陸Online — テキスト速報 / 大会結果
 * ====================================================================== */
const SERIES_TITLES = [   // order matters: the more specific name first
  ['yosen', /箱根駅伝予選会|箱根駅伝の予選会/], ['hakone', /箱根駅伝/], ['izumo', /出雲駅伝|出雲全日本大学選抜/],
  ['morinomiya', /全日本大学女子駅伝|杜の都/], ['fujisan', /富士山女子駅伝|全日本大学女子選抜/], ['kwj', /関東大学女子駅伝/],
  ['zsel', /全日本大学駅伝.*(関東|選考会)/], ['zen', /全日本大学駅伝/], ['oga', /男鹿駅伝/],
  ['tokai', /東海学生駅伝|東海地区.*選考/], ['kansai', /関西学生駅伝|丹後.*駅伝|関西学生対校駅伝/], ['kyushu', /九州学生駅伝|九州地区.*選考/],
  ['hokushinetsu', /北信越学生駅伝|北信越.*選考/], ['chushikoku', /中国四国学生駅伝|中四国.*選考/], ['tohoku', /東北学生駅伝|東北地区.*選考/], ['hokkaido', /北海道学生駅伝|北海道地区.*選考/],
  ['kwjsel', /全日本大学女子駅伝.*関東.*選考/]
];
function seriesOf(title) {
  title = String(title || '');
  if (!/駅伝/.test(title) || /高校|中学|実業団|ニューイヤー|クイーンズ|都道府県|全国女子駅伝|全国男子駅伝/.test(title) && !/大学|学生|箱根|出雲|杜の都|富士山/.test(title)) return null;
  for (let i = 0; i < SERIES_TITLES.length; i++) if (SERIES_TITLES[i][1].test(title)) return SERIES_TITLES[i][0];
  return null;
}
function editionOf(title) { const m = hankaku(title).match(/第\s*(\d+)\s*回/); return m ? +m[1] : null; }
/* article body as lines (paragraphs, headings and <br> breaks) */
function articleLines(html) {
  html = String(html || '');
  const body = (html.match(/<div[^>]+class=["'][^"']*(entry-content|post-content|article-body|single-content|entry-body)[^"']*["'][^>]*>([\s\S]*)/i) || [])[2] || (html.match(/<article\b[\s\S]*?<\/article>/i) || [html])[0];
  return body.replace(/<(script|style|noscript)\b[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<\/(p|h[1-6]|li|div|tr|dt|dd)>|<br\s*\/?>/gi, '\n').replace(/<(h[1-6])\b[^>]*>/gi, '\n<<$1>>')
    .split('\n').map(function (l) { const hd = /^<<h[1-6]>>/.test(l); const t = cellText(l.replace(/^<<h[1-6]>>/, '')); return hd ? '##' + t : t; })
    .filter(function (l) { return l && l !== '##'; });
}
/* テキスト速報: 区ごとの見出しと「▼10.0km …」の行 */
function gtLive(html) {
  const lines = articleLines(html), legs = [], wins = [];
  let cur = null;
  lines.forEach(function (raw) {
    const l = hankaku(raw.replace(/^##/, ''));
    const hm = l.match(/^(\d{1,2})区\s*(.{0,40}?)[（(]\s*([\d.]+)\s*km\s*[）)]/);
    if (hm && l.length < 60) { cur = { leg: +hm[1], label: hm[2].trim(), km: +hm[3], lines: [] }; legs.push(cur); return; }
    if (/^▼/.test(l) && cur) {
      const km = (l.match(/^▼\s*([\d.]+)\s*km/) || [])[1], text = l.replace(/^▼\s*([\d.]+\s*km)?\s*/, '');
      cur.lines.push({ km: km != null ? +km : null, text: text });
      const w = text.match(/([^\s・、。！]+?)・([^\s、。！]+?)が区間(賞|新)[^タ]*?タイムは\s*((?:\d+時間)?\d+分\d+秒)/);
      if (w) wins.push({ leg: cur.leg, u: univCanon(w[1]), nm: w[2], t: parseTime(w[4]), rec: /区間新/.test(text) });
    }
  });
  return { legs: legs, winners: wins };
}
/* 大会結果: 総合成績・オープン・区間賞（同タイムは次の行）・個人成績 */
function gtResult(html) {
  const lines = articleLines(html), teams = [], open = [], awards = [], indiv = [];
  let mode = '', leg = null, km = null;
  lines.forEach(function (raw) {
    const l = hankaku(raw.replace(/^##/, '')).replace(/[　]/g, ' ').trim();
    if (/^●?\s*総合成績|^●?\s*総合順位|^●?\s*チーム成績|^●?\s*団体/.test(l)) { mode = 'team'; return; }
    if (/^●?\s*区間賞/.test(l)) { mode = 'award'; return; }
    if (/^●?\s*個人成績|^●?\s*個人順位/.test(l)) { mode = 'indiv'; return; }
    if (/^オープン/.test(l)) { mode = 'open'; return; }
    let m;
    const T = '((?:\\d+時間)?\\d+分\\d+秒)';
    if ((m = l.match(new RegExp('^(\\d+)位\\s*(\\S+?)\\s*[（(]\\s*(\\S+?)\\s*(\\d)?\\s*[）)]\\s*' + T + '(?:\\s*[=＝]\\s*(\\S+))?')))) {
      indiv.push({ rk: +m[1], nm: m[2], u: univCanon(m[3]), g: m[4] ? +m[4] : null, t: parseTime(m[5]), rec: m[6] || '' }); return;
    }
    if ((m = l.match(new RegExp('^(\\d+)位\\s+(\\S+)\\s+' + T + '(?:\\s*[=＝]\\s*(\\S+))?')))) { teams.push({ rank: +m[1], u: univCanon(m[2]), t: parseTime(m[3]), rec: m[4] || '' }); mode = mode || 'team'; return; }
    if (mode === 'open' && (m = l.match(new RegExp('^(\\S+)\\s+' + T)))) { open.push({ u: univCanon(m[1]), t: parseTime(m[2]), op: true }); return; }
    if ((m = l.match(new RegExp('^(\\d{1,2})区\\s*[（(]\\s*([\\d.]+)\\s*km\\s*[）)]\\s*(\\S+?)\\s*[（(]\\s*(\\S+?)\\s*(\\d)?\\s*[）)]\\s*' + T + '(?:\\s*[=＝]\\s*(\\S+))?')))) {
      leg = +m[1]; km = +m[2]; awards.push({ leg: leg, km: km, nm: m[3], u: univCanon(m[4]), g: m[5] ? +m[5] : null, t: parseTime(m[6]), rec: /区間新/.test(m[7] || '') }); return;
    }
    if (mode === 'award' && leg && (m = l.match(new RegExp('^(\\S+?)\\s*[（(]\\s*(\\S+?)\\s*(\\d)?\\s*[）)]\\s*' + T + '(?:\\s*[=＝]\\s*(\\S+))?')))) {
      awards.push({ leg: leg, km: km, nm: m[1], u: univCanon(m[2]), g: m[3] ? +m[3] : null, t: parseTime(m[4]), rec: /区間新/.test(m[5] || '') });
    }
  });
  return { teams: teams, open: open, awards: awards, indiv: indiv };
}

/* ======================================================================
 * 区間ごとの成績表が並ぶページ → 1大会分のデータ
 * (columns: 区間順位 | 選手(名) | 大学・チーム | 区間タイム [| 学年]; the leg number is in the heading above each table)
 * ====================================================================== */
function importTables(html) {
  const legs = {};
  htmlTables(html).forEach(function (T) {
    const H = headerMap(T.rows, { lr: /区間順位|^順位$|^位$/, nm: /選手|氏名|名前/, u: /大学|チーム|所属/, t: /タイム|記録/, g: /学年/ });
    if (!H || H.nm == null || H.t == null) return;
    const lm = hankaku(T.caption + ' ' + T.head + ' ' + T.pre).match(/(\d{1,2})\s*区(?!間)/g);
    if (!lm) return;
    const leg = +hankaku(lm[lm.length - 1]).match(/\d+/)[0];
    if (legs[leg]) return;
    const runs = [];
    T.rows.slice(H._row + 1).forEach(function (r) {
      const t = parseTime((r[H.t] || {}).t || ''); if (t == null) return;
      const nmT = String((r[H.nm] || {}).t || ''), gm = hankaku(nmT).match(/[（(]\s*(\d)\s*[）)]|(\d)\s*年/);
      const lr = H.lr != null ? intOf(r[H.lr].t) : null;
      runs.push({ lr: lr, nm: nmT.replace(/[（(].*?[）)]|\d\s*年/g, '').trim(), u: univCanon((r[H.u] || {}).t || ''), g: H.g != null ? intOf(r[H.g].t) : gm ? +(gm[1] || gm[2]) : null, t: t });
    });
    if (runs.length >= 3) legs[leg] = runs;
  });
  return legs;
}
/* legs → チーム順位 (sums) and the running order after each leg */
function editionFromLegs(legMap, meta) {
  const L = Object.keys(legMap).map(Number).sort(function (a, b) { return a - b; });
  const n = L.length ? L[L.length - 1] : 0, legs = [];
  const openRe = (meta && meta.openRe) || OPEN_TEAM;
  for (let i = 1; i <= n; i++) legs.push((legMap[i] || []).map(function (r) { const o = Object.assign({}, r); o.op = !!o.op || openRe.test(o.u); return o; }));
  const cum = {};
  legs.forEach(function (runs, i) {
    runs.forEach(function (r) { const c = cum[r.u] = cum[r.u] || { t: 0, k: 0, op: r.op }; if (r.t != null && c.k === i) { c.t += r.t; c.k++; } });
    const ranked = Object.keys(cum).filter(function (u) { return cum[u].k === i + 1 && !cum[u].op; }).sort(function (a, b) { return cum[a].t - cum[b].t; });
    runs.forEach(function (r) { const k = ranked.indexOf(r.u); if (r.cr == null) r.cr = k >= 0 ? k + 1 : null; });
  });
  const teams = Object.keys(cum).filter(function (u) { return cum[u].k === n; }).map(function (u) { return { u: u, t: cum[u].t, op: !!cum[u].op }; })
    .sort(function (a, b) { return a.t - b.t; });
  let k = 0; teams.forEach(function (t) { t.rank = t.op ? null : ++k; });
  const out = Object.assign({}, meta || {}, { teams: teams, legs: legs }); delete out.openRe;
  return out;
}

/* ======================================================================
 * Wikipedia: 歴代優勝 and 区間記録 tables
 * ====================================================================== */
const UNIV_LIKE = /大学|大學|大$|学院|師範|専門学校|高専|選抜|連合|クラブ/;
function wikiWinners(tables) {
  let best = [];
  const cards = wikiEditionCards(tables);
  if (cards.length) best = cards;
  tables.forEach(function (T) {
    const H = headerMap(T.rows, { n: /^回$|^回次$|^大会$|回数|^第?回/, y: /年|開催日|日付/, w: /優勝|^1位$|^総合優勝/, t: /タイム|記録/, w2: /準優勝|^2位$/, w3: /^3位$/ });
    if (!H || H.w == null) return;
    const out = [];
    T.rows.slice(H._row + 1).forEach(function (r) {
      const all = hankaku(r.map(function (c) { return c.t; }).join(' '));
      const nT = H.n != null ? hankaku(r[H.n].t) : all, nm = nT.match(/第?\s*(\d{1,3})\s*回?/), ym = (H.y != null ? hankaku(r[H.y].t) : all).match(/(19|20)\d\d/);
      if (!nm) return;
      const clean = function (s) { return String(s || '').replace(/[\[［].*?[\]］]|\(\d+(年ぶり)?\s*(回目)?\)|（\d+(年ぶり)?\s*(回目)?）|\d+回目|\(初\)|（初）|初優勝/g, '').trim(); };
      const w = clean(r[H.w].t);
      if (!w || /中止|不開催|開催せず/.test(all) && !parseTime(all)) { out.push({ n: +nm[1], year: ym ? +ym[0] : null, cancel: /中止|開催せず|不開催/.test(all) }); return; }
      let t = H.t != null ? parseTime(r[H.t].t) : null;
      if (t == null) for (let j = H.w + 1; j < r.length; j++) { const x = parseTime(r[j].t); if (x != null && x > 1200) { t = x; break; } }
      if (!UNIV_LIKE.test(w) || w.length > 24) return;
      out.push({ n: +nm[1], year: ym ? +ym[0] : null, u: univCanon(w), t: t, u2: H.w2 != null ? univCanon(clean(r[H.w2].t)) : '', u3: H.w3 != null ? univCanon(clean(r[H.w3].t)) : '' });
    });
    if (out.filter(function (x) { return x.u; }).length > best.filter(function (x) { return x.u; }).length) best = out;
  });
  const seen = {};
  return best.filter(function (x) { if (seen[x.n]) return false; seen[x.n] = 1; return true; }).sort(function (a, b) { return a.n - b.n; });
}
function cleanWin(s) { return String(s || '').replace(/[\[［].*?[\]］]|[（(]\s*(\d+|初)\s*[）)]|\d+回目|初優勝/g, '').replace(/\s+/g, ' ').trim(); }
/* 全日本の Wikipedia: one small table per edition — first row "第1回（1970年3月…）", then 優勝 / 準優勝 / 3位 rows */
function wikiEditionCards(tables) {
  const out = [];
  tables.forEach(function (T) {
    if (!T.rows.length) return;
    const top = hankaku(T.rows[0].map(function (c) { return c.t; }).join(' ')), m = top.match(/第\s*(\d{1,3})\s*回\s*[（(]?\s*((?:19|20)\d\d)?/);
    if (!m) return;
    const o = { n: +m[1], year: m[2] ? +m[2] : null };
    T.rows.slice(1).forEach(function (r) {
      const k = hankaku((r[0] || {}).t || ''), v = cleanWin((r[1] || {}).t || ''), t = r.slice(1).map(function (c) { return parseTime(c.t); }).filter(function (x) { return x != null && x > 1200; })[0];
      if (!v || !UNIV_LIKE.test(v)) return;
      if (/^(総合)?優勝$|^1位$/.test(k)) { o.u = univCanon(v); if (t) o.t = t; }
      else if (/準優勝|^2位$/.test(k)) o.u2 = univCanon(v);
      else if (/^3位$/.test(k)) o.u3 = univCanon(v);
    });
    if (/中止/.test(T.rows.map(function (r) { return r.map(function (c) { return c.t; }).join(' '); }).join(' ')) && !o.u) o.cancel = true;
    if (o.u || o.cancel) out.push(o);
  });
  return out;
}
/* 区間記録 (one row per leg) and 区間歴代10傑 (one table per leg; the title row says which course: 「区間歴代10傑（第50回大会以降）」「区間日本人歴代10傑」) */
function wikiLegRecords(tables) {
  const recs = [], tops = {};
  tables.forEach(function (T) {
    const H = headerMap(T.rows, { leg: /^区間$|^区$/, t: /記録|タイム/, nm: /氏名|選手|名前|記録保持者/, u: /所属|大学|チーム/, y: /年次|大会|^回$|開催|^年$|^年度$/, rk: /^位$|^順位$/, g: /学年/ });
    if (!H || H.t == null || H.nm == null) return;
    const legIn = function (x) { const m = hankaku(x || '').match(/(\d{1,2})\s*区(?!間)/); return m ? +m[1] : null; };
    const ctxLeg = legIn(T.head) || legIn(T.caption) || legIn(T.pre);
    const kmM = hankaku(T.head + ' ' + T.caption).match(/([\d.]+)\s*km/), title = H._row > 0 ? hankaku(T.rows[0][0].t) : '';
    const em = hankaku(title + ' ' + T.caption + ' ' + T.head).match(/第\s*(\d+)\s*回(?:大会)?\s*(?:以降|～|〜|-|から)\s*(?:第\s*(\d+)\s*回)?/);
    const era = (em ? '第' + em[1] + '回〜' + (em[2] ? '第' + em[2] + '回' : '') : '') + (/日本人/.test(title + T.caption) ? ' 日本人' : '') + (kmM ? ' ' + kmM[1] + 'km' : '');
    T.rows.slice(H._row + 1).forEach(function (r) {
      const t = parseTime((r[H.t] || {}).t || ''); if (t == null) return;
      const ys = H.y != null ? hankaku(r[H.y].t) : '', ed = ys.match(/第?\s*(\d+)\s*回/), yr = ys.match(/(19|20)\d\d/);
      const o = { t: t, nm: String((r[H.nm] || {}).t || '').replace(/[\[［].*?[\]］]/g, '').trim(), u: univCanon((r[H.u] || {}).t || ''), n: ed ? +ed[1] : null, year: yr ? +yr[0] : null, era: era, g: H.g != null ? intOf(r[H.g].t) : null };
      if (H.leg != null && H.rk == null) { const lg = intOf(r[H.leg].t); if (lg) { o.leg = lg; o.label = r[H.leg].t; recs.push(o); } }
      else if (ctxLeg && H.rk != null) { const key = ctxLeg + '|' + era.trim(); (tops[key] = tops[key] || []).push(Object.assign({ rk: intOf(r[H.rk].t), leg: ctxLeg }, o)); }
    });
  });
  return { recs: recs, tops: tops };
}

/* ======================================================================
 * ほぼニートの資格取得日記（blog.neet-shikakugets.com）の「結果・速報（リザルト）」記事
 *   区間ごとの表: 区間順位 | 区間記録 | 選手 "榅山 一颯(2)" | チーム "青山学院大 ↑1" | 通過記録 | 通過順位
 *   チーム結果:   "01. 5:03:31　　早稲田大 NGR"
 * ====================================================================== */
function neetTitle(title) {
  title = nfkc(title);
  if (!/結果|リザルト|速報/.test(title) || /エントリー|展望|予想/.test(title)) return null;
  const s = seriesOf(title), y = (title.match(/(19|20)\d\d/) || [])[0];
  return s ? { s: s, year: y ? +y : null, n: editionOf(title) } : null;
}
function neetResult(html) {
  const legs = {}, km = {}, teams = [];
  htmlTables(html).forEach(function (T) {
    const H = headerMap(T.rows, { lr: /区間\s*順位/, t: /区間\s*記録/, nm: /選手/, u: /チーム|大学/, ct: /通過\s*記録/, cr: /通過\s*順位/ });
    if (!H || H.nm == null || H.t == null) return;
    const ctx = hankaku(T.head + ' ' + T.caption + ' ' + T.pre), m = ctx.match(/(\d{1,2})\s*区\s*[（(]\s*([\d.]+)\s*km/) || ctx.match(/(\d{1,2})\s*区/);
    if (!m) return;
    const leg = +m[1]; if (legs[leg]) return;
    if (m[2]) km[leg] = +m[2];
    legs[leg] = T.rows.slice(H._row + 1).map(function (r) {
      const lrT = hankaku((r[H.lr] || {}).t || ''), raw = nfkc((r[H.nm] || {}).t || ''), gm = raw.match(/[（(]\s*(M?)(\d)\s*[）)]/);
      const rec = /NSR|区間新/.test(raw), nm = raw.replace(/[（(].*?[）)]/g, '').replace(/\b(NSR|NGR|NR|CR|JR)\b|区間新|大会新/g, '').replace(/\s+/g, ' ').trim();
      const uT = nfkc((r[H.u] || {}).t || '').replace(/[↑↓→]\s*\d*/g, '').trim();
      const t = parseTime((r[H.t] || {}).t || '');
      return { lr: /^\d+$/.test(lrT) ? +lrT : null, op: /OP|ＯＰ|参考/.test(lrT), nm: nm, g: gm ? (gm[1] ? 4 + +gm[2] : +gm[2]) : null, u: univCanon(uT), t: t,
        ct: H.ct != null ? parseTime(r[H.ct].t) : null, cr: H.cr != null ? intOf(r[H.cr].t) : null, rec: rec };
    }).filter(function (x) { return x.nm && x.u && x.t; });
  });
  articleLines(html).forEach(function (l) {
    const m = nfkc(l).match(/^\s*(\d{1,2}|OP)\s*[.．]\s*((?:\d+:)?\d+:\d\d)\s+(\S+)(?:\s+(NGR|大会新))?/);
    if (m) teams.push({ rank: /OP/.test(m[1]) ? null : +m[1], op: /OP/.test(m[1]), t: parseTime(m[2]), u: univCanon(m[3]), rec: m[4] ? '大会新' : '' });
  });
  return { legs: legs, km: km, teams: teams };
}

/* トラックの種目と記録 */
function trackEvent(e) { e = nfkc(e).replace(/\s/g, '').toLowerCase(); if (/^5000|^5,000|5km?$/.test(e)) return '5000m'; if (/^10000|^10,000/.test(e)) return '10000m'; if (/half|ハーフ|21\.0975/.test(e)) return 'half'; if (/^3000.*sc|障害/.test(e)) return '3000msc'; return null; }
function markTime(s) { s = hankaku(nfkc(s)).trim(); if (typeof s === 'number') return s; let m;
  if ((m = s.match(/^(\d+):(\d\d):(\d\d)(?:\.(\d+))?$/))) return +m[1] * 3600 + +m[2] * 60 + +m[3] + (m[4] ? +('0.' + m[4]) : 0);
  if ((m = s.match(/^(\d+):(\d\d)(?:\.(\d+))?$/))) return +m[1] * 60 + +m[2] + (m[3] ? +('0.' + m[3]) : 0);
  if ((m = s.match(/^(\d+)分(\d+)秒(\d+)?$/))) return +m[1] * 60 + +m[2] + (m[3] ? +('0.' + m[3]) : 0);
  const t = parseTime(s); return t; }

/* ======================================================================
 * ニュース
 * ====================================================================== */
const NEWS_KEEP = /駅伝|箱根|出雲|全日本大学|学連|予選会|学生ハーフ|日本インカレ|関東インカレ|10000m記録挑戦|MARCH対抗|ハーフマラソン/;
const NEWS_DROP = /高校駅伝|中学駅伝|実業団駅伝|ニューイヤー駅伝|クイーンズ駅伝|都道府県対抗|全国中学/;
function newsItem(it, src) {
  const title = String(it.title || '').replace(/\s+/g, ' ').trim();
  if (!NEWS_KEEP.test(title + ' ' + (it.desc || '').slice(0, 200)) || NEWS_DROP.test(title) && !/大学|箱根|出雲|学生/.test(title)) return null;
  const d = parseDate(it.date, 0);
  return { id: hashId(normTitle(title)), t: title, u: it.link, d: d, s: src.name, desc: String(it.desc || '').slice(0, 220), series: seriesOf(title) };
}

/* ======================================================================
 * The app's copy of one race series: names and universities are listed once and referred to by number.
 *   U  universities          R  runners [name, 公式サイトの選手ID?]
 *   E  editions [{n, y, d, st, dist?, T:[[u, rank, total, 往路, 復路, open]], L:[ leg → [[u, r, grade, time, 区間順位, 通過順位, open, 最終順位]] ],
 *                 I:[[rank, r, u, grade, time]] (個人), A:[[leg, r, u, grade, time, 区間新]] (区間賞のみの大会)}]
 *   H  history {W:[[n, year, u, time, u2, u3, cancel, 往路, 復路]], REC:[[leg, time, name, univ, n, year, label]], TOP:{key: [[rk, time, name, univ, n, year, grade]]}}
 * ====================================================================== */
function strHash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
function compactDb(S, cfg) {
  const U = [], Ui = {}, R = [], Ri = {};
  if (cfg.track) {   // M: [[runner, univ, grade, event, time, date, meet, women]]
    const u0 = function (name) { if (Ui[name] == null) { Ui[name] = U.length; U.push(name); } return Ui[name]; }, ME = [], MEi = {};
    const r0 = function (nm, un) { const k = normName(nm) + '|' + un; if (Ri[k] == null) { Ri[k] = R.length; R.push([nm]); } return Ri[k]; };
    const marks = (S.marks || []).map(function (m) { if (MEi[m.meet] == null) { MEi[m.meet] = ME.length; ME.push(m.meet); } return [r0(m.nm, m.u), u0(m.u), m.g || 0, m.ev, m.t, m.date, MEi[m.meet], m.w ? 1 : 0]; });
    const ST = (S.status || []).map(function (x) { return [r0(x.nm, x.u), u0(x.u), x.kind, x.note, x.date, x.src]; });   // ケガ・欠場
    const db = { key: 'track', name: cfg.name, track: true, U: U, R: R, M: marks, MEETS: ME, ST: ST, E: [], H: {} };
    db.ver = strHash(JSON.stringify(db)); return db;
  }
  const u = function (name) { name = name || ''; if (Ui[name] == null) { Ui[name] = U.length; U.push(name); } return Ui[name]; };
  const r = function (nm, rid, un) { nm = String(nm || ''); const k = rid ? 'r' + rid : normName(nm) + '|' + un; if (Ri[k] == null) { Ri[k] = R.length; R.push(rid ? [nm, rid] : [nm]); } return Ri[k]; };
  const ns = Object.keys(S.eds || {}).map(Number).sort(function (a, b) { return a - b; });
  const E = ns.map(function (n) {
    const e = S.eds[n], stale = e.status === 'live' && !(e.liveUntil > Date.now());   // a race page that stopped updating is not "live" any more
    const o = { n: n, y: e.year || 0, d: e.date || '', st: stale ? ((e.legs || []).some(function (l) { return l && l.length; }) ? 'full' : 'result') : e.status || '' };
    if (e.dist && e.dist.length) o.dist = e.dist;
    if (e.name) o.nm = e.name;
    if (e.teams && e.teams.length) o.T = e.teams.map(function (t) { return [u(t.u), t.rank == null ? 0 : t.rank, t.t || 0, t.out || 0, t.ret || 0, t.op ? 1 : 0]; });
    if (e.legs && e.legs.some(function (l) { return l && l.length; })) o.L = e.legs.map(function (runs) { return (runs || []).map(function (x) { return [u(x.u), r(x.nm, x.rid, x.u), x.g || 0, x.t || 0, x.lr || 0, x.cr || 0, x.op ? 1 : 0, x.fr || 0]; }); });
    if (e.indiv && e.indiv.length) o.I = e.indiv.map(function (x) { return [x.rk || 0, r(x.nm, null, x.u), u(x.u), x.g || 0, x.t || 0]; });
    if (e.awards && e.awards.length && !o.L) o.A = e.awards.map(function (a) { return [a.leg, r(a.nm, null, a.u), u(a.u), a.g || 0, a.t || 0, a.rec ? 1 : 0]; });
    if (e.src) o.src = e.src.slice(0, 3);
    return o;
  });
  const h = S.hist || {}, tops = {};
  Object.keys(h.tops || {}).forEach(function (k) { tops[k] = h.tops[k].map(function (x) { return [x.rk || 0, x.t, x.nm, x.u, x.n || 0, x.year || 0, x.g || 0]; }); });
  const H = { W: (h.winners || []).map(function (w) { return [w.n, w.year || 0, w.u ? u(w.u) : -1, w.t || 0, w.u2 ? u(w.u2) : -1, w.u3 ? u(w.u3) : -1, w.cancel ? 1 : 0, w.out || 0, w.ret || 0]; }),
    REC: (h.recs || []).map(function (x) { return [x.leg, x.t, x.nm, x.u, x.n || 0, x.year || 0, x.label || '']; }), TOP: tops, wiki: h.wiki || [] };
  const db = { key: S.key, name: cfg.name, full: cfg.full, women: !!cfg.women, legs: cfg.legs || 0, dist: cfg.dist || null, since: cfg.since || null, eras: cfg.eras || null, totalEras: cfg.totalEras || null, tags: cfg.tags || null, indivKm: cfg.indivKm || null, U: U, R: R, E: E, H: H };
  db.ver = strHash(JSON.stringify(db));
  return db;
}

/* 2026年度シーズンの結果（公開されている成績ページから手で集めたもの。各チームの区間タイムの合計が発表された総合タイムと一致することを確認済み） */
const SEED_EDS = {"hakone":[{"n":102,"year":2026,"date":"2026-01-02","name":"第102回東京箱根間往復大学駅伝競走","teams":[{"rank":1,"u":"青山学院大学","t":38254,"out":19088,"ret":19166,"op":false},{"rank":2,"u":"國學院大學","t":38407,"out":19202,"ret":19205,"op":false},{"rank":3,"u":"順天堂大学","t":38635,"out":19309,"ret":19326,"op":false},{"rank":4,"u":"早稲田大学","t":38669,"out":19106,"ret":19563,"op":false},{"rank":5,"u":"中央大学","t":38671,"out":19184,"ret":19487,"op":false},{"rank":6,"u":"駒澤大学","t":38690,"out":19380,"ret":19310,"op":false},{"rank":7,"u":"城西大学","t":38777,"out":19220,"ret":19557,"op":false},{"rank":8,"u":"創価大学","t":39100,"out":19442,"ret":19658,"op":false},{"rank":9,"u":"帝京大学","t":39195,"out":19825,"ret":19370,"op":false},{"rank":10,"u":"日本大学","t":39236,"out":19500,"ret":19736,"op":false},{"rank":11,"u":"中央学院大学","t":39291,"out":19582,"ret":19709,"op":false},{"rank":12,"u":"東海大学","t":39301,"out":19570,"ret":19731,"op":false},{"rank":13,"u":"神奈川大学","t":39309,"out":19705,"ret":19604,"op":false},{"rank":14,"u":"東洋大学","t":39387,"out":19735,"ret":19652,"op":false},{"rank":15,"u":"日本体育大学","t":39402,"out":19804,"ret":19598,"op":false},{"rank":16,"u":"東京国際大学","t":39496,"out":19845,"ret":19651,"op":false},{"rank":17,"u":"山梨学院大学","t":39500,"out":19648,"ret":19852,"op":false},{"rank":18,"u":"東京農業大学","t":39672,"out":19682,"ret":19990,"op":false},{"rank":19,"u":"大東文化大学","t":39897,"out":19843,"ret":20054,"op":false},{"rank":20,"u":"立教大学","t":39958,"out":19985,"ret":19973,"op":false},{"rank":null,"u":"関東学生連合","t":39455,"out":19922,"ret":19533,"op":true}],"legs":[[{"lr":1,"u":"國學院大學","g":4,"nm":"青木 瑠郁","t":3628,"fr":2,"rid":7498,"op":false},{"lr":2,"u":"中央大学","g":3,"nm":"藤田 大智","t":3637,"fr":5,"rid":7800,"op":false},{"lr":3,"u":"東洋大学","g":2,"nm":"松井 海斗","t":3643,"fr":14,"rid":7884,"op":false},{"lr":4,"u":"中央学院大学","g":4,"nm":"近田 陽路","t":3645,"fr":11,"rid":7674,"op":false},{"lr":5,"u":"駒澤大学","g":3,"nm":"小山 翔也","t":3648,"fr":6,"rid":7716,"op":false},{"lr":6,"u":"城西大学","g":3,"nm":"柴田 侑","t":3651,"fr":7,"rid":7722,"op":false},{"lr":7,"u":"早稲田大学","g":2,"nm":"吉倉 ナヤブ直希","t":3658,"fr":4,"rid":7742,"op":false},{"lr":8,"u":"日本体育大学","g":4,"nm":"平島 龍斗","t":3661,"fr":15,"rid":7641,"op":false},{"lr":9,"u":"順天堂大学","g":2,"nm":"池間 凛斗","t":3680,"fr":3,"rid":7894,"op":false},{"lr":10,"u":"東京農業大学","g":3,"nm":"栗本 航希","t":3681,"fr":18,"rid":7690,"op":false},{"lr":11,"u":"神奈川大学","g":4,"nm":"酒井 健成","t":3681,"fr":13,"rid":7664,"op":false},{"lr":12,"u":"山梨学院大学","g":4,"nm":"平八重 充希","t":3693,"fr":17,"rid":7704,"op":false},{"lr":13,"u":"東海大学","g":4,"nm":"兵藤 ジュダ","t":3701,"fr":12,"rid":7676,"op":false},{"lr":14,"u":"創価大学","g":4,"nm":"黒木 陽向","t":3703,"fr":8,"rid":7745,"op":false},{"lr":15,"u":"大東文化大学","g":2,"nm":"大浜 逞真","t":3706,"fr":19,"rid":7760,"op":false},{"lr":16,"u":"青山学院大学","g":2,"nm":"小河原 陽琉","t":3707,"fr":1,"rid":7708,"op":false},{"lr":17,"u":"日本大学","g":3,"nm":"山口 彰太","t":3728,"fr":10,"rid":7804,"op":false},{"lr":18,"u":"東京国際大学","g":2,"nm":"小柴 裕士郎","t":3782,"fr":16,"rid":7878,"op":false},{"lr":19,"u":"帝京大学","g":3,"nm":"原 悠太","t":3789,"fr":9,"rid":7887,"op":false},{"lr":20,"u":"立教大学","g":4,"nm":"吉屋 佑晟","t":3807,"fr":20,"rid":7659,"op":false},{"lr":null,"u":"関東学生連合","g":3,"nm":"川崎 颯","t":3638,"fr":null,"rid":7930,"op":true}],[{"lr":1,"u":"城西大学","g":4,"nm":"キムタイ","t":3909,"fr":7,"rid":7533,"op":false},{"lr":2,"u":"日本大学","g":3,"nm":"キップケメイ","t":3942,"fr":10,"rid":7649,"op":false},{"lr":3,"u":"山梨学院大学","g":3,"nm":"キピエゴ","t":3943,"fr":17,"rid":7700,"op":false},{"lr":4,"u":"早稲田大学","g":4,"nm":"山口 智規","t":3947,"fr":4,"rid":7611,"op":false},{"lr":5,"u":"創価大学","g":3,"nm":"ムチーニ","t":3960,"fr":8,"rid":7617,"op":false},{"lr":6,"u":"中央大学","g":4,"nm":"溜池 一太","t":3966,"fr":5,"rid":7490,"op":false},{"lr":7,"u":"東京国際大学","g":3,"nm":"エティーリ","t":3974,"fr":16,"rid":7811,"op":false},{"lr":8,"u":"駒澤大学","g":2,"nm":"桑田 駿介","t":3979,"fr":6,"rid":7714,"op":false},{"lr":9,"u":"順天堂大学","g":3,"nm":"吉岡 大翔","t":3988,"fr":3,"rid":7606,"op":false},{"lr":10,"u":"青山学院大学","g":2,"nm":"飯田 翔大","t":3989,"fr":1,"rid":7860,"op":false},{"lr":11,"u":"東京農業大学","g":3,"nm":"前田 和摩","t":3991,"fr":18,"rid":7687,"op":false},{"lr":12,"u":"國學院大學","g":4,"nm":"上原 琉翔","t":4028,"fr":2,"rid":7500,"op":false},{"lr":13,"u":"神奈川大学","g":4,"nm":"宮本 陽叶","t":4046,"fr":13,"rid":7661,"op":false},{"lr":14,"u":"日本体育大学","g":4,"nm":"田島 駿介","t":4061,"fr":15,"rid":7645,"op":false},{"lr":15,"u":"中央学院大学","g":3,"nm":"市川 大世","t":4062,"fr":11,"rid":7791,"op":false},{"lr":16,"u":"東海大学","g":4,"nm":"花岡 寿哉","t":4080,"fr":12,"rid":7567,"op":false},{"lr":17,"u":"大東文化大学","g":3,"nm":"棟方 一楽","t":4169,"fr":19,"rid":7755,"op":false},{"lr":18,"u":"立教大学","g":4,"nm":"馬場 賢人","t":4194,"fr":20,"rid":7551,"op":false},{"lr":19,"u":"東洋大学","g":4,"nm":"西村 真周","t":4224,"fr":14,"rid":7485,"op":false},{"lr":20,"u":"帝京大学","g":3,"nm":"楠岡 由浩","t":4310,"fr":9,"rid":7747,"op":false},{"lr":null,"u":"関東学生連合","g":3,"nm":"古橋 希翁","t":4079,"fr":null,"rid":7931,"op":true}],[{"lr":1,"u":"中央大学","g":3,"nm":"本間 颯","t":3608,"fr":5,"rid":7796,"op":false},{"lr":2,"u":"駒澤大学","g":4,"nm":"帰山 侑大","t":3651,"fr":6,"rid":7587,"op":false},{"lr":3,"u":"國學院大學","g":3,"nm":"野中 恒亨","t":3682,"fr":2,"rid":7731,"op":false},{"lr":4,"u":"順天堂大学","g":1,"nm":"井上 朋哉","t":3693,"fr":3,"rid":7895,"op":false},{"lr":5,"u":"帝京大学","g":4,"nm":"島田 晃希","t":3704,"fr":9,"rid":7640,"op":false},{"lr":6,"u":"城西大学","g":2,"nm":"小林 竜輝","t":3709,"fr":7,"rid":7719,"op":false},{"lr":7,"u":"青山学院大学","g":4,"nm":"宇田川 瞬矢","t":3711,"fr":1,"rid":7599,"op":false},{"lr":8,"u":"早稲田大学","g":2,"nm":"山口 竣平","t":3714,"fr":4,"rid":7739,"op":false},{"lr":9,"u":"創価大学","g":3,"nm":"織橋 巧","t":3724,"fr":8,"rid":7746,"op":false},{"lr":10,"u":"東洋大学","g":2,"nm":"迎 暖人","t":3726,"fr":14,"rid":7727,"op":false},{"lr":11,"u":"東京国際大学","g":4,"nm":"菅野 裕二郎","t":3727,"fr":16,"rid":7815,"op":false},{"lr":12,"u":"東京農業大学","g":4,"nm":"原田 洋輔","t":3744,"fr":18,"rid":7684,"op":false},{"lr":13,"u":"東海大学","g":4,"nm":"草刈 恭弓","t":3748,"fr":12,"rid":7903,"op":false},{"lr":14,"u":"日本大学","g":4,"nm":"冨田 悠晟","t":3750,"fr":10,"rid":7803,"op":false},{"lr":15,"u":"立教大学","g":3,"nm":"原田 颯大","t":3776,"fr":20,"rid":7658,"op":false},{"lr":16,"u":"中央学院大学","g":4,"nm":"坂本 駿","t":3787,"fr":11,"rid":7792,"op":false},{"lr":17,"u":"神奈川大学","g":3,"nm":"新妻 玲旺","t":3792,"fr":13,"rid":7663,"op":false},{"lr":18,"u":"山梨学院大学","g":3,"nm":"占部 大和","t":3806,"fr":17,"rid":7705,"op":false},{"lr":19,"u":"日本体育大学","g":2,"nm":"荻野 桂輔","t":3817,"fr":15,"rid":7923,"op":false},{"lr":20,"u":"大東文化大学","g":1,"nm":"菅崎 大翔","t":3851,"fr":19,"rid":7917,"op":false},{"lr":null,"u":"関東学生連合","g":4,"nm":"大島 史也","t":3801,"fr":null,"rid":7932,"op":true}],[{"lr":1,"u":"早稲田大学","g":1,"nm":"鈴木 琉胤","t":3601,"fr":4,"rid":7869,"op":false},{"lr":2,"u":"中央大学","g":2,"nm":"岡田 開成","t":3637,"fr":5,"rid":7797,"op":false},{"lr":3,"u":"青山学院大学","g":3,"nm":"平松 享祐","t":3645,"fr":1,"rid":7861,"op":false},{"lr":4,"u":"國學院大學","g":3,"nm":"辻原 輝","t":3659,"fr":2,"rid":7600,"op":false},{"lr":5,"u":"東海大学","g":3,"nm":"南坂 柚汰","t":3682,"fr":12,"rid":7680,"op":false},{"lr":6,"u":"大東文化大学","g":2,"nm":"松浦 輝仁","t":3708,"fr":19,"rid":7918,"op":false},{"lr":7,"u":"帝京大学","g":3,"nm":"谷口 颯太","t":3711,"fr":9,"rid":7888,"op":false},{"lr":8,"u":"順天堂大学","g":2,"nm":"川原 琉人","t":3717,"fr":3,"rid":7826,"op":false},{"lr":9,"u":"東洋大学","g":4,"nm":"緒方 澪那斗","t":3724,"fr":14,"rid":7625,"op":false},{"lr":9,"u":"神奈川大学","g":3,"nm":"平川 瑠星","t":3724,"fr":13,"rid":7914,"op":false},{"lr":11,"u":"立教大学","g":4,"nm":"国安 広人","t":3738,"fr":20,"rid":7549,"op":false},{"lr":12,"u":"中央学院大学","g":2,"nm":"長友 英吾","t":3739,"fr":11,"rid":7790,"op":false},{"lr":13,"u":"東京農業大学","g":4,"nm":"深堀 優","t":3754,"fr":18,"rid":7689,"op":false},{"lr":14,"u":"日本大学","g":3,"nm":"片桐 禅太","t":3761,"fr":10,"rid":7901,"op":false},{"lr":15,"u":"創価大学","g":2,"nm":"山口 翔輝","t":3764,"fr":8,"rid":7744,"op":false},{"lr":16,"u":"城西大学","g":4,"nm":"桜井 優我","t":3783,"fr":7,"rid":7537,"op":false},{"lr":17,"u":"日本体育大学","g":4,"nm":"山崎 丞","t":3787,"fr":15,"rid":7544,"op":false},{"lr":18,"u":"東京国際大学","g":3,"nm":"久保 遼人","t":3792,"fr":16,"rid":7879,"op":false},{"lr":19,"u":"駒澤大学","g":3,"nm":"村上 響","t":3804,"fr":6,"rid":7715,"op":false},{"lr":20,"u":"山梨学院大学","g":2,"nm":"阿部 紘也","t":3886,"fr":17,"rid":7777,"op":false},{"lr":null,"u":"関東学生連合","g":null,"nm":"本多 健亮","t":3805,"fr":null,"rid":7933,"op":true}],[{"lr":1,"u":"青山学院大学","g":4,"nm":"黒田 朝日","t":4036,"fr":1,"rid":7594,"op":false},{"lr":2,"u":"城西大学","g":4,"nm":"斎藤 将也","t":4168,"fr":7,"rid":7532,"op":false},{"lr":3,"u":"早稲田大学","g":3,"nm":"工藤 慎作","t":4186,"fr":4,"rid":7613,"op":false},{"lr":4,"u":"國學院大學","g":1,"nm":"高石 樹","t":4205,"fr":2,"rid":7866,"op":false},{"lr":5,"u":"順天堂大学","g":3,"nm":"小林 侑世","t":4231,"fr":3,"rid":7832,"op":false},{"lr":6,"u":"創価大学","g":4,"nm":"野沢 悠真","t":4291,"fr":8,"rid":7495,"op":false},{"lr":7,"u":"駒澤大学","g":3,"nm":"安原 海晴","t":4298,"fr":6,"rid":7712,"op":false},{"lr":8,"u":"帝京大学","g":3,"nm":"浅川 侑大","t":4311,"fr":9,"rid":7748,"op":false},{"lr":9,"u":"日本大学","g":4,"nm":"鈴木 孔士","t":4319,"fr":10,"rid":7655,"op":false},{"lr":10,"u":"山梨学院大学","g":4,"nm":"弓削 征慶","t":4320,"fr":17,"rid":7702,"op":false},{"lr":11,"u":"中央大学","g":3,"nm":"柴田 大地","t":4336,"fr":5,"rid":7592,"op":false},{"lr":12,"u":"中央学院大学","g":2,"nm":"米田 昂太","t":4349,"fr":11,"rid":7890,"op":false},{"lr":13,"u":"東海大学","g":3,"nm":"永本 脩","t":4359,"fr":12,"rid":7904,"op":false},{"lr":14,"u":"大東文化大学","g":1,"nm":"上田 翔大","t":4409,"fr":19,"rid":7919,"op":false},{"lr":15,"u":"東洋大学","g":2,"nm":"宮崎 優","t":4418,"fr":14,"rid":7724,"op":false},{"lr":16,"u":"神奈川大学","g":3,"nm":"三原 涼雅","t":4462,"fr":13,"rid":7819,"op":false},{"lr":17,"u":"立教大学","g":3,"nm":"木島 陸","t":4470,"fr":20,"rid":7926,"op":false},{"lr":18,"u":"日本体育大学","g":4,"nm":"浦上 和樹","t":4478,"fr":15,"rid":7784,"op":false},{"lr":19,"u":"東京農業大学","g":4,"nm":"小島 岳斗","t":4512,"fr":18,"rid":7908,"op":false},{"lr":20,"u":"東京国際大学","g":1,"nm":"荒谷 俊輔","t":4570,"fr":16,"rid":7880,"op":false},{"lr":null,"u":"関東学生連合","g":3,"nm":"高橋 歩夢","t":4599,"fr":null,"rid":7934,"op":true}],[{"lr":1,"u":"創価大学","g":3,"nm":"小池 莉希","t":3408,"fr":8,"rid":7620,"op":false},{"lr":2,"u":"駒澤大学","g":4,"nm":"伊藤 蒼唯","t":3410,"fr":6,"rid":7480,"op":false},{"lr":3,"u":"青山学院大学","g":1,"nm":"石川 浩輝","t":3435,"fr":1,"rid":7862,"op":false},{"lr":4,"u":"中央大学","g":2,"nm":"並川 颯太","t":3456,"fr":5,"rid":7873,"op":false},{"lr":5,"u":"神奈川大学","g":3,"nm":"大岩 蓮","t":3464,"fr":13,"rid":7825,"op":false},{"lr":6,"u":"早稲田大学","g":3,"nm":"山崎 一吹","t":3511,"fr":4,"rid":7740,"op":false},{"lr":6,"u":"帝京大学","g":3,"nm":"広田 陸","t":3511,"fr":9,"rid":7753,"op":false},{"lr":8,"u":"國學院大學","g":3,"nm":"後村 光星","t":3524,"fr":2,"rid":7601,"op":false},{"lr":9,"u":"城西大学","g":4,"nm":"大沼 良太郎","t":3532,"fr":7,"rid":7535,"op":false},{"lr":10,"u":"東京国際大学","g":4,"nm":"中山 拓真","t":3533,"fr":16,"rid":7810,"op":false},{"lr":11,"u":"中央学院大学","g":4,"nm":"小松 裕大朗","t":3535,"fr":11,"rid":7672,"op":false},{"lr":12,"u":"順天堂大学","g":2,"nm":"谷本 昂士郎","t":3538,"fr":3,"rid":7827,"op":false},{"lr":13,"u":"立教大学","g":3,"nm":"野口 颯汰","t":3542,"fr":20,"rid":7927,"op":false},{"lr":14,"u":"東洋大学","g":2,"nm":"内堀 勇","t":3551,"fr":14,"rid":7725,"op":false},{"lr":15,"u":"日本大学","g":3,"nm":"山口 聡太","t":3559,"fr":10,"rid":7802,"op":false},{"lr":16,"u":"日本体育大学","g":2,"nm":"山上 勇希","t":3604,"fr":15,"rid":7924,"op":false},{"lr":17,"u":"東京農業大学","g":2,"nm":"梅原 悠良","t":3633,"fr":18,"rid":7909,"op":false},{"lr":18,"u":"山梨学院大学","g":3,"nm":"南葉 聖琥","t":3639,"fr":17,"rid":7898,"op":false},{"lr":19,"u":"東海大学","g":2,"nm":"水野 夢大","t":3649,"fr":12,"rid":7905,"op":false},{"lr":20,"u":"大東文化大学","g":4,"nm":"戸田 優真","t":3675,"fr":19,"rid":7920,"op":false},{"lr":null,"u":"関東学生連合","g":3,"nm":"山中 寿世夢","t":3566,"fr":null,"rid":7935,"op":true}],[{"lr":1,"u":"國學院大學","g":4,"nm":"高山 豪起","t":3654,"fr":2,"rid":7501,"op":false},{"lr":2,"u":"順天堂大学","g":2,"nm":"玉目 陸","t":3741,"fr":3,"rid":7831,"op":false},{"lr":3,"u":"青山学院大学","g":2,"nm":"佐藤 愛斗","t":3769,"fr":1,"rid":7709,"op":false},{"lr":4,"u":"城西大学","g":4,"nm":"山中 達貴","t":3778,"fr":7,"rid":7875,"op":false},{"lr":5,"u":"日本体育大学","g":4,"nm":"二村 昇太朗","t":3784,"fr":15,"rid":7785,"op":false},{"lr":6,"u":"帝京大学","g":4,"nm":"柴戸 遼太","t":3787,"fr":9,"rid":7505,"op":false},{"lr":7,"u":"中央大学","g":2,"nm":"七枝 直","t":3797,"fr":5,"rid":7874,"op":false},{"lr":8,"u":"東洋大学","g":3,"nm":"浜中 尊","t":3800,"fr":14,"rid":7885,"op":false},{"lr":9,"u":"駒澤大学","g":2,"nm":"谷中 晴","t":3818,"fr":6,"rid":7713,"op":false},{"lr":9,"u":"日本大学","g":3,"nm":"天野 啓太","t":3818,"fr":10,"rid":7902,"op":false},{"lr":11,"u":"東海大学","g":4,"nm":"鈴木 天智","t":3819,"fr":12,"rid":7677,"op":false},{"lr":12,"u":"早稲田大学","g":4,"nm":"間瀬田 純平","t":3838,"fr":4,"rid":7540,"op":false},{"lr":13,"u":"山梨学院大学","g":2,"nm":"大杉 亮太朗","t":3847,"fr":17,"rid":7780,"op":false},{"lr":14,"u":"神奈川大学","g":3,"nm":"滝本 朗史","t":3849,"fr":13,"rid":7823,"op":false},{"lr":15,"u":"中央学院大学","g":4,"nm":"三角 洸太","t":3861,"fr":11,"rid":7891,"op":false},{"lr":16,"u":"東京国際大学","g":4,"nm":"大村 良紀","t":3878,"fr":16,"rid":7813,"op":false},{"lr":17,"u":"創価大学","g":4,"nm":"石丸 惇那","t":3886,"fr":8,"rid":7497,"op":false},{"lr":18,"u":"大東文化大学","g":2,"nm":"中沢 真大","t":3891,"fr":19,"rid":7754,"op":false},{"lr":19,"u":"東京農業大学","g":1,"nm":"内田 温規","t":3897,"fr":18,"rid":7910,"op":false},{"lr":20,"u":"立教大学","g":4,"nm":"小倉 史也","t":3919,"fr":20,"rid":7764,"op":false}],[{"lr":1,"u":"青山学院大学","g":4,"nm":"塩出 翔太","t":3825,"fr":1,"rid":7597,"op":false},{"lr":2,"u":"國學院大學","g":2,"nm":"飯国 新太","t":3841,"fr":2,"rid":7729,"op":false},{"lr":3,"u":"順天堂大学","g":2,"nm":"永原 颯磨","t":3844,"fr":3,"rid":7896,"op":false},{"lr":4,"u":"駒澤大学","g":4,"nm":"山川 拓馬","t":3874,"fr":6,"rid":7479,"op":false},{"lr":4,"u":"中央大学","g":2,"nm":"佐藤 大介","t":3874,"fr":5,"rid":7794,"op":false},{"lr":4,"u":"帝京大学","g":2,"nm":"松井 一","t":3874,"fr":9,"rid":7889,"op":false},{"lr":7,"u":"中央学院大学","g":4,"nm":"黒谷 優","t":3892,"fr":11,"rid":7673,"op":false},{"lr":8,"u":"東京国際大学","g":4,"nm":"前田 寛明","t":3895,"fr":16,"rid":7881,"op":false},{"lr":9,"u":"山梨学院大学","g":2,"nm":"松岡 一星","t":3901,"fr":17,"rid":7899,"op":false},{"lr":10,"u":"東海大学","g":4,"nm":"ロホマン シュモン","t":3905,"fr":12,"rid":7906,"op":false},{"lr":11,"u":"創価大学","g":1,"nm":"衣川 勇太","t":3914,"fr":8,"rid":7876,"op":false},{"lr":12,"u":"日本体育大学","g":3,"nm":"吉田 黎大","t":3920,"fr":15,"rid":7786,"op":false},{"lr":13,"u":"城西大学","g":3,"nm":"小田 伊織","t":3926,"fr":7,"rid":7623,"op":false},{"lr":14,"u":"東洋大学","g":4,"nm":"網本 佳悟","t":3953,"fr":14,"rid":7723,"op":false},{"lr":15,"u":"東京農業大学","g":2,"nm":"菅原 匠人","t":3955,"fr":18,"rid":7911,"op":false},{"lr":16,"u":"早稲田大学","g":1,"nm":"堀野 正太","t":3969,"fr":4,"rid":7870,"op":false},{"lr":17,"u":"大東文化大学","g":4,"nm":"照井 海翔","t":4004,"fr":19,"rid":7921,"op":false},{"lr":18,"u":"日本大学","g":4,"nm":"山口 月暉","t":4006,"fr":10,"rid":7653,"op":false},{"lr":19,"u":"神奈川大学","g":2,"nm":"遠藤 優裕","t":4008,"fr":13,"rid":7915,"op":false},{"lr":20,"u":"立教大学","g":2,"nm":"山下 翔吾","t":4014,"fr":20,"rid":7928,"op":false},{"lr":null,"u":"関東学生連合","g":4,"nm":"横尾 皓","t":3928,"fr":null,"rid":7936,"op":true}],[{"lr":1,"u":"青山学院大学","g":4,"nm":"佐藤 有一","t":4058,"fr":1,"rid":7863,"op":false},{"lr":2,"u":"早稲田大学","g":3,"nm":"小平 敦之","t":4065,"fr":4,"rid":7871,"op":false},{"lr":3,"u":"國學院大學","g":1,"nm":"野田 顕臣","t":4073,"fr":2,"rid":7867,"op":false},{"lr":4,"u":"帝京大学","g":4,"nm":"尾崎 仁哉","t":4075,"fr":9,"rid":7638,"op":false},{"lr":5,"u":"順天堂大学","g":4,"nm":"石岡 大侑","t":4103,"fr":3,"rid":7829,"op":false},{"lr":6,"u":"城西大学","g":3,"nm":"中島 巨翔","t":4110,"fr":7,"rid":7721,"op":false},{"lr":7,"u":"神奈川大学","g":3,"nm":"花井 創","t":4124,"fr":13,"rid":7916,"op":false},{"lr":8,"u":"中央大学","g":4,"nm":"吉居 駿恭","t":4127,"fr":5,"rid":7491,"op":false},{"lr":9,"u":"日本体育大学","g":2,"nm":"佐藤 大和","t":4143,"fr":15,"rid":7781,"op":false},{"lr":10,"u":"駒澤大学","g":2,"nm":"菅谷 希弥","t":4157,"fr":6,"rid":7865,"op":false},{"lr":11,"u":"大東文化大学","g":4,"nm":"入浜 輝大","t":4168,"fr":19,"rid":7518,"op":false},{"lr":12,"u":"東海大学","g":2,"nm":"中野 純平","t":4171,"fr":12,"rid":7907,"op":false},{"lr":13,"u":"日本大学","g":4,"nm":"中沢 星音","t":4173,"fr":10,"rid":7656,"op":false},{"lr":14,"u":"東京農業大学","g":2,"nm":"菅野 優空","t":4175,"fr":18,"rid":7912,"op":false},{"lr":15,"u":"東京国際大学","g":4,"nm":"川内 琉生","t":4179,"fr":16,"rid":7882,"op":false},{"lr":16,"u":"中央学院大学","g":2,"nm":"山中 航太","t":4189,"fr":11,"rid":7892,"op":false},{"lr":17,"u":"山梨学院大学","g":3,"nm":"和田 瑛登","t":4191,"fr":17,"rid":7701,"op":false},{"lr":18,"u":"創価大学","g":2,"nm":"榎木 凜太朗","t":4206,"fr":8,"rid":7877,"op":false},{"lr":19,"u":"東洋大学","g":3,"nm":"久保田 琉月","t":4211,"fr":14,"rid":7886,"op":false},{"lr":20,"u":"立教大学","g":4,"nm":"永井 駿","t":4259,"fr":20,"rid":7765,"op":false},{"lr":null,"u":"関東学生連合","g":4,"nm":"染谷 雄輝","t":4153,"fr":null,"rid":7937,"op":true}],[{"lr":1,"u":"駒澤大学","g":4,"nm":"佐藤 圭汰","t":4051,"fr":6,"rid":7586,"op":false},{"lr":2,"u":"青山学院大学","g":2,"nm":"折田 壮太","t":4079,"fr":1,"rid":7864,"op":false},{"lr":3,"u":"順天堂大学","g":2,"nm":"山本 悠","t":4100,"fr":3,"rid":7897,"op":false},{"lr":4,"u":"國學院大學","g":2,"nm":"尾熊 迅斗","t":4113,"fr":2,"rid":7868,"op":false},{"lr":5,"u":"帝京大学","g":4,"nm":"鎗田 大輝","t":4123,"fr":9,"rid":7751,"op":false},{"lr":6,"u":"東洋大学","g":3,"nm":"薄根 大河","t":4137,"fr":14,"rid":7726,"op":false},{"lr":7,"u":"日本体育大学","g":1,"nm":"夏見 虹郎","t":4147,"fr":15,"rid":7925,"op":false},{"lr":8,"u":"神奈川大学","g":4,"nm":"志食 隆希","t":4159,"fr":13,"rid":7821,"op":false},{"lr":9,"u":"東京国際大学","g":1,"nm":"久保 茉潤","t":4166,"fr":16,"rid":7883,"op":false},{"lr":10,"u":"早稲田大学","g":2,"nm":"瀬間 元輔","t":4180,"fr":4,"rid":7872,"op":false},{"lr":10,"u":"日本大学","g":4,"nm":"大仲 竜平","t":4180,"fr":10,"rid":7657,"op":false},{"lr":12,"u":"東海大学","g":4,"nm":"竹割 真","t":4187,"fr":12,"rid":7569,"op":false},{"lr":13,"u":"城西大学","g":4,"nm":"岩田 真之","t":4211,"fr":7,"rid":7720,"op":false},{"lr":14,"u":"中央学院大学","g":4,"nm":"成川 翔太","t":4232,"fr":11,"rid":7893,"op":false},{"lr":15,"u":"中央大学","g":4,"nm":"吉中 祐太","t":4233,"fr":5,"rid":7798,"op":false},{"lr":16,"u":"立教大学","g":2,"nm":"鈴木 愛音","t":4239,"fr":20,"rid":7929,"op":false},{"lr":17,"u":"創価大学","g":3,"nm":"斉藤 大空","t":4244,"fr":8,"rid":7743,"op":false},{"lr":18,"u":"山梨学院大学","g":3,"nm":"田原 匠真","t":4274,"fr":17,"rid":7900,"op":false},{"lr":19,"u":"大東文化大学","g":4,"nm":"赤星 龍舞","t":4316,"fr":19,"rid":7922,"op":false},{"lr":20,"u":"東京農業大学","g":1,"nm":"井坂 光","t":4330,"fr":18,"rid":7913,"op":false},{"lr":null,"u":"関東学生連合","g":3,"nm":"佐野 颯人","t":4113,"fr":null,"rid":7938,"op":true}]],"src":["https://www.hakone-ekiden.jp/record/tournament-detail.php?tn=106"]}],"zen":[{"n":58,"year":2026,"date":"2026-11-01","name":"第58回全日本大学駅伝対校選手権大会","dist":[9.5,11.1,11.9,11.8,12.4,12.8,17.6,19.7],"teams":[{"u":"早稲田大学","t":18211,"op":false,"rank":1},{"u":"國學院大學","t":18425,"op":false,"rank":2},{"u":"創価大学","t":18568,"op":false,"rank":3},{"u":"青山学院大学","t":18616,"op":false,"rank":4},{"u":"中央大学","t":18689,"op":false,"rank":5},{"u":"駒澤大学","t":18689,"op":false,"rank":6},{"u":"大東文化大学","t":18692,"op":false,"rank":7},{"u":"帝京大学","t":18722,"op":false,"rank":8},{"u":"順天堂大学","t":18740,"op":false,"rank":9},{"u":"日本大学","t":18843,"op":false,"rank":10},{"u":"東海大学","t":18934,"op":false,"rank":11},{"u":"神奈川大学","t":18949,"op":false,"rank":12},{"u":"中央学院大学","t":18985,"op":false,"rank":13},{"u":"山梨学院大学","t":19000,"op":false,"rank":14},{"u":"東洋大学","t":19191,"op":false,"rank":15},{"u":"関西学院大学","t":19602,"op":false,"rank":16},{"u":"大阪経済大学","t":19691,"op":false,"rank":17},{"u":"立命館大学","t":19724,"op":false,"rank":18},{"u":"札幌学院大学","t":19726,"op":false,"rank":19},{"u":"京都産業大学","t":19790,"op":false,"rank":20},{"u":"愛知工業大学","t":19912,"op":false,"rank":21},{"u":"広島経済大学","t":19931,"op":false,"rank":22},{"u":"信州大学","t":20121,"op":false,"rank":23},{"u":"志學館大学","t":20232,"op":false,"rank":24},{"u":"東北大学","t":20581,"op":false,"rank":25},{"u":"日本学連選抜","t":19421,"op":true,"rank":null},{"u":"東海学連選抜","t":19676,"op":true,"rank":null}],"legs":[[{"lr":1,"nm":"榅山 一颯","u":"青山学院大学","t":1665,"rec":false,"op":false,"g":2,"cr":1},{"lr":2,"nm":"本田 桜二郎","u":"早稲田大学","t":1667,"rec":false,"op":false,"cr":2},{"lr":3,"nm":"上岡 煌","u":"駒澤大学","t":1668,"rec":false,"op":false,"cr":3},{"lr":4,"nm":"簡 子傑","u":"中央大学","t":1669,"rec":false,"op":false,"cr":4},{"lr":5,"nm":"松尾 航希","u":"帝京大学","t":1669,"rec":false,"op":false,"cr":5},{"lr":6,"nm":"首藤 海翔","u":"日本大学","t":1669,"rec":false,"op":false,"cr":6},{"lr":7,"nm":"大野 聖登","u":"順天堂大学","t":1670,"rec":false,"op":false,"cr":7},{"lr":8,"nm":"米田 昂太","u":"中央学院大学","t":1672,"rec":false,"op":false,"cr":8},{"lr":9,"nm":"近江 亮","u":"大東文化大学","t":1674,"rec":false,"op":false,"cr":10},{"lr":10,"nm":"北村 海智","u":"神奈川大学","t":1674,"rec":false,"op":false,"cr":12},{"lr":11,"nm":"田村 幸太","u":"創価大学","t":1674,"rec":false,"op":false,"cr":9},{"lr":12,"nm":"矢口 陽太","u":"東海大学","t":1674,"rec":false,"op":false,"cr":11},{"lr":13,"nm":"尾熊 迅斗","u":"國學院大學","t":1675,"rec":false,"op":false,"cr":13},{"lr":14,"nm":"山下 慶馬","u":"関西学院大学","t":1679,"rec":false,"op":false,"cr":14},{"lr":15,"nm":"松原 幸之助","u":"京都産業大学","t":1680,"rec":false,"op":false,"cr":15},{"lr":16,"nm":"和田 瑛登","u":"山梨学院大学","t":1681,"rec":false,"op":false,"cr":16},{"lr":17,"nm":"林 柚杏","u":"東洋大学","t":1681,"rec":false,"op":false,"cr":17},{"lr":18,"nm":"片岡 晴哉","u":"信州大学","t":1690,"rec":false,"op":false,"cr":18},{"lr":19,"nm":"水野 颯也","u":"立命館大学","t":1691,"rec":false,"op":false,"cr":19},{"lr":20,"nm":"瀬尾 大和","u":"広島経済大学","t":1694,"rec":false,"op":false,"cr":20},{"lr":21,"nm":"清水 大斗","u":"東海学連選抜","t":1695,"rec":false,"op":true,"cr":null},{"lr":22,"nm":"小柴 裕士郎","u":"日本学連選抜","t":1695,"rec":false,"op":true,"cr":null},{"lr":23,"nm":"浦田 陽聖","u":"札幌学院大学","t":1705,"rec":false,"op":false,"cr":21},{"lr":24,"nm":"桂 一太","u":"大阪経済大学","t":1706,"rec":false,"op":false,"cr":22},{"lr":25,"nm":"坂井田 翔太","u":"愛知工業大学","t":1728,"rec":false,"op":false,"cr":23},{"lr":26,"nm":"中村 晃斗","u":"志學館大学","t":1740,"rec":false,"op":false,"cr":24},{"lr":27,"nm":"松本 諒哉","u":"東北大学","t":1744,"rec":false,"op":false,"cr":25}],[{"lr":1,"nm":"増子 陽太","u":"早稲田大学","t":1851,"rec":true,"op":false,"g":1,"cr":1},{"lr":1,"nm":"楠岡 由浩","u":"帝京大学","t":1851,"rec":true,"op":false,"g":4,"cr":2},{"lr":3,"nm":"鈴木 大翔","u":"駒澤大学","t":1857,"rec":false,"op":false,"cr":3},{"lr":4,"nm":"永本 脩","u":"東海大学","t":1872,"rec":false,"op":false,"cr":4},{"lr":5,"nm":"浅野 結太","u":"國學院大學","t":1881,"rec":false,"op":false,"cr":5},{"lr":6,"nm":"上田 航大","u":"神奈川大学","t":1890,"rec":false,"op":false,"cr":6},{"lr":7,"nm":"吉岡 大翔","u":"順天堂大学","t":1899,"rec":false,"op":false,"cr":7},{"lr":8,"nm":"大濱 逞真","u":"大東文化大学","t":1903,"rec":false,"op":false,"cr":8},{"lr":9,"nm":"織橋 巧","u":"創価大学","t":1917,"rec":false,"op":false,"cr":10},{"lr":10,"nm":"石川 浩輝","u":"青山学院大学","t":1918,"rec":false,"op":false,"cr":9},{"lr":11,"nm":"市川 大世","u":"中央学院大学","t":1923,"rec":false,"op":false,"cr":11},{"lr":12,"nm":"岩田 玄弥","u":"愛知工業大学","t":1959,"rec":false,"op":false,"cr":20},{"lr":13,"nm":"栗村 凌","u":"中央大学","t":1962,"rec":false,"op":false,"cr":12},{"lr":13,"nm":"岩坂 蓮太","u":"大阪経済大学","t":1962,"rec":false,"op":false,"cr":17},{"lr":15,"nm":"天野 啓太","u":"日本大学","t":1964,"rec":false,"op":false,"cr":13},{"lr":16,"nm":"占部 大和","u":"山梨学院大学","t":1974,"rec":false,"op":false,"cr":14},{"lr":17,"nm":"南部 悠陽","u":"日本学連選抜","t":1976,"rec":false,"op":true,"cr":null},{"lr":18,"nm":"寺川 直央","u":"関西学院大学","t":1979,"rec":false,"op":false,"cr":15},{"lr":19,"nm":"高坂 光希","u":"札幌学院大学","t":1982,"rec":false,"op":false,"cr":19},{"lr":20,"nm":"竹村 明人","u":"京都産業大学","t":1984,"rec":false,"op":false,"cr":16},{"lr":21,"nm":"内堀 勇","u":"東洋大学","t":2000,"rec":false,"op":false,"cr":18},{"lr":22,"nm":"嶋津 明良","u":"信州大学","t":2002,"rec":false,"op":false,"cr":21},{"lr":23,"nm":"前野 皓士","u":"東海学連選抜","t":2013,"rec":false,"op":true,"cr":null},{"lr":24,"nm":"柏木 優希","u":"立命館大学","t":2020,"rec":false,"op":false,"cr":22},{"lr":25,"nm":"小田 夕琥","u":"志學館大学","t":2024,"rec":false,"op":false,"cr":24},{"lr":26,"nm":"小川 晴也","u":"広島経済大学","t":2026,"rec":false,"op":false,"cr":23},{"lr":27,"nm":"渡邉 優典","u":"東北大学","t":2170,"rec":false,"op":false,"cr":25}],[{"lr":1,"nm":"新妻 遼己","u":"早稲田大学","t":1965,"rec":true,"op":false,"g":1,"cr":1},{"lr":2,"nm":"上田 翔大","u":"大東文化大学","t":2024,"rec":false,"op":false,"cr":6},{"lr":3,"nm":"佐藤 大介","u":"中央大学","t":2025,"rec":false,"op":false,"cr":10},{"lr":4,"nm":"池間 凛斗","u":"順天堂大学","t":2027,"rec":false,"op":false,"cr":5},{"lr":5,"nm":"松田 煌希","u":"青山学院大学","t":2030,"rec":false,"op":false,"cr":8},{"lr":6,"nm":"牟田 凜太","u":"駒澤大学","t":2032,"rec":false,"op":false,"cr":2},{"lr":6,"nm":"辻原 輝","u":"國學院大學","t":2032,"rec":false,"op":false,"cr":3},{"lr":8,"nm":"平川 瑠星","u":"神奈川大学","t":2039,"rec":false,"op":false,"cr":7},{"lr":9,"nm":"松井 海斗","u":"東洋大学","t":2067,"rec":false,"op":false,"cr":14},{"lr":10,"nm":"松井 一","u":"帝京大学","t":2068,"rec":false,"op":false,"cr":4},{"lr":11,"nm":"長部 虎太郎","u":"中央学院大学","t":2076,"rec":false,"op":false,"cr":12},{"lr":12,"nm":"菅野 元太","u":"創価大学","t":2077,"rec":false,"op":false,"cr":11},{"lr":13,"nm":"後藤 玄樹","u":"日本大学","t":2088,"rec":false,"op":false,"cr":13},{"lr":14,"nm":"平井 璃空","u":"東海大学","t":2091,"rec":false,"op":false,"cr":9},{"lr":15,"nm":"松岡 一星","u":"山梨学院大学","t":2098,"rec":false,"op":false,"cr":15},{"lr":16,"nm":"田畑 来成","u":"東海学連選抜","t":2112,"rec":false,"op":true,"cr":null},{"lr":17,"nm":"佐藤 我駆人","u":"日本学連選抜","t":2114,"rec":false,"op":true,"cr":null},{"lr":18,"nm":"伊藤 大弥","u":"広島経済大学","t":2129,"rec":false,"op":false,"cr":20},{"lr":19,"nm":"児玉 航洋","u":"立命館大学","t":2144,"rec":false,"op":false,"cr":21},{"lr":20,"nm":"大橋 史空","u":"札幌学院大学","t":2147,"rec":false,"op":false,"cr":18},{"lr":21,"nm":"久山 大祐","u":"関西学院大学","t":2163,"rec":false,"op":false,"cr":16},{"lr":22,"nm":"西川 天馬","u":"京都産業大学","t":2165,"rec":false,"op":false,"cr":17},{"lr":23,"nm":"三浦 璃空","u":"大阪経済大学","t":2167,"rec":false,"op":false,"cr":19},{"lr":24,"nm":"大迫 汰希","u":"愛知工業大学","t":2177,"rec":false,"op":false,"cr":22},{"lr":25,"nm":"福嶋 明大","u":"信州大学","t":2179,"rec":false,"op":false,"cr":23},{"lr":26,"nm":"福田 陽仁","u":"志學館大学","t":2230,"rec":false,"op":false,"cr":24},{"lr":26,"nm":"照内 優允","u":"東北大学","t":2230,"rec":false,"op":false,"cr":25}],[{"lr":1,"nm":"飯國 新太","u":"國學院大學","t":1995,"rec":false,"op":false,"g":3,"cr":2},{"lr":2,"nm":"小池 莉希","u":"創価大学","t":1998,"rec":false,"op":false,"cr":9},{"lr":3,"nm":"宮崎 優","u":"東洋大学","t":2000,"rec":false,"op":false,"cr":12},{"lr":4,"nm":"小平 敦之","u":"早稲田大学","t":2004,"rec":false,"op":false,"cr":1},{"lr":5,"nm":"黒田 然","u":"青山学院大学","t":2007,"rec":false,"op":false,"cr":4},{"lr":6,"nm":"菅﨑 大翔","u":"大東文化大学","t":2032,"rec":false,"op":false,"cr":5},{"lr":7,"nm":"山崎 碧葉","u":"神奈川大学","t":2040,"rec":false,"op":false,"cr":7},{"lr":8,"nm":"今井 悠貴","u":"順天堂大学","t":2050,"rec":false,"op":false,"cr":8},{"lr":9,"nm":"柴田 大地","u":"中央大学","t":2052,"rec":false,"op":false,"cr":11},{"lr":10,"nm":"池谷 陸斗","u":"駒澤大学","t":2054,"rec":false,"op":false,"cr":3},{"lr":11,"nm":"廣田 陸","u":"帝京大学","t":2055,"rec":false,"op":false,"cr":6},{"lr":12,"nm":"松山 優太","u":"東海大学","t":2062,"rec":false,"op":false,"cr":10},{"lr":13,"nm":"山口 聡太","u":"日本大学","t":2080,"rec":false,"op":false,"cr":14},{"lr":14,"nm":"内尾 射光矢","u":"大阪経済大学","t":2087,"rec":false,"op":false,"cr":16},{"lr":15,"nm":"長友 英吾","u":"中央学院大学","t":2090,"rec":false,"op":false,"cr":13},{"lr":16,"nm":"坂本 亘生","u":"日本学連選抜","t":2094,"rec":false,"op":true,"cr":null},{"lr":17,"nm":"傳法谷 元","u":"山梨学院大学","t":2112,"rec":false,"op":false,"cr":15},{"lr":18,"nm":"上井 卓巳","u":"関西学院大学","t":2128,"rec":false,"op":false,"cr":17},{"lr":19,"nm":"南 月人","u":"京都産業大学","t":2129,"rec":false,"op":false,"cr":18},{"lr":20,"nm":"豊田 雄大","u":"愛知工業大学","t":2131,"rec":false,"op":false,"cr":19},{"lr":21,"nm":"藪田 虎志朗","u":"立命館大学","t":2144,"rec":false,"op":false,"cr":20},{"lr":22,"nm":"杉本 光琉","u":"東海学連選抜","t":2169,"rec":false,"op":true,"cr":null},{"lr":23,"nm":"大宮 千來","u":"札幌学院大学","t":2185,"rec":false,"op":false,"cr":21},{"lr":24,"nm":"漆原 幹人","u":"信州大学","t":2205,"rec":false,"op":false,"cr":23},{"lr":25,"nm":"田中 陸","u":"広島経済大学","t":2218,"rec":false,"op":false,"cr":22},{"lr":26,"nm":"小林 由輝","u":"東北大学","t":2230,"rec":false,"op":false,"cr":25},{"lr":27,"nm":"黒葛 琉碧","u":"志學館大学","t":2333,"rec":false,"op":false,"cr":24}],[{"lr":1,"nm":"鈴木 琉胤","u":"早稲田大学","t":2071,"rec":true,"op":false,"g":2,"cr":1},{"lr":2,"nm":"鼻野木 悠翔","u":"國學院大學","t":2134,"rec":false,"op":false,"cr":2},{"lr":3,"nm":"小河原 陽琉","u":"青山学院大学","t":2136,"rec":false,"op":false,"cr":4},{"lr":4,"nm":"植阪 嶺児","u":"駒澤大学","t":2138,"rec":false,"op":false,"cr":3},{"lr":5,"nm":"三宅 悠斗","u":"中央大学","t":2141,"rec":false,"op":false,"cr":10},{"lr":6,"nm":"山本 悠","u":"順天堂大学","t":2149,"rec":false,"op":false,"cr":6},{"lr":7,"nm":"棟方 一楽","u":"大東文化大学","t":2161,"rec":false,"op":false,"cr":5},{"lr":8,"nm":"村上 遵世","u":"創価大学","t":2176,"rec":false,"op":false,"cr":8},{"lr":9,"nm":"浅野 智仁","u":"帝京大学","t":2178,"rec":false,"op":false,"cr":7},{"lr":10,"nm":"迎 暖人","u":"東洋大学","t":2196,"rec":false,"op":false,"cr":12},{"lr":11,"nm":"一ノ瀬 慎太","u":"中央学院大学","t":2198,"rec":false,"op":false,"cr":13},{"lr":12,"nm":"新妻 昂己","u":"神奈川大学","t":2200,"rec":false,"op":false,"cr":9},{"lr":12,"nm":"松山 唯人","u":"東海大学","t":2200,"rec":false,"op":false,"cr":11},{"lr":14,"nm":"𣘺本 櫂知","u":"日本大学","t":2202,"rec":false,"op":false,"cr":14},{"lr":15,"nm":"高橋 楓河","u":"山梨学院大学","t":2209,"rec":false,"op":false,"cr":15},{"lr":16,"nm":"橋本 友樹","u":"大阪経済大学","t":2284,"rec":false,"op":false,"cr":16},{"lr":17,"nm":"藤田 大輝","u":"京都産業大学","t":2294,"rec":false,"op":false,"cr":17},{"lr":18,"nm":"岡村 和真","u":"日本学連選抜","t":2295,"rec":false,"op":true,"cr":null},{"lr":19,"nm":"阿部 祥典","u":"東海学連選抜","t":2306,"rec":false,"op":true,"cr":null},{"lr":19,"nm":"髙橋 早大","u":"立命館大学","t":2306,"rec":false,"op":false,"cr":19},{"lr":21,"nm":"冨永 己太朗","u":"関西学院大学","t":2313,"rec":false,"op":false,"cr":18},{"lr":22,"nm":"小林 歩夢","u":"札幌学院大学","t":2337,"rec":false,"op":false,"cr":21},{"lr":23,"nm":"日隈 敦士","u":"広島経済大学","t":2350,"rec":false,"op":false,"cr":22},{"lr":24,"nm":"加藤 晨","u":"愛知工業大学","t":2356,"rec":false,"op":false,"cr":20},{"lr":25,"nm":"村上 尚希","u":"信州大学","t":2369,"rec":false,"op":false,"cr":23},{"lr":26,"nm":"新美 友哉","u":"東北大学","t":2382,"rec":false,"op":false,"cr":24},{"lr":27,"nm":"大平 倫嗣","u":"志學館大学","t":2489,"rec":false,"op":false,"cr":25}],[{"lr":1,"nm":"吉田 蔵之介","u":"國學院大學","t":2201,"rec":true,"op":false,"g":4,"cr":2},{"lr":2,"nm":"並川 颯太","u":"中央大学","t":2214,"rec":false,"op":false,"cr":6},{"lr":3,"nm":"堀野 正太","u":"早稲田大学","t":2215,"rec":false,"op":false,"cr":1},{"lr":4,"nm":"飯田 翔大","u":"青山学院大学","t":2218,"rec":false,"op":false,"cr":3},{"lr":5,"nm":"原 悠太","u":"帝京大学","t":2235,"rec":false,"op":false,"cr":5},{"lr":6,"nm":"榎木 凜太朗","u":"創価大学","t":2238,"rec":false,"op":false,"cr":8},{"lr":7,"nm":"新妻 玲旺","u":"神奈川大学","t":2243,"rec":false,"op":false,"cr":9},{"lr":8,"nm":"菅谷 希弥","u":"駒澤大学","t":2245,"rec":false,"op":false,"cr":4},{"lr":9,"nm":"エヴァンス キプロップ","u":"大東文化大学","t":2271,"rec":false,"op":false,"cr":7},{"lr":10,"nm":"佐野 鈴太","u":"東海大学","t":2284,"rec":false,"op":false,"cr":11},{"lr":11,"nm":"倉本 晃羽","u":"東洋大学","t":2294,"rec":false,"op":false,"cr":12},{"lr":11,"nm":"綱本 幸栄","u":"山梨学院大学","t":2294,"rec":false,"op":false,"cr":15},{"lr":13,"nm":"石川 悠斗","u":"日本大学","t":2297,"rec":false,"op":false,"cr":14},{"lr":14,"nm":"永原 颯磨","u":"順天堂大学","t":2298,"rec":false,"op":false,"cr":10},{"lr":15,"nm":"徳善 龍","u":"中央学院大学","t":2321,"rec":false,"op":false,"cr":13},{"lr":16,"nm":"吉原 諒","u":"東海学連選抜","t":2322,"rec":false,"op":true,"cr":null},{"lr":17,"nm":"片山 堅友","u":"関西学院大学","t":2337,"rec":false,"op":false,"cr":16},{"lr":18,"nm":"兵藤 颯太","u":"日本学連選抜","t":2357,"rec":false,"op":true,"cr":null},{"lr":19,"nm":"髙倉 侃斗","u":"京都産業大学","t":2388,"rec":false,"op":false,"cr":18},{"lr":20,"nm":"田野 朝陽","u":"札幌学院大学","t":2393,"rec":false,"op":false,"cr":20},{"lr":21,"nm":"橋本 和希","u":"立命館大学","t":2407,"rec":false,"op":false,"cr":19},{"lr":22,"nm":"卯野 大樹","u":"大阪経済大学","t":2414,"rec":false,"op":false,"cr":17},{"lr":23,"nm":"横田 弥海","u":"愛知工業大学","t":2429,"rec":false,"op":false,"cr":21},{"lr":24,"nm":"倉元 大智","u":"志學館大学","t":2450,"rec":false,"op":false,"cr":24},{"lr":25,"nm":"井﨑 尋斗","u":"広島経済大学","t":2473,"rec":false,"op":false,"cr":22},{"lr":26,"nm":"有元 裕人","u":"信州大学","t":2486,"rec":false,"op":false,"cr":23},{"lr":27,"nm":"山内 滉介","u":"東北大学","t":2512,"rec":false,"op":false,"cr":25}],[{"lr":1,"nm":"シャドラック キップケメイ","u":"日本大学","t":2985,"rec":false,"op":false,"g":4,"cr":10},{"lr":2,"nm":"スティーブン ムチーニ","u":"創価大学","t":3048,"rec":false,"op":false,"cr":5},{"lr":3,"nm":"山口 竣平","u":"早稲田大学","t":3058,"rec":false,"op":false,"cr":1},{"lr":4,"nm":"野中 恒亨","u":"國學院大學","t":3067,"rec":false,"op":false,"cr":2},{"lr":5,"nm":"岡田 開成","u":"中央大学","t":3104,"rec":false,"op":false,"cr":6},{"lr":6,"nm":"桑田 駿介","u":"駒澤大学","t":3107,"rec":false,"op":false,"cr":4},{"lr":7,"nm":"平松 享祐","u":"青山学院大学","t":3119,"rec":false,"op":false,"cr":3},{"lr":8,"nm":"玉目 陸","u":"順天堂大学","t":3129,"rec":false,"op":false,"cr":9},{"lr":9,"nm":"谷口 颯太","u":"帝京大学","t":3135,"rec":false,"op":false,"cr":7},{"lr":10,"nm":"藤原 幹大","u":"大東文化大学","t":3141,"rec":false,"op":false,"cr":8},{"lr":11,"nm":"林 愛斗","u":"中央学院大学","t":3199,"rec":false,"op":false,"cr":13},{"lr":12,"nm":"大岩 蓮","u":"神奈川大学","t":3224,"rec":false,"op":false,"cr":11},{"lr":13,"nm":"鶴田 寛武","u":"日本学連選抜","t":3235,"rec":false,"op":true,"cr":null},{"lr":14,"nm":"平井 翼","u":"山梨学院大学","t":3243,"rec":false,"op":false,"cr":15},{"lr":15,"nm":"馬場 大翔","u":"東洋大学","t":3244,"rec":false,"op":false,"cr":14},{"lr":16,"nm":"中野 純平","u":"東海大学","t":3256,"rec":false,"op":false,"cr":12},{"lr":17,"nm":"中嶋 希","u":"東海学連選抜","t":3261,"rec":false,"op":true,"cr":null},{"lr":18,"nm":"髙田 智生","u":"立命館大学","t":3289,"rec":false,"op":false,"cr":18},{"lr":19,"nm":"栗田 紳冴","u":"札幌学院大学","t":3316,"rec":false,"op":false,"cr":19},{"lr":20,"nm":"辻田 鉄人","u":"志學館大学","t":3326,"rec":false,"op":false,"cr":24},{"lr":21,"nm":"尼子 和磨","u":"関西学院大学","t":3356,"rec":false,"op":false,"cr":16},{"lr":22,"nm":"中村 太一","u":"愛知工業大学","t":3371,"rec":false,"op":false,"cr":21},{"lr":23,"nm":"京川 大真","u":"大阪経済大学","t":3378,"rec":false,"op":false,"cr":17},{"lr":24,"nm":"中垣 颯太","u":"広島経済大学","t":3391,"rec":false,"op":false,"cr":22},{"lr":25,"nm":"出田 義貴","u":"東北大学","t":3432,"rec":false,"op":false,"cr":25},{"lr":26,"nm":"吉村 陸翔","u":"京都産業大学","t":3450,"rec":false,"op":false,"cr":20},{"lr":27,"nm":"川上 玄","u":"信州大学","t":3500,"rec":false,"op":false,"cr":23}],[{"lr":1,"nm":"工藤 慎作","u":"早稲田大学","t":3380,"rec":false,"op":false,"g":4,"cr":1},{"lr":2,"nm":"ブライアン キピエゴ","u":"山梨学院大学","t":3389,"rec":false,"op":false,"cr":14},{"lr":3,"nm":"髙石 樹","u":"國學院大學","t":3440,"rec":false,"op":false,"cr":2},{"lr":3,"nm":"山口 翔輝","u":"創価大学","t":3440,"rec":false,"op":false,"cr":3},{"lr":5,"nm":"松浦 輝仁","u":"大東文化大学","t":3486,"rec":false,"op":false,"cr":7},{"lr":6,"nm":"南坂 柚汰","u":"東海大学","t":3495,"rec":false,"op":false,"cr":11},{"lr":7,"nm":"小川 優晴","u":"中央学院大学","t":3506,"rec":false,"op":false,"cr":13},{"lr":8,"nm":"小林 侑世","u":"順天堂大学","t":3518,"rec":false,"op":false,"cr":9},{"lr":9,"nm":"藤田 大智","u":"中央大学","t":3522,"rec":false,"op":false,"cr":5},{"lr":10,"nm":"鳥井 健太","u":"青山学院大学","t":3523,"rec":false,"op":false,"cr":4},{"lr":11,"nm":"浅川 侑大","u":"帝京大学","t":3531,"rec":false,"op":false,"cr":8},{"lr":12,"nm":"長澤 辰朗","u":"日本大学","t":3558,"rec":false,"op":false,"cr":10},{"lr":13,"nm":"新谷 倖生","u":"駒澤大学","t":3588,"rec":false,"op":false,"cr":6},{"lr":14,"nm":"花井 創","u":"神奈川大学","t":3639,"rec":false,"op":false,"cr":12},{"lr":15,"nm":"日野 拓夢","u":"志學館大学","t":3640,"rec":false,"op":false,"cr":24},{"lr":16,"nm":"嘉味本 謙信","u":"関西学院大学","t":3647,"rec":false,"op":false,"cr":16},{"lr":17,"nm":"佐々木 昴","u":"広島経済大学","t":3650,"rec":false,"op":false,"cr":22},{"lr":18,"nm":"藤本 悠太郎","u":"日本学連選抜","t":3655,"rec":false,"op":true,"cr":null},{"lr":19,"nm":"キプゲノ ケネス","u":"札幌学院大学","t":3661,"rec":false,"op":false,"cr":19},{"lr":20,"nm":"内田 善登","u":"信州大学","t":3690,"rec":false,"op":false,"cr":23},{"lr":21,"nm":"野島 清盟","u":"大阪経済大学","t":3693,"rec":false,"op":false,"cr":17},{"lr":22,"nm":"古田 瑞樹","u":"京都産業大学","t":3700,"rec":false,"op":false,"cr":20},{"lr":23,"nm":"薄根 大河","u":"東洋大学","t":3709,"rec":false,"op":false,"cr":15},{"lr":24,"nm":"矢谷 隆斗","u":"立命館大学","t":3723,"rec":false,"op":false,"cr":18},{"lr":25,"nm":"渥美 希良","u":"愛知工業大学","t":3761,"rec":false,"op":false,"cr":21},{"lr":26,"nm":"田中 瑞輝","u":"東海学連選抜","t":3798,"rec":false,"op":true,"cr":null},{"lr":27,"nm":"向田 祐翔","u":"東北大学","t":3881,"rec":false,"op":false,"cr":25}]],"src":["https://the-ans.jp/chart/743216/","https://www.rikujyokyogi.co.jp/archives/220967"]}],"izumo":[{"n":38,"year":2026,"date":"2026-10-12","name":"第38回出雲全日本大学選抜駅伝競走","dist":[8.0,5.8,8.5,6.2,6.4,10.2],"teams":[{"u":"早稲田大学","t":7556,"op":false,"rank":1},{"u":"國學院大學","t":7614,"op":false,"rank":2},{"u":"アイビーリーグ選抜","t":7644,"op":false,"rank":3},{"u":"順天堂大学","t":7653,"op":false,"rank":4},{"u":"中央大学","t":7656,"op":false,"rank":5},{"u":"帝京大学","t":7661,"op":false,"rank":6},{"u":"駒澤大学","t":7665,"op":false,"rank":7},{"u":"日本大学","t":7695,"op":false,"rank":8},{"u":"創価大学","t":7711,"op":false,"rank":9},{"u":"城西大学","t":7762,"op":false,"rank":10},{"u":"青山学院大学","t":7793,"op":false,"rank":11},{"u":"関西大学","t":8155,"op":false,"rank":12},{"u":"札幌学院大学","t":8194,"op":false,"rank":13},{"u":"東北学連選抜","t":8197,"op":false,"rank":14},{"u":"皇學館大学","t":8198,"op":false,"rank":15},{"u":"信州大学","t":8229,"op":false,"rank":16},{"u":"京都産業大学","t":8252,"op":false,"rank":17},{"u":"広島経済大学","t":8326,"op":false,"rank":18},{"u":"中四国学連選抜","t":8351,"op":false,"rank":19},{"u":"第一工科大学","t":8353,"op":false,"rank":20},{"u":"金沢学院大学","t":8438,"op":false,"rank":21},{"u":"北海道大学","t":8901,"op":false,"rank":22}],"legs":[[{"lr":1,"nm":"鈴木 大翔","u":"駒澤大学","t":1362,"rec":false,"op":false,"cr":1},{"lr":2,"nm":"石川 浩輝","u":"青山学院大学","t":1368,"rec":false,"op":false,"cr":2},{"lr":3,"nm":"藤田 大智","u":"中央大学","t":1371,"rec":false,"op":false,"cr":3},{"lr":4,"nm":"浅野 結太","u":"國學院大學","t":1372,"rec":false,"op":false,"cr":4},{"lr":5,"nm":"天野 啓太","u":"日本大学","t":1374,"rec":false,"op":false,"cr":5},{"lr":6,"nm":"小林 侑世","u":"順天堂大学","t":1375,"rec":false,"op":false,"cr":6},{"lr":7,"nm":"吉倉 ナヤブ直希","u":"早稲田大学","t":1378,"rec":false,"op":false,"cr":7},{"lr":8,"nm":"菅野 元太","u":"創価大学","t":1378,"rec":false,"op":false,"cr":8},{"lr":9,"nm":"松尾 航希","u":"帝京大学","t":1381,"rec":false,"op":false,"cr":9},{"lr":10,"nm":"ニック ベンドツェン","u":"アイビーリーグ選抜","t":1385,"rec":false,"op":false,"cr":10},{"lr":11,"nm":"チェボティビン サイラスキプラガット","u":"第一工科大学","t":1416,"rec":false,"op":false,"cr":11},{"lr":12,"nm":"山本 聖也","u":"城西大学","t":1420,"rec":false,"op":false,"cr":12},{"lr":13,"nm":"片岡 晴哉","u":"信州大学","t":1439,"rec":false,"op":false,"cr":13},{"lr":14,"nm":"栗田 紳冴","u":"札幌学院大学","t":1440,"rec":false,"op":false,"cr":14},{"lr":15,"nm":"浦野 蒼日","u":"金沢学院大学","t":1442,"rec":false,"op":false,"cr":15},{"lr":16,"nm":"吉田 奏斗","u":"東北学連選抜","t":1448,"rec":false,"op":false,"cr":16},{"lr":17,"nm":"清水 大斗","u":"皇學館大学","t":1454,"rec":false,"op":false,"cr":17},{"lr":18,"nm":"平野 圭人","u":"関西大学","t":1458,"rec":false,"op":false,"cr":18},{"lr":19,"nm":"木戸 颯","u":"中四国学連選抜","t":1468,"rec":false,"op":false,"cr":19},{"lr":20,"nm":"小郷 紘矢","u":"京都産業大学","t":1476,"rec":false,"op":false,"cr":20},{"lr":21,"nm":"小川 晴也","u":"広島経済大学","t":1495,"rec":false,"op":false,"cr":21},{"lr":22,"nm":"大野 憲尚","u":"北海道大学","t":1784,"rec":false,"op":false,"cr":22}],[{"lr":1,"nm":"本田 桜二郎","u":"早稲田大学","t":942,"rec":false,"op":false,"cr":1},{"lr":2,"nm":"織橋 巧","u":"創価大学","t":945,"rec":false,"op":false,"cr":5},{"lr":3,"nm":"吉岡 大翔","u":"順天堂大学","t":947,"rec":false,"op":false,"cr":2},{"lr":4,"nm":"岡田 開成","u":"中央大学","t":951,"rec":false,"op":false,"cr":3},{"lr":4,"nm":"マイルズ ホーガン","u":"アイビーリーグ選抜","t":951,"rec":false,"op":false,"cr":7},{"lr":6,"nm":"鼻野木 悠翔","u":"國學院大學","t":953,"rec":false,"op":false,"cr":6},{"lr":7,"nm":"柴田 侑","u":"城西大学","t":956,"rec":false,"op":false,"cr":11},{"lr":8,"nm":"上岡 煌","u":"駒澤大学","t":960,"rec":false,"op":false,"cr":4},{"lr":9,"nm":"鳥井 健太","u":"青山学院大学","t":970,"rec":false,"op":false,"cr":8},{"lr":10,"nm":"山口 聡太","u":"日本大学","t":972,"rec":false,"op":false,"cr":9},{"lr":11,"nm":"小林 咲冴","u":"帝京大学","t":985,"rec":false,"op":false,"cr":10},{"lr":12,"nm":"高坂 光希","u":"札幌学院大学","t":1004,"rec":false,"op":false,"cr":12},{"lr":13,"nm":"井手 蒼人","u":"関西大学","t":1016,"rec":false,"op":false,"cr":13},{"lr":14,"nm":"重谷 斗貴","u":"京都産業大学","t":1021,"rec":false,"op":false,"cr":20},{"lr":15,"nm":"村井 冠太","u":"中四国学連選抜","t":1028,"rec":false,"op":false,"cr":19},{"lr":16,"nm":"松葉 琥太郎","u":"皇學館大学","t":1034,"rec":false,"op":false,"cr":16},{"lr":17,"nm":"福嶋 明大","u":"信州大学","t":1038,"rec":false,"op":false,"cr":14},{"lr":18,"nm":"萩川 晄","u":"東北学連選抜","t":1040,"rec":false,"op":false,"cr":15},{"lr":19,"nm":"金森 柊弥","u":"金沢学院大学","t":1053,"rec":false,"op":false,"cr":18},{"lr":20,"nm":"宮瀬 陸","u":"北海道大学","t":1071,"rec":false,"op":false,"cr":22},{"lr":21,"nm":"伊藤 大弥","u":"広島経済大学","t":1073,"rec":false,"op":false,"cr":21},{"lr":22,"nm":"山崎 誠也","u":"第一工科大学","t":1079,"rec":false,"op":false,"cr":17}],[{"lr":1,"nm":"シャドラック キップケメイ","u":"日本大学","t":1376,"rec":true,"op":false,"cr":1},{"lr":2,"nm":"楠岡 由浩","u":"帝京大学","t":1409,"rec":true,"op":false,"cr":9},{"lr":3,"nm":"鈴木 琉胤","u":"早稲田大学","t":1411,"rec":true,"op":false,"cr":2},{"lr":4,"nm":"三宅 悠斗","u":"中央大学","t":1416,"rec":false,"op":false,"cr":3},{"lr":5,"nm":"井上 朋哉","u":"順天堂大学","t":1428,"rec":false,"op":false,"cr":4},{"lr":6,"nm":"スティーブン ムチーニ","u":"創価大学","t":1429,"rec":false,"op":false,"cr":5},{"lr":7,"nm":"グレハム ブランクス","u":"アイビーリーグ選抜","t":1430,"rec":false,"op":false,"cr":7},{"lr":8,"nm":"辻原 輝","u":"國學院大學","t":1436,"rec":false,"op":false,"cr":6},{"lr":9,"nm":"ルト アロン","u":"城西大学","t":1443,"rec":false,"op":false,"cr":11},{"lr":10,"nm":"植阪 嶺児","u":"駒澤大学","t":1444,"rec":false,"op":false,"cr":8},{"lr":11,"nm":"飯田 翔大","u":"青山学院大学","t":1479,"rec":false,"op":false,"cr":10},{"lr":12,"nm":"坂本 亘生","u":"関西大学","t":1521,"rec":false,"op":false,"cr":12},{"lr":13,"nm":"近江 周","u":"東北学連選抜","t":1535,"rec":false,"op":false,"cr":15},{"lr":14,"nm":"嶋津 明良","u":"信州大学","t":1538,"rec":false,"op":false,"cr":14},{"lr":15,"nm":"清水 喜一郎","u":"第一工科大学","t":1539,"rec":false,"op":false,"cr":16},{"lr":16,"nm":"日古見 那由他","u":"皇學館大学","t":1549,"rec":false,"op":false,"cr":17},{"lr":17,"nm":"藤田 大輝","u":"京都産業大学","t":1563,"rec":false,"op":false,"cr":18},{"lr":18,"nm":"瀬尾 大和","u":"広島経済大学","t":1564,"rec":false,"op":false,"cr":21},{"lr":19,"nm":"田野 朝陽","u":"札幌学院大学","t":1568,"rec":false,"op":false,"cr":13},{"lr":20,"nm":"田川 滉介","u":"中四国学連選抜","t":1581,"rec":false,"op":false,"cr":19},{"lr":21,"nm":"佐々木 彪我","u":"金沢学院大学","t":1587,"rec":false,"op":false,"cr":20},{"lr":22,"nm":"奥村 日向","u":"北海道大学","t":1625,"rec":false,"op":false,"cr":22}],[{"lr":1,"nm":"新妻 遼己","u":"早稲田大学","t":1030,"rec":true,"op":false,"cr":1},{"lr":2,"nm":"野中 恒亨","u":"國學院大學","t":1034,"rec":true,"op":false,"cr":4},{"lr":3,"nm":"浅川 侑大","u":"帝京大学","t":1043,"rec":false,"op":false,"cr":9},{"lr":4,"nm":"小山 翔也","u":"駒澤大学","t":1044,"rec":false,"op":false,"cr":7},{"lr":5,"nm":"タイラー バーグ","u":"アイビーリーグ選抜","t":1045,"rec":false,"op":false,"cr":8},{"lr":6,"nm":"濱口 大和","u":"中央大学","t":1049,"rec":false,"op":false,"cr":3},{"lr":6,"nm":"村上 遵世","u":"創価大学","t":1049,"rec":false,"op":false,"cr":5},{"lr":8,"nm":"首藤 海翔","u":"日本大学","t":1055,"rec":false,"op":false,"cr":2},{"lr":8,"nm":"橋本 健市","u":"城西大学","t":1055,"rec":false,"op":false,"cr":10},{"lr":10,"nm":"佐藤 賢仁","u":"順天堂大学","t":1056,"rec":false,"op":false,"cr":6},{"lr":11,"nm":"小河原 陽琉","u":"青山学院大学","t":1079,"rec":false,"op":false,"cr":11},{"lr":12,"nm":"塩見 昊瑛","u":"皇學館大学","t":1113,"rec":false,"op":false,"cr":14},{"lr":13,"nm":"岡村 和真","u":"関西大学","t":1116,"rec":false,"op":false,"cr":12},{"lr":13,"nm":"浦田 陽聖","u":"札幌学院大学","t":1116,"rec":false,"op":false,"cr":13},{"lr":15,"nm":"吉村 陸翔","u":"京都産業大学","t":1129,"rec":false,"op":false,"cr":18},{"lr":16,"nm":"松本 諒哉","u":"東北学連選抜","t":1134,"rec":false,"op":false,"cr":15},{"lr":16,"nm":"田中 陸","u":"広島経済大学","t":1134,"rec":false,"op":false,"cr":21},{"lr":18,"nm":"加藤 快都","u":"金沢学院大学","t":1143,"rec":false,"op":false,"cr":19},{"lr":19,"nm":"古谷 大翔","u":"第一工科大学","t":1153,"rec":false,"op":false,"cr":17},{"lr":20,"nm":"船山 柚樹","u":"北海道大学","t":1159,"rec":false,"op":false,"cr":22},{"lr":21,"nm":"和久津 友杜","u":"信州大学","t":1161,"rec":false,"op":false,"cr":16},{"lr":22,"nm":"佐野 泰斗","u":"中四国学連選抜","t":1174,"rec":false,"op":false,"cr":20}],[{"lr":1,"nm":"山口 竣平","u":"早稲田大学","t":1055,"rec":true,"op":false,"cr":1},{"lr":2,"nm":"デレック アミコン","u":"アイビーリーグ選抜","t":1056,"rec":true,"op":false,"cr":5},{"lr":3,"nm":"飯國 新太","u":"國學院大學","t":1059,"rec":true,"op":false,"cr":4},{"lr":4,"nm":"柴田 大地","u":"中央大学","t":1061,"rec":true,"op":false,"cr":3},{"lr":5,"nm":"長澤 辰朗","u":"日本大学","t":1062,"rec":true,"op":false,"cr":2},{"lr":6,"nm":"山口 翔輝","u":"創価大学","t":1069,"rec":false,"op":false,"cr":6},{"lr":7,"nm":"小林 竜輝","u":"城西大学","t":1072,"rec":false,"op":false,"cr":10},{"lr":7,"nm":"黒田 然","u":"青山学院大学","t":1072,"rec":false,"op":false,"cr":11},{"lr":9,"nm":"池谷 陸斗","u":"駒澤大学","t":1075,"rec":false,"op":false,"cr":7},{"lr":10,"nm":"廣田 陸","u":"帝京大学","t":1076,"rec":false,"op":false,"cr":9},{"lr":11,"nm":"古川 達也","u":"順天堂大学","t":1088,"rec":false,"op":false,"cr":8},{"lr":12,"nm":"信田 亮太","u":"関西大学","t":1112,"rec":false,"op":false,"cr":12},{"lr":13,"nm":"曽越 祐志","u":"皇學館大学","t":1124,"rec":false,"op":false,"cr":13},{"lr":14,"nm":"西川 天馬","u":"京都産業大学","t":1126,"rec":false,"op":false,"cr":16},{"lr":15,"nm":"中垣 颯太","u":"広島経済大学","t":1130,"rec":false,"op":false,"cr":20},{"lr":16,"nm":"向田 祐翔","u":"東北学連選抜","t":1137,"rec":false,"op":false,"cr":15},{"lr":17,"nm":"漆原 幹人","u":"信州大学","t":1144,"rec":false,"op":false,"cr":17},{"lr":18,"nm":"大宮 千來","u":"札幌学院大学","t":1155,"rec":false,"op":false,"cr":14},{"lr":19,"nm":"岡本 颯太","u":"中四国学連選抜","t":1157,"rec":false,"op":false,"cr":21},{"lr":20,"nm":"片桐 遥久","u":"金沢学院大学","t":1164,"rec":false,"op":false,"cr":19},{"lr":21,"nm":"大良 優斗","u":"第一工科大学","t":1187,"rec":false,"op":false,"cr":18},{"lr":22,"nm":"林 啓樹","u":"北海道大学","t":1227,"rec":false,"op":false,"cr":22}],[{"lr":1,"nm":"工藤 慎作","u":"早稲田大学","t":1740,"rec":false,"op":false,"cr":1},{"lr":2,"nm":"山本 悠","u":"順天堂大学","t":1759,"rec":false,"op":false,"cr":4},{"lr":3,"nm":"高石 樹","u":"國學院大學","t":1760,"rec":false,"op":false,"cr":2},{"lr":4,"nm":"原 悠太","u":"帝京大学","t":1767,"rec":false,"op":false,"cr":6},{"lr":5,"nm":"エイサー アイバーソン","u":"アイビーリーグ選抜","t":1777,"rec":false,"op":false,"cr":3},{"lr":6,"nm":"桑田 駿介","u":"駒澤大学","t":1780,"rec":false,"op":false,"cr":7},{"lr":7,"nm":"栗村 凌","u":"中央大学","t":1808,"rec":false,"op":false,"cr":5},{"lr":8,"nm":"中島 巨翔","u":"城西大学","t":1816,"rec":false,"op":false,"cr":10},{"lr":9,"nm":"前川 竜之将","u":"青山学院大学","t":1825,"rec":false,"op":false,"cr":11},{"lr":10,"nm":"小池 莉希","u":"創価大学","t":1841,"rec":false,"op":false,"cr":9},{"lr":11,"nm":"𣘺本 櫂知","u":"日本大学","t":1856,"rec":false,"op":false,"cr":8},{"lr":12,"nm":"岡田 卓","u":"東北学連選抜","t":1903,"rec":false,"op":false,"cr":14},{"lr":13,"nm":"内田 善登","u":"信州大学","t":1909,"rec":false,"op":false,"cr":16},{"lr":14,"nm":"大橋 史空","u":"札幌学院大学","t":1911,"rec":false,"op":false,"cr":13},{"lr":15,"nm":"新間 圭","u":"皇學館大学","t":1924,"rec":false,"op":false,"cr":15},{"lr":16,"nm":"佐々木 昴","u":"広島経済大学","t":1930,"rec":false,"op":false,"cr":18},{"lr":17,"nm":"高村 瑛太","u":"関西大学","t":1932,"rec":false,"op":false,"cr":12},{"lr":18,"nm":"竹村 明人","u":"京都産業大学","t":1937,"rec":false,"op":false,"cr":17},{"lr":19,"nm":"角南 祐行","u":"中四国学連選抜","t":1943,"rec":false,"op":false,"cr":19},{"lr":20,"nm":"森 大空","u":"第一工科大学","t":1979,"rec":false,"op":false,"cr":20},{"lr":21,"nm":"秋野 僚太","u":"北海道大学","t":2035,"rec":false,"op":false,"cr":22},{"lr":22,"nm":"山田 琢心","u":"金沢学院大学","t":2049,"rec":false,"op":false,"cr":21}]],"src":["https://the-ans.jp/news/739601/"]}],"yosen":[{"n":103,"year":2026,"date":"2026-10-17","name":"第103回東京箱根間往復大学駅伝競走予選会","teams":[{"rank":1,"u":"東洋大学","t":37890,"pass":true},{"rank":2,"u":"中央学院大学","t":38011,"pass":true},{"rank":3,"u":"東海大学","t":38021,"pass":true},{"rank":4,"u":"専修大学","t":38022,"pass":true},{"rank":5,"u":"東京農業大学","t":38073,"pass":true},{"rank":6,"u":"山梨学院大学","t":38118,"pass":true},{"rank":7,"u":"大東文化大学","t":38123,"pass":true},{"rank":8,"u":"神奈川大学","t":38208,"pass":true},{"rank":9,"u":"日本体育大学","t":38392,"pass":true},{"rank":10,"u":"法政大学","t":38408,"pass":true},{"rank":11,"u":"国士舘大学","t":38514,"pass":false},{"rank":12,"u":"武蔵野学院大学","t":38634,"pass":false},{"rank":13,"u":"立教大学","t":38641,"pass":false},{"rank":14,"u":"明治大学","t":38646,"pass":false},{"rank":15,"u":"東京国際大学","t":38704,"pass":false},{"rank":16,"u":"駿河台大学","t":38755,"pass":false},{"rank":17,"u":"麗澤大学","t":38785,"pass":false},{"rank":18,"u":"筑波大学","t":38818,"pass":false},{"rank":19,"u":"拓殖大学","t":38869,"pass":false},{"rank":20,"u":"日本薬科大学","t":38872,"pass":false},{"rank":21,"u":"明治学院大学","t":39021,"pass":false},{"rank":22,"u":"流通経済大学","t":39213,"pass":false},{"rank":23,"u":"上武大学","t":39271,"pass":false},{"rank":24,"u":"平成国際大学","t":39615,"pass":false},{"rank":25,"u":"育英大学","t":39675,"pass":false},{"rank":26,"u":"関東学院大学","t":39719,"pass":false},{"rank":27,"u":"立正大学","t":39725,"pass":false},{"rank":28,"u":"亜細亜大学","t":39786,"pass":false},{"rank":29,"u":"芝浦工業大学","t":39794,"pass":false},{"rank":30,"u":"慶應義塾大学","t":40012,"pass":false},{"rank":31,"u":"東京経済大学","t":40328,"pass":false},{"rank":32,"u":"桜美林大学","t":40754,"pass":false},{"rank":33,"u":"東京大学大学院","t":41481,"pass":false},{"rank":34,"u":"湘南工科大学","t":41825,"pass":false},{"rank":35,"u":"国際武道大学","t":41836,"pass":false},{"rank":36,"u":"東京大学","t":41910,"pass":false},{"rank":37,"u":"清和大学","t":42332,"pass":false},{"rank":38,"u":"東京理科大学","t":42550,"pass":false},{"rank":39,"u":"防衛大学校","t":43038,"pass":false},{"rank":40,"u":"千葉大学","t":43322,"pass":false},{"rank":41,"u":"一橋大学","t":43614,"pass":false},{"rank":42,"u":"埼玉大学","t":43703,"pass":false},{"rank":43,"u":"横浜国立大学","t":43948,"pass":false},{"rank":44,"u":"東京都立大学","t":44482,"pass":false},{"rank":45,"u":"高崎経済大学","t":44597,"pass":false}],"indiv":[{"rk":1,"nm":"B.キピエゴ","u":"山梨学院大学","g":4,"t":3648},{"rk":2,"nm":"R.エティーリ","u":"東京国際大学","g":4,"t":3659},{"rk":3,"nm":"B.テスファイゼラツィオン","u":"武蔵野学院大学","g":4,"t":3659},{"rk":4,"nm":"宮崎優","u":"東洋大学","g":3,"t":3665},{"rk":5,"nm":"D.キプルト","u":"日本薬科大学","g":4,"t":3675},{"rk":6,"nm":"B.キプトゥーブシューアキットゥ","u":"麗澤大学","g":3,"t":3692},{"rk":7,"nm":"前田和摩","u":"東京農業大学","g":4,"t":3717},{"rk":8,"nm":"S.レマイヤン","u":"駿河台大学","g":4,"t":3722},{"rk":9,"nm":"R.ロンギサ","u":"拓殖大学","g":4,"t":3724},{"rk":10,"nm":"永本脩","u":"東海大学","g":4,"t":3739},{"rk":11,"nm":"K.エヴァンス","u":"国士舘大学","g":1,"t":3741},{"rk":12,"nm":"中野純平","u":"東海大学","g":3,"t":3745},{"rk":13,"nm":"小川優晴","u":"中央学院大学","g":2,"t":3750},{"rk":14,"nm":"南坂柚汰","u":"東海大学","g":4,"t":3754},{"rk":15,"nm":"上田航大","u":"神奈川大学","g":3,"t":3755},{"rk":16,"nm":"佐野颯人","u":"武蔵野学院大学","g":4,"t":3759},{"rk":17,"nm":"古橋希翁","u":"駿河台大学","g":4,"t":3760},{"rk":18,"nm":"向田泰誠","u":"専修大学","g":2,"t":3761},{"rk":19,"nm":"阿部宥人","u":"明治大学","g":2,"t":3762},{"rk":20,"nm":"林愛斗","u":"中央学院大学","g":4,"t":3763},{"rk":21,"nm":"O.エズラ","u":"関東学院大学","g":1,"t":3765},{"rk":22,"nm":"長部虎太郎","u":"中央学院大学","g":3,"t":3766},{"rk":23,"nm":"大濱逞真","u":"大東文化大学","g":3,"t":3766},{"rk":24,"nm":"大湊柊翔","u":"明治大学","g":4,"t":3767},{"rk":25,"nm":"平井璃空","u":"東海大学","g":3,"t":3768},{"rk":26,"nm":"和田瑛登","u":"山梨学院大学","g":4,"t":3768},{"rk":27,"nm":"成沢翔英","u":"慶應義塾大学","g":3,"t":3768},{"rk":28,"nm":"内田温規","u":"東京農業大学","g":2,"t":3768},{"rk":29,"nm":"馬場大翔","u":"東洋大学","g":4,"t":3769},{"rk":30,"nm":"内堀勇","u":"東洋大学","g":3,"t":3769},{"rk":31,"nm":"S.ガユ","u":"専修大学","g":1,"t":3769},{"rk":32,"nm":"原田颯大","u":"立教大学","g":4,"t":3770},{"rk":33,"nm":"平川瑠星","u":"神奈川大学","g":4,"t":3772},{"rk":34,"nm":"松岡一星","u":"山梨学院大学","g":3,"t":3772},{"rk":35,"nm":"夏見虹郎","u":"日本体育大学","g":2,"t":3772},{"rk":36,"nm":"松井海斗","u":"東洋大学","g":3,"t":3775},{"rk":37,"nm":"平井蒼大","u":"法政大学","g":4,"t":3776},{"rk":38,"nm":"J.ムイガイ","u":"平成国際大学","g":4,"t":3776},{"rk":39,"nm":"西澤匡哉","u":"立教大学","g":2,"t":3776},{"rk":40,"nm":"西岳政宗","u":"専修大学","g":3,"t":3776},{"rk":41,"nm":"小林晴琉","u":"筑波大学","g":2,"t":3777},{"rk":42,"nm":"野田晶斗","u":"法政大学","g":4,"t":3779},{"rk":43,"nm":"市川大世","u":"中央学院大学","g":4,"t":3779},{"rk":44,"nm":"J.カマウ","u":"立正大学","g":2,"t":3779},{"rk":45,"nm":"松浦輝仁","u":"大東文化大学","g":3,"t":3783},{"rk":46,"nm":"可児悠貴","u":"東海大学","g":4,"t":3784},{"rk":47,"nm":"薄根大河","u":"東洋大学","g":4,"t":3785},{"rk":48,"nm":"島居優成","u":"日本薬科大学","g":3,"t":3786},{"rk":49,"nm":"花井創","u":"神奈川大学","g":4,"t":3789},{"rk":50,"nm":"三代田宏太朗","u":"中央学院大学","g":3,"t":3790},{"rk":51,"nm":"占部大和","u":"山梨学院大学","g":4,"t":3790},{"rk":52,"nm":"佐藤大和","u":"日本体育大学","g":3,"t":3792},{"rk":53,"nm":"水津智哉","u":"専修大学","g":3,"t":3792},{"rk":54,"nm":"植月俊太","u":"東京農業大学","g":4,"t":3792},{"rk":55,"nm":"菅野優空","u":"東京農業大学","g":3,"t":3793},{"rk":56,"nm":"米田昂太","u":"中央学院大学","g":3,"t":3793},{"rk":57,"nm":"矢口陽太","u":"東海大学","g":4,"t":3793},{"rk":58,"nm":"藤原幹大","u":"大東文化大学","g":4,"t":3794},{"rk":59,"nm":"川﨑颯","u":"筑波大学","g":4,"t":3795},{"rk":60,"nm":"菅原匠人","u":"東京農業大学","g":3,"t":3795},{"rk":61,"nm":"木村楓斗","u":"流通経済大学","g":4,"t":3798},{"rk":62,"nm":"菅﨑大翔","u":"大東文化大学","g":2,"t":3800},{"rk":63,"nm":"N.キプチュンバ","u":"上武大学","g":1,"t":3801},{"rk":64,"nm":"倉本晃羽","u":"東洋大学","g":4,"t":3803},{"rk":65,"nm":"B.ムテチ","u":"流通経済大学","g":4,"t":3804},{"rk":66,"nm":"平松龍青","u":"専修大学","g":4,"t":3805},{"rk":67,"nm":"具志堅一斗","u":"専修大学","g":4,"t":3806},{"rk":68,"nm":"大島希","u":"武蔵野学院大学","g":4,"t":3813},{"rk":69,"nm":"尾島樹","u":"上武大学","g":3,"t":3814},{"rk":70,"nm":"大岩蓮","u":"神奈川大学","g":4,"t":3815},{"rk":71,"nm":"上田翔大","u":"大東文化大学","g":2,"t":3816},{"rk":72,"nm":"中澤真大","u":"大東文化大学","g":3,"t":3818},{"rk":73,"nm":"丹柊太郎","u":"専修大学","g":4,"t":3819},{"rk":74,"nm":"田井中悠成","u":"法政大学","g":4,"t":3820},{"rk":75,"nm":"上山詩樹","u":"専修大学","g":4,"t":3821},{"rk":76,"nm":"星野泰地","u":"法政大学","g":4,"t":3822},{"rk":77,"nm":"佐藤我駆人","u":"駿河台大学","g":3,"t":3822},{"rk":78,"nm":"河原大和","u":"日本薬科大学","g":4,"t":3822},{"rk":79,"nm":"有川紘樹","u":"一橋大学","g":4,"t":3823},{"rk":80,"nm":"陳内紫音","u":"東洋大学","g":3,"t":3823},{"rk":81,"nm":"久保俊翔","u":"駿河台大学","g":4,"t":3823},{"rk":82,"nm":"森本守勇","u":"東京農業大学","g":2,"t":3825},{"rk":83,"nm":"長友英吾","u":"中央学院大学","g":3,"t":3825},{"rk":84,"nm":"小野真和","u":"東洋大学","g":2,"t":3826},{"rk":85,"nm":"松山優太","u":"東海大学","g":2,"t":3826},{"rk":86,"nm":"生田鼓太郎","u":"東京農業大学","g":3,"t":3826},{"rk":87,"nm":"熊谷颯柊","u":"武蔵野学院大学","g":2,"t":3828},{"rk":88,"nm":"橋本将汰","u":"立正大学","g":4,"t":3829},{"rk":89,"nm":"荻野桂輔","u":"日本体育大学","g":3,"t":3829},{"rk":90,"nm":"生天目温","u":"東洋大学","g":2,"t":3829},{"rk":91,"nm":"安斎陸久","u":"専修大学","g":2,"t":3830},{"rk":92,"nm":"大橋正昊","u":"駿河台大学","g":4,"t":3830},{"rk":93,"nm":"荒原駿","u":"麗澤大学","g":4,"t":3831},{"rk":94,"nm":"徳善龍","u":"中央学院大学","g":3,"t":3831},{"rk":95,"nm":"野﨑想","u":"大東文化大学","g":3,"t":3832},{"rk":96,"nm":"鈴木要","u":"大東文化大学","g":2,"t":3832},{"rk":97,"nm":"小柴裕士郎","u":"東京国際大学","g":3,"t":3833},{"rk":98,"nm":"山中寿世夢","u":"国士舘大学","g":4,"t":3834},{"rk":99,"nm":"福田大馳","u":"法政大学","g":3,"t":3834},{"rk":100,"nm":"山崎碧葉","u":"神奈川大学","g":1,"t":3834}],"src":["https://the-ans.jp/chart/741234/","https://www.rikujyokyogi.co.jp/archives/219630"]}]};
const SEED_HIST = {"izumo":{"winners":[{"n":1,"year":1989,"u":"日本大学","t":7460,"cancel":false},{"n":2,"year":1990,"u":"大東文化大学","t":7601,"cancel":false},{"n":3,"year":1991,"u":"山梨学院大学","t":7570,"cancel":false},{"n":4,"year":1992,"u":"山梨学院大学","t":7486,"cancel":false},{"n":5,"year":1993,"u":"山梨学院大学","t":7530,"cancel":false},{"n":6,"year":1994,"u":"山梨学院大学","t":7442,"cancel":false},{"n":7,"year":1995,"u":"山梨学院大学","t":7474,"cancel":false},{"n":8,"year":1996,"u":"早稲田大学","t":7511,"cancel":false},{"n":9,"year":1997,"u":"駒澤大学","t":7521,"cancel":false},{"n":10,"year":1998,"u":"駒澤大学","t":7488,"cancel":false},{"n":11,"year":1999,"u":"順天堂大学","t":7497,"cancel":false},{"n":12,"year":2000,"u":"順天堂大学","t":7526,"cancel":false},{"n":13,"year":2001,"u":"順天堂大学","t":7789,"cancel":false},{"n":14,"year":2002,"u":"山梨学院大学","t":7827,"cancel":false},{"n":15,"year":2003,"u":"日本大学","t":7804,"cancel":false},{"n":16,"year":2004,"u":"日本大学","t":7752,"cancel":false},{"n":17,"year":2005,"u":"東海大学","t":7722,"cancel":false},{"n":18,"year":2006,"u":"東海大学","t":7668,"cancel":false},{"n":19,"year":2007,"u":"東海大学","t":7634,"cancel":false},{"n":20,"year":2008,"u":"日本大学","t":7707,"cancel":false},{"n":21,"year":2009,"u":"日本大学","t":7807,"cancel":false},{"n":22,"year":2010,"u":"早稲田大学","t":7805,"cancel":false},{"n":23,"year":2011,"u":"東洋大学","t":7843,"cancel":false},{"n":24,"year":2012,"u":"青山学院大学","t":7781,"cancel":false},{"n":25,"year":2013,"u":"駒澤大学","t":7750,"cancel":false},{"n":26,"year":2014,"u":"","t":null,"cancel":true},{"n":27,"year":2015,"u":"青山学院大学","t":7745,"cancel":false},{"n":28,"year":2016,"u":"青山学院大学","t":7809,"cancel":false},{"n":29,"year":2017,"u":"東海大学","t":7919,"cancel":false},{"n":30,"year":2018,"u":"青山学院大学","t":7918,"cancel":false},{"n":31,"year":2019,"u":"國學院大學","t":7796,"cancel":false},{"n":32,"year":2020,"u":"","t":null,"cancel":true},{"n":37,"year":2025,"u":"國學院大學","t":7752,"cancel":false},{"n":38,"year":2026,"u":"早稲田大学","t":7556,"cancel":false}]}};

/* ======================================================================
 * Shared with BMERadar: feed parsing, storage, in-app reader, Web Push (VAPID / P-256)
 * ====================================================================== */
function decodeEntities(s) {
  return String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#x([0-9a-f]+);/gi, function (m, h) { return String.fromCharCode(parseInt(h, 16)); })
    .replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); })
    .replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}
function stripTags(s) { return decodeEntities(String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }
function tagText(block, names) {
  for (let i = 0; i < names.length; i++) {
    const m = block.match(new RegExp('<' + names[i] + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + names[i] + '>', 'i'));
    if (m) return m[1];
  }
  return '';
}
function attr(block, tag, name, where) {
  const re = new RegExp('<' + tag + '\\b([^>]*)>', 'gi'); let m;
  while ((m = re.exec(block))) {
    if (where && !where.test(m[1])) continue;
    const a = m[1].match(new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i')) || m[1].match(new RegExp(name + "\\s*=\\s*'([^']*)'", 'i'));
    if (a) return decodeEntities(a[1]);
  }
  return '';
}
function parseFeed(xml) {
  xml = String(xml || '');
  const atom = /<feed[\s>]/i.test(xml) && !/<rss[\s>]/i.test(xml);
  const blocks = xml.match(atom ? /<entry[\s>][\s\S]*?<\/entry>/gi : /<item[\s>][\s\S]*?<\/item>/gi) || [];
  return blocks.map(function (b) {
    let link = '';
    if (atom) link = attr(b, 'link', 'href', /rel\s*=\s*["']alternate["']/i) || attr(b, 'link', 'href');
    else link = stripTags(tagText(b, ['link'])) || attr(b, 'item', 'rdf:about') || stripTags(tagText(b, ['guid']));
    const descRaw = tagText(b, ['description', 'summary', 'content:encoded', 'content']);
    const fullRaw = [tagText(b, ['content:encoded']), tagText(b, ['content']), descRaw].sort(function (x, y) { return y.length - x.length; })[0] || '';
    const img = attr(b, 'media:content', 'url') || attr(b, 'media:thumbnail', 'url') || attr(b, 'enclosure', 'url', /type\s*=\s*["']image/i) ||
      ((decodeEntities(descRaw).match(/<img[^>]+src\s*=\s*["']([^"']+)["']/i) || [])[1] || '');
    return {
      title: stripTags(tagText(b, ['title', 'dc:title'])),
      link: link.trim(),
      guid: stripTags(tagText(b, ['guid', 'id'])),
      date: stripTags(tagText(b, ['pubDate', 'published', 'dc:date', 'updated', 'prism:publicationDate'])),
      desc: stripTags(descRaw),
      source: stripTags(tagText(b, ['source', 'prism:publicationName'])),
      image: /^https?:/.test(img) ? img : '',
      full: fullRaw.length > 800 ? decodeEntities(fullRaw).slice(0, 80000) : ''
    };
  }).filter(function (r) { return r.title && r.link; });
}
function parseDate(s, fallback) {
  s = String(s || '').trim();
  if (!s) return fallback;
  if (/^\d{8}$/.test(s)) return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8), 12);
  let t = Date.parse(s);
  if (isFinite(t)) return t;
  let m = s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] - 9 : 3, m[5] ? +m[5] : 0);
  m = s.match(/^([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})(?:,? (\d{1,2}):(\d{2})\s*([ap]m)?)?/i);
  if (m) {
    const mon = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(m[1].toLowerCase()) / 3;
    let h = m[4] ? +m[4] : 12; if (m[6] && /pm/i.test(m[6]) && h < 12) h += 12; if (m[6] && /am/i.test(m[6]) && h === 12) h = 0;
    if (mon >= 0) return Date.UTC(+m[3], mon, +m[2], h + 5, m[5] ? +m[5] : 0);   // US Eastern
  }
  return fallback;
}
function normTitle(t) { return String(t || '').toLowerCase().replace(/\s+[-–|]\s+[^-–|]+$/, '').replace(/[^\w぀-ヿ一-鿿]+/g, '').slice(0, 90); }
function hashId(s) { let h = 5381; s = String(s); for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
function checkPass_(p) {
  const want = PropertiesService.getScriptProperties().getProperty('PASS');
  return !!want && typeof p === 'string' && p === want;
}
function dataFolder_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const f = DriveApp.createFolder(DATA_FOLDER);
  props.setProperty('FOLDER_ID', f.getId());
  return f;
}
function findFile_(folder, name) { const it = folder.getFilesByName(name); return it.hasNext() ? it.next() : null; }
function readJson_(name, fallback) {
  const f = findFile_(dataFolder_(), name);
  if (!f) return fallback;
  try { return JSON.parse(f.getBlob().getDataAsString()); } catch (e) { return fallback; }
}
function writeJson_(name, obj) {
  const folder = dataFolder_(), body = JSON.stringify(obj), f = findFile_(folder, name);
  if (f) f.setContent(body); else folder.createFile(name, body, MimeType.PLAIN_TEXT);
}
function cachePut_(key, str) {
  const c = CacheService.getScriptCache(), size = 90000, parts = {}, n = Math.ceil(str.length / size);
  if (n > 9) return;  // too large for the cache; served from Drive instead
  for (let i = 0; i < n; i++) parts[key + '_' + i] = str.slice(i * size, (i + 1) * size);
  parts[key + '_n'] = String(n);
  try { c.putAll(parts, 21600); } catch (e) {}
}
function cacheGet_(key) {
  const c = CacheService.getScriptCache(), n = +(c.get(key + '_n') || 0);
  if (!n) return null;
  const keys = []; for (let i = 0; i < n; i++) keys.push(key + '_' + i);
  const got = c.getAll(keys); let s = '';
  for (let i = 0; i < n; i++) { if (got[keys[i]] == null) return null; s += got[keys[i]]; }
  return s;
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function metaContent(html, key) {
  const re = new RegExp('<meta[^>]+(?:property|name|itemprop)\\s*=\\s*["\']' + key.replace(/[:.]/g, '\\$&') + '["\'][^>]*>', 'i');
  const tag = (html.match(re) || [])[0];
  if (!tag) return '';
  return decodeEntities((tag.match(/content\s*=\s*"([^"]*)"/i) || tag.match(/content\s*=\s*'([^']*)'/i) || [])[1] || '').trim();
}
function absUrl(u, base) {
  u = decodeEntities(String(u || '').trim());
  if (!u || /^data:/i.test(u)) return '';
  if (/^https?:\/\//i.test(u)) return u;
  const m = String(base).match(/^(https?:\/\/[^\/]+)(\/[^?#]*)?/i); if (!m) return '';
  if (/^\/\//.test(u)) return 'https:' + u;
  if (/^\//.test(u)) return m[1] + u;
  return m[1] + (m[2] || '/').replace(/[^\/]*$/, '') + u;
}
const BOILER = /^(advertisement|sponsored|subscribe|sign up|sign in|log in|read more|related:|share this|copyright|all rights reserved|©|photo:|image:|credit:|getty images|this article (was|is)|click here|newsletter|cookie|we use cookies|follow us|もっと見る|関連記事|広告|この記事をシェア|会員登録|ログイン)/i;
function jsonLdBody(html) {
  const blocks = html.match(/<script[^>]+application\/ld\+json[^>]*>[\s\S]*?<\/script>/gi) || [];
  for (let i = 0; i < blocks.length; i++) {
    const txt = blocks[i].replace(/^<script[^>]*>/i, '').replace(/<\/script>$/i, '').trim();
    let j = null;
    // some sites put raw line breaks inside JSON strings; try a few repairs
    [txt, txt.replace(/\r?\n/g, '\\n').replace(/\t/g, ' '), txt.replace(/[\u0000-\u001f]+/g, ' ')].some(function (t) { try { j = JSON.parse(t); return true; } catch (e) { return false; } });
    if (!j) continue;
    try {
      const list = [].concat(j['@graph'] || j);
      for (let k = 0; k < list.length; k++) if (list[k] && typeof list[k].articleBody === 'string' && list[k].articleBody.length > 300) return list[k];
    } catch (e) {}
  }
  return null;
}
function extractArticle(html, url) {
  html = String(html || '');
  const title = metaContent(html, 'og:title') || stripTags(tagText(html, ['title'])) || '';
  const site = metaContent(html, 'og:site_name');
  const desc = metaContent(html, 'og:description') || metaContent(html, 'description');
  const image = absUrl(metaContent(html, 'og:image') || metaContent(html, 'twitter:image'), url);
  const date = metaContent(html, 'article:published_time') || metaContent(html, 'datePublished') || metaContent(html, 'citation_publication_date') || '';
  const paras = [];
  const ld = jsonLdBody(html);
  if (ld) {
    String(ld.articleBody).split(/\n\s*\n|\r?\n/).map(function (x) { return decodeEntities(x).replace(/\s+/g, ' ').trim(); }).filter(function (x) { return x.length > 1; }).forEach(function (x) { paras.push({ t: 'p', x: x }); });
  }
  if (!paras.length) {
    let body = html.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style|noscript|svg|nav|header|footer|aside|form|button|iframe|select)\b[\s\S]*?<\/\1>/gi, ' ');
    // arXiv abstract
    const abs = body.match(/<blockquote[^>]*class="[^"]*abstract[^"]*"[^>]*>([\s\S]*?)<\/blockquote>/i);
    if (abs) paras.push({ t: 'p', x: stripTags(abs[1]).replace(/^Abstract:\s*/i, '') });
    // pick the densest container: <article>, then main/role=main, then common content classes, else the body
    const cands = [];
    (body.match(/<article\b[\s\S]*?<\/article>/gi) || []).forEach(function (b) { cands.push(b); });
    const mm = body.match(/<main\b[\s\S]*?<\/main>/i); if (mm) cands.push(mm[0]);
    const re = /<(div|section)\b[^>]*(?:class|id)\s*=\s*["'][^"']*(article[-_]?body|entry[-_]content|post[-_]content|story[-_]body|article[-_]content|main[-_]content|content[-_]body|news[-_]body|articleBody|rich[-_]text|body[-_]text|text[-_]body)[^"']*["'][^>]*>/gi;
    let m; while ((m = re.exec(body))) cands.push(body.slice(m.index, m.index + 200000));
    cands.push(body);
    let best = null, bestLen = 0;
    cands.forEach(function (c) {
      const ps = collectParas(c, url);
      const len = ps.reduce(function (s, p) { return s + (p.t === 'p' ? p.x.length : 0); }, 0);
      if (len > bestLen * 1.6 || (!best && len)) { best = ps; bestLen = len; }   // earlier candidates are more specific
    });
    if (best && !abs) best.forEach(function (p) { paras.push(p); });
  }
  // de-duplicate repeated paragraphs and drop the title if repeated
  const seen = {}, out = [];
  paras.forEach(function (p) { const k = p.t + (p.x || p.src); if (seen[k] || (p.t !== 'img' && normTitle(p.x) === normTitle(title))) return; seen[k] = 1; out.push(p); });
  const text = out.filter(function (p) { return p.t === 'p'; }).map(function (p) { return p.x; }).join(' ');
  return { title: title, site: site, desc: desc, image: image, date: date, paras: out.slice(0, 120), chars: text.length };
}
function collectParas(block, url) {
  const out = [];
  let m, imgs = 0;
  const tagRe = /<(p|h2|h3|li|blockquote)\b[^>]*>([\s\S]*?)<\/\1>|<img\b([^>]*)>/gi;
  while ((m = tagRe.exec(block))) {
    if (m[3] != null) {
      if (imgs >= 6) continue;
      const a = m[3], src = (a.match(/\s(?:data-src|data-lazy-src|data-original|src)\s*=\s*["']([^"']+)["']/i) || [])[1];
      const w = +((a.match(/\swidth\s*=\s*["']?(\d+)/i) || [])[1] || 0);
      const u = absUrl(src, url);
      if (!u || /\.svg(\?|$)|logo|icon|avatar|sprite|pixel|tracking|1x1|blank\.gif/i.test(u) || (w && w < 240)) continue;
      out.push({ t: 'img', src: u, alt: decodeEntities((a.match(/\salt\s*=\s*["']([^"']*)["']/i) || [])[1] || '').slice(0, 200) }); imgs++;
      continue;
    }
    const tag = m[1].toLowerCase(), x = stripTags(m[2]);
    if (!x || BOILER.test(x)) continue;
    if (tag === 'h2' || tag === 'h3') { if (x.length < 120) out.push({ t: 'h', x: x }); continue; }
    if (tag === 'li' && x.length < 60) continue;
    if (x.length < 40 && !/[。！？」]$/.test(x)) continue;
    out.push({ t: 'p', x: x });
  }
  // drop a trailing run of headings / images without text
  while (out.length && out[out.length - 1].t !== 'p') out.pop();
  return out;
}
function vapid_() {
  const props = PropertiesService.getScriptProperties();
  let d = props.getProperty('VAPID_D'), pub = props.getProperty('VAPID_PUB');
  if (!d || !pub) {
    const seed = [Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Date.now()].join('');
    const dd = P256.mod(P256.bytesToBig(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, seed)), P256.n - BI1) + BI1;
    const Q = P256.affine(P256.mul(dd, P256.G));
    d = dd.toString(16); pub = P256.b64u([4].concat(P256.bigTo32(Q[0]), P256.bigTo32(Q[1])));
    props.setProperty('VAPID_D', d); props.setProperty('VAPID_PUB', pub);
  }
  return { d: BigInt('0x' + d), pub: pub };
}
function vapidJwt_(aud) {
  const cache = CacheService.getScriptCache(), ck = 'jwt_' + hashId(aud);
  const hit = cache.get(ck); if (hit) return hit;
  const v = vapid_(), enc = function (o) { return Utilities.base64EncodeWebSafe(JSON.stringify(o)).replace(/=+$/, ''); };
  let sub = 'mailto:bme-radar@example.com';
  try { const em = Session.getEffectiveUser().getEmail(); if (em) sub = 'mailto:' + em; } catch (e) {}
  const input = enc({ typ: 'JWT', alg: 'ES256' }) + '.' + enc({ aud: aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: sub });
  const jwt = input + '.' + P256.signB64u(input, v.d);
  cache.put(ck, jwt, 6 * 3600);
  return jwt;
}
function sendPush_(s) {
  const aud = s.endpoint.match(/^https:\/\/[^\/]+/)[0];
  const r = UrlFetchApp.fetch(s.endpoint, { method: 'post', muteHttpExceptions: true, contentType: 'application/octet-stream', payload: '',
    headers: { TTL: '43200', Urgency: 'high', Authorization: 'vapid t=' + vapidJwt_(aud) + ', k=' + vapid_().pub } });
  const code = r.getResponseCode();
  return { ok: code >= 200 && code < 300, code: code, gone: code === 404 || code === 410, body: code >= 300 ? String(r.getContentText() || '').replace(/\s+/g, ' ').slice(0, 160) : '' };
}
const BI0 = BigInt(0);
const BI1 = BigInt(1);
const BI2 = BigInt(2);
const BI3 = BigInt(3);
const BI4 = BigInt(4);
const BI8 = BigInt(8);
const P256 = (function () {
  const p = BigInt('0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff');
  const n = BigInt('0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551');
  const G = [BigInt('0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296'), BigInt('0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5'), BI1];
  const mod = function (a, m) { const r = a % m; return r >= BI0 ? r : r + m; };
  const inv = function (a, m) { let lm = BI1, hm = BI0, low = mod(a, m), high = m; while (low > BI1) { const r = high / low; const nm = hm - lm * r, nw = high - low * r; hm = lm; lm = nm; high = low; low = nw; } return mod(lm, m); };
  const dbl = function (P) {
    if (!P || P[1] === BI0) return null;
    const X = P[0], Y = P[1], Z = P[2], YY = Y * Y % p, S = BI4 * X * YY % p, ZZ = Z * Z % p, M = BI3 * mod(X - ZZ, p) * (X + ZZ) % p;
    const X3 = mod(M * M - BI2 * S, p); return [X3, mod(M * (S - X3) - BI8 * YY * YY, p), BI2 * Y * Z % p];
  };
  const add = function (P, Q) {
    if (!P) return Q; if (!Q) return P;
    const Z1Z1 = P[2] * P[2] % p, Z2Z2 = Q[2] * Q[2] % p, U1 = P[0] * Z2Z2 % p, U2 = Q[0] * Z1Z1 % p;
    const S1 = P[1] * Q[2] % p * Z2Z2 % p, S2 = Q[1] * P[2] % p * Z1Z1 % p;
    if (U1 === U2) return S1 === S2 ? dbl(P) : null;
    const H = mod(U2 - U1, p), R = mod(S2 - S1, p), HH = H * H % p, HHH = H * HH % p, V = U1 * HH % p;
    const X3 = mod(R * R - HHH - BI2 * V, p); return [X3, mod(R * (V - X3) - S1 * HHH, p), H * P[2] % p * Q[2] % p];
  };
  const mul = function (k, P) { let R = null, Q = P; while (k > BI0) { if (k & BI1) R = add(R, Q); Q = dbl(Q); k >>= BI1; } return R; };
  const affine = function (P) { const zi = inv(P[2], p), zi2 = zi * zi % p; return [P[0] * zi2 % p, P[1] * zi2 % p * zi % p]; };
  const bytesToBig = function (b) { let h = ''; for (let i = 0; i < b.length; i++) h += ((b[i] & 255) + 256).toString(16).slice(1); return BigInt('0x' + (h || '0')); };
  const bigTo32 = function (x) { const h = x.toString(16).padStart(64, '0'), out = []; for (let i = 0; i < 64; i += 2) out.push(parseInt(h.substr(i, 2), 16)); return out; };
  const b64u = function (bytes) { return Utilities.base64EncodeWebSafe(bytes.map(function (x) { return x > 127 ? x - 256 : x; })).replace(/=+$/, ''); };
  const sha = function (str) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, str, Utilities.Charset.UTF_8); };
  const signB64u = function (msg, d) {
    const e = bytesToBig(sha(msg));
    for (let tries = 0; tries < 8; tries++) {
      const k = mod(bytesToBig(sha(Utilities.getUuid() + Utilities.getUuid() + msg + d.toString(16) + tries)), n - BI1) + BI1;
      const R = affine(mul(k, G)), r = mod(R[0], n); if (r === BI0) continue;
      const s = mod(inv(k, n) * (e + r * d), n); if (s === BI0) continue;
      return b64u(bigTo32(r).concat(bigTo32(s)));
    }
    throw new Error('sign failed');
  };
  return { p: p, n: n, G: G, mod: mod, mul: mul, affine: affine, bytesToBig: bytesToBig, bigTo32: bigTo32, b64u: b64u, signB64u: signB64u };
})();

