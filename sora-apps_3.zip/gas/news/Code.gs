/**
 * 医工学レーダー — collector for biomedical-engineering news, papers, approvals, trials,
 * company news and university/academic notices. Brain and nervous-system items are ranked first.
 * (Google Apps Script web app; the PWA in /news/ reads from it.)
 *
 *   GET  (no params)                        latest feed: last 4 days + highlights + trends + source status
 *   GET  ?v=more&before=<ms>&type=&cat=     older items (index and monthly archive)
 *   GET  ?v=search&q=<words>&type=&cat=     full search over the archive
 *   POST {pass, action:'prefs-get'|'prefs-set'|'bm-load'|'bm-save'|'refresh'|'digest-test', ...}
 *
 * First time: set PASS_PHRASE, run setup() once (registers the pass phrase, installs the hourly
 * collector and the morning digest, does the first collection), then
 * Deploy > New deployment > Web app (Execute as: Me / Who has access: Anyone).
 * To add or remove sources, edit SOURCES below.
 */
const PASS_PHRASE = 'ここを自分だけの合言葉に変える';
const DATA_FOLDER = 'bme-radar-data';
const APP_URL = '';          // e.g. https://<user>.github.io/sora-apps/news/  (link at the bottom of the morning mail)
const INDEX_DAYS = 30, FEED_DAYS = 4, TIME_BUDGET_MS = 270000;

/* ---------- sources ----------
 * kind: rss | gnews | pubmed | fda510k | fdapma | fdarecall | ctgov
 * type: news | paper | reg | trial | biz | acad        every: hours between fetches
 * filter: bme (must look like biomedical engineering) | none (keep everything) | kw (must match kw)
 */
const GN = (id, name, q, extra) => Object.assign({ id: id, name: name, kind: 'gnews', q: q, type: 'news', every: 1, filter: 'bme' }, extra || {});
const PM = (id, name, term, extra) => Object.assign({ id: id, name: name, kind: 'pubmed', term: term, type: 'paper', every: 6, filter: 'none' }, extra || {});
const SOURCES = [
  // --- brain first ---
  GN('gn-bci', 'Google News: BCI', '"brain-computer interface" OR "brain-machine interface" OR "neural interface" OR "brain implant"', { trust: true }),
  GN('gn-neurotech', 'Google News: ニューロテック企業', 'Neuralink OR Synchron OR "Precision Neuroscience" OR Paradromics OR "Blackrock Neurotech" OR Neuropace OR "Onward Medical" OR Motif Neurotech', { trust: true }),
  GN('gn-neuromod', 'Google News: 神経刺激', '"deep brain stimulation" OR neuromodulation OR "vagus nerve stimulation" OR "spinal cord stimulation" OR "transcranial magnetic stimulation" OR "focused ultrasound" brain'),
  GN('gn-neuroimaging', 'Google News: 脳計測', 'EEG device OR "brain imaging" OR "brain scan" technology OR neuroimaging OR "brain wearable"'),
  GN('gn-neuroprosth', 'Google News: 神経補綴・感覚', 'neuroprosthesis OR neuroprosthetic OR "retinal implant" OR "bionic eye" OR "spinal cord injury" implant OR "nerve stimulator" OR "cochlear implant"'),
  // --- the rest of biomedical engineering ---
  GN('gn-device', 'Google News: 医療機器・承認', '"medical device" OR "FDA clearance" OR "FDA clears" OR "breakthrough device designation" OR "De Novo" device'),
  GN('gn-sensing', 'Google News: 生体計測・ウェアラブル', 'wearable biosensor OR "continuous glucose monitor" OR "pulse oximeter" OR cuffless "blood pressure" OR "smart patch" health OR "remote patient monitoring"'),
  GN('gn-imaging', 'Google News: 医用画像', '"medical imaging" OR "MRI scanner" OR "ultrasound device" OR "photon-counting CT" OR "AI radiology" OR endoscopy device'),
  GN('gn-robot', 'Google News: 手術支援・ロボット・補綴', '"surgical robot" OR "robotic surgery" OR exoskeleton OR "bionic" prosthetic OR "rehabilitation robot"'),
  GN('gn-implant', 'Google News: 人工臓器・埋込機器', '"artificial heart" OR LVAD OR pacemaker OR "cochlear implant" OR "artificial pancreas" OR "implantable device" OR "heart valve" device'),
  GN('gn-regen', 'Google News: 再生医療・材料', '"tissue engineering" OR bioprinting OR organoid OR biomaterial OR hydrogel implant OR "organ-on-a-chip"'),
  GN('gn-digital', 'Google News: AI・デジタルヘルス', '"AI medical device" OR "software as a medical device" OR "digital therapeutics" OR "digital health" FDA'),
  GN('gn-therapy', 'Google News: 治療機器', '"drug delivery" device OR microneedle OR "proton therapy" OR ablation device OR "radiotherapy system"'),
  GN('gn-funding', 'Google News: 企業・資金調達', 'medtech raises OR "medical device" startup funding OR neurotech funding OR medtech acquisition', { type: 'biz' }),
  GN('gn-ja-bme', 'Google ニュース: 医工学', '医工学 OR 生体医工学 OR 医療機器 開発 OR 医療機器 研究', { lang: 'ja' }),
  GN('gn-ja-brain', 'Google ニュース: 脳・BMI', 'ブレイン・マシン・インターフェース OR ブレイン・コンピューター・インターフェース OR ニューロテック OR 脳波 デバイス OR 脳 インプラント', { lang: 'ja', trust: true }),
  GN('gn-ja-approval', 'Google ニュース: 承認・薬事', '医療機器 承認 OR プログラム医療機器 OR SaMD 承認 OR 医療機器 認証 取得', { lang: 'ja', type: 'reg' }),
  GN('gn-ja-wearable', 'Google ニュース: 生体計測', 'ウェアラブル 医療 OR 血糖 センサ OR パルスオキシメータ OR 血圧計 OR 生体センサ', { lang: 'ja' }),
  GN('gn-ja-startup', 'Google ニュース: 医療機器スタートアップ', '医療機器 スタートアップ 資金調達 OR ヘルステック 資金調達 OR 医療機器 買収', { lang: 'ja', type: 'biz' }),
  GN('gn-ja-univ', 'Google ニュース: 大学の研究成果', '大学 発表 脳 計測 OR 大学 開発 医療機器 OR 大学 研究 ウェアラブル 医療 OR 大学 研究 手術支援ロボット', { lang: 'ja', type: 'acad' }),
  GN('gn-ja-academia', 'Google ニュース: 学会・公募', '生体医工学会 OR 医工学 シンポジウム OR 医療機器 公募 OR AMED 公募 医療機器', { lang: 'ja', type: 'acad', filter: 'none' }),
  // industry press
  { id: 'medtechdive', name: 'MedTech Dive', kind: 'rss', url: 'https://www.medtechdive.com/feeds/news/', type: 'news', every: 1, filter: 'none' },
  { id: 'fierce', name: 'Fierce Biotech MedTech', kind: 'rss', url: 'https://www.fiercebiotech.com/rss/medtech/xml', type: 'news', every: 2, filter: 'none' },
  { id: 'massdevice', name: 'MassDevice', kind: 'rss', url: 'https://www.massdevice.com/feed/', type: 'news', every: 2, filter: 'none' },
  { id: 'mdo', name: 'Medical Design & Outsourcing', kind: 'rss', url: 'https://feeds.feedburner.com/MedicalDesignAndOutsourcing', type: 'news', every: 2, filter: 'none' },
  { id: 'medgadget', name: 'Medgadget', kind: 'rss', url: 'https://www.medgadget.com/feed', type: 'news', every: 2, filter: 'none' },
  { id: 'mobihealth', name: 'MobiHealthNews', kind: 'rss', url: 'https://www.mobihealthnews.com/rss.xml', type: 'news', every: 3, filter: 'bme' },
  { id: 'stat-tech', name: 'STAT Health Tech', kind: 'rss', url: 'https://www.statnews.com/category/health-tech/feed/', type: 'news', every: 2, filter: 'bme' },
  { id: 'spectrum', name: 'IEEE Spectrum', kind: 'rss', url: 'https://spectrum.ieee.org/feeds/topic/biomedical.rss', type: 'news', every: 3, filter: 'none' },
  { id: 'nn-neurotech', name: 'Neuroscience News', kind: 'rss', url: 'https://neurosciencenews.com/neuroscience-topics/neurotech/feed/', type: 'news', every: 2, filter: 'none' },
  { id: 'sd-devices', name: 'ScienceDaily: Medical Devices', kind: 'rss', url: 'https://www.sciencedaily.com/rss/health_medicine/medical_devices.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-imaging', name: 'ScienceDaily: Medical Imaging', kind: 'rss', url: 'https://www.sciencedaily.com/rss/health_medicine/medical_imaging.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-medtech', name: 'ScienceDaily: Medical Technology', kind: 'rss', url: 'https://www.sciencedaily.com/rss/matter_energy/medical_technology.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-bci', name: 'ScienceDaily: BCI', kind: 'rss', url: 'https://www.sciencedaily.com/rss/mind_brain/brain-computer_interfaces.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-wearable', name: 'ScienceDaily: Wearable', kind: 'rss', url: 'https://www.sciencedaily.com/rss/matter_energy/wearable_technology.xml', type: 'news', every: 3, filter: 'bme' },
  { id: 'sd-neuro', name: 'ScienceDaily: Neuroscience', kind: 'rss', url: 'https://www.sciencedaily.com/rss/mind_brain/neuroscience.xml', type: 'news', every: 3, filter: 'bme' },
  { id: 'eurekalert', name: 'EurekAlert! Technology', kind: 'rss', url: 'https://www.eurekalert.org/rss/technology_engineering.xml', type: 'news', every: 3, filter: 'bme' },
  { id: 'monoist', name: 'MONOist', kind: 'rss', url: 'https://rss.itmedia.co.jp/rss/2.0/monoist.xml', type: 'news', every: 3, filter: 'bme', lang: 'ja' },
  // papers and preprints
  { id: 'nbme', name: 'Nature Biomedical Engineering', kind: 'rss', url: 'https://www.nature.com/natbiomedeng.rss', type: 'paper', every: 6, filter: 'none', tier: 3 },
  { id: 'npjdm', name: 'npj Digital Medicine', kind: 'rss', url: 'https://www.nature.com/npjdigitalmed.rss', type: 'paper', every: 6, filter: 'none', tier: 2 },
  { id: 'jne', name: 'Journal of Neural Engineering', kind: 'rss', url: 'https://iopscience.iop.org/journal/rss/1741-2552', type: 'paper', every: 6, filter: 'none', tier: 2 },
  PM('pm-journals', 'PubMed: 主要医工学誌', '("IEEE Trans Biomed Eng"[ta] OR "IEEE J Biomed Health Inform"[ta] OR "IEEE Trans Neural Syst Rehabil Eng"[ta] OR "IEEE Trans Med Imaging"[ta] OR "J Neural Eng"[ta] OR "Sci Transl Med"[ta] OR "Nat Biomed Eng"[ta] OR "Biomaterials"[ta] OR "Lancet Digit Health"[ta] OR "Sci Robot"[ta] OR "Med Image Anal"[ta] OR "Biosens Bioelectron"[ta] OR "Ann Biomed Eng"[ta])', { tier: 2, ret: 80 }),
  PM('pm-brain', 'PubMed: 脳・神経工学', '("brain-computer interface"[tiab] OR "brain-machine interface"[tiab] OR "neural interface"[tiab] OR intracortical[tiab] OR neuroprosthe*[tiab] OR "deep brain stimulation"[tiab] OR "transcranial magnetic stimulation"[tiab] OR "spinal cord stimulation"[tiab] OR "vagus nerve stimulation"[tiab] OR "neural decoding"[tiab])', { ret: 60 }),
  PM('pm-sensing', 'PubMed: 生体計測・ウェアラブル', '(wearable[tiab] OR "continuous glucose monitoring"[tiab] OR "pulse oximetry"[tiab] OR photoplethysmograph*[tiab] OR "cuffless blood pressure"[tiab] OR biosensor*[tiab]) AND (device*[tiab] OR sensor*[tiab] OR system[tiab])', { ret: 50 }),
  PM('pm-robot', 'PubMed: ロボット・補綴', '("surgical robot*"[tiab] OR "robot-assisted"[tiab] OR exoskeleton*[tiab] OR "prosthetic hand"[tiab] OR "powered prosthesis"[tiab] OR "rehabilitation robot*"[tiab])', { ret: 40 }),
  PM('pm-implant', 'PubMed: 人工臓器・埋込機器', '("artificial heart"[tiab] OR "ventricular assist device"[tiab] OR "cochlear implant*"[tiab] OR "artificial pancreas"[tiab] OR "implantable"[tiab] AND device*[tiab])', { ret: 40 }),
  PM('pm-imaging', 'PubMed: 医用画像・AI', '("deep learning"[tiab] OR "foundation model"[tiab]) AND (MRI[tiab] OR "computed tomography"[tiab] OR ultrasound[tiab] OR endoscop*[tiab] OR "medical image*"[tiab])', { ret: 40 }),
  PM('pm-regen', 'PubMed: 組織工学・材料', '("tissue engineering"[tiab] OR bioprint*[tiab] OR "organ-on-a-chip"[tiab] OR (scaffold*[tiab] AND regenerat*[tiab]))', { ret: 40 }),
  { id: 'arxiv', name: 'arXiv', kind: 'rss', url: 'https://export.arxiv.org/api/query?sortBy=submittedDate&sortOrder=descending&max_results=60&search_query=' + encodeURIComponent('abs:"brain-computer interface" OR abs:"neural decoding" OR abs:"intracortical" OR abs:"medical image" OR abs:"wearable sensor" OR abs:"biomedical signal" OR abs:"surgical robot" OR abs:"photoplethysmography"'), type: 'paper', every: 6, filter: 'none' },
  { id: 'biorxiv-bioeng', name: 'bioRxiv Bioengineering', kind: 'rss', url: 'https://connect.biorxiv.org/biorxiv_xml.php?subject=bioengineering', type: 'paper', every: 6, filter: 'none' },
  { id: 'biorxiv-neuro', name: 'bioRxiv Neuroscience', kind: 'rss', url: 'https://connect.biorxiv.org/biorxiv_xml.php?subject=neuroscience', type: 'paper', every: 6, filter: 'bme' },
  // approvals and regulation
  { id: 'fda-510k', name: 'FDA 510(k)', kind: 'fda510k', type: 'reg', every: 6, filter: 'none' },
  { id: 'fda-pma', name: 'FDA PMA 承認', kind: 'fdapma', type: 'reg', every: 12, filter: 'none', tier: 3 },
  { id: 'fda-recall', name: 'FDA クラスIリコール', kind: 'fdarecall', type: 'reg', every: 12, filter: 'none' },
  { id: 'fda-press', name: 'FDA Press', kind: 'rss', url: 'https://www.fda.gov/about-fda/contact-fda/stay-informed/rss-feeds/press-releases/rss.xml', type: 'reg', every: 3, filter: 'kw', kw: 'device|diagnostic|digital|software|implant|AI\\b|artificial intelligence|neuro|brain|monitor' },
  { id: 'pmda', name: 'PMDA', kind: 'rss', url: 'https://www.pmda.go.jp/rss_008.xml', type: 'reg', every: 6, filter: 'kw', kw: 'device|SaMD|medical device|regenerative|AI|プログラム|医療機器|再生医療' },
  { id: 'mhlw', name: '厚生労働省', kind: 'rss', url: 'https://www.mhlw.go.jp/stf/news.rdf', type: 'reg', every: 3, filter: 'kw', kw: '医療機器|プログラム医療機器|再生医療|デジタル|薬事|ＡＩ|AI|医療ＤＸ|医療DX', lang: 'ja' },
  // clinical trials
  { id: 'ctgov', name: 'ClinicalTrials.gov', kind: 'ctgov', type: 'trial', every: 6, filter: 'none' },
  // universities, academic, calls
  { id: 'tuat-research', name: '東京農工大学 研究成果', kind: 'rss', url: 'http://www.tuat.ac.jp/NEWS/research/rss.xml', type: 'acad', every: 6, filter: 'none', lang: 'ja', tier: 2 },
  { id: 'tuat-event', name: '東京農工大学 イベント', kind: 'rss', url: 'http://www.tuat.ac.jp/event/rss.xml', type: 'acad', every: 12, filter: 'none', lang: 'ja' },
  { id: 'univ-journal', name: '大学ジャーナル', kind: 'rss', url: 'https://univ-journal.jp/feed/', type: 'acad', every: 3, filter: 'bme', lang: 'ja' },
  { id: 'jst-portal', name: 'JST サイエンスポータル', kind: 'rss', url: 'https://scienceportal.jst.go.jp/feed/rss.xml', type: 'acad', every: 3, filter: 'bme', lang: 'ja' },
  { id: 'nih-guide', name: 'NIH 公募', kind: 'rss', url: 'https://grants.nih.gov/grants/guide/newsfeed/fundingopps.xml', type: 'acad', every: 12, filter: 'bme' },
];

/* ---------- categories ---------- */
const CATS = {
  brain: { name: '脳・神経', re: /brain|neur(o|al|on)|cortex|cortical|cerebr|spinal cord|\bEEG\b|\bBCIs?\b|\bBMIs?\b(?![\s-]*(index|score|value|of))|deep brain|\bDBS\b|\bTMS\b|epilep|parkinson|alzheimer|dementia|stroke|\bALS\b|seizure|neuromodulat|optogenet|vagus|cochlear|retinal prosthe|脳|神経|脊髄|てんかん|パーキンソン|認知症|脳卒中/i },
  imaging: { name: '医用画像', re: /\bf?MRI\b|\bCT\b|computed tomograph|ultrasound|ultrasonograph|\bPET\b|x-ray|radiograph|radiolog|mammograph|endoscop|\bOCT\b|optical coherence|photoacoustic|imaging|画像|内視鏡|超音波|MRI|ＣＴ/i },
  sensing: { name: '生体計測・ウェアラブル', re: /wearable|biosensor|sensor|smartwatch|\bECG\b|\bEKG\b|electrocardiog|\bPPG\b|photoplethysm|pulse oxim|oximet|SpO2|blood pressure|cuffless|glucose monitor|\bCGM\b|sweat|remote (patient )?monitoring|ウェアラブル|センサ|血圧|血糖|パルスオキシ|心電|生体計測/i },
  implant: { name: '人工臓器・埋込機器', re: /implant|pacemaker|defibrillator|\bLVAD\b|ventricular assist|artificial (heart|pancreas|kidney|organ|lung|retina)|cochlear|stent|heart valve|\bTAVR\b|dialys|catheter|人工(心臓|臓器|膵臓|関節|網膜)|インプラント|ステント|カテーテル|ペースメーカ|人工内耳/i },
  regen: { name: '再生医療・材料', re: /tissue engineer|regenerat|scaffold|biomaterial|hydrogel|bioprint|organoid|organ[-\s]on[-\s]a[-\s]chip|stem cell|\biPS|biofabricat|biodegradable|再生医療|組織工学|バイオマテリアル|足場材料|オルガノイド|iPS/i },
  robot: { name: '手術支援・ロボット・補綴', re: /robot|exoskeleton|prosthe(sis|tic|ses)|bionic|da vinci|teleoperat|haptic|rehabilitat|ロボット|義手|義足|リハビリ|外骨格/i },
  ai: { name: 'AI・デジタルヘルス', re: /\bAI\b|artificial intelligence|machine learning|deep learning|neural network|foundation model|language model|\bLLMs?\b|digital health|telehealth|telemedicine|software as a medical device|\bSaMD\b|digital therapeut|人工知能|機械学習|深層学習|生成AI|デジタルヘルス|プログラム医療機器|遠隔医療|ＡＩ/i },
  therapy: { name: '治療機器・DDS', re: /drug delivery|microneedle|nanoparticle|radiotherapy|radiation therapy|proton therapy|ablation|laser|focused ultrasound|\bHIFU\b|electroporation|photodynamic|hyperthermia|infusion pump|insulin pump|ドラッグデリバリー|マイクロニードル|放射線治療|陽子線|アブレーション|レーザー/i },
};
const STRONG_RE = /biomedical engineer|bioengineer|medical device|medtech|med-tech|neurotech|brain[-\s]?(computer|machine) interface|neural interface|\bBCIs?\b|\bSaMD\b|510\(k\)|De Novo|医工学|生体医工|医療機器|プログラム医療機器|ニューロテック|ブレイン.?(マシン|コンピュータ)/i;
const MED_RE = /patient|clinical|clinic|medical|medicine|health|disease|disorder|surgery|surgical|surgeon|hospital|therap|diagnos|cancer|tumou?r|cardiac|cardio|heart|arrhythm|atrial|\bECG\b|\bEKG\b|brain|neuro|epilep|parkinson|alzheimer|dementia|diabet|glucose|insulin|stroke|injur|paraly|rehabilit|blood|organ|tissue|lung|pulmon|respirat|kidney|renal|liver|retina|hearing|wound|bone|ortho|spine|spinal|pain|sleep apnea|\bFDA\b|PMDA|医療|患者|病院|治療|診断|疾患|手術|がん|心臓|脳|神経|糖尿病|リハビリ|臨床|健康/i;
const ENG_RE = /device|sensor|imaging|implant|robot|wearable|algorithm|\bAI\b|machine learning|engineer|material|scaffold|electrode|ultrasound|laser|chip|stimulat|prosthe|system|3D[- ]print|bioprint|nanoparticle|microneedle|catheter|stent|monitor|interface|platform|software|デバイス|機器|装置|センサ|ロボット|電極|材料|システム|ソフトウェア|AI|ＡＩ|開発|技術/i;
const BIZ_RE = /\braises?\b|\bfunding\b|series [a-e]\b|acqui(re|res|red|sition)|merger|\bIPO\b|investment round|financing|資金調達|買収|出資|上場|シリーズ[A-EＡ-Ｅ]/i;
const REG_RE = /FDA (clear|approv|grant|authori)|510\(k\)|De Novo|\bPMA\b|CE mark|breakthrough device|recall|承認(を)?取得|薬事承認|製造販売承認|認証取得|PMDA/i;
const TOP_SOURCES = /Nature|Science|NEJM|Lancet|Cell|IEEE Trans|J Neural Eng|Journal of Neural Engineering/i;

/* ========== setup / triggers ========== */
function setup() {
  if (!PASS_PHRASE || PASS_PHRASE.indexOf('ここを') === 0) throw new Error('PASS_PHRASE を書き換えてから実行してください');
  const props = PropertiesService.getScriptProperties();
  props.setProperty('PASS', PASS_PHRASE);
  dataFolder_();
  installTriggers_(getPrefs_().email.hour);
  const r = collect_({ force: true });
  Logger.log('準備完了: ' + JSON.stringify(r));
}
function installTriggers_(hour) {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    const h = t.getHandlerFunction(); if (h === 'updateNews' || h === 'sendDigest') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('updateNews').timeBased().everyHours(1).create();
  ScriptApp.newTrigger('sendDigest').timeBased().atHour(hour).everyDays(1).inTimezone('Asia/Tokyo').create();
}
/* hourly trigger */
function updateNews() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(2000)) return { busy: true };
  try { return collect_({}); } finally { lock.releaseLock(); }
}

/* ========== web endpoints ========== */
function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    if (p.v === 'more') return json_(queryArchive_({ before: +p.before || Date.now(), type: p.type || '', cat: p.cat || '', q: '', limit: 150 }));
    if (p.v === 'search') return json_(queryArchive_({ before: Date.now() + 864e5, type: p.type || '', cat: p.cat || '', q: String(p.q || ''), limit: 200, months: 12 }));
    let body = cacheGet_('feed');
    if (!body) { body = JSON.stringify(readJson_('feed.json', { ok: true, updated: 0, items: [], highlights: [], brain: [], trends: [], stats: [], sources: [] })); cachePut_('feed', body); }
    return ContentService.createTextOutput(body).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}
function doPost(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'bad request' }); }
  if (!checkPass_(req.pass)) return json_({ ok: false, error: 'auth' });
  try {
    switch (req.action) {
      case 'prefs-get': return json_({ ok: true, prefs: getPrefs_(), email: Session.getEffectiveUser().getEmail() });
      case 'prefs-set': {
        const old = getPrefs_(), p = sanitizePrefs_(Object.assign({}, old, req.prefs || {}));
        PropertiesService.getScriptProperties().setProperty('PREFS', JSON.stringify(p));
        if (p.email.hour !== old.email.hour) installTriggers_(p.email.hour);
        if (JSON.stringify(p.watch) !== JSON.stringify(old.watch)) { const lock = LockService.getScriptLock(); if (lock.tryLock(10000)) { try { rebuild_(); } finally { lock.releaseLock(); } } }
        return json_({ ok: true, prefs: p });
      }
      case 'bm-load': return json_(Object.assign({ ok: true }, readJson_('bookmarks.json', { updated: 0, items: {} })));
      case 'bm-save': { const o = { updated: Date.now(), items: req.items || {} }; writeJson_('bookmarks.json', o); return json_({ ok: true, updated: o.updated }); }
      case 'refresh': { const r = updateNews(); return json_(r.busy ? { ok: false, error: 'busy' } : Object.assign({ ok: true }, r)); }
      case 'force': { const lock = LockService.getScriptLock(); if (!lock.tryLock(2000)) return json_({ ok: false, error: 'busy' }); try { return json_(Object.assign({ ok: true }, collect_({ force: true }))); } finally { lock.releaseLock(); } }
      case 'digest-test': { const r = sendDigest(true); return json_(Object.assign({ ok: true }, r)); }
      default: return json_({ ok: false, error: 'unknown action' });
    }
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

/* ========== preferences ========== */
function getPrefs_() {
  let p = {};
  try { p = JSON.parse(PropertiesService.getScriptProperties().getProperty('PREFS') || '{}'); } catch (e) {}
  return sanitizePrefs_(p);
}
function sanitizePrefs_(p) {
  const e = p.email || {};
  return {
    watch: (Array.isArray(p.watch) ? p.watch : []).map(function (s) { return String(s).trim(); }).filter(function (s) { return s; }).slice(0, 40),
    muted: Array.isArray(p.muted) ? p.muted.slice(0, 100) : [],
    email: { on: e.on !== false, hour: Math.max(0, Math.min(23, isFinite(+e.hour) && e.hour !== '' ? +e.hour : 7)), to: String(e.to || '').trim(), max: Math.max(5, Math.min(40, +e.max || 15)) }
  };
}
function markWatch(items, wre) { items.forEach(function (it) { it.w = wre && wre.test(it.t + ' ' + (it.x || '') + ' ' + it.s) ? 1 : 0; }); }
/* rebuild feed.json from the index without fetching (after the watch list changes) */
function rebuild_() {
  const now = Date.now(), index = readJson_('index.json', { items: [] }), state = readJson_('state.json', { last: {}, status: {} });
  markWatch(index.items, watchRegex(getPrefs_().watch));
  writeJson_('index.json', index);
  const feed = buildFeed(index.items, state, now);
  writeJson_('feed.json', feed); cachePut_('feed', JSON.stringify(feed));
}
function watchRegex(words) {
  if (!words || !words.length) return null;
  return new RegExp(words.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|'), 'i');
}

/* ========== collection ========== */
function collect_(opts) {
  const t0 = Date.now(), now = Date.now();
  const state = readJson_('state.json', { last: {}, status: {} });
  const index = readJson_('index.json', { items: [] });
  const prefs = getPrefs_(), wre = watchRegex(prefs.watch);
  const byId = {}, byTitle = {};
  index.items.forEach(function (it) { byId[it.id] = it; byTitle[normTitle(it.t)] = it.id; });
  const recent = index.items.filter(function (it) { return it.d > now - 3 * 864e5; }).map(function (it) { return { it: it, tok: titleTokens(it.t) }; });
  const due = SOURCES.filter(function (s) {
    if (prefs.muted.indexOf(s.id) >= 0) return false;
    return opts.force || !state.last[s.id] || now - state.last[s.id] >= s.every * 36e5 - 6 * 6e4;
  });
  const fresh = [];
  const ingest = function (src, raws) {
    let n = 0;
    raws.slice(0, src.ret || 80).forEach(function (r) {
      const it = normalizeItem(r, src, now);
      if (!it) return;
      const nt = normTitle(it.t);
      if (byId[it.id] || byTitle[nt]) return;
      it.sc = scoreItem(it, src);
      assignCluster(it, recent);
      byId[it.id] = it; byTitle[nt] = it.id; fresh.push(it); n++;
    });
    return n;
  };
  // network sources, a dozen at a time
  const net = due.filter(function (s) { return s.kind !== 'pubmed'; });
  for (let i = 0; i < net.length && Date.now() - t0 < TIME_BUDGET_MS; i += 12) {
    const chunk = net.slice(i, i + 12);
    let res = [];
    try { res = UrlFetchApp.fetchAll(chunk.map(function (s) { return { url: sourceUrl(s, now), muteHttpExceptions: true, followRedirects: true, headers: { 'User-Agent': 'Mozilla/5.0 (compatible; bme-radar/1.0)' } }; })); }
    catch (err) { chunk.forEach(function (s) { state.status[s.id] = { ok: false, error: String(err.message || err).slice(0, 100), at: now }; }); continue; }
    chunk.forEach(function (s, k) {
      try {
        const code = res[k].getResponseCode();
        if (code === 404 && /^fda/.test(s.kind)) { state.status[s.id] = { ok: true, n: 0, at: now }; state.last[s.id] = now; return; }  // openFDA: no matches
        if (code >= 400) { state.status[s.id] = { ok: false, error: 'HTTP ' + code, at: now }; return; }
        const raws = parseSource(s, res[k].getContentText());
        state.status[s.id] = { ok: true, n: ingest(s, raws), seen: raws.length, at: now };
        state.last[s.id] = now;
      } catch (err) { state.status[s.id] = { ok: false, error: String(err && err.message || err).slice(0, 100), at: now }; }
    });
  }
  // PubMed politely, one request at a time
  due.filter(function (s) { return s.kind === 'pubmed'; }).forEach(function (s) {
    if (Date.now() - t0 > TIME_BUDGET_MS) return;
    try {
      const raws = pubmedFetch_(s);
      state.status[s.id] = { ok: true, n: ingest(s, raws), seen: raws.length, at: now };
      state.last[s.id] = now;
    } catch (err) { state.status[s.id] = { ok: false, error: String(err && err.message || err).slice(0, 100), at: now }; }
    Utilities.sleep(400);
  });
  // keep 30 days in the index; everything also goes to the monthly archive
  const cutoff = now - INDEX_DAYS * 864e5;
  const items = Object.keys(byId).map(function (k) { return byId[k]; }).filter(function (it) { return it.d >= cutoff; }).sort(function (a, b) { return b.d - a.d; });
  refreshClusterCounts(items);
  markWatch(items, wre);
  writeJson_('index.json', { updated: now, items: items });
  if (fresh.length) archiveAppend_(fresh);
  state.updated = now;
  writeJson_('state.json', state);
  const feed = buildFeed(items, state, now);
  writeJson_('feed.json', feed);
  cachePut_('feed', JSON.stringify(feed));
  return { added: fresh.length, fetched: due.length, total: items.length, ms: Date.now() - t0, failed: due.filter(function (s) { return state.status[s.id] && !state.status[s.id].ok; }).length };
}

function sourceUrl(s, now) {
  if (s.kind === 'rss') return s.url;
  if (s.kind === 'gnews') return 'https://news.google.com/rss/search?q=' + encodeURIComponent(s.q + ' when:3d') + (s.lang === 'ja' ? '&hl=ja&gl=JP&ceid=JP:ja' : '&hl=en-US&gl=US&ceid=US:en');
  const ymd = function (ms) { const d = new Date(ms); return d.getUTCFullYear() + ('0' + (d.getUTCMonth() + 1)).slice(-2) + ('0' + d.getUTCDate()).slice(-2); };
  if (s.kind === 'fda510k') return 'https://api.fda.gov/device/510k.json?limit=100&sort=decision_date:desc&search=decision_date:[' + ymd(now - 10 * 864e5) + '+TO+' + ymd(now) + ']';
  if (s.kind === 'fdapma') return 'https://api.fda.gov/device/pma.json?limit=100&sort=decision_date:desc&search=decision_date:[' + ymd(now - 30 * 864e5) + '+TO+' + ymd(now) + ']';
  if (s.kind === 'fdarecall') return 'https://api.fda.gov/device/enforcement.json?limit=50&sort=report_date:desc&search=report_date:[' + ymd(now - 30 * 864e5) + '+TO+' + ymd(now) + ']+AND+classification:"Class+I"';
  if (s.kind === 'ctgov') {
    const from = new Date(now - 4 * 864e5).toISOString().slice(0, 10);
    return 'https://clinicaltrials.gov/api/v2/studies?pageSize=100&sort=StudyFirstPostDate:desc&filter.advanced=' + encodeURIComponent('AREA[InterventionType]DEVICE AND AREA[StudyFirstPostDate]RANGE[' + from + ',MAX]');
  }
  return '';
}
function parseSource(s, text) {
  switch (s.kind) {
    case 'rss': case 'gnews': return parseFeed(text);
    case 'fda510k': return fda510kItems(JSON.parse(text));
    case 'fdapma': return fdaPmaItems(JSON.parse(text));
    case 'fdarecall': return fdaRecallItems(JSON.parse(text));
    case 'ctgov': return ctgovItems(JSON.parse(text));
  }
  return [];
}
function pubmedFetch_(s) {
  const base = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
  const r1 = UrlFetchApp.fetch(base + 'esearch.fcgi?db=pubmed&retmode=json&sort=pub_date&datetype=edat&reldate=3&retmax=' + (s.ret || 60) + '&term=' + encodeURIComponent(s.term), { muteHttpExceptions: true });
  if (r1.getResponseCode() >= 400) throw new Error('HTTP ' + r1.getResponseCode());
  const ids = ((JSON.parse(r1.getContentText()).esearchresult || {}).idlist) || [];
  if (!ids.length) return [];
  Utilities.sleep(350);
  const r2 = UrlFetchApp.fetch(base + 'esummary.fcgi?db=pubmed&retmode=json&id=' + ids.join(','), { muteHttpExceptions: true });
  if (r2.getResponseCode() >= 400) throw new Error('HTTP ' + r2.getResponseCode());
  return pubmedSummaryToItems(JSON.parse(r2.getContentText()));
}

/* ========== archive & queries ========== */
function monthKey(ms) { const d = new Date(ms + 9 * 36e5); return d.getUTCFullYear() + '-' + ('0' + (d.getUTCMonth() + 1)).slice(-2); }
function archiveAppend_(fresh) {
  const groups = {};
  fresh.forEach(function (it) { const k = monthKey(it.d); (groups[k] = groups[k] || []).push(it); });
  Object.keys(groups).forEach(function (k) {
    const name = 'archive_' + k + '.json', cur = readJson_(name, { items: [] });
    const seen = {}; cur.items.forEach(function (it) { seen[it.id] = 1; });
    groups[k].forEach(function (it) { if (!seen[it.id]) cur.items.push(it); });
    writeJson_(name, cur);
  });
}
function queryArchive_(o) {
  const out = [], seen = {};
  const terms = String(o.q || '').toLowerCase().split(/\s+/).filter(function (t) { return t; });
  const match = function (it) {
    if (it.d >= o.before) return false;
    if (o.type && it.ty !== o.type) return false;
    if (o.cat && (it.g || []).indexOf(o.cat) < 0) return false;
    if (terms.length) { const hay = (it.t + ' ' + (it.x || '') + ' ' + it.s).toLowerCase(); for (let i = 0; i < terms.length; i++) if (hay.indexOf(terms[i]) < 0) return false; }
    return true;
  };
  const push = function (list) { for (let i = 0; i < list.length; i++) { const it = list[i]; if (!seen[it.id] && match(it)) { seen[it.id] = 1; out.push(it); } } };
  push(readJson_('index.json', { items: [] }).items);
  const months = o.months || 3;
  for (let m = 0; m < months && out.length < o.limit; m++) {
    const d = new Date(Math.min(o.before, Date.now())); d.setMonth(d.getMonth() - m);
    push(readJson_('archive_' + monthKey(d.getTime()) + '.json', { items: [] }).items);
  }
  out.sort(function (a, b) { return b.d - a.d; });
  return { ok: true, items: out.slice(0, o.limit), more: out.length > o.limit };
}

/* ========== morning digest ========== */
function sendDigest(force) {
  const prefs = getPrefs_();
  if (!prefs.email.on && force !== true) return { sent: false, reason: 'off' };
  const props = PropertiesService.getScriptProperties();
  const since = Math.max(Date.now() - 36 * 36e5, +(props.getProperty('LAST_DIGEST') || 0) || 0);
  const items = readJson_('index.json', { items: [] }).items.filter(function (it) { return (it.f || it.d) >= since; });
  markWatch(items, watchRegex(prefs.watch));
  const html = digestHtml(items, prefs, Date.now());
  const to = prefs.email.to || Session.getEffectiveUser().getEmail();
  const d = new Date(Date.now() + 9 * 36e5);
  MailApp.sendEmail({ to: to, subject: '医工学レーダー ' + (d.getUTCMonth() + 1) + '/' + d.getUTCDate() + '｜新着 ' + items.length + ' 件', htmlBody: html, name: '医工学レーダー' });
  props.setProperty('LAST_DIGEST', String(Date.now()));
  return { sent: true, to: to, count: items.length };
}

/* ========== helpers: storage, cache, json ========== */
function checkPass_(p) {
  const want = PropertiesService.getScriptProperties().getProperty('PASS');
  return !!want && typeof p === 'string' && p === want;
}
function dataFolder_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const f = DriveApp.createFolder(DATA_FOLDER);
  props.setProperty('FOLDER_ID', f.getId());
  return f;
}
function findFile_(folder, name) { const it = folder.getFilesByName(name); return it.hasNext() ? it.next() : null; }
function readJson_(name, fallback) {
  const f = findFile_(dataFolder_(), name);
  if (!f) return fallback;
  try { return JSON.parse(f.getBlob().getDataAsString()); } catch (e) { return fallback; }
}
function writeJson_(name, obj) {
  const folder = dataFolder_(), body = JSON.stringify(obj), f = findFile_(folder, name);
  if (f) f.setContent(body); else folder.createFile(name, body, MimeType.PLAIN_TEXT);
}
function cachePut_(key, str) {
  const c = CacheService.getScriptCache(), size = 90000, parts = {}, n = Math.ceil(str.length / size);
  if (n > 9) return;  // too large for the cache; served from Drive instead
  for (let i = 0; i < n; i++) parts[key + '_' + i] = str.slice(i * size, (i + 1) * size);
  parts[key + '_n'] = String(n);
  try { c.putAll(parts, 21600); } catch (e) {}
}
function cacheGet_(key) {
  const c = CacheService.getScriptCache(), n = +(c.get(key + '_n') || 0);
  if (!n) return null;
  const keys = []; for (let i = 0; i < n; i++) keys.push(key + '_' + i);
  const got = c.getAll(keys); let s = '';
  for (let i = 0; i < n; i++) { if (got[keys[i]] == null) return null; s += got[keys[i]]; }
  return s;
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

/* ======================================================================
 * Pure functions below (no Apps Script services) — also run in tests.
 * ====================================================================== */
function decodeEntities(s) {
  return String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#x([0-9a-f]+);/gi, function (m, h) { return String.fromCharCode(parseInt(h, 16)); })
    .replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); })
    .replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}
function stripTags(s) { return decodeEntities(String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }
function tagText(block, names) {
  for (let i = 0; i < names.length; i++) {
    const m = block.match(new RegExp('<' + names[i] + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + names[i] + '>', 'i'));
    if (m) return m[1];
  }
  return '';
}
function attr(block, tag, name, where) {
  const re = new RegExp('<' + tag + '\\b([^>]*)>', 'gi'); let m;
  while ((m = re.exec(block))) {
    if (where && !where.test(m[1])) continue;
    const a = m[1].match(new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i')) || m[1].match(new RegExp(name + "\\s*=\\s*'([^']*)'", 'i'));
    if (a) return decodeEntities(a[1]);
  }
  return '';
}
/* RSS 2.0, RSS 1.0 (RDF) and Atom */
function parseFeed(xml) {
  xml = String(xml || '');
  const atom = /<feed[\s>]/i.test(xml) && !/<rss[\s>]/i.test(xml);
  const blocks = xml.match(atom ? /<entry[\s>][\s\S]*?<\/entry>/gi : /<item[\s>][\s\S]*?<\/item>/gi) || [];
  return blocks.map(function (b) {
    let link = '';
    if (atom) link = attr(b, 'link', 'href', /rel\s*=\s*["']alternate["']/i) || attr(b, 'link', 'href');
    else link = stripTags(tagText(b, ['link'])) || attr(b, 'item', 'rdf:about') || stripTags(tagText(b, ['guid']));
    const descRaw = tagText(b, ['description', 'summary', 'content:encoded', 'content']);
    const img = attr(b, 'media:content', 'url') || attr(b, 'media:thumbnail', 'url') || attr(b, 'enclosure', 'url', /type\s*=\s*["']image/i) ||
      ((decodeEntities(descRaw).match(/<img[^>]+src\s*=\s*["']([^"']+)["']/i) || [])[1] || '');
    return {
      title: stripTags(tagText(b, ['title', 'dc:title'])),
      link: link.trim(),
      guid: stripTags(tagText(b, ['guid', 'id'])),
      date: stripTags(tagText(b, ['pubDate', 'published', 'dc:date', 'updated', 'prism:publicationDate'])),
      desc: stripTags(descRaw),
      source: stripTags(tagText(b, ['source', 'prism:publicationName'])),
      image: /^https?:/.test(img) ? img : ''
    };
  }).filter(function (r) { return r.title && r.link; });
}
function parseDate(s, fallback) {
  s = String(s || '').trim();
  if (!s) return fallback;
  if (/^\d{8}$/.test(s)) return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8), 12);
  let t = Date.parse(s);
  if (isFinite(t)) return t;
  let m = s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] - 9 : 3, m[5] ? +m[5] : 0);
  m = s.match(/^([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})(?:,? (\d{1,2}):(\d{2})\s*([ap]m)?)?/i);
  if (m) {
    const mon = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(m[1].toLowerCase()) / 3;
    let h = m[4] ? +m[4] : 12; if (m[6] && /pm/i.test(m[6]) && h < 12) h += 12; if (m[6] && /am/i.test(m[6]) && h === 12) h = 0;
    if (mon >= 0) return Date.UTC(+m[3], mon, +m[2], h + 5, m[5] ? +m[5] : 0);   // US Eastern
  }
  return fallback;
}
function pubmedSummaryToItems(sum) {
  const res = sum.result || {}, uids = res.uids || [];
  return uids.map(function (id) {
    const r = res[id] || {};
    const authors = (r.authors || []).slice(0, 3).map(function (a) { return a.name; }).join(', ') + ((r.authors || []).length > 3 ? ' et al.' : '');
    return { title: stripTags(r.title || ''), link: 'https://pubmed.ncbi.nlm.nih.gov/' + id + '/', guid: 'pmid:' + id, date: r.sortpubdate || r.epubdate || r.pubdate || '', desc: authors, source: r.fulljournalname || r.source || 'PubMed', image: '' };
  }).filter(function (r) { return r.title; });
}
function fda510kItems(j) {
  return (j.results || []).map(function (r) {
    const panel = r.advisory_committee_description || r.advisory_committee || '';
    return { title: (r.device_name || '').trim() + ' — ' + (r.applicant || '').trim(), link: 'https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfpmn/pmn.cfm?ID=' + r.k_number, guid: r.k_number,
      date: r.decision_date || '', desc: '510(k) ' + r.k_number + '・' + panel + (r.decision_description ? '・' + r.decision_description : ''), source: 'FDA 510(k)', panel: r.advisory_committee || '', image: '' };
  });
}
function fdaPmaItems(j) {
  return (j.results || []).filter(function (r) { return !r.supplement_number; }).map(function (r) {
    return { title: (r.trade_name || r.generic_name || '').trim() + ' — ' + (r.applicant || '').trim(), link: 'https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfpma/pma.cfm?id=' + r.pma_number, guid: r.pma_number,
      date: r.decision_date || '', desc: 'PMA ' + r.pma_number + ' 承認・' + (r.generic_name || '') + '・' + (r.advisory_committee_description || ''), source: 'FDA PMA', panel: r.advisory_committee || '', image: '' };
  });
}
function fdaRecallItems(j) {
  return (j.results || []).map(function (r) {
    const prod = String(r.product_description || '').replace(/\s+/g, ' ').slice(0, 140);
    return { title: 'Class I recall: ' + prod + ' — ' + (r.recalling_firm || ''), link: 'https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfRES/res.cfm', guid: r.recall_number || prod,
      date: r.report_date || r.recall_initiation_date || '', desc: String(r.reason_for_recall || '').slice(0, 300), source: 'FDA Recall', image: '' };
  });
}
function ctgovItems(j) {
  return (j.studies || []).map(function (st) {
    const p = st.protocolSection || {}, id = p.identificationModule || {}, cond = (p.conditionsModule || {}).conditions || [];
    const sp = ((p.sponsorCollaboratorsModule || {}).leadSponsor || {}).name || '';
    const iv = ((p.armsInterventionsModule || {}).interventions || []).filter(function (x) { return x.type === 'DEVICE'; }).map(function (x) { return x.name; }).slice(0, 3);
    const date = ((p.statusModule || {}).studyFirstPostDateStruct || {}).date || '';
    const sum = String(((p.descriptionModule || {}).briefSummary) || '').replace(/\s+/g, ' ');
    return { title: id.briefTitle || id.officialTitle || '', link: 'https://clinicaltrials.gov/study/' + id.nctId, guid: id.nctId, date: date,
      desc: [cond.slice(0, 3).join(', '), iv.length ? 'Device: ' + iv.join(', ') : '', sp ? 'Sponsor: ' + sp : ''].filter(function (x) { return x; }).join(' ・ ') + (sum ? ' — ' + sum : ''), source: 'ClinicalTrials.gov', image: '' };
  }).filter(function (r) { return r.title; });
}

function classify(text) {
  const g = [];
  Object.keys(CATS).forEach(function (k) { if (CATS[k].re.test(text)) g.push(k); });
  return g;
}
function isBme(text) {
  if (STRONG_RE.test(text)) return true;
  return MED_RE.test(text) && ENG_RE.test(text);
}
function normTitle(t) { return String(t || '').toLowerCase().replace(/\s+[-–|]\s+[^-–|]+$/, '').replace(/[^\w぀-ヿ一-鿿]+/g, '').slice(0, 90); }
function hashId(s) { let h = 5381; s = String(s); for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
const STOP = ('the a an of for and to in on with by from at as is are be its new study shows show finds find using use used via into after over how why what could may can will first more than that this their these new about says said report reports device devices medical patients patient system wins win gets gains launches launch receives announces announced begins adds helps help team researchers scientists year years people data results human next-generation initiative company firm based near could would one two now just').split(' ');
const STOP_JA = ('開発 研究 発表 大学 技術 医療 患者 実証 活用 取得 成功 可能 世界 初 日本 国内 企業 研究所 研究グループ チーム 年度 令和 について お知らせ').split(' ');
function titleTokens(t) {
  const out = {};
  String(t || '').toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).forEach(function (w) { w = w.replace(/^-+|-+$/g, ''); if (w.length >= 3 && STOP.indexOf(w) < 0) out[w] = 1; });
  const ja = String(t || '').match(/[゠-ヿ]{3,}|[一-鿿]{2,}/g) || [];
  ja.forEach(function (w) { if (STOP_JA.indexOf(w) < 0) out[w] = 1; });
  return Object.keys(out);
}
function normalizeItem(r, src, now) {
  let title = r.title, source = r.source || src.name;
  if (src.kind === 'gnews') { const m = title.match(/^(.*)\s+-\s+([^-]{2,60})$/); if (m) { title = m[1]; if (!r.source) source = m[2]; } }
  if (!title) return null;
  const desc = src.kind === 'gnews' ? '' : String(r.desc || '').replace(/\s+/g, ' ');
  const text = title + ' ' + desc;
  if (src.filter === 'bme' && !(src.trust && CATS.brain.re.test(text)) && !isBme(text)) return null;
  if (src.filter === 'kw' && !new RegExp(src.kw, 'i').test(text)) return null;
  let d = parseDate(r.date, now);
  if (d > now + 864e5) d = now;
  let ty = src.type;
  if (ty === 'news' && BIZ_RE.test(title)) ty = 'biz';
  else if (ty === 'news' && REG_RE.test(title)) ty = 'reg';
  let g = classify(text);
  if (r.panel === 'NE' && g.indexOf('brain') < 0) g.unshift('brain');
  const ja = src.lang === 'ja' || /[぀-ヿ]/.test(title);
  return { id: hashId(r.link || r.guid || title), t: title, u: r.link, s: source, sid: src.id, d: d, f: now,
    x: desc.length > 300 ? desc.slice(0, 297) + '…' : desc, im: r.image || '', ty: ty, g: g, l: ja ? 'ja' : 'en', pn: r.panel || '' };
}
function scoreItem(it, src) {
  let s = { news: 14, paper: 12, reg: 18, trial: 8, biz: 13, acad: 12 }[it.ty] || 10;
  if (src.kind === 'fdapma') s += 22;
  if (src.kind === 'fda510k') s += it.pn === 'NE' ? 8 : -4;
  if (src.kind === 'fdarecall') s += 8;
  if (src.tier) s += src.tier * 4;
  if (it.ty === 'paper' && TOP_SOURCES.test(it.s)) s += 8;
  if (it.g.indexOf('brain') >= 0) s += 22;
  if (/brain[-\s]?(computer|machine)|\bBCI|neural interface|neuralink|synchron|intracortical|ブレイン/i.test(it.t)) s += 12;
  s += Math.min(3, it.g.length) * 2;
  if (src.id && src.id.indexOf('tuat') === 0) s += 10;
  return s;
}
function jaccard(a, b) {
  if (!a.length || !b.length) return 0;
  const set = {}; a.forEach(function (x) { set[x] = 1; });
  let inter = 0; b.forEach(function (x) { if (set[x]) inter++; });
  return inter / (a.length + b.length - inter);
}
function assignCluster(it, recent) {
  const tok = titleTokens(it.t);
  let best = null, bs = 0;
  for (let i = 0; i < recent.length; i++) {
    const o = recent[i];
    if (o.it.ty === 'paper' || o.it.ty === 'trial' || it.ty === 'paper' || it.ty === 'trial') continue;
    const s = jaccard(tok, o.tok);
    if (s > bs) { bs = s; best = o; }
  }
  if (best && bs >= 0.5) it.c = best.it.c || best.it.id;
  recent.push({ it: it, tok: tok });
}
function refreshClusterCounts(items) {
  const cnt = {}, ids = {};
  items.forEach(function (it) { ids[it.id] = 1; });
  items.forEach(function (it) { if (it.c && !ids[it.c]) delete it.c; if (it.c) cnt[it.c] = (cnt[it.c] || 0) + 1; });
  items.forEach(function (it) { it.n = cnt[it.id] ? cnt[it.id] + 1 : 0; });
}
function effScore(it, now) {
  const ageH = Math.max(0, (now - it.d) / 36e5);
  return (it.sc || 0) + (it.w ? 30 : 0) + (it.n ? Math.min(5, it.n - 1) * 6 : 0) - ageH * 0.35;
}
function pickTop(list, now, n, perCat) {
  const ranked = list.filter(function (it) { return !it.c; }).sort(function (a, b) { return effScore(b, now) - effScore(a, now); });
  const used = {}, out = [];
  for (let i = 0; i < ranked.length && out.length < n; i++) {
    const it = ranked[i], k = (it.g[0] || it.ty);
    if (perCat && (used[k] || 0) >= perCat) continue;
    used[k] = (used[k] || 0) + 1; out.push(it);
  }
  return out;
}
function trendTerms(items, now) {
  const recent = {}, base = {};
  items.forEach(function (it) {
    const age = (now - it.d) / 864e5, tok = titleTokens(it.t);
    tok.forEach(function (w) { if (/^\d+$/.test(w)) return; if (age <= 3) recent[w] = (recent[w] || 0) + 1; else if (age <= 30) base[w] = (base[w] || 0) + 1; });
  });
  return Object.keys(recent).filter(function (w) { return recent[w] >= 3; }).map(function (w) {
    const b = (base[w] || 0) / 9;   // per 3 days over the previous 27 days
    return { term: w, n: recent[w], rise: Math.round((recent[w] + 1) / (b + 1) * 10) / 10, s: (recent[w] + 1) / (b + 1) * Math.log(recent[w] + 1) };
  }).sort(function (a, b) { return b.s - a.s; }).slice(0, 16).map(function (o) { return { term: o.term, n: o.n, rise: o.rise }; });
}
function dailyStats(items, now) {
  const days = [];
  for (let i = 29; i >= 0; i--) {
    const t = now - i * 864e5, k = new Date(t + 9 * 36e5).toISOString().slice(0, 10);
    days.push({ day: k, total: 0, cats: {}, types: {} });
  }
  const pos = {}; days.forEach(function (d, i) { pos[d.day] = i; });
  items.forEach(function (it) {
    const k = new Date(it.d + 9 * 36e5).toISOString().slice(0, 10), i = pos[k];
    if (i == null) return;
    const d = days[i]; d.total++; d.types[it.ty] = (d.types[it.ty] || 0) + 1;
    it.g.forEach(function (g) { d.cats[g] = (d.cats[g] || 0) + 1; });
  });
  return days;
}
function buildFeed(items, state, now) {
  const recent = items.filter(function (it) { return it.d >= now - FEED_DAYS * 864e5; });
  const last36 = recent.filter(function (it) { return it.d >= now - 36 * 36e5; });
  const brain = pickTop(items.filter(function (it) { return it.d >= now - 72 * 36e5 && it.g.indexOf('brain') >= 0; }), now, 8, 0);
  const highlights = pickTop(last36.filter(function (it) { return brain.indexOf(it) < 0; }), now, 12, 3);
  const sources = SOURCES.map(function (s) { const st = state.status[s.id] || {}; return { id: s.id, name: s.name, type: s.type, ok: st.ok !== false, n: st.n || 0, seen: st.seen || 0, error: st.error || '', at: st.at || 0, every: s.every }; });
  return { ok: true, updated: now, items: recent, highlights: highlights.map(function (it) { return it.id; }), brain: brain.map(function (it) { return it.id; }),
    trends: trendTerms(items, now), stats: dailyStats(items, now), sources: sources,
    cats: Object.keys(CATS).map(function (k) { return { id: k, name: CATS[k].name }; }) };
}
function escHtml(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
const TYPE_JA = { news: 'ニュース', paper: '論文', reg: '承認・規制', trial: '臨床試験', biz: '企業・資金', acad: '大学・学会・公募' };
function digestHtml(items, prefs, now) {
  const fmt = function (ms) { const d = new Date(ms + 9 * 36e5); return (d.getUTCMonth() + 1) + '/' + d.getUTCDate(); };
  const row = function (it) {
    const cats = it.g.slice(0, 3).map(function (g) { return CATS[g] ? CATS[g].name : g; }).join(' / ');
    return '<tr><td style="padding:10px 0;border-bottom:1px solid #e3e7ee">' +
      '<div style="font-size:11px;color:#6b7a90;margin-bottom:3px">' + escHtml(TYPE_JA[it.ty] || '') + '　' + escHtml(it.s) + '　' + fmt(it.d) + (it.n > 1 ? '　ほか' + (it.n - 1) + '件の報道' : '') + '</div>' +
      '<a href="' + escHtml(it.u) + '" style="font-size:15px;line-height:1.45;color:#0b2a5b;text-decoration:none;font-weight:600">' + escHtml(it.t) + '</a>' +
      (cats ? '<div style="font-size:11px;color:#3f6fb5;margin-top:3px">' + escHtml(cats) + '</div>' : '') + '</td></tr>';
  };
  const section = function (title, list, accent) {
    if (!list.length) return '';
    return '<h2 style="font-size:14px;margin:26px 0 4px;padding-left:8px;border-left:4px solid ' + accent + ';color:#0b1120">' + escHtml(title) + '</h2><table style="width:100%;border-collapse:collapse">' + list.map(row).join('') + '</table>';
  };
  const max = prefs.email.max || 15, used = {};
  const take = function (list, n) { const out = []; for (let i = 0; i < list.length && out.length < n; i++) { const it = list[i]; if (used[it.id] || it.c) continue; used[it.id] = 1; out.push(it); } return out; };
  const byScore = items.slice().sort(function (a, b) { return effScore(b, now) - effScore(a, now); });
  const watch = take(byScore.filter(function (it) { return it.w; }), 10);
  const brain = take(byScore.filter(function (it) { return it.g.indexOf('brain') >= 0; }), 6);
  const top = take(byScore.filter(function (it) { return it.ty === 'news'; }), Math.max(5, max - 8));
  const reg = take(byScore.filter(function (it) { return it.ty === 'reg'; }), 6);
  const biz = take(byScore.filter(function (it) { return it.ty === 'biz'; }), 4);
  const acad = take(byScore.filter(function (it) { return it.ty === 'acad'; }), 4);
  const paper = take(byScore.filter(function (it) { return it.ty === 'paper'; }), 6);
  const trial = take(byScore.filter(function (it) { return it.ty === 'trial'; }), 4);
  const counts = {}; items.forEach(function (it) { counts[it.ty] = (counts[it.ty] || 0) + 1; });
  const summary = Object.keys(TYPE_JA).filter(function (k) { return counts[k]; }).map(function (k) { return TYPE_JA[k] + ' ' + counts[k]; }).join('　');
  return '<div style="font-family:-apple-system,\'Hiragino Sans\',\'Noto Sans JP\',sans-serif;max-width:640px;margin:0 auto;color:#1b2232">' +
    '<div style="background:#0b1120;color:#fff;padding:18px 20px"><div style="font-size:12px;letter-spacing:.2em;color:#7aa7ff">BME RADAR</div>' +
    '<div style="font-size:20px;font-weight:700;margin-top:4px">医工学レーダー　' + fmt(now) + '</div><div style="font-size:12px;color:#a9b6c9;margin-top:6px">' + escHtml(summary || '新着なし') + '</div></div>' +
    '<div style="padding:0 20px 24px">' +
    section('ウォッチ中のキーワード', watch, '#e5b53a') + section('脳・神経', brain, '#7aa7ff') + section('注目ニュース', top, '#5fc9b8') +
    section('承認・規制', reg, '#f0a35e') + section('論文', paper, '#a9b6c9') + section('企業・資金', biz, '#c48cf0') +
    section('大学・学会・公募', acad, '#d9c95f') + section('臨床試験', trial, '#ef7f9a') +
    (APP_URL ? '<p style="margin-top:28px"><a href="' + escHtml(APP_URL) + '" style="color:#0b2a5b">アプリで全部見る</a></p>' : '') +
    '</div></div>';
}
