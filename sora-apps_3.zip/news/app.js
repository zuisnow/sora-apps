'use strict';
/* 医工学レーダー — reader for the feed built by gas/news/Code.gs */
const CATS=[['brain','脳・神経'],['imaging','医用画像'],['sensing','生体計測・ウェアラブル'],['implant','人工臓器・埋込機器'],['regen','再生医療・材料'],['robot','手術支援・ロボット・補綴'],['ai','AI・デジタルヘルス'],['therapy','治療機器・DDS']];
const CATN=Object.fromEntries(CATS);
const TYPES=[['all','すべて'],['news','ニュース'],['paper','論文'],['reg','承認・規制'],['trial','臨床試験'],['biz','企業・資金'],['acad','大学・学会・公募']];
const TYPEN=Object.fromEntries(TYPES);
const LS={cache:'radar-cache-v1',read:'radar-read-v1',bm:'radar-bm-v1',cfg:'radar-cfg-v1',prefs:'radar-prefs-v1'};
const app=document.getElementById('app');
const st={view:'today',type:'all',cat:'',q:'',feed:null,loading:false,err:'',limit:50,msg:{},busy:'',search:false,
  older:[],olderDone:false,olderBusy:false,sr:null,open:{},seenAt:0,acct:''};
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function lsGet(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch(e){return d;}}
function lsSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function cfg(){const c=lsGet(LS.cfg,{});
  return{url:c.url||(window.NEWS_CONFIG&&window.NEWS_CONFIG.gasUrl)||'',pass:c.pass||'',img:c.img!==false,group:c.group!==false,seen:c.seen||0};}
function setCfg(k,v){const c=lsGet(LS.cfg,{});c[k]=v;lsSet(LS.cfg,c);}
function prefs(){const p=lsGet(LS.prefs,{});return{watch:(p.watch||[]).slice(),muted:(p.muted||[]).slice(),email:Object.assign({on:true,hour:7,to:'',max:15},p.email||{}),synced:!!p.synced};}
function setPrefs(p){lsSet(LS.prefs,p);wre=watchRe(p.watch);}
function watchRe(ws){ws=(ws||[]).filter(Boolean);return ws.length?new RegExp(ws.map(w=>w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'),'i'):null;}
let wre=watchRe(prefs().watch);
const isWatch=it=>!!(wre&&wre.test(it.t+' '+(it.x||'')+' '+it.s));
const readSet=new Set(lsGet(LS.read,[]));
function markRead(id){readSet.add(id);lsSet(LS.read,[...readSet].slice(-5000));}
function bmGet(){return lsGet(LS.bm,{updated:0,items:{}});}
const pad=n=>String(n).padStart(2,'0');
function ago(ms){const m=Math.round((Date.now()-ms)/60000);if(m<1)return'たった今';if(m<60)return m+'分前';const h=Math.round(m/60);if(h<24)return h+'時間前';const d=new Date(ms);return `${d.getMonth()+1}/${d.getDate()}`;}
function dayKey(ms){const d=new Date(ms);return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;}
function dayLabel(ms){const d=new Date(ms),t=new Date(),y=new Date(t.getFullYear(),t.getMonth(),t.getDate()-1);
  const w='日月火水木金土'[d.getDay()],md=`${d.getMonth()+1}月${d.getDate()}日`;
  if(dayKey(ms)===dayKey(t.getTime()))return['今日',md+'（'+w+'）'];if(dayKey(ms)===dayKey(y.getTime()))return['昨日',md+'（'+w+'）'];return[md,'（'+w+'）'];}
function fmtWhen(ms){if(!ms)return'—';const d=new Date(ms);return `${d.getMonth()+1}/${d.getDate()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;}

/* ---------- sample shown before the GAS URL is set ---------- */
const H=36e5,now0=Date.now();
const SAMPLE={sample:true,updated:0,items:[
  {id:'s1',t:'（表示例）脳・神経に関わる記事は「今日」の先頭にまとまります',s:'Google News',d:now0-2*H,f:now0,ty:'news',g:['brain','robot'],l:'ja',x:'同じ話題を複数の媒体が報じたときは1つにまとめ、件数を添えます。'},
  {id:'s2',t:'（表示例）FDA の 510(k)・PMA、PMDA や厚生労働省の発表は「承認・規制」に入ります',s:'FDA 510(k)',d:now0-5*H,f:now0,ty:'reg',g:['sensing'],l:'ja',x:'510(k) K000000・Neurology'},
  {id:'s3',t:'（表示例）PubMed・Nature Biomedical Engineering・arXiv・bioRxiv の新着論文',s:'PubMed',d:now0-9*H,f:now0,ty:'paper',g:['imaging','ai'],l:'ja',x:'著者名が表示されます'},
  {id:'s4',t:'（表示例）ClinicalTrials.gov に新しく登録された医療機器の臨床試験',s:'ClinicalTrials.gov',d:now0-20*H,f:now0,ty:'trial',g:['therapy'],l:'ja',x:''},
  {id:'s5',t:'（表示例）大学の研究成果、学会の演題募集、研究費の公募',s:'東京農工大学',d:now0-26*H,f:now0,ty:'acad',g:['regen'],l:'ja',x:''},
],highlights:['s2','s3','s4','s5'],brain:['s1'],trends:[],stats:[],sources:[]};

/* ---------- network ---------- */
function gasGet(params){const c=cfg();const u=new URL(c.url);Object.entries(params||{}).forEach(([k,v])=>{if(v!==''&&v!=null)u.searchParams.set(k,v);});u.searchParams.set('t',Date.now());
  return fetch(u.toString()).then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.error||'取得できませんでした');return j;});}
async function post(body){const c=cfg();if(!c.url)throw new Error('GAS の URL が未設定です');if(!c.pass)throw new Error('合言葉が未設定です');
  let r;try{r=await fetch(c.url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(Object.assign({pass:c.pass},body))});}catch(e){throw new Error('GAS に接続できません');}
  const j=await r.json();if(!j.ok)throw new Error(j.error==='auth'?'合言葉が違います':j.error==='busy'?'収集中です。少し待ってからもう一度':j.error||'失敗しました');return j;}
async function loadFeed(){const c=cfg();
  if(!st.feed){st.feed=lsGet(LS.cache,null)||(c.url?null:SAMPLE);}
  if(!c.url){st.feed=SAMPLE;render();return;}
  st.loading=true;st.err='';render();
  try{const j=await gasGet();j.fetchedAt=Date.now();st.feed=j;st.older=[];st.olderDone=false;lsSet(LS.cache,j);}
  catch(e){st.err=navigator.onLine===false?'オフラインです。前回取得した記事を表示しています':'取得できませんでした。設定の URL を確認してください';}
  if(!st.feed)st.feed={items:[],highlights:[],brain:[],trends:[],stats:[],sources:[]};
  st.loading=false;render();}
async function syncPrefs(){const c=cfg();if(!c.url||!c.pass)return;
  try{const j=await post({action:'prefs-get'});st.acct=j.email||'';setPrefs(Object.assign({},j.prefs,{synced:true}));render();}catch(e){}}
let prefTimer=null;
function pushPrefs(){const q=prefs();return post({action:'prefs-set',prefs:{watch:q.watch,muted:q.muted,email:q.email}}).then(j=>{setPrefs(Object.assign({},j.prefs,{synced:true}));return j;});}
function savePrefs(p){setPrefs(Object.assign({},p,{synced:false}));render();
  const c=cfg();if(!c.url||!c.pass)return;clearTimeout(prefTimer);
  prefTimer=setTimeout(()=>{pushPrefs().then(()=>{st.msg.prefs=null;if(st.view==='settings')render();}).catch(e=>{st.msg.prefs=[e.message,1];render();});},1200);}
let bmTimer=null;
function findItem(id){return allItems().find(x=>x.id===id)||(st.sr&&st.sr.items.find(x=>x.id===id));}
function toggleBm(id){const b=bmGet();if(b.items[id])delete b.items[id];else{const it=findItem(id);if(!it)return;b.items[id]=Object.assign({},it,{saved:Date.now()});}
  b.updated=Date.now();lsSet(LS.bm,b);render();
  const c=cfg();if(c.url&&c.pass){clearTimeout(bmTimer);bmTimer=setTimeout(()=>{post({action:'bm-save',items:bmGet().items}).then(j=>{const x=bmGet();x.updated=j.updated;lsSet(LS.bm,x);}).catch(()=>{});},2500);}}
async function syncBm(){const c=cfg();if(!c.url||!c.pass)return;try{const j=await post({action:'bm-load'});const local=bmGet();
  if((j.updated||0)>local.updated){lsSet(LS.bm,{updated:j.updated,items:j.items||{}});render();}
  else if(local.updated>(j.updated||0)&&Object.keys(local.items).length){const s=await post({action:'bm-save',items:local.items});local.updated=s.updated;lsSet(LS.bm,local);}}catch(e){}}
async function loadOlder(){if(st.olderBusy||!cfg().url||st.feed.sample)return;st.olderBusy=true;render();
  const list=filtered(allItems());const before=list.length?Math.min(...list.map(i=>i.d)):Date.now();
  try{const j=await gasGet({v:'more',before,type:st.type==='all'?'':st.type,cat:st.cat});const have=new Set(allItems().map(i=>i.id));
    const add=j.items.filter(i=>!have.has(i.id));st.older=st.older.concat(add);if(!add.length)st.olderDone=true;st.limit=heads(filtered(allItems())).length;}
  catch(e){st.err='古い記事を読み込めませんでした';}
  st.olderBusy=false;render();}
async function searchArchive(){const q=st.q.trim();if(!q||!cfg().url||st.feed.sample)return;st.sr={q,items:[],loading:true};render();
  try{const j=await gasGet({v:'search',q,type:st.type==='all'?'':st.type,cat:st.cat});st.sr={q,items:j.items,more:j.more};}
  catch(e){st.sr={q,items:[],err:'検索できませんでした'};}render();}

/* ---------- selection ---------- */
function feedItems(){return st.feed?st.feed.items||[]:[];}
function allItems(){return feedItems().concat(st.older);}
function byId(){const m={};allItems().forEach(i=>m[i.id]=i);return m;}
function matchQ(it,q){if(!q)return true;const hay=(it.t+' '+(it.x||'')+' '+it.s).toLowerCase();return q.toLowerCase().split(/\s+/).filter(Boolean).every(w=>hay.includes(w));}
function filtered(list){return list.filter(it=>(st.type==='all'||it.ty===st.type)&&(!st.cat||(it.g||[]).includes(st.cat))&&matchQ(it,st.q));}
function heads(list){return cfg().group?list.filter(i=>!i.c):list;}
function children(id){return allItems().filter(i=>i.c===id).sort((a,b)=>a.d-b.d);}

/* ---------- view pieces ---------- */
const ICON={refresh:'<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
  search:'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>',
  bm:'<svg viewBox="0 0 24 24"><path d="M6.5 3.5h11v17l-5.5-4-5.5 4z"/></svg>'};
function trace(){let d='M0 11';for(let x=2;x<=240;x+=2){const y=11+Math.sin(x*0.26)*3.2+Math.sin(x*0.07)*2+(x%46===0?-7:0)+(x%46===2?6:0);d+=` L${x} ${y.toFixed(1)}`;}
  return `<svg class="trace" viewBox="0 0 240 22" preserveAspectRatio="none" aria-hidden="true"><path d="${d}"/></svg>`;}
function hl(s){s=esc(s);if(!wre)return s;try{return s.replace(new RegExp('('+wre.source+')','gi'),'<mark>$1</mark>');}catch(e){return s;}}
function itemHtml(it,o){o=o||{};const c=cfg();
  const tags=(it.g||[]).slice(0,3).map(g=>CATN[g]?`<span class="tag" style="--c:var(--${g})">${CATN[g]}</span>`:'').join('');
  const saved=!!bmGet().items[it.id],ja=it.l==='ja',w=isWatch(it);
  const img=c.img&&it.im?`<img class="thumb" src="${esc(it.im)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">`:'';
  const cov=it.n>1&&c.group?`<button class="more-cov" data-open="${esc(it.id)}">${st.open[it.id]?'閉じる':`ほか ${it.n-1} 件の報道`}</button>`:'';
  const kids=st.open[it.id]?`<ul class="cluster">${children(it.id).map(k=>`<li><a href="${esc(k.u)}" target="_blank" rel="noopener" data-read="${esc(k.id)}"><b>${esc(k.s)}</b>${esc(k.t)}</a></li>`).join('')}</ul>`:'';
  const isNew=st.seenAt&&it.f>st.seenAt&&!readSet.has(it.id);
  return `<article class="${readSet.has(it.id)?'read':''} ${o.lead?'lead':''}">
    <div class="meta">${isNew?'<i class="newdot" title="前回から"></i>':''}<span class="src">${esc(it.s)}</span><span class="time">${ago(it.d)}</span>${it.ty!=='news'&&TYPEN[it.ty]?`<span class="kind ${it.ty}">${TYPEN[it.ty]}</span>`:''}${w?'<span class="watch">ウォッチ</span>':''}${st.feed&&st.feed.sample?'<span class="sample">表示例</span>':''}${cov}</div>
    <div class="body"><a class="ttl ${ja?'ja':''}" href="${esc(it.u||'#')}" target="_blank" rel="noopener" data-read="${esc(it.id)}">${w?hl(it.t):esc(it.t)}</a>
      ${it.x&&!o.compact?`<div class="snip">${esc(it.x)}</div>`:''}${tags?`<div class="tags">${tags}</div>`:''}</div>
    <div class="side">${img}<button class="bm ${saved?'on':''}" data-bm="${esc(it.id)}" aria-label="${saved?'しおりを外す':'しおりを付ける'}">${ICON.bm}</button></div>${kids}</article>`;}
function listHtml(items,emptyText){if(!items.length)return `<p class="empty">${emptyText||'記事はまだありません'}</p>`;
  let h='',last='';for(const it of items){const k=dayKey(it.d);if(k!==last){last=k;const [a,b]=dayLabel(it.d);h+=`<div class="day"><b>${a}</b>${b}</div>`;}h+=itemHtml(it);}return h;}
function setupPanel(){return `<section class="panel"><h3>取得先を設定する</h3><ol>
  <li>ニュース用の GAS プロジェクトに gas/news/Code.gs を貼り、setup を一度実行</li><li>ウェブアプリとしてデプロイし、URL をコピー</li><li>「設定」に URL と合言葉を入れる</li></ol>
  <div class="row"><button class="btn primary" data-view="settings">設定を開く</button></div></section>`;}
const errHtml=()=>st.err?`<p class="msg bad">${esc(st.err)}</p>`:'';

/* ---------- 今日 ---------- */
function todayView(){const c=cfg(),f=st.feed||{items:[]},m=byId(),now=Date.now();
  const d24=feedItems().filter(i=>i.d>=now-24*H);
  const tc={};d24.forEach(i=>tc[i.ty]=(tc[i.ty]||0)+1);
  const brainN=d24.filter(i=>(i.g||[]).includes('brain')).length;
  const pick=ids=>(ids||[]).map(id=>m[id]).filter(Boolean);
  const watch=wre?heads(feedItems()).filter(isWatch).sort((a,b)=>b.d-a.d).slice(0,8):[];
  const wid=new Set(watch.map(i=>i.id));
  const brain=pick(f.brain).filter(i=>!wid.has(i.id)),hi=pick(f.highlights).filter(i=>!wid.has(i.id));
  const t=new Date(),w='日月火水木金土'[t.getDay()];
  const sec=(title,sub,col,list,lead)=>list.length?`<h2 class="sec" style="--c:${col}">${title}${sub?`<small>${sub}</small>`:''}</h2>${list.map((it,i)=>itemHtml(it,{lead:lead&&i===0,compact:!(lead&&i===0)})).join('')}`:'';
  return `<div class="g">${!c.url?setupPanel():''}${errHtml()}
    <div class="today-head"><div class="date">${t.getMonth()+1}月${t.getDate()}日（${w}）</div>
      <div class="big"><b>${d24.length}</b><span>件　過去24時間の新着　うち脳・神経 ${brainN} 件</span></div>
      <div class="tcount">${TYPES.slice(1).map(([k,n])=>`<button data-jump="${k}">${n}<b>${tc[k]||0}</b></button>`).join('')}</div></div>
    ${sec('ウォッチ','設定したキーワードを含む記事','var(--gold)',watch,false)}
    ${sec('脳・神経','この3日間で大きいもの','var(--brain)',brain,true)}
    ${sec('注目','36時間以内・分野ごとに上位','var(--ink)',hi,false)}
    ${!brain.length&&!hi.length&&!watch.length?'<p class="empty">まだ記事がありません</p>':''}
    <div class="row" style="justify-content:center;margin-top:22px"><button class="btn" data-view="feed">新着をすべて見る</button></div></div>`;}

/* ---------- 新着 ---------- */
function feedView(){const c=cfg();
  if(st.sr)return searchView();
  const base=allItems();
  const count=(ty,cat)=>heads(base.filter(it=>(ty==='all'||it.ty===ty)&&(!cat||(it.g||[]).includes(cat))&&matchQ(it,st.q))).length;
  const shown=heads(filtered(base)).sort((a,b)=>b.d-a.d);
  const canOlder=c.url&&st.feed&&!st.feed.sample&&!st.olderDone;
  return `<div class="g">
    ${st.search?`<div class="search"><input id="q" type="search" placeholder="キーワード（英語・日本語）" value="${esc(st.q)}" autocomplete="off" enterkeyhint="search"></div>
      ${st.q.trim()&&c.url?`<div class="sr-note"><span>読み込み済みの記事から ${shown.length} 件</span><button class="linkbtn" data-act="archive">過去1年分から探す</button></div>`:''}`:''}
    <div class="seg">${TYPES.map(([k,n])=>`<button class="segb ${st.type===k?'on':''}" data-type="${k}">${n}<b>${count(k,st.cat)}</b></button>`).join('')}</div>
    <div class="chips"><button class="chip ${!st.cat?'on':''}" data-cat="">全分野<b>${count(st.type,'')}</b></button>${CATS.map(([k,n])=>`<button class="chip ${st.cat===k?'on':''}" style="--c:var(--${k})" data-cat="${k}"><i></i>${n}<b>${count(st.type,k)}</b></button>`).join('')}</div>
    ${!c.url?setupPanel():''}${errHtml()}
    ${listHtml(shown.slice(0,st.limit),st.q?'見つかりませんでした':'該当する記事はありません')}
    ${shown.length>st.limit?`<button class="btn morebtn" data-more="1">さらに表示（残り ${shown.length-st.limit} 件）</button>`:
      canOlder?`<button class="btn morebtn" data-act="older" ${st.olderBusy?'disabled':''}>${st.olderBusy?'読み込み中…':'さらに前の記事を読み込む'}</button>`:''}</div>`;}
function searchView(){const s=st.sr,list=cfg().group?s.items.filter(i=>!i.c):s.items;
  return `<div class="g"><div class="search"><input id="q" type="search" value="${esc(st.q)}" autocomplete="off" enterkeyhint="search"></div>
    <div class="sr-note"><span>${s.loading?'検索しています…':s.err?esc(s.err):`過去1年分から「${esc(s.q)}」 ${list.length}${s.more?'+':''} 件${st.type!=='all'?'・'+TYPEN[st.type]:''}${st.cat?'・'+CATN[st.cat]:''}`}</span><button class="linkbtn" data-act="sr-close">検索を閉じる</button></div>
    <div class="seg">${TYPES.map(([k,n])=>`<button class="segb ${st.type===k?'on':''}" data-type="${k}">${n}</button>`).join('')}</div>
    ${s.loading?'':listHtml(list,'見つかりませんでした')}</div>`;}
function savedView(){const items=Object.values(bmGet().items).sort((a,b)=>(b.saved||0)-(a.saved||0));
  return `<div class="g">${items.length?listHtml(items):'<p class="empty">しおりを付けた記事がここに並びます</p>'}</div>`;}

/* ---------- 傾向 ---------- */
function barChart(stats){const W=640,Hh=150,pl=28,pb=20,pt=8,n=stats.length,max=Math.max(4,...stats.map(s=>s.total));
  const step=Math.pow(10,Math.floor(Math.log10(max)));const tick=[1,2,5,10].map(m=>m*step).find(t=>max/t<=4)||step;
  const top=Math.ceil(max/tick)*tick,y=v=>pt+(Hh-pt-pb)*(1-v/top),bw=(W-pl)/n;
  let g='';for(let v=0;v<=top;v+=tick)g+=`<line class="grid" x1="${pl}" x2="${W}" y1="${y(v)}" y2="${y(v)}"/><text class="ax" x="${pl-6}" y="${y(v)+4}" text-anchor="end">${v}</text>`;
  let b='';stats.forEach((s,i)=>{const x=pl+i*bw+1,w=Math.max(2,bw-2),h=Math.max(0,y(0)-y(s.total)),r=Math.min(4,w/2,h),yy=y(s.total);
    if(h>0)b+=`<path d="M${x.toFixed(1)} ${y(0)}V${(yy+r).toFixed(1)}q0 ${-r} ${r} ${-r}h${(w-2*r).toFixed(1)}q${r} 0 ${r} ${r}V${y(0)}z" fill="var(--brain)"/>`;
    b+=`<rect x="${(pl+i*bw).toFixed(1)}" y="${pt}" width="${bw.toFixed(1)}" height="${Hh-pt-pb}" fill="transparent" data-tip="${+s.day.slice(5,7)}/${+s.day.slice(8)}" data-v="${s.total}"/>`;});
  let ax='';stats.forEach((s,i)=>{if((n-1-i)%7===0)ax+=`<text class="ax" x="${(pl+i*bw+bw/2).toFixed(1)}" y="${Hh-4}" text-anchor="middle">${+s.day.slice(5,7)}/${+s.day.slice(8)}</text>`;});
  return `<div class="chart" data-chart="1"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="30日間の1日あたり件数">${g}${b}${ax}</svg><div class="tip"></div></div>`;}
function spark(vals){const W=120,Hh=34,max=Math.max(1,...vals),n=vals.length;
  return `<svg viewBox="0 0 ${W} ${Hh}" preserveAspectRatio="none" aria-hidden="true"><path d="${vals.map((v,i)=>(i?'L':'M')+(i*(W-4)/(n-1)+2).toFixed(1)+' '+(Hh-3-(Hh-6)*v/max).toFixed(1)).join(' ')}" vector-effect="non-scaling-stroke"/></svg>`;}
function trendsView(){const f=st.feed||{},stats=f.stats||[],terms=f.trends||[];
  if(!stats.length)return `<div class="g">${!cfg().url?setupPanel():''}<p class="empty">収集が進むと、分野ごとの件数の推移と、増えている言葉がここに出ます</p></div>`;
  const sum=(a,b,fn)=>stats.slice(a,b).reduce((s,d)=>s+fn(d),0);
  const cells=CATS.map(([k,n])=>{const vals=stats.map(d=>d.cats[k]||0),w1=sum(23,30,d=>d.cats[k]||0),w0=sum(16,23,d=>d.cats[k]||0),diff=w1-w0;
    return `<button class="mcell" style="--c:var(--${k})" data-gocat="${k}"><div class="nm"><i></i>${n}</div><div class="v"><b>${w1}</b><span>直近7日・前週${diff>=0?'+':''}${diff}</span></div>${spark(vals)}</button>`;}).join('');
  const tsum=TYPES.slice(1).map(([k,n])=>[n,sum(0,30,d=>d.types[k]||0),sum(23,30,d=>d.types[k]||0)]);
  const srcs=f.sources||[],okN=srcs.filter(s=>s.ok).length;
  return `<div class="g">
    <h2 class="sec">1日あたりの件数<small>30日間・すべての種類</small></h2>${barChart(stats)}
    <details class="tvw"><summary>種類別の件数を表で見る</summary><table class="tv"><tr><th>種類</th><th>30日</th><th>7日</th></tr>${tsum.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('')}</table></details>
    <h2 class="sec" style="--c:var(--brain)">分野ごと<small>線は30日間の推移・押すと新着を絞り込み</small></h2><div class="mult">${cells}</div>
    <h2 class="sec" style="--c:var(--gold)">増えている言葉<small>直近3日の見出し・それ以前と比べた倍率</small></h2>
    ${terms.length?`<ul class="terms">${terms.map(t=>`<li><button data-term="${esc(t.term)}"><span class="w">${esc(t.term)}</span><span class="n">${t.n}件</span><span class="r">×${t.rise}</span></button></li>`).join('')}</ul>`:'<p class="msg">まだ十分な記事がありません</p>'}
    <p class="msg">収集元 ${srcs.length} か所のうち ${okN} か所から取得できています（詳しくは設定）</p></div>`;}

/* ---------- 設定 ---------- */
function settingsView(){const c=cfg(),p=prefs(),f=st.feed||{},srcs=f.sources||[];
  const msg=k=>st.msg[k]?`<p class="msg ${st.msg[k][1]?'bad':''}">${esc(st.msg[k][0])}</p>`:'';
  const hours=Array.from({length:24},(_,h)=>`<option value="${h}" ${+p.email.hour===h?'selected':''}>${h}時</option>`).join('');
  const maxes=[10,15,20,30].map(n=>`<option value="${n}" ${+p.email.max===n?'selected':''}>${n}件ほど</option>`).join('');
  const needPass=!c.url||!c.pass?'<p class="note">GAS の URL と合言葉を入れると、ここの設定が GAS に保存され、メールにも反映されます。</p>':'';
  const groups=TYPES.slice(1).map(([k,n])=>{const list=srcs.filter(s=>s.type===k);if(!list.length)return'';
    return `<div class="src-group">${n}</div><table class="src-list">${list.map(s=>{const off=p.muted.includes(s.id);
      return `<tr class="${off?'off':''}"><td class="c"><input type="checkbox" data-mute="${esc(s.id)}" ${off?'':'checked'} aria-label="${esc(s.name)} を収集する"></td><td>${esc(s.name)}</td><td class="r ${off?'':s.ok?'ok':'ng'}">${off?'停止中':s.ok?(s.at?'+'+s.n:'—'):esc(s.error||'失敗')}</td></tr>`;}).join('')}</table>`;}).join('');
  return `<div class="g">
  <section class="panel"><h3>取得先</h3>
    <label class="lbl" for="s_url">ニュース用 GAS のウェブアプリ URL</label><input id="s_url" class="inp" data-cfg="url" inputmode="url" autocomplete="off" placeholder="https://script.google.com/macros/s/…/exec" value="${esc(c.url)}">
    <label class="lbl" for="s_pass">合言葉</label><input id="s_pass" class="inp" type="password" data-cfg="pass" autocomplete="off" value="${esc(c.pass)}">
    <p class="note">合言葉は、キーワード・メール設定・しおりの同期と、手動の収集に使います。</p>
    <div class="row"><button class="btn primary" data-act="reload" ${st.busy?'disabled':''}>保存して読み込む</button></div>${msg('conn')}</section>
  <section class="panel"><h3>ウォッチするキーワード</h3>
    <p class="note">見出しや要約にこの言葉を含む記事は「今日」の先頭と、朝のメールの最上段に出ます。英語でも日本語でも。</p>
    <div class="wlist">${p.watch.map((w,i)=>`<span class="wtag">${esc(w)}<button data-unwatch="${i}" aria-label="${esc(w)} を外す">×</button></span>`).join('')||'<span class="msg" style="margin:0">まだありません（例：Neuralink、EEG、東京農工大学、photoacoustic）</span>'}</div>
    <div class="addrow"><input id="w_add" class="inp" placeholder="キーワードを追加（、で区切って複数）" autocomplete="off" enterkeyhint="done"><button class="btn" data-act="watch-add">追加</button></div>
    ${needPass}${msg('prefs')}</section>
  <section class="panel"><h3>朝のまとめメール</h3>
    <label class="chk"><input type="checkbox" data-email="on" ${p.email.on?'checked':''}> 毎朝メールで受け取る</label>
    <div class="two"><div><label class="lbl" for="e_hour">届く時刻</label><select id="e_hour" class="inp" data-email="hour">${hours}</select></div>
      <div><label class="lbl" for="e_max">注目ニュースの数</label><select id="e_max" class="inp" data-email="max">${maxes}</select></div></div>
    <label class="lbl" for="e_to">送信先（空なら GAS の Google アカウント${st.acct?'：'+esc(st.acct):''}）</label><input id="e_to" class="inp" type="email" data-email="to" autocomplete="off" value="${esc(p.email.to)}">
    <p class="note">前回のメール以降に届いた分を、ウォッチ・脳・神経・注目・承認・論文・企業・大学・臨床試験の順にまとめます。届く時刻は1時間ほど幅があります。</p>
    <div class="row"><button class="btn" data-act="digest-test" ${st.busy?'disabled':''}>いまテストメールを送る</button></div>${needPass}${msg('mail')}</section>
  <section class="panel"><h3>表示</h3>
    <label class="chk"><input type="checkbox" data-cfg="group" ${c.group?'checked':''}> 同じ話題の記事を1つにまとめる</label>
    <label class="chk"><input type="checkbox" data-cfg="img" ${c.img?'checked':''}> 記事の画像を表示する</label></section>
  <section class="panel"><h3>収集元</h3><p class="note">最終収集 ${fmtWhen(f.updated)}・1時間ごとに自動。チェックを外すと、その収集元から集めるのを止めます。</p>
    <div class="row"><button class="btn" data-act="collect" ${st.busy?'disabled':''}>${st.busy==='collect'?'収集しています…':'今すぐ収集する'}</button></div>${msg('collect')}
    ${groups||'<p class="msg">まだ収集していません</p>'}</section></div>`;}

/* ---------- render ---------- */
function render(){const nSaved=Object.keys(bmGet().items).length;
  const body={today:todayView,feed:feedView,saved:savedView,trends:trendsView,settings:settingsView}[st.view]();
  const y=scrollY,ae=document.activeElement&&document.activeElement.id;
  app.innerHTML=`<header><div class="g"><div class="hd"><h1>医工学レーダー</h1>${trace()}
      <button class="iconbtn ${st.search?'on':''}" data-act="search" aria-label="検索">${ICON.search}</button><button class="iconbtn ${st.loading?'spin':''}" data-act="refresh" aria-label="再読み込み">${ICON.refresh}</button></div>
    <div class="tabs">${[['today','今日'],['feed','新着'],['saved','しおり'],['trends','傾向'],['settings','設定']].map(([k,n])=>`<button class="tab ${st.view===k?'on':''}" data-view="${k}">${n}${k==='saved'&&nSaved?`<span class="n">${nSaved}</span>`:''}</button>`).join('')}
      <span class="upd">${st.feed&&st.feed.updated?'更新 '+fmtWhen(st.feed.updated):''}</span></div></div></header>${body}`;
  scrollTo(0,y);if(ae){const el=document.getElementById(ae);if(el){el.focus({preventScroll:true});if(el.setSelectionRange&&/text|search|password/.test(el.type)){const n=el.value.length;try{el.setSelectionRange(n,n);}catch(e){}}}}}
function go(view,o){Object.assign(st,{view,limit:50,sr:null},o||{});render();scrollTo(0,0);}

/* ---------- events ---------- */
app.addEventListener('click',async e=>{const t=e.target.closest('[data-type],[data-cat],[data-bm],[data-view],[data-act],[data-more],[data-read],[data-open],[data-jump],[data-gocat],[data-term],[data-unwatch]');if(!t)return;
  const d=t.dataset;
  if(d.read){markRead(d.read);setTimeout(render,300);return;}
  if(d.type){st.type=d.type;st.limit=50;if(st.sr)searchArchive();else render();return;}
  if(d.cat!==undefined){st.cat=d.cat;st.limit=50;render();return;}
  if(d.bm){toggleBm(d.bm);return;}
  if(d.open){st.open[d.open]=!st.open[d.open];render();return;}
  if(d.jump){go('feed',{type:d.jump,cat:''});return;}
  if(d.gocat){go('feed',{type:'all',cat:d.gocat});return;}
  if(d.term){go('feed',{type:'all',cat:'',q:d.term,search:true});return;}
  if(d.view){st.msg={};go(d.view);return;}
  if(d.more){st.limit+=50;render();return;}
  if(d.unwatch!==undefined){const p=prefs();p.watch.splice(+d.unwatch,1);savePrefs(p);return;}
  const a=d.act;
  if(a==='search'){st.search=!st.search;if(!st.search){st.q='';st.sr=null;}if(st.search)st.view='feed';render();if(st.search)document.getElementById('q')?.focus();}
  else if(a==='refresh'){loadFeed();syncBm();syncPrefs();}
  else if(a==='older')loadOlder();
  else if(a==='archive')searchArchive();
  else if(a==='sr-close'){st.sr=null;render();}
  else if(a==='watch-add')addWatch();
  else if(a==='reload'){st.msg={};st.feed=null;await loadFeed();
    if(cfg().url&&cfg().pass){try{const j=await post({action:'prefs-get'});st.acct=j.email||'';setPrefs(Object.assign({},j.prefs,{synced:true}));st.msg.conn=['つながりました'];}catch(err){st.msg.conn=[err.message,1];}}
    else if(cfg().url)st.msg.conn=[st.err?st.err:'読み込みました（合言葉なし：読むだけ）',!!st.err];
    syncBm();render();}
  else if(a==='digest-test'){st.busy='mail';st.msg.mail=['送っています…'];render();
    try{await pushPrefs();const j=await post({action:'digest-test'});st.msg.mail=[`${j.to} に送りました（${j.count}件）`];}catch(err){st.msg.mail=[err.message,1];}
    st.busy='';render();}
  else if(a==='collect'){st.busy='collect';st.msg.collect=['収集しています（1〜4分）…'];render();
    try{const j=await post({action:'refresh'});st.msg.collect=[`新しい記事 ${j.added} 件${j.failed?`・取得できなかった収集元 ${j.failed} か所`:''}`];await loadFeed();}catch(err){st.msg.collect=[err.message,1];}
    st.busy='';render();}});
function addWatch(){const el=document.getElementById('w_add');const v=(el&&el.value||'').trim();if(!v)return;const p=prefs();
  v.split(/[,、，]/).map(s=>s.trim()).filter(Boolean).forEach(w=>{if(!p.watch.some(x=>x.toLowerCase()===w.toLowerCase()))p.watch.push(w);});
  p.watch=p.watch.slice(0,40);savePrefs(p);const el2=document.getElementById('w_add');if(el2){el2.value='';el2.focus();}}
app.addEventListener('keydown',e=>{if(e.key!=='Enter'||e.isComposing)return;
  if(e.target.id==='w_add'){e.preventDefault();addWatch();}
  else if(e.target.id==='q'&&st.q.trim()&&cfg().url&&!(st.feed&&st.feed.sample)){e.preventDefault();e.target.blur();searchArchive();}});
let qTimer=null;
app.addEventListener('input',e=>{if(e.target.id==='q'){st.q=e.target.value;st.limit=50;if(st.sr&&!st.q.trim())st.sr=null;clearTimeout(qTimer);qTimer=setTimeout(()=>{if(!st.sr)render();},150);}});
app.addEventListener('change',e=>{const t=e.target,d=t.dataset;
  if(d.cfg){setCfg(d.cfg,t.type==='checkbox'?t.checked:t.value.trim());if(t.type==='checkbox')render();return;}
  if(d.email){const p=prefs();p.email[d.email]=t.type==='checkbox'?t.checked:(d.email==='hour'||d.email==='max')?+t.value:t.value.trim();savePrefs(p);return;}
  if(d.mute){const p=prefs();p.muted=p.muted.filter(x=>x!==d.mute);if(!t.checked)p.muted.push(d.mute);savePrefs(p);}});
/* chart tooltip follows the pointer over the 30-day bars */
app.addEventListener('pointermove',e=>{const r=e.target.closest&&e.target.closest('[data-tip]'),ch=e.target.closest&&e.target.closest('[data-chart]');
  app.querySelectorAll('.tip').forEach(tp=>{if(!ch||!r||!ch.contains(tp)){tp.style.display='none';return;}
    const box=ch.getBoundingClientRect(),rb=r.getBoundingClientRect();tp.innerHTML=`${esc(r.dataset.tip)}<span>${esc(r.dataset.v)}件</span>`;
    tp.style.display='block';tp.style.left=Math.min(box.width-40,Math.max(40,rb.left-box.left+rb.width/2))+'px';tp.style.top=Math.max(24,e.clientY-box.top-10)+'px';});});
app.addEventListener('pointerleave',()=>app.querySelectorAll('.tip').forEach(tp=>tp.style.display='none'),true);
document.addEventListener('visibilitychange',()=>{if(document.hidden){setCfg('seen',Date.now());return;}
  if(st.feed&&!st.feed.sample&&Date.now()-(st.feed.fetchedAt||0)>15*60e3)loadFeed();});
addEventListener('pagehide',()=>setCfg('seen',Date.now()));

/* the dot marks items collected since the previous visit */
st.seenAt=cfg().seen;render();loadFeed();syncBm();syncPrefs();
if('serviceWorker' in navigator&&location.protocol.startsWith('http')){const had=!!navigator.serviceWorker.controller;navigator.serviceWorker.register('./sw.js').catch(()=>{});
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(had)location.reload();});}
