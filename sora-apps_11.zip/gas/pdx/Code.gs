/**
 * PDXRadar — everything about the Portland Trail Blazers in one place
 * (Google Apps Script web app; the PWA in /pdx/ reads from it).
 *
 * Data: ESPN (schedule, live scores, box scores, play-by-play with shot locations, roster, contracts, injuries,
 * standings, news), Basketball-Reference (franchise totals, advanced stats, once a day), Blazers news feeds and
 * Google News. League-wide ratings (offense / defense / pace / four factors) are computed here from every NBA box score.
 *
 *   GET  (no params)            app feed
 *   GET  ?v=player&id=<espn id> player page          GET ?v=game&id=<espn event id>  game page
 *   GET  ?v=live                current Blazers game GET ?v=leaders  franchise leaderboards
 *   GET  ?v=team                lineups, on/off, clutch, assist pairs, franchise history
 *   GET  ?v=read&id=<news id>   in-app reader        GET ?v=vapid / ?v=push-latest / ?v=brief-input
 *   POST {pass, action:'prefs-get'|'prefs-set'|'refresh'|'push-sub'|'push-unsub'|'push-test'}
 *   POST {key, action:'brief-save', brief:{...}}
 *
 * First time: set PASS_PHRASE, run setup() once, then Deploy > New deployment > Web app
 * (Execute as: Me / Who has access: Anyone).
 */
const PASS_PHRASE = 'ここを自分だけの合言葉に変える';
const APP_NAME = 'PDXRadar';
const DATA_FOLDER = 'pdx-radar-data';
const TEAM = { espn: '22', abbr: 'POR', br: 'POR', name: 'Trail Blazers' };
const ESPN = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba';
const SALARY_CAP = 164961000;                       // 2026-27 salary cap
const WIN_SHARE_VALUE = SALARY_CAP * 30 / 1230;     // ≈ $4.0M: league payroll at the cap ÷ all wins in a season
const MIN_SALARY = 1300000;
const TIME_BUDGET_MS = 240000;
const UA_DESKTOP = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36';

/* news sources (ESPN team news is added in code) */
const NEWS_SOURCES = [
  { id: 'gn-blazers', name: 'Google News: Trail Blazers', kind: 'gnews', q: '"Trail Blazers" OR "Blazers" Portland NBA' },
  { id: 'gn-moves', name: 'Google News: moves', kind: 'gnews', q: 'Blazers (trade OR signs OR waive OR extension OR contract OR "free agent" OR rumor)' },
  { id: 'gn-injury', name: 'Google News: injuries', kind: 'gnews', q: 'Blazers (injury OR injured OR "out for" OR questionable OR surgery OR "injury report")' },
  { id: 'blazersedge', name: "Blazer's Edge", kind: 'rss', url: 'https://www.blazersedge.com/rss/current.xml' },
  { id: 'hoopsrumors', name: 'Hoops Rumors', kind: 'rss', url: 'https://www.hoopsrumors.com/portland-trail-blazers/feed' },
  { id: 'ripcity', name: 'Rip City Project', kind: 'rss', url: 'https://ripcityproject.com/feed' },
  { id: 'hoopshype', name: 'HoopsHype', kind: 'rss', url: 'https://hoopshype.com/team/portland-trail-blazers/feed/' },
  { id: 'yahoo', name: 'Yahoo Sports', kind: 'rss', url: 'https://sports.yahoo.com/nba/teams/por/rss/' },
  { id: 'blazersland', name: 'Blazersland', kind: 'rss', url: 'https://www.blazersland.com/feed/' },
  { id: 'gn-remix', name: 'Google News: Rip City Remix', kind: 'gnews', q: '"Rip City Remix" OR (Blazers "two-way") OR (Blazers "G League")' }
];
const NEWS_CATS = [
  ['remix', /Rip City Remix|G League|G-League|\bassign(s|ed)? to\b|recall(s|ed)? from/i],
  ['move', /\btrade[sd]?\b|\bsigns?\b|\bsigned\b|\bwaive[sd]?\b|extension|contract|free agen|buyout|two-way|rumou?r|\bdeal\b|acquire|option|re-sign/i],
  ['injury', /injur|\bout\b.*(game|week|month|indefinitely)|questionable|doubtful|surgery|sprain|strain|ankle|knee|hamstring|concussion|return(s|ed)? (to|from)|injury report|day-to-day/i],
  ['off', /foundation|charity|community|interview|podcast|family|wedding|engaged|baby|fashion|music|album|camp\b|donat|hometown|\bwife\b|\bson\b|\bdaughter\b|birthday|documentary|book|faith|business|investment|sneaker|shoe deal|endorse/i],
  ['game', /\bvs\.?\b|\bbeat\b|\bloss\b|\bwin\b|\bfall\b|preview|recap|takeaways|observations|score|halftime|overtime|game \d|\d{2,3}-\d{2,3}/i]
];

/* ========== setup / triggers ========== */
function setup() {
  if (!PASS_PHRASE || PASS_PHRASE.indexOf('ここを') === 0) throw new Error('PASS_PHRASE を書き換えてから実行してください');
  PropertiesService.getScriptProperties().setProperty('PASS', PASS_PHRASE);
  dataFolder_(); briefKey_(); vapid_();
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'tick') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('tick').timeBased().everyMinutes(10).create();
  const r = tick(true);
  Logger.log('準備完了: ' + JSON.stringify(r) + '（過去の試合は10分ごとに少しずつ取り込みます）');
}
/* every 10 minutes: live game, finished games, then hourly / daily work as it comes due */
function tick(force) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(3000)) return { busy: true };
  const t0 = Date.now(), log = {};
  try {
    const st = readJson_('state.json', { hourly: 0, daily: 0, doneDates: {}, porDone: {}, leagueDone: {}, live: null, status: {} });
    const now = Date.now(), due = function (k, ms) { return force === true || !st[k] || now - st[k] > ms; };
    if (due('hourly', 55 * 6e4)) { safe_(st, 'schedule', function () { log.schedule = updateSchedule_(st); }); safe_(st, 'roster', function () { log.roster = updateRoster_(st); });
      safe_(st, 'standings', function () { log.standings = updateStandings_(); }); safe_(st, 'news', function () { log.news = updateNews_(st); });
      safe_(st, 'opponent', function () { log.opponent = updateOpponent_(); }); st.hourly = now; }
    safe_(st, 'live', function () { log.live = updateLive_(st); });
    safe_(st, 'league', function () { log.league = updateLeague_(st, t0); });
    if (due('daily', 20 * 36e5) && Date.now() - t0 < 150000) { safe_(st, 'bbref', function () { log.br = updateBbref_(); }); safe_(st, 'values', function () { log.values = snapshotValues_(); }); st.daily = now; }
    safe_(st, 'leaders', function () { log.leaders = updateLeaders_(st); });
    st.updated = now;
    writeJson_('state.json', st);
    buildFeed_(st);
    log.ms = Date.now() - t0;
    return log;
  } finally { lock.releaseLock(); }
}
function safe_(st, key, fn) {
  try { fn(); st.status[key] = { ok: true, at: Date.now() }; }
  catch (e) { st.status[key] = { ok: false, at: Date.now(), error: errText(e).slice(0, 140) }; Logger.log(key + ': ' + e); }
}
function espn_(path) {
  const r = UrlFetchApp.fetch(path.indexOf('http') === 0 ? path : ESPN + path, { muteHttpExceptions: true, headers: { 'User-Agent': UA_DESKTOP } });
  if (r.getResponseCode() >= 400) throw new Error('ESPN HTTP ' + r.getResponseCode());
  return JSON.parse(r.getContentText());
}
function etDate_(ms) { return Utilities.formatDate(new Date(ms), 'America/New_York', 'yyyyMMdd'); }

/* ========== schedule & live game ========== */
function updateSchedule_(st) {
  const j = espn_('/teams/' + TEAM.espn + '/schedule?seasontype=2');
  let games = scheduleFromEspn(j);
  try { const po = scheduleFromEspn(espn_('/teams/' + TEAM.espn + '/schedule?seasontype=3')); if (po.length) games = games.concat(po).sort(function (a, b) { return a.t - b.t; }); } catch (e) {}
  if (j.season && j.season.year) st.season = j.season.year;
  writeJson_('schedule.json', { at: Date.now(), season: st.season, games: games });
  return games.length;
}
function updateLive_(st) {
  const sched = readJson_('schedule.json', { games: [] }).games, now = Date.now();
  // the game that is on now, about to start, or just finished and not yet stored
  const g = sched.filter(function (x) { return (x.state === 'in') || (x.state === 'pre' && x.t - now < 40 * 6e4 && x.t - now > -5 * 36e5) || (x.state === 'post' && !st.porDone[x.id] && now - x.t < 3 * 864e5); })[0];
  if (!g) { if (st.live && now - (st.live.at || 0) > 6 * 36e5) st.live = null; return 'idle'; }
  const sum = espn_('/summary?event=' + g.id), p = parseSummary(sum);
  const prev = st.live && st.live.id === g.id ? st.live.state : (g.state === 'pre' ? 'pre' : '');
  st.live = { id: g.id, state: p.status.state, detail: p.status.detail, at: now };
  cachePut_('live', JSON.stringify(liveView(p)));
  if (prev === 'pre' && p.status.state === 'in') notify_('start', startMessage(p));
  if (p.status.state === 'post' && p.status.completed && !st.porDone[g.id]) {
    const por = readJson_('por.json', { games: [], players: {}, shots: {} });
    const before = leaderRanksSnapshot_();
    ingestPorGame(p, por);
    writeJson_('por.json', por);
    writeJson_('game_' + g.id + '.json', gameView(p));
    st.porDone[g.id] = 1;
    // the league table counts this game too
    if (!st.leagueDone[g.id]) { const L = readJson_('league.json', newLeague()); ingestLeagueGame(p, L); st.leagueDone[g.id] = 1; recomputeLeague(L, etDate_(p.date)); writeJson_('league.json', L); }
    g.state = 'post';
    notify_('final', finalMessage(p, por));
    st.pendingMilestones = before;   // compared after leaders are recomputed in this tick
  }
  return p.status.state;
}

/* ========== league-wide ratings from every box score ========== */
function updateLeague_(st, t0) {
  const sched = readJson_('schedule.json', { games: [] }).games;
  if (!sched.length) return 'no schedule';
  const first = sched.map(function (g) { return g.t; }).sort(function (a, b) { return a - b; })[0];
  const L = readJson_('league.json', newLeague());
  let fetched = 0, changed = false;
  const today = etDate_(Date.now());
  for (let t = first - 864e5; etDate_(t) <= today && Date.now() - t0 < 170000 && fetched < 14; t += 864e5) {
    const day = etDate_(t);
    if (st.doneDates[day]) continue;
    const sb = espn_('/scoreboard?dates=' + day);
    const evs = (sb.events || []).filter(function (e) { return e.season ? e.season.type === 2 || e.season.type === 3 : true; });
    let allDone = true, dayChanged = false;
    for (let i = 0; i < evs.length; i++) {
      const e = evs[i], fin = e.status && e.status.type && e.status.type.completed;
      if (!fin) { allDone = false; continue; }
      if (st.leagueDone[e.id]) continue;
      if (Date.now() - t0 > 170000 || fetched >= 14) { allDone = false; break; }
      const p = parseSummary(espn_('/summary?event=' + e.id)); fetched++;
      ingestLeagueGame(p, L); st.leagueDone[e.id] = 1; changed = true; dayChanged = true;
      if (p.teams.some(function (x) { return x.id === TEAM.espn; }) && !st.porDone[e.id]) {
        const por = readJson_('por.json', { games: [], players: {}, shots: {} });
        ingestPorGame(p, por); writeJson_('por.json', por); writeJson_('game_' + e.id + '.json', gameView(p)); st.porDone[e.id] = 1;
      }
    }
    if (allDone && day < today) st.doneDates[day] = 1;
    if (dayChanged) recomputeLeague(L, day);
  }
  if (changed) writeJson_('league.json', L);
  return { fetched: fetched, teams: Object.keys(L.teams).length };
}
function updateStandings_() {
  const j = espn_('https://site.api.espn.com/apis/v2/sports/basketball/nba/standings');
  const out = standingsFromEspn(j);
  writeJson_('standings.json', Object.assign({ at: Date.now() }, out));
  return (out.west || []).length + (out.east || []).length;
}

/* ========== next opponent: injuries (their roster, hourly while the game is within 4 days) ========== */
function updateOpponent_() {
  const now = Date.now(), next = readJson_('schedule.json', { games: [] }).games.filter(function (g) { return g.state !== 'post'; })[0];
  if (!next || !next.opp || !next.opp.id || next.t - now > 4 * 864e5) return 'none';
  const list = rosterFromEspn(espn_('/teams/' + next.opp.id + '/roster'));
  writeJson_('opp.json', { id: next.opp.id, at: now, inj: list.filter(function (p) { return p.inj; }).map(function (p) { return { id: p.id, name: p.name, pos: p.pos, status: p.inj.status, detail: p.inj.detail, ret: p.inj.ret }; }) });
  return next.opp.abbr;
}

/* ========== roster, contracts, injuries ========== */
function updateRoster_(st) {
  const j = espn_('/teams/' + TEAM.espn + '/roster');
  const roster = rosterFromEspn(j);
  const old = readJson_('roster.json', { players: [] }).players;
  if (old.length) {
    const msgs = rosterChanges(old, roster);
    msgs.forEach(function (m) { notify_('moves', m); });
  }
  writeJson_('roster.json', { at: Date.now(), coach: rosterCoach(j), players: roster });
  return roster.length;
}

/* ========== Basketball-Reference: franchise totals and advanced stats (once a day) ========== */
function updateBbref_() {
  const season = readJson_('schedule.json', {}).season || (new Date().getMonth() >= 8 ? new Date().getFullYear() + 1 : new Date().getFullYear());
  const get = function (u) {
    const r = UrlFetchApp.fetch(u, { muteHttpExceptions: true, headers: { 'User-Agent': UA_DESKTOP } });
    if (r.getResponseCode() >= 400) throw new Error('Basketball-Reference HTTP ' + r.getResponseCode());
    return r.getContentText();
  };
  const franchise = brTableRows(get('https://www.basketball-reference.com/teams/' + TEAM.br + '/players.html'), /^(players|franchise_register|players_\w*)$/);
  Utilities.sleep(3500);
  const seasonHtml = get('https://www.basketball-reference.com/teams/' + TEAM.br + '/' + season + '.html');
  const adv = brTableRows(seasonHtml, /^advanced$/), per = brTableRows(seasonHtml, /^per_game(_stats)?$/);
  const totals = {}; franchise.forEach(function (r) { const n = r.player || r.name_display; if (n && r.pts !== '') totals[normName(n)] = brNumbers(r, n); });
  const seasonRows = {};
  per.forEach(function (r) { const n = r.player || r.name_display; if (n) seasonRows[normName(n)] = { name: n, g: +(r.g || r.games || 0) }; });
  adv.forEach(function (r) { const n = r.player || r.name_display; if (!n) return; const k = normName(n); seasonRows[k] = Object.assign(seasonRows[k] || { name: n, g: +(r.g || r.games || 0) }, { adv: brAdvanced(r) }); });
  if (!Object.keys(totals).length) throw new Error('Could not read the franchise totals table');
  // season-by-season franchise history (kept from the last good read if this one fails)
  let history = (readJson_('bbref.json', {}) || {}).history || [];
  try { Utilities.sleep(3500); const h = brHistory(brTableRows(get('https://www.basketball-reference.com/teams/' + TEAM.br + '/'), new RegExp('^' + TEAM.br + '$'), 'season')); if (h.length > 10) history = h; } catch (e) {}
  writeJson_('bbref.json', { at: Date.now(), season: season, totals: totals, season_: seasonRows, history: history });
  return { totals: Object.keys(totals).length, season: Object.keys(seasonRows).length };
}

/* ========== franchise leaderboards (Basketball-Reference totals + games played since) ========== */
function updateLeaders_(st) {
  const br = readJson_('bbref.json', null);
  if (!br) return 'no bbref';
  const por = readJson_('por.json', { games: [], players: {} }), roster = readJson_('roster.json', { players: [] }).players;
  const boards = buildLeaders(br, por, roster);
  const prev = readJson_('leaders.json', null);
  if (st.pendingMilestones && prev) milestoneMessages(st.pendingMilestones, boards).forEach(function (m) { notify_('records', m); });
  st.pendingMilestones = null;
  writeJson_('leaders.json', Object.assign({ at: Date.now(), brAt: br.at }, boards));
  return Object.keys(boards.cats).length;
}
function leaderRanksSnapshot_() { const l = readJson_('leaders.json', null); return l ? l.active : null; }

/* ========== market value (estimated from Win Shares) and contracts ========== */
function snapshotValues_() {
  const br = readJson_('bbref.json', null), roster = readJson_('roster.json', { players: [] }).players, por = readJson_('por.json', { games: [] });
  const vals = readJson_('values.json', { players: {} }), day = Utilities.formatDate(new Date(), 'Asia/Tokyo', 'yyyy-MM-dd');
  roster.forEach(function (p) {
    const s = br && br.season_ ? br.season_[normName(p.name)] : null;
    const v = marketValue(s && s.adv ? s.adv.ws : null, por.games.length, p);
    const h = vals.players[p.id] = vals.players[p.id] || [];
    const row = { d: day, ws: v.ws, v: v.value, s: p.contract ? p.contract.salary : null, t: p.contract ? p.contract.trade : null };
    if (h.length && h[h.length - 1].d === day) h[h.length - 1] = row; else h.push(row);
    if (h.length > 400) h.splice(0, h.length - 400);
  });
  writeJson_('values.json', vals);
  return roster.length;
}

/* ========== news ========== */
function updateNews_(st) {
  const idx = readJson_('news.json', { items: [] }), roster = readJson_('roster.json', { players: [] }).players;
  const seen = {}; idx.items.forEach(function (it) { seen[it.id] = 1; seen['t:' + normTitle(it.t)] = 1; });
  const now = Date.now(), fresh = [], status = st.newsStatus = st.newsStatus || {};
  const nameRe = rosterNameRegex(roster);
  const add = function (r, src) {
    const it = newsItem(r, src, now, nameRe, roster);
    if (!it || seen[it.id] || seen['t:' + normTitle(it.t)]) return 0;
    seen[it.id] = 1; seen['t:' + normTitle(it.t)] = 1; fresh.push(it); return 1;
  };
  // player queries for off-court and individual news, a few players per query
  const players = roster.map(function (p) { return '"' + p.name + '"'; });
  const srcs = NEWS_SOURCES.slice();
  for (let i = 0; i < players.length; i += 5) srcs.push({ id: 'gn-players-' + (i / 5), name: 'Google News: players ' + (i / 5 + 1), kind: 'gnews', q: '(' + players.slice(i, i + 5).join(' OR ') + ')' });
  const reqs = srcs.map(function (s) { return { url: s.kind === 'gnews' ? 'https://news.google.com/rss/search?q=' + encodeURIComponent(s.q + ' when:3d') + '&hl=en-US&gl=US&ceid=US:en' : s.url, muteHttpExceptions: true, headers: { 'User-Agent': UA_DESKTOP } }; });
  let res = [];
  try { res = UrlFetchApp.fetchAll(reqs); }
  catch (e) { res = reqs.map(function (q) { try { const u = q.url; delete q.url; return UrlFetchApp.fetch(u, q); } catch (err) { return { error: errText(err).replace(/: https?:\/\/\S+/, '').slice(0, 80) }; } }); }
  srcs.forEach(function (s, k) {
    try {
      if (res[k].error) { status[s.id] = { ok: false, error: res[k].error, name: s.name }; return; }
      const code = res[k].getResponseCode();
      if (code >= 400) { status[s.id] = { ok: false, error: 'HTTP ' + code, name: s.name }; return; }
      const raws = parseFeed(res[k].getContentText());
      let n = 0; raws.slice(0, 60).forEach(function (r) { n += add(r, s); });
      status[s.id] = { ok: true, n: n, name: s.name };
    } catch (e) { status[s.id] = { ok: false, error: errText(e).slice(0, 80), name: s.name }; }
  });
  try {
    const j = espn_('/news?team=' + TEAM.espn + '&limit=40'); let n = 0;
    (j.articles || []).forEach(function (a) { n += add({ title: a.headline, link: ((a.links || {}).web || {}).href || '', date: a.published, desc: a.description || '', source: 'ESPN', image: (a.images && a.images[0] && a.images[0].url) || '' }, { id: 'espn', name: 'ESPN', kind: 'espn' }); });
    status.espn = { ok: true, n: n, name: 'ESPN' };
  } catch (e) { status.espn = { ok: false, error: errText(e).slice(0, 80), name: 'ESPN' }; }
  const items = fresh.concat(idx.items).filter(function (it) { return it.d > now - 45 * 864e5; }).sort(function (a, b) { return b.d - a.d; }).slice(0, 1500);
  writeJson_('news.json', { at: now, items: items });
  // contract / trade news is pushed (a few per hour at most)
  fresh.filter(function (it) { return it.cat === 'move' && /official|signs|signed|traded|waive|extension|agree/i.test(it.t); }).slice(0, 2).forEach(function (it) { notify_('moves', { title: 'Roster move', body: it.t, url: './?n=' + it.id }); });
  return fresh.length;
}

/* ========== in-app reader ========== */
function readNews_(id) {
  const key = 'rd_' + id, hit = cacheGet_(key);
  if (hit) return JSON.parse(hit);
  const it = readJson_('news.json', { items: [] }).items.filter(function (x) { return x.id === id; })[0];
  if (!it) return { ok: false, error: 'not found' };
  let url = it.u, best = null, err = '';
  const better = function (a, u) { if (a && (!best || a.chars > best.chars)) { best = a; best.url = u; } };
  const get = function (u) { const r = UrlFetchApp.fetch(u, { muteHttpExceptions: true, followRedirects: true, headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' } }); if (r.getResponseCode() >= 400) throw new Error('HTTP ' + r.getResponseCode()); return decodeHtml_(r); };
  try {
    if (/news\.google\.com\/(rss\/)?articles\//.test(url)) { const g = resolveGn_(url, it); if (g.url) url = g.url; else err = 'Could not resolve the Google News link (' + g.err + ')'; }
    if (!/news\.google\.com/.test(url)) { const html = get(url), a = extractArticle(html, url); better(a, url);
      const amp = absUrl((html.match(/<link[^>]+rel=["']amphtml["'][^>]*>/i) || [''])[0].replace(/^.*href=["']([^"']+)["'].*$/i, '$1'), url);
      if (a.chars < 700 && amp) { try { better(extractArticle(get(amp), amp), url); } catch (e) {} } }
  } catch (e) { err = errText(e).slice(0, 100); }
  if ((!best || best.chars < 500)) {
    try { const r = UrlFetchApp.fetch('https://r.jina.ai/' + url, { muteHttpExceptions: true, headers: { 'X-Return-Format': 'markdown' } });
      if (r.getResponseCode() === 200) { const t = r.getContentText(), src = ((t.match(/^URL Source:\s*(\S+)/m) || [])[1] || url); better(jinaToArticle(t, src), src); } } catch (e) {}
  }
  const out = buildReaderResult({ id: it.id, u: url, s: it.s, ty: 'news', d: it.d, t: it.t, x: it.x }, best ? best.url : url, best, err);
  cachePut_(key, JSON.stringify(out));
  return out;
}

/* ========== notifications ========== */
const PUSH_TYPES = ['start', 'final', 'records', 'moves', 'brief'];
function notify_(type, msg) {
  if (!msg) return;
  const ev = readJson_('events.json', { list: [] });
  const e = { type: type, title: msg.title, body: msg.body, url: msg.url || './', at: Date.now(), tag: 'pdx-' + type };
  ev.list.unshift(e); ev.list = ev.list.slice(0, 60);
  writeJson_('events.json', ev);
  const subs = readJson_('subs.json', { list: [] });
  const keep = subs.list.filter(function (s) {
    if (s.types && s.types[type] === false) return true;
    try { const r = sendPush_(s); return !r.gone; } catch (err) { return true; }
  });
  if (keep.length !== subs.list.length) { subs.list = keep; writeJson_('subs.json', subs); }
}
function pushLatest_() {
  const e = readJson_('events.json', { list: [] }).list[0];
  return e ? { ok: true, title: e.title, body: e.body, url: e.url, tag: e.tag } : { ok: true, title: APP_NAME, body: 'New update', url: './', tag: 'pdx' };
}

/* ========== web endpoints ========== */
function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    switch (p.v) {
      case 'player': return json_(playerView_(String(p.id || '')));
      case 'game': return json_(readJson_('game_' + String(p.id || '').replace(/\D/g, '') + '.json', { ok: false, error: 'not found' }));
      case 'live': {
        if (p.fresh === '1') { const st = readJson_('state.json', {}); const id = (st.live && st.live.id) || p.id; if (id) { const v = liveView(parseSummary(espn_('/summary?event=' + String(id).replace(/\D/g, '')))); cachePut_('live', JSON.stringify(v)); return json_(v); } }
        const c = cacheGet_('live'); return c ? ContentService.createTextOutput(c).setMimeType(ContentService.MimeType.JSON) : json_({ ok: true, none: true });
      }
      case 'leaders': return json_(readJson_('leaders.json', { ok: false }));
      case 'team': return json_(teamPage(readJson_('por.json', { games: [], players: {} }), readJson_('roster.json', { players: [] }).players, readJson_('bbref.json', null)));
      case 'read': return json_(readNews_(String(p.id || '')));
      case 'vapid': return json_({ ok: true, key: vapid_().pub });
      case 'push-latest': return json_(pushLatest_());
      case 'brief-input': return json_(briefInput_());
    }
    let body = cacheGet_('feed');
    if (!body) { body = JSON.stringify(readJson_('feed.json', { ok: true, empty: true })); cachePut_('feed', body); }
    return ContentService.createTextOutput(body).setMimeType(ContentService.MimeType.JSON);
  } catch (err) { return json_({ ok: false, error: String(err && err.message || err) }); }
}
function doPost(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'bad request' }); }
  if (req.action === 'brief-save') {
    if (!req.key || req.key !== briefKey_()) return json_({ ok: false, error: 'auth' });
    const b = sanitizeBrief(req.brief);
    if (!b) return json_({ ok: false, error: 'bad brief' });
    writeJson_('brief.json', b);
    notify_('brief', { title: APP_NAME + ' morning brief', body: b.headline || (b.points[0] && b.points[0].text) || '', url: './' });
    const lock = LockService.getScriptLock(); if (lock.tryLock(15000)) { try { buildFeed_(readJson_('state.json', {})); } finally { lock.releaseLock(); } }
    return json_({ ok: true, at: b.at });
  }
  if (!checkPass_(req.pass)) return json_({ ok: false, error: 'auth' });
  try {
    switch (req.action) {
      case 'prefs-get': { const subs = readJson_('subs.json', { list: [] }).list, me = subs.filter(function (x) { return x.endpoint === req.endpoint; })[0];
        return json_({ ok: true, briefKey: briefKey_(), push: { devices: subs.length, registered: !!me, types: me ? me.types : null, tick: ScriptApp.getProjectTriggers().some(function (t) { return t.getHandlerFunction() === 'tick'; }) } }); }
      case 'refresh': { const r = tick(true); return json_(r.busy ? { ok: false, error: 'busy' } : Object.assign({ ok: true }, r)); }
      case 'push-sub': {
        if (!req.sub || !/^https:\/\//.test(req.sub.endpoint || '')) return json_({ ok: false, error: 'bad subscription' });
        const subs = readJson_('subs.json', { list: [] }), types = {};
        PUSH_TYPES.forEach(function (t) { types[t] = !(req.types && req.types[t] === false); });
        subs.list = subs.list.filter(function (x) { return x.endpoint !== req.sub.endpoint; }).concat([{ endpoint: req.sub.endpoint, types: types, label: String(req.label || '').slice(0, 30), at: Date.now() }]).slice(-10);
        writeJson_('subs.json', subs); return json_({ ok: true, count: subs.list.length });
      }
      case 'push-unsub': { const subs = readJson_('subs.json', { list: [] }); subs.list = subs.list.filter(function (x) { return x.endpoint !== req.endpoint; }); writeJson_('subs.json', subs); return json_({ ok: true }); }
      case 'push-test': {
        const s = readJson_('subs.json', { list: [] }).list.filter(function (x) { return x.endpoint === req.endpoint; })[0];
        if (!s) return json_({ ok: false, error: 'This device is not registered' });
        const ev = readJson_('events.json', { list: [] }); ev.list.unshift({ type: 'test', title: APP_NAME, body: 'Test notification', url: './', at: Date.now(), tag: 'pdx-test' }); writeJson_('events.json', ev);
        const r = sendPush_(s); return json_({ ok: r.ok, code: r.code, error: r.ok ? '' : 'The push service rejected it (' + r.code + ')' + (r.body ? ': ' + r.body : '') });
      }
      default: return json_({ ok: false, error: 'unknown action' });
    }
  } catch (err) { return json_({ ok: false, error: String(err && err.message || err) }); }
}

/* ========== views for the app ========== */
function buildFeed_(st) {
  const sched = readJson_('schedule.json', { games: [] }), por = readJson_('por.json', { games: [], players: {} }), L = readJson_('league.json', newLeague());
  const roster = readJson_('roster.json', { players: [] }), leaders = readJson_('leaders.json', null), standings = readJson_('standings.json', {}), br = readJson_('bbref.json', null);
  const news = readJson_('news.json', { items: [] }).items.slice(0, 120), brief = readJson_('brief.json', null), vals = readJson_('values.json', { players: {} });
  const feed = feedView(Date.now(), sched, por, L, roster, leaders, standings, br, news, brief, vals, st, readJson_('opp.json', null));
  writeJson_('feed.json', feed); cachePut_('feed', JSON.stringify(feed));
  return feed;
}
function playerView_(id) {
  const roster = readJson_('roster.json', { players: [] }).players, por = readJson_('por.json', { games: [], players: {}, shots: {} });
  const p = roster.filter(function (x) { return x.id === id; })[0] || (por.players[id] ? { id: id, name: por.players[id].name } : null);
  if (!p) return { ok: false, error: 'not found' };
  const br = readJson_('bbref.json', null), leaders = readJson_('leaders.json', null), L = readJson_('league.json', newLeague());
  const vals = readJson_('values.json', { players: {} }).players[id] || [], news = readJson_('news.json', { items: [] }).items;
  return playerPage(p, por, br, leaders, L, vals, news);
}
function briefInput_() {
  const f = readJson_('feed.json', {}), since = Date.now() - 30 * 36e5;
  return { ok: true, now: Date.now(), record: f.record, last: f.last, next: f.next, standing: f.standing, ranks: f.ranks, milestones: (f.milestones || []).slice(0, 8),
    injuries: (f.roster || []).filter(function (p) { return p.inj; }).map(function (p) { return { name: p.name, inj: p.inj }; }),
    news: (f.news || []).filter(function (n) { return n.d >= since; }).slice(0, 60).map(function (n) { return { t: n.t, s: n.s, cat: n.cat, u: n.u, who: n.who }; }) };
}
function briefKey_() {
  const props = PropertiesService.getScriptProperties();
  let k = props.getProperty('BRIEF_KEY');
  if (!k) { k = Utilities.getUuid().replace(/-/g, ''); props.setProperty('BRIEF_KEY', k); }
  return k;
}

/* ======================================================================
 * Pure functions (no Apps Script services) — also run in the tests.
 * ====================================================================== */
const NUM = function (v) { const n = parseFloat(String(v == null ? '' : v).replace(/,/g, '')); return isFinite(n) ? n : 0; };
const MADE = function (s) { const m = String(s || '').match(/(\d+)\s*-\s*(\d+)/); return m ? [+m[1], +m[2]] : [0, 0]; };
const r1 = function (x) { return Math.round(x * 10) / 10; };
function normName(n) {
  return String(n || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\*/g, '').replace(/\b(jr|sr|ii|iii|iv)\b\.?/g, '').replace(/[^a-z ]/g, '').replace(/\s+/g, ' ').trim();
}

/* ---------- ESPN: schedule ---------- */
function scheduleFromEspn(j) {
  return (j.events || []).map(function (e) {
    const c = (e.competitions || [])[0] || {}, cs = c.competitors || [];
    const me = cs.filter(function (x) { return String(x.team && x.team.id) === TEAM.espn || (x.team && x.team.abbreviation) === TEAM.abbr; })[0] || {};
    const op = cs.filter(function (x) { return x !== me; })[0] || { team: {} };
    const sc = function (x) { return x && x.score != null ? NUM(typeof x.score === 'object' ? (x.score.value != null ? x.score.value : x.score.displayValue) : x.score) : null; };
    const stt = ((c.status || e.status || {}).type) || {};
    const st = e.seasonType || (e.season && { type: e.season.type }) || {};
    return { id: String(e.id), t: Date.parse(e.date), home: me.homeAway === 'home', reg: (st.type || st.id || 2) == 2 || (st.type || st.id) == 3,
      opp: { id: String(op.team.id || ''), abbr: op.team.abbreviation || '', name: op.team.displayName || op.team.shortDisplayName || '', logo: op.team.logo || ((op.team.logos || [])[0] || {}).href || '' },
      state: stt.state || 'pre', completed: !!stt.completed, detail: stt.shortDetail || stt.detail || '',
      pf: sc(me), pa: sc(op), win: me.winner === true ? true : op.winner === true ? false : null,
      venue: ((c.venue || {}).fullName) || '', tv: ((c.broadcasts || [])[0] || {}).media ? c.broadcasts[0].media.shortName : '' };
  }).sort(function (a, b) { return a.t - b.t; });
}

/* ---------- ESPN: game summary ---------- */
const BOX_KEYS = { minutes: 'min', points: 'pts', rebounds: 'reb', assists: 'ast', turnovers: 'tov', steals: 'stl', blocks: 'blk', offensiveRebounds: 'oreb', defensiveRebounds: 'dreb', fouls: 'pf', plusMinus: 'pm' };
function parseSummary(j) {
  const comp = (((j.header || {}).competitions) || [])[0] || {}, stt = (comp.status || {}).type || {};
  const teams = (comp.competitors || []).map(function (c) {
    const t = c.team || {};
    return { id: String(t.id), abbr: t.abbreviation || '', name: t.displayName || '', logo: ((t.logos || [])[0] || {}).href || t.logo || '', home: c.homeAway === 'home', score: NUM(c.score), winner: !!c.winner, stats: {} };
  });
  const byId = {}; teams.forEach(function (t) { byId[t.id] = t; });
  (((j.boxscore || {}).teams) || []).forEach(function (bt) {
    const t = byId[String((bt.team || {}).id)]; if (!t) return;
    const s = {}; (bt.statistics || []).forEach(function (x) { s[x.name] = x.displayValue; });
    const fg = MADE(s['fieldGoalsMade-fieldGoalsAttempted']), tp = MADE(s['threePointFieldGoalsMade-threePointFieldGoalsAttempted']), ft = MADE(s['freeThrowsMade-freeThrowsAttempted']);
    t.stats = { fgm: fg[0], fga: fg[1], tpm: tp[0], tpa: tp[1], ftm: ft[0], fta: ft[1], oreb: NUM(s.offensiveRebounds), dreb: NUM(s.defensiveRebounds), reb: NUM(s.totalRebounds || s.rebounds),
      ast: NUM(s.assists), stl: NUM(s.steals), blk: NUM(s.blocks), tov: NUM(s.totalTurnovers != null ? s.totalTurnovers : s.turnovers), pf: NUM(s.fouls || s.personalFouls),
      paint: NUM(s.pointsInPaint), fast: NUM(s.fastBreakPoints), lead: NUM(s.largestLead) };
  });
  const players = {};
  (((j.boxscore || {}).players) || []).forEach(function (bp) {
    const tid = String((bp.team || {}).id), st0 = (bp.statistics || [])[0] || {}, keys = st0.keys || [];
    players[tid] = (st0.athletes || []).map(function (a) {
      const ath = a.athlete || {}, o = { id: String(ath.id), name: ath.displayName || '', short: ath.shortName || '', jersey: ath.jersey || '', pos: (ath.position || {}).abbreviation || '', head: (ath.headshot || {}).href || '',
        starter: !!a.starter, dnp: !!a.didNotPlay || !(a.stats && a.stats.length), reason: a.reason || '' };
      (a.stats || []).forEach(function (v, i) {
        const k = keys[i];
        if (k === 'fieldGoalsMade-fieldGoalsAttempted') { const m = MADE(v); o.fgm = m[0]; o.fga = m[1]; }
        else if (k === 'threePointFieldGoalsMade-threePointFieldGoalsAttempted') { const m = MADE(v); o.tpm = m[0]; o.tpa = m[1]; }
        else if (k === 'freeThrowsMade-freeThrowsAttempted') { const m = MADE(v); o.ftm = m[0]; o.fta = m[1]; }
        else if (BOX_KEYS[k]) o[BOX_KEYS[k]] = NUM(v);
      });
      return o;
    });
  });
  const plays = (j.plays || []).map(function (pl) {
    const c = pl.coordinate || {}, x = NUM(c.x), y = NUM(c.y), onCourt = c.x != null && x >= 0 && x <= 50 && y >= 0 && y <= 94;
    const pid = pl.participants && pl.participants[0] && pl.participants[0].athlete ? String(pl.participants[0].athlete.id) : '';
    const shot = !!pl.shootingPlay && !/free throw/i.test((pl.type || {}).text || pl.text || '');
    const pids = (pl.participants || []).map(function (q) { return q && q.athlete ? String(q.athlete.id) : ''; }).filter(function (q) { return q; });
    const typ = String((pl.type || {}).text || ''), clk = (pl.clock || {}).displayValue || '';
    return { per: (pl.period || {}).number || 0, clk: clk, sec: clockSec(clk), tid: String((pl.team || {}).id || ''), txt: String(pl.text || '').replace(/\s+/g, ' ').trim(), typ: typ,
      sc: !!pl.scoringPlay, sv: NUM(pl.scoreValue), hs: pl.homeScore == null ? null : NUM(pl.homeScore), as: pl.awayScore == null ? null : NUM(pl.awayScore), pid: pid, pids: pids, shot: shot && onCourt,
      fga: shot, fta: !!pl.shootingPlay && !shot,
      x: onCourt ? x : null, y: onCourt ? y : null, three: /three point|3-pt|3pt/i.test(pl.text || '') || (pl.scoreValue === 3 && shot), made: !!pl.scoringPlay };
  });
  return { id: String((j.header || {}).id || comp.id || ''), date: Date.parse(comp.date || ''), status: { state: stt.state || 'pre', completed: !!stt.completed, detail: stt.shortDetail || stt.detail || '', period: (comp.status || {}).period || 0, clock: (comp.status || {}).displayClock || '' },
    teams: teams, players: players, plays: plays, venue: ((((j.gameInfo || {}).venue) || {}).fullName) || '' };
}
function clockSec(c) { c = String(c || ''); if (c.indexOf(':') >= 0) { const a = c.split(':'); return NUM(a[0]) * 60 + NUM(a[1]); } return NUM(c); }
function periodLen(per) { return per <= 4 ? 720 : 300; }
function elapsedAt(per, sec) { return (per <= 4 ? (per - 1) * 720 : 2880 + (per - 5) * 300) + periodLen(per) - sec; }
function possOf(s) { return s ? s.fga - s.oreb + s.tov + 0.44 * s.fta : 0; }

/* shot zones on ESPN's half court (feet; basket at x=25, y≈4.75) */
const ZONES = [['RA', 'Restricted area'], ['PAINT', 'Paint'], ['MID_L', 'Mid-range left'], ['MID_C', 'Mid-range center'], ['MID_R', 'Mid-range right'], ['C3_L', 'Left corner 3'], ['C3_R', 'Right corner 3'], ['AB3_L', 'Left wing 3'], ['AB3_C', 'Top of key 3'], ['AB3_R', 'Right wing 3']];
function zoneOf(x, y, three) {
  const dx = x - 25, dy = y - 4.75, d = Math.sqrt(dx * dx + dy * dy), ang = Math.atan2(dx, dy) * 180 / Math.PI;
  if (three || d > 23.6) { if (y < 14) return dx < 0 ? 'C3_L' : 'C3_R'; return ang < -22 ? 'AB3_L' : ang > 22 ? 'AB3_R' : 'AB3_C'; }
  if (d < 4) return 'RA';
  if (Math.abs(dx) <= 8 && y <= 19) return 'PAINT';
  return ang < -30 ? 'MID_L' : ang > 30 ? 'MID_R' : 'MID_C';
}

/* ---------- Blazers games ---------- */
function ingestPorGame(p, por) {
  if (por.games.some(function (g) { return g.id === p.id; })) return false;
  const me = p.teams.filter(function (t) { return t.id === TEAM.espn; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.espn; })[0];
  if (!me || !op) return false;
  const poss = (possOf(me.stats) + possOf(op.stats)) / 2 || 1;
  const gi = por.games.length;
  por.games.push({ id: p.id, d: p.date, home: me.home, opp: op.abbr, oppName: op.name, oppLogo: op.logo, pf: me.score, pa: op.score, win: me.score > op.score,
    poss: r1(poss), ortg: r1(100 * me.score / poss), drtg: r1(100 * op.score / poss), s: me.stats, os: op.stats });
  (p.players[TEAM.espn] || []).forEach(function (pl) {
    const P = por.players[pl.id] = por.players[pl.id] || { name: pl.name, logs: [] };
    P.name = pl.name; P.jersey = pl.jersey; P.pos = pl.pos; P.head = pl.head || P.head;
    if (pl.dnp || !pl.min) { P.logs.push({ e: p.id, d: p.date, o: op.abbr, h: me.home, dnp: pl.reason || 'DNP' }); return; }
    P.logs.push({ e: p.id, d: p.date, o: op.abbr, h: me.home, w: me.score > op.score, st: pl.starter, min: pl.min, pts: pl.pts || 0, reb: pl.reb || 0, ast: pl.ast || 0, stl: pl.stl || 0, blk: pl.blk || 0, tov: pl.tov || 0,
      fgm: pl.fgm || 0, fga: pl.fga || 0, tpm: pl.tpm || 0, tpa: pl.tpa || 0, ftm: pl.ftm || 0, fta: pl.fta || 0, oreb: pl.oreb || 0, dreb: pl.dreb || 0, pf: pl.pf || 0, pm: pl.pm || 0 });
  });
  por.shots = por.shots || {};
  p.plays.forEach(function (pl) {
    if (!pl.shot || pl.tid !== TEAM.espn || !pl.pid) return;
    (por.shots[pl.pid] = por.shots[pl.pid] || []).push([pl.x, pl.y, pl.made ? 1 : 0, pl.three ? 1 : 0, gi]);
  });
  try { ingestPbp_(p, por, por.games[gi]); } catch (e) { por.games[gi].pbpErr = String(e && e.message || e).slice(0, 80); }
  return true;
}

/* ---------- play-by-play: lineups, on/off, clutch, assists, quarters ----------
 * Who is on the floor is rebuilt from substitutions ("X enters the game for Y"). ESPN does not list the five
 * players at the start of a quarter, so they are inferred: anyone who appears in the quarter before being
 * subbed in was already on the floor. Points come from score changes, so free throws and and-ones count. */
const SUB_RE = /^(.+?) enters the game for (.+?)\.?$/i, AST_RE = /\(([^()]+?) assists?\)/i;
function pbpAnalyze(p) {
  const me = p.teams.filter(function (t) { return t.id === TEAM.espn; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.espn; })[0];
  const box = (p.players[TEAM.espn] || []).filter(function (x) { return !x.dnp; });
  if (!me || !op || !box.length || p.plays.length < 60) return null;
  const mine = {}, byName = {}; box.forEach(function (x) { mine[x.id] = 1; byName[normName(x.name)] = x.id; if (x.short) byName[normName(x.short)] = byName[normName(x.short)] || x.id; });
  const idOf = function (name, fallback) { const k = byName[normName(name)]; return k || (fallback && mine[fallback] ? fallback : ''); };
  const subOf = function (ev) {
    const m = SUB_RE.exec(ev.txt); if (!m && !/substitution/i.test(ev.typ)) return null;
    const inn = m ? idOf(m[1], ev.pids[0]) : (mine[ev.pids[0]] ? ev.pids[0] : ''), out = m ? idOf(m[2], ev.pids[1]) : (mine[ev.pids[1]] ? ev.pids[1] : '');
    return inn && out ? { inn: inn, out: out } : null;
  };
  const pers = []; p.plays.forEach(function (ev) { if (ev.per >= 1) (pers[ev.per - 1] = pers[ev.per - 1] || []).push(ev); });
  const stints = {}, clutch = { sec: 0, pf: 0, pa: 0, players: {} }, assists = {}, quarters = [];
  let cur = box.filter(function (x) { return x.starter; }).map(function (x) { return x.id; }).slice(0, 5), hs = 0, as = 0, lastEnd = cur.slice();
  const myScore = function () { return me.home ? hs : as; }, opScore = function () { return me.home ? as : hs; };
  const stint = function () { const k = cur.slice().sort().join(','); return stints[k] = stints[k] || { sec: 0, pf: 0, pa: 0 }; };
  const cp = function (id) { return clutch.players[id] = clutch.players[id] || { pts: 0, fgm: 0, fga: 0, tpm: 0, tpa: 0, ftm: 0, fta: 0, ast: 0, sec: 0 }; };
  for (let pi = 0; pi < pers.length; pi++) {
    const evs = pers[pi] || [], per = pi + 1;
    if (per > 1) {   // infer who started this period
      const start = [], seenIn = {};
      for (let i = 0; i < evs.length && start.length < 5; i++) {
        const sb = subOf(evs[i]);
        if (sb) { if (!seenIn[sb.out] && start.indexOf(sb.out) < 0) start.push(sb.out); seenIn[sb.inn] = 1; continue; }
        evs[i].pids.forEach(function (id) { if (mine[id] && !seenIn[id] && start.indexOf(id) < 0 && start.length < 5) start.push(id); });
      }
      lastEnd.forEach(function (id) { if (start.length < 5 && start.indexOf(id) < 0 && !seenIn[id]) start.push(id); });
      cur = start.slice(0, 5);
    }
    const q0 = [myScore(), opScore()];
    let lastSec = periodLen(per);
    const clutchNow = function (sec) { return per >= 4 && sec <= 300 && Math.abs(myScore() - opScore()) <= 5; };
    const run = function (sec) {   // time passes from lastSec down to sec with the current five
      const dt = Math.max(0, lastSec - sec); if (!dt) return;
      if (cur.length === 5) stint().sec += dt;
      if (clutchNow(lastSec)) { clutch.sec += dt; cur.forEach(function (id) { cp(id).sec += dt; }); }
      lastSec = sec;
    };
    evs.forEach(function (ev) {
      run(ev.sec);
      const inClutch = clutchNow(ev.sec);
      if (ev.hs != null && ev.as != null && (ev.hs !== hs || ev.as !== as) && ev.hs >= hs && ev.as >= as) {
        const dm = (me.home ? ev.hs - hs : ev.as - as), dop = (me.home ? ev.as - as : ev.hs - hs);
        if (cur.length === 5) { const S = stint(); S.pf += dm; S.pa += dop; }
        if (inClutch) { clutch.pf += dm; clutch.pa += dop; }
        hs = ev.hs; as = ev.as;
      }
      if (ev.tid === TEAM.espn && mine[ev.pids[0]]) {
        const shooter = ev.pids[0];
        if (ev.fga && ev.made) {
          const am = AST_RE.exec(ev.txt), a = am ? idOf(am[1], ev.pids[1]) : (mine[ev.pids[1]] && ev.pids[1] !== shooter ? ev.pids[1] : '');
          if (a && a !== shooter) { const k = a + '>' + shooter; assists[k] = (assists[k] || 0) + 1; if (inClutch) cp(a).ast++; }
        }
        if (inClutch) {
          const c = cp(shooter);
          if (ev.fga) { c.fga++; if (ev.three) c.tpa++; if (ev.made) { c.fgm++; c.pts += ev.three ? 3 : 2; if (ev.three) c.tpm++; } }
          else if (ev.fta) { c.fta++; if (ev.made) { c.ftm++; c.pts++; } }
        }
      }
      const sb = ev.tid === TEAM.espn || !ev.tid ? subOf(ev) : null;
      if (sb) { const i = cur.indexOf(sb.out); if (i >= 0) cur[i] = sb.inn; else if (cur.indexOf(sb.inn) < 0 && cur.length < 5) cur.push(sb.inn); }
    });
    run(0);
    quarters.push([myScore() - q0[0], opScore() - q0[1]]);
    lastEnd = cur.slice();
  }
  const total = Object.keys(stints).reduce(function (s, k) { return s + stints[k].sec; }, 0);
  return { stints: stints, total: total, clutch: clutch, assists: assists, quarters: quarters };
}
function addRate_(o, sec, pf, pa, poss) { o.sec = (o.sec || 0) + sec; o.pf = (o.pf || 0) + pf; o.pa = (o.pa || 0) + pa; o.poss = (o.poss || 0) + poss; return o; }
function ingestPbp_(p, por, g) {
  const a = pbpAnalyze(p); if (!a || a.total < 1500) return false;
  const me = p.teams.filter(function (t) { return t.id === TEAM.espn; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.espn; })[0];
  const pps = ((possOf(me.stats) + possOf(op.stats)) / 2) / (a.total || 1);   // possessions per second of this game
  por.lineups = por.lineups || {}; por.onoff = por.onoff || {}; por.assists = por.assists || {};
  por.clutch = por.clutch || { g: 0, w: 0, l: 0, sec: 0, pf: 0, pa: 0, poss: 0, players: {} };
  const tot = { sec: 0, pf: 0, pa: 0 };
  Object.keys(a.stints).forEach(function (k) {
    const S = a.stints[k]; tot.sec += S.sec; tot.pf += S.pf; tot.pa += S.pa;
    const L = por.lineups[k] = por.lineups[k] || { g: 0, sec: 0, pf: 0, pa: 0, poss: 0, last: '' };
    addRate_(L, S.sec, S.pf, S.pa, S.sec * pps); if (L.last !== p.id) { L.g++; L.last = p.id; }
  });
  const ids = {}; Object.keys(a.stints).forEach(function (k) { k.split(',').forEach(function (id) { ids[id] = 1; }); });
  Object.keys(ids).forEach(function (id) {
    const on = { sec: 0, pf: 0, pa: 0 };
    Object.keys(a.stints).forEach(function (k) { if (k.split(',').indexOf(id) >= 0) { on.sec += a.stints[k].sec; on.pf += a.stints[k].pf; on.pa += a.stints[k].pa; } });
    const O = por.onoff[id] = por.onoff[id] || { on: {}, off: {}, g: 0 };
    addRate_(O.on, on.sec, on.pf, on.pa, on.sec * pps); addRate_(O.off, tot.sec - on.sec, tot.pf - on.pf, tot.pa - on.pa, (tot.sec - on.sec) * pps); O.g++;
  });
  Object.keys(a.assists).forEach(function (k) { por.assists[k] = (por.assists[k] || 0) + a.assists[k]; });
  if (a.clutch.sec > 0) {
    const C = por.clutch; C.g++; if (g.win) C.w++; else C.l++;
    addRate_(C, a.clutch.sec, a.clutch.pf, a.clutch.pa, a.clutch.sec * pps);
    Object.keys(a.clutch.players).forEach(function (id) { const s = a.clutch.players[id], P = C.players[id] = C.players[id] || {}; Object.keys(s).forEach(function (k) { P[k] = (P[k] || 0) + s[k]; }); });
  }
  g.q = a.quarters; g.clutch = a.clutch.sec > 0; g.pbp = 1;
  return true;
}
function newLeague() { return { teams: {}, zones: {}, hist: [], ranks: {}, games: 0, players: {} }; }
function ingestLeagueGame(p, L) {
  if (p.teams.length !== 2 || !p.status.completed) return false;
  const a = p.teams[0], b = p.teams[1], poss = (possOf(a.stats) + possOf(b.stats)) / 2;
  if (!poss) return false;
  [[a, b], [b, a]].forEach(function (pair) {
    const t = pair[0], o = pair[1], T = L.teams[t.id] = L.teams[t.id] || { abbr: t.abbr, name: t.name, logo: t.logo, g: 0, w: 0, l: 0, pts: 0, opp: 0, poss: 0, fga: 0, fgm: 0, tpm: 0, tpa: 0, fta: 0, ftm: 0, oreb: 0, dreb: 0, tov: 0, ofga: 0, ofgm: 0, otpm: 0, ofta: 0, ooreb: 0, odreb: 0, otov: 0 };
    T.abbr = t.abbr; T.name = t.name; T.logo = t.logo || T.logo;
    T.g++; if (t.score > o.score) T.w++; else T.l++;
    T.pts += t.score; T.opp += o.score; T.poss += poss;
    ['fga', 'fgm', 'tpm', 'tpa', 'fta', 'ftm', 'oreb', 'dreb', 'tov'].forEach(function (k) { T[k] += t.stats[k] || 0; });
    T.ofga += o.stats.fga || 0; T.ofgm += o.stats.fgm || 0; T.otpm += o.stats.tpm || 0; T.ofta += o.stats.fta || 0; T.ooreb += o.stats.oreb || 0; T.odreb += o.stats.dreb || 0; T.otov += o.stats.tov || 0;
    // recent results and per-player totals, for the opponent preview
    T.last = (T.last || []).concat([{ id: p.id, d: p.date, o: o.abbr, h: t.home, w: t.score > o.score, pf: t.score, pa: o.score }]).sort(function (x, y) { return x.d - y.d; }).slice(-10);
    L.players = L.players || {}; const PL = L.players[t.id] = L.players[t.id] || {};
    (p.players[t.id] || []).forEach(function (x) {
      if (x.dnp || !x.min) return;
      const q = PL[x.id] = PL[x.id] || { n: x.name, gp: 0, min: 0, pts: 0, reb: 0, ast: 0, head: x.head || '' };
      q.n = x.name; q.gp++; q.min += x.min || 0; q.pts += x.pts || 0; q.reb += x.reb || 0; q.ast += x.ast || 0;
    });
  });
  p.plays.forEach(function (pl) { if (!pl.shot) return; const z = zoneOf(pl.x, pl.y, pl.three), Z = L.zones[z] = L.zones[z] || [0, 0]; Z[1]++; if (pl.made) Z[0]++; });
  L.games++;
  return true;
}
const METRICS = [['ortg', 'Off rating', 1], ['drtg', 'Def rating', -1], ['net', 'Net rating', 1], ['pace', 'Pace', 1], ['efg', 'eFG%', 1], ['tovp', 'TOV%', -1], ['orbp', 'ORB%', 1], ['ftr', 'FT rate', 1], ['oefg', 'Opp eFG%', -1], ['ppg', 'Points', 1], ['oppg', 'Opp points', -1]];
function teamMetrics(T) {
  const g = T.g || 1, poss = T.poss || 1;
  return { ortg: r1(100 * T.pts / poss), drtg: r1(100 * T.opp / poss), net: r1(100 * (T.pts - T.opp) / poss), pace: r1(poss / g),
    efg: Math.round(1000 * (T.fgm + 0.5 * T.tpm) / (T.fga || 1)) / 10, tovp: Math.round(1000 * T.tov / poss) / 10, orbp: Math.round(1000 * T.oreb / ((T.oreb + T.odreb) || 1)) / 10,
    ftr: Math.round(1000 * T.ftm / (T.fga || 1)) / 10, oefg: Math.round(1000 * (T.ofgm + 0.5 * T.otpm) / (T.ofga || 1)) / 10, ppg: r1(T.pts / g), oppg: r1(T.opp / g) };
}
function recomputeLeague(L, day) {
  const ids = Object.keys(L.teams), m = {};
  ids.forEach(function (id) { m[id] = teamMetrics(L.teams[id]); });
  const ranks = {};
  METRICS.forEach(function (mt) {
    const k = mt[0], dir = mt[2];
    const sorted = ids.slice().sort(function (a, b) { return dir * (m[b][k] - m[a][k]); });
    sorted.forEach(function (id, i) { (ranks[id] = ranks[id] || {})[k] = i + 1; });
  });
  L.metrics = m; L.ranks = ranks;
  if (m[TEAM.espn]) {
    const d = day.slice(0, 4) + '-' + day.slice(4, 6) + '-' + day.slice(6, 8);
    const row = { d: d, g: L.teams[TEAM.espn].g, m: m[TEAM.espn], r: ranks[TEAM.espn] };
    if (L.hist.length && L.hist[L.hist.length - 1].d === d) L.hist[L.hist.length - 1] = row; else L.hist.push(row);
    L.hist.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
  }
}

/* ---------- live / game views and messages ---------- */
function teamLine(t) { return { id: t.id, abbr: t.abbr, name: t.name, logo: t.logo, home: t.home, score: t.score, s: t.stats }; }
function boxRows(list) { return (list || []).map(function (p) { return p.dnp ? { id: p.id, n: p.short || p.name, dnp: p.reason || 'DNP' } : { id: p.id, n: p.short || p.name, st: p.starter, min: p.min, pts: p.pts, reb: p.reb, ast: p.ast, stl: p.stl, blk: p.blk, tov: p.tov, fg: (p.fgm || 0) + '-' + (p.fga || 0), tp: (p.tpm || 0) + '-' + (p.tpa || 0), ft: (p.ftm || 0) + '-' + (p.fta || 0), pm: p.pm }; }); }
function gameRatings(p) {
  const me = p.teams.filter(function (t) { return t.id === TEAM.espn; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.espn; })[0];
  if (!me || !op) return null;
  const poss = (possOf(me.stats) + possOf(op.stats)) / 2;
  return poss ? { poss: r1(poss), ortg: r1(100 * me.score / poss), drtg: r1(100 * op.score / poss) } : null;
}
function liveView(p) {
  return { ok: true, id: p.id, status: p.status, teams: p.teams.map(teamLine), box: (function () { const o = {}; Object.keys(p.players).forEach(function (k) { o[k] = boxRows(p.players[k]); }); return o; })(),
    ratings: gameRatings(p), last: p.plays.slice(-8).reverse().map(function (x) { return { per: x.per, clk: x.clk, txt: x.txt, tid: x.tid }; }), at: Date.now() };
}
function gameView(p) {
  const v = liveView(p);
  v.shots = p.plays.filter(function (x) { return x.shot; }).map(function (x) { return [x.x, x.y, x.made ? 1 : 0, x.three ? 1 : 0, x.tid === TEAM.espn ? 1 : 0, x.pid]; });
  v.scoring = p.plays.filter(function (x) { return x.sc; }).map(function (x) { return [x.per, x.clk, x.hs, x.as]; });
  v.last = p.plays.filter(function (x) { return x.sc && x.sv >= 2; }).slice(-12).reverse().map(function (x) { return { per: x.per, clk: x.clk, txt: x.txt, tid: x.tid }; });
  v.venue = p.venue;
  // line score and game flow (Blazers margin over game time, in minutes)
  const me = p.teams.filter(function (t) { return t.id === TEAM.espn; })[0];
  if (me) {
    const qs = [], flow = [[0, 0]]; let h = 0, a = 0, per = 1, q0 = [0, 0];
    p.plays.forEach(function (x) {
      if (x.per !== per && x.per > per) { qs.push([(me.home ? h : a) - q0[0], (me.home ? a : h) - q0[1]]); q0 = [me.home ? h : a, me.home ? a : h]; per = x.per; }
      if (x.hs != null && x.as != null && (x.hs !== h || x.as !== a) && x.hs >= h && x.as >= a) { h = x.hs; a = x.as; flow.push([r1(elapsedAt(x.per, x.sec) / 60), (me.home ? h - a : a - h)]); }
    });
    if (p.plays.length) qs.push([(me.home ? h : a) - q0[0], (me.home ? a : h) - q0[1]]);
    v.quarters = qs.length && qs.reduce(function (s, q) { return s + q[0]; }, 0) === me.score ? qs : null;
    v.flow = flow.length > 10 ? flow : null;
  }
  return v;
}
function vsLine(p) {
  const me = p.teams.filter(function (t) { return t.id === TEAM.espn; })[0] || {}, op = p.teams.filter(function (t) { return t.id !== TEAM.espn; })[0] || {};
  return { me: me, op: op, at: me.home ? 'vs' : '@' };
}
function startMessage(p) { const v = vsLine(p); return { title: 'Tip-off ' + TEAM.abbr + ' ' + v.at + ' ' + v.op.abbr, body: 'Blazers vs ' + v.op.name + ' is underway' + (p.venue ? ' at ' + p.venue : ''), url: './?g=' + p.id }; }
function finalMessage(p, por) {
  const v = vsLine(p), win = v.me.score > v.op.score;
  const pl = (p.players[TEAM.espn] || []).filter(function (x) { return !x.dnp; }).sort(function (a, b) { return (b.pts || 0) - (a.pts || 0); }).slice(0, 2);
  const rec = por ? por.games.filter(function (g) { return g.win; }).length + '-' + por.games.filter(function (g) { return !g.win; }).length : '';
  return { title: (win ? 'Win ' : 'Loss ') + TEAM.abbr + ' ' + v.me.score + '-' + v.op.score + ' ' + v.op.abbr,
    body: pl.map(function (x) { return (x.short || x.name) + ' ' + x.pts + ' pts' + (x.reb >= 10 ? ' ' + x.reb + ' reb' : '') + (x.ast >= 8 ? ' ' + x.ast + ' ast' : ''); }).join(', ') + (rec ? ' (' + rec + ')' : ''), url: './?g=' + p.id };
}

/* ---------- standings ---------- */
function standingsFromEspn(j) {
  const out = {};
  (j.children || []).forEach(function (c) {
    const key = /west/i.test(c.name || c.abbreviation || '') ? 'west' : 'east';
    out[key] = ((c.standings || {}).entries || []).map(function (e) {
      const s = {}; (e.stats || []).forEach(function (x) { s[x.name || x.type] = x.displayValue != null ? x.displayValue : x.value; s['_' + (x.name || x.type)] = x.value; });
      return { id: String((e.team || {}).id), abbr: (e.team || {}).abbreviation || '', name: (e.team || {}).displayName || '', logo: (((e.team || {}).logos || [])[0] || {}).href || '',
        w: NUM(s._wins), l: NUM(s._losses), pct: s.winPercent || '', gb: s.gamesBehind || '', streak: s.streak || '', seed: NUM(s._playoffSeed) };
    }).sort(function (a, b) { return (a.seed || 99) - (b.seed || 99) || (b.w - b.l) - (a.w - a.l); });
  });
  return out;
}

/* ---------- roster ---------- */
function rosterFromEspn(j) {
  const list = j.athletes && j.athletes.length && j.athletes[0].items ? [].concat.apply([], j.athletes.map(function (g) { return g.items; })) : (j.athletes || []);
  return list.map(function (a) {
    const c = a.contract || {}, inj = (a.injuries || [])[0];
    return { id: String(a.id), name: a.fullName || a.displayName, short: a.shortName || '', jersey: a.jersey || '', pos: (a.position || {}).abbreviation || '', age: a.age || null,
      ht: a.displayHeight || '', wt: a.displayWeight || '', exp: (a.experience || {}).years, head: (a.headshot || {}).href || '', birth: [((a.birthPlace || {}).city || ''), ((a.birthPlace || {}).country || '')].filter(function (x) { return x; }).join(', '),
      college: (a.college || {}).name || '', debut: a.debutYear || null,
      inj: inj ? { status: inj.status || (inj.type || {}).description || '', detail: inj.longComment || inj.shortComment || (inj.details ? [(inj.details.type || ''), (inj.details.detail || ''), (inj.details.side || '')].join(' ').trim() : ''), ret: inj.details && inj.details.returnDate || '' } : null,
      contract: c.salary != null ? { salary: c.salary, years: c.yearsRemaining, option: c.optionType || 0, trade: c.incomingTradeValue || null, bird: c.birdStatus } : null,
      contracts: (a.contracts || []).map(function (k) { return { y: (k.season || {}).year, s: k.salary }; }).filter(function (k) { return k.y && k.s; }) };
  });
}
function rosterCoach(j) { const c = (j.coach || [])[0]; return c ? (c.firstName + ' ' + c.lastName) : ''; }
function rosterChanges(old, cur) {
  const om = {}, cm = {}, out = [];
  old.forEach(function (p) { om[p.id] = p; }); cur.forEach(function (p) { cm[p.id] = p; });
  cur.forEach(function (p) { if (!om[p.id]) out.push({ title: 'Added', body: p.name + ' joined the roster' + (p.contract ? ' (' + money(p.contract.salary) + ')' : ''), url: './?p=' + p.id }); });
  old.forEach(function (p) { if (!cm[p.id]) out.push({ title: 'Left', body: p.name + ' is off the roster', url: './' }); });
  cur.forEach(function (p) {
    const o = om[p.id]; if (!o) return;
    const a = o.inj ? o.inj.status : '', b = p.inj ? p.inj.status : '';
    if (a !== b) out.push({ title: b ? 'Injury: ' + p.name : 'Back: ' + p.name, body: b ? b + (p.inj.detail ? ': ' + p.inj.detail : '') : 'Off the injury report', url: './?p=' + p.id });
    if (o.contract && p.contract && o.contract.salary !== p.contract.salary) out.push({ title: 'Contract: ' + p.name, body: 'Salary changed from ' + money(o.contract.salary) + ' to ' + money(p.contract.salary), url: './?p=' + p.id });
  });
  return out;
}
function money(v) { if (v == null) return '—'; return v >= 1e6 ? '$' + (Math.round(v / 1e5) / 10) + 'M' : '$' + Math.round(v / 1e3) + 'K'; }

/* ---------- Basketball-Reference tables ---------- */
function brTableRows(html, idRe, key) {
  html = String(html || '').replace(/<!--|-->/g, '');
  const out = [], tre = /<table\b[^>]*\bid="([^"]+)"[^>]*>([\s\S]*?)<\/table>/gi;
  let m;
  while ((m = tre.exec(html))) {
    if (!idRe.test(m[1])) continue;
    const rows = m[2].match(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi) || [];
    rows.forEach(function (r) {
      if (/class="[^"]*\bthead\b/.test(r)) return;
      const o = {}, cre = /<(td|th)\b[^>]*data-stat="([^"]+)"[^>]*>([\s\S]*?)<\/\1>/gi; let c;
      while ((c = cre.exec(r))) { if (o[c[2]] == null) o[c[2]] = stripTags(c[3]).replace(/\*$/, '').trim(); }
      if (key ? o[key] : (o.player || o.name_display)) out.push(o);
    });
  }
  return out;
}
const BR_TOTAL_KEYS = ['g', 'mp', 'fg', 'fga', 'fg3', 'fg3a', 'ft', 'fta', 'orb', 'trb', 'ast', 'stl', 'blk', 'tov', 'pf', 'pts'];
function brNumbers(r, name) {
  const o = { name: name, from: r.year_min || r.from || '', to: r.year_max || r.to || '' };
  BR_TOTAL_KEYS.forEach(function (k) { const v = r[k] != null ? r[k] : r[k === 'g' ? 'games' : k]; o[k] = NUM(v); });
  return o;
}
/* franchise history: one row per season from /teams/POR/ */
function brHistory(rows) {
  const pick = function (r, ks) { for (let i = 0; i < ks.length; i++) if (r[ks[i]] != null && r[ks[i]] !== '') return r[ks[i]]; return ''; };
  return rows.filter(function (r) { return /^\d{4}-\d{2}$/.test(r.season || ''); }).map(function (r) {
    return { s: r.season, w: NUM(pick(r, ['wins', 'w'])), l: NUM(pick(r, ['losses', 'l'])), fin: pick(r, ['rank_team', 'finish']), po: pick(r, ['rank_team_playoffs', 'playoffs']),
      coach: pick(r, ['coaches', 'coach']).replace(/\s*\(\d+-\d+\)/g, ''), top: pick(r, ['top_ws']), ortg: NUM(pick(r, ['off_rtg'])) || null, drtg: NUM(pick(r, ['def_rtg'])) || null, srs: pick(r, ['srs']) };
  }).sort(function (a, b) { return a.s < b.s ? 1 : -1; });
}
function brAdvanced(r) {
  const o = {};
  [['per', 'per'], ['ts', 'ts_pct'], ['usg', 'usg_pct'], ['ows', 'ows'], ['dws', 'dws'], ['ws', 'ws'], ['ws48', 'ws_per_48'], ['obpm', 'obpm'], ['dbpm', 'dbpm'], ['bpm', 'bpm'], ['vorp', 'vorp'], ['ast_pct', 'ast_pct'], ['trb_pct', 'trb_pct'], ['tov_pct', 'tov_pct'], ['mp', 'mp']]
    .forEach(function (k) { if (r[k[1]] != null && r[k[1]] !== '') o[k[0]] = NUM(r[k[1]]); });
  return o;
}

/* ---------- franchise leaderboards ---------- */
/* GAS reports fetch errors in the account's language; the app is English */
function errText(e) {
  const m = String(e && e.message || e || '');
  const map = [[/使用できないアドレス|Address unavailable/i, 'Address unavailable'], [/無効な引数|Invalid argument/i, 'Invalid argument'], [/タイムアウト|timed? ?out/i, 'Timed out'],
    [/使用回数|too many times|quota/i, 'Daily quota exceeded'], [/帯域幅|bandwidth/i, 'Bandwidth quota exceeded'], [/DNS/i, 'DNS error'], [/SSL/i, 'SSL error']];
  for (let i = 0; i < map.length; i++) if (map[i][0].test(m)) return map[i][1];
  return /[\u3040-\u30ff\u4e00-\u9fff]/.test(m) ? 'Fetch failed' : m;
}
function ordinal(n) { const v = n % 100; return n + ((v >= 11 && v <= 13) ? 'th' : (['th', 'st', 'nd', 'rd'][n % 10] || 'th')); }
const LEADER_CATS = [['pts', 'Points', 'pts', 1000], ['trb', 'Rebounds', 'reb', 500], ['ast', 'Assists', 'ast', 500], ['stl', 'Steals', 'stl', 100], ['blk', 'Blocks', 'blk', 100], ['fg3', '3-pointers', 'tpm', 100], ['g', 'Games', 'g', 100], ['mp', 'Minutes', 'min', 5000], ['ft', 'Free throws', 'ftm', 500], ['fg', 'Field goals', 'fgm', 500]];
function buildLeaders(br, por, roster) {
  const active = {};   // normName → { id, name, add: {...} }
  roster.forEach(function (p) { active[normName(p.name)] = { id: p.id, name: p.name, add: {} }; });
  // games Basketball-Reference has not counted yet: those after its season game count, in date order
  Object.keys(por.players || {}).forEach(function (pid) {
    const P = por.players[pid], k = normName(P.name), a = active[k]; if (!a) return;
    const s = br.season_ && br.season_[k], gBR = s ? s.g : 0;
    const played = P.logs.filter(function (l) { return !l.dnp; }).sort(function (x, y) { return x.d - y.d; }), extra = played.slice(gBR);
    LEADER_CATS.forEach(function (c) { a.add[c[0]] = extra.reduce(function (sum, l) { return sum + (c[2] === 'g' ? 1 : (l[c[2]] || 0)); }, 0); });
    a.extra = extra.length;
  });
  const cats = {}, act = {};
  LEADER_CATS.forEach(function (c) {
    const k = c[0];
    const list = Object.keys(br.totals).map(function (nk) {
      const t = br.totals[nk], a = active[nk];
      return { n: t.name, v: Math.round((t[k] || 0) + (a ? a.add[k] || 0 : 0)), a: a ? a.id : '', y: t.from + (t.to && t.to !== t.from ? '–' + t.to : '') };
    }).filter(function (e) { return e.v > 0; }).sort(function (x, y) { return y.v - x.v; });
    list.forEach(function (e, i) { e.r = i + 1; });
    const actives = list.filter(function (e) { return e.a; });
    cats[k] = { name: c[1], top: list.slice(0, 30), active: actives.map(function (e) { const above = e.r > 1 ? list[e.r - 2] : null; return { a: e.a, n: e.n, v: e.v, r: e.r, next: above ? { n: above.n, v: above.v, gap: above.v - e.v + 1 } : null, step: c[3] }; }) };
    actives.forEach(function (e) { (act[e.a] = act[e.a] || {})[k] = { r: e.r, v: e.v }; });
  });
  // players on the roster who have never played for Portland before are not in the table yet
  return { cats: cats, active: act, pending: Object.keys(active).filter(function (k) { return !br.totals[k]; }).map(function (k) { return active[k].name; }) };
}
function milestoneMessages(before, boards) {
  const out = [];
  Object.keys(boards.active).forEach(function (id) {
    Object.keys(boards.active[id]).forEach(function (k) {
      const now = boards.active[id][k], was = before && before[id] && before[id][k], cat = boards.cats[k], c = LEADER_CATS.filter(function (x) { return x[0] === k; })[0];
      if (!was) return;
      const e = cat.active.filter(function (x) { return x.a === id; })[0]; if (!e) return;
      if (now.r < was.r && now.r <= 50) {
        const passed = cat.top[now.r] ? cat.top[now.r].n : '';
        out.push({ title: 'Franchise record: ' + e.n, body: 'Now ' + ordinal(now.r) + ' all-time in ' + c[1].toLowerCase() + ' (' + now.v.toLocaleString() + (passed ? ', passing ' + passed : '') + ')', url: './?p=' + id });
      }
      const step = c[3];
      if (Math.floor(now.v / step) > Math.floor(was.v / step) && now.v >= step) out.push({ title: 'Milestone: ' + e.n, body: 'Reached ' + (Math.floor(now.v / step) * step).toLocaleString() + ' career ' + c[1].toLowerCase() + ' with Portland', url: './?p=' + id });
    });
  });
  return out.slice(0, 4);
}

/* ---------- market value ---------- */
function marketValue(ws, teamGames, p) {
  if (ws == null) return { ws: null, value: null };
  const pace = teamGames >= 5 ? ws * 82 / teamGames : ws * 82 / Math.max(5, teamGames);
  return { ws: ws, value: Math.round(Math.max(MIN_SALARY, pace * WIN_SHARE_VALUE) / 1e4) * 1e4 };
}

/* ---------- news ---------- */
function rosterNameRegex(roster) {
  const names = [];
  roster.forEach(function (p) { names.push(p.name); const last = String(p.name).split(' ').slice(-1)[0]; if (last.length >= 5) names.push(last); });
  return names.length ? new RegExp('\\b(' + names.map(function (n) { return n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')\\b', 'i') : null;
}
function newsItem(r, src, now, nameRe, roster) {
  let title = r.title, source = r.source || src.name;
  if (src.kind === 'gnews') { const m = String(title).match(/^(.*)\s+-\s+([^-]{2,60})$/); if (m) { title = m[1]; if (!r.source) source = m[2]; } }
  if (!title || !r.link) return null;
  const desc = src.kind === 'gnews' ? '' : String(r.desc || '').replace(/\s+/g, ' ').slice(0, 300);
  const text = title + ' ' + desc;
  if (!/blazers|portland|rip city|\bPOR\b/i.test(text) && !(nameRe && nameRe.test(text))) return null;
  let d = parseDate(r.date, now); if (d > now + 864e5) d = now;
  let cat = 'other';
  for (let i = 0; i < NEWS_CATS.length; i++) if (NEWS_CATS[i][1].test(title)) { cat = NEWS_CATS[i][0]; break; }
  const who = [];
  (roster || []).forEach(function (p) { const last = String(p.name).split(' ').slice(-1)[0]; if (new RegExp('\\b' + p.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i').test(text) || (last.length >= 5 && new RegExp('\\b' + last + '\\b', 'i').test(title))) who.push(p.id); });
  return { id: hashId(r.link || title), t: title, u: r.link, s: source, sid: src.id, d: d, x: desc.length > 280 ? desc.slice(0, 277) + '…' : desc, im: r.image || '', cat: cat, who: who.slice(0, 4) };
}

/* ---------- brief written by the Claude scheduled task ---------- */
function sanitizeBrief(b) {
  if (!b || typeof b !== 'object') return null;
  const clean = function (s, n) { return String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n); };
  const list = function (a) { return (Array.isArray(a) ? a : []).slice(0, 10).map(function (x) { return { text: clean(x && x.text, 400), url: /^https?:\/\//.test(String(x && x.url)) ? clean(x.url, 600) : '' }; }).filter(function (x) { return x.text; }); };
  const out = { at: Date.now(), headline: clean(b.headline, 160), points: list(b.points), players: list(b.players), watch: clean(b.watch, 600) };
  return out.points.length ? out : null;
}


/* ---------- team page: lineups, on/off, clutch, assist pairs, franchise history ---------- */
function rateOf(o) { const poss = o.poss || 0; return poss > 0 ? { min: r1(o.sec / 60), pf: o.pf, pa: o.pa, ortg: r1(100 * o.pf / poss), drtg: r1(100 * o.pa / poss), net: r1(100 * (o.pf - o.pa) / poss) } : { min: r1((o.sec || 0) / 60), pf: o.pf || 0, pa: o.pa || 0, ortg: null, drtg: null, net: null }; }
function teamPage(por, roster, br) {
  const nm = {}; Object.keys(por.players || {}).forEach(function (id) { nm[id] = por.players[id].name; });
  (roster || []).forEach(function (p) { nm[p.id] = p.name; });
  const short = function (id) { const n = nm[id] || id, a = String(n).split(' '); return a.length > 1 ? a[0][0] + '. ' + a.slice(1).join(' ') : n; };
  const onRoster = {}; (roster || []).forEach(function (p) { onRoster[p.id] = 1; });
  const lineups = Object.keys(por.lineups || {}).map(function (k) { const L = por.lineups[k]; return Object.assign({ ids: k.split(','), names: k.split(',').map(short), g: L.g }, rateOf(L)); })
    .filter(function (l) { return l.min >= 1; }).sort(function (a, b) { return b.min - a.min; }).slice(0, 40);
  const onoff = Object.keys(por.onoff || {}).map(function (id) { const O = por.onoff[id], on = rateOf(O.on), off = rateOf(O.off);
    return { id: id, n: nm[id] || id, g: O.g, onMin: on.min, on: on, off: off, diff: on.net != null && off.net != null ? r1(on.net - off.net) : null, cur: !!onRoster[id] }; })
    .filter(function (x) { return x.onMin >= 5; }).sort(function (a, b) { return b.onMin - a.onMin; });
  const C = por.clutch || { g: 0, w: 0, l: 0, sec: 0, pf: 0, pa: 0, poss: 0, players: {} };
  const clutch = Object.assign({ g: C.g, w: C.w, l: C.l }, rateOf(C), { players: Object.keys(C.players || {}).map(function (id) { const q = C.players[id];
    return { id: id, n: nm[id] || id, min: r1(q.sec / 60), pts: q.pts, fgm: q.fgm, fga: q.fga, tpm: q.tpm, tpa: q.tpa, ftm: q.ftm, fta: q.fta, ast: q.ast }; })
    .filter(function (x) { return x.min > 0 || x.pts > 0; }).sort(function (a, b) { return b.pts - a.pts || b.min - a.min; }) });
  const assists = Object.keys(por.assists || {}).map(function (k) { const a = k.split('>'); return { from: a[0], to: a[1], fromN: short(a[0]), toN: short(a[1]), n: por.assists[k] }; })
    .sort(function (a, b) { return b.n - a.n; }).slice(0, 40);
  const games = (por.games || []).slice().sort(function (a, b) { return a.d - b.d; }).map(function (g) { return { id: g.id, d: g.d, opp: g.opp, home: g.home, win: g.win, pf: g.pf, pa: g.pa, q: g.q || null, clutch: !!g.clutch }; });
  return { ok: true, lineups: lineups, onoff: onoff, clutch: clutch, assists: assists, games: games, pbpGames: (por.games || []).filter(function (g) { return g.pbp; }).length,
    history: (br && br.history) || [], historyAt: br ? br.at : 0 };
}

/* ---------- next opponent ---------- */
function previewOf(next, L, sched, opp) {
  if (!next || !next.opp || !next.opp.id) return null;
  const id = next.opp.id, T = (L.teams || {})[id], M = L.metrics && L.metrics[id], R = L.ranks && L.ranks[id];
  const leaders = Object.keys(((L.players || {})[id]) || {}).map(function (pid) { const q = L.players[id][pid]; return { id: pid, n: q.n, gp: q.gp, pts: r1(q.pts / q.gp), reb: r1(q.reb / q.gp), ast: r1(q.ast / q.gp), min: r1(q.min / q.gp) }; })
    .filter(function (q) { return q.gp >= 1; }).sort(function (a, b) { return b.pts - a.pts; }).slice(0, 4);
  const h2h = (sched.games || []).filter(function (g) { return g.opp && g.opp.id === id && g.state === 'post'; }).map(function (g) { return { id: g.id, t: g.t, home: g.home, win: g.win, pf: g.pf, pa: g.pa }; });
  const cmp = []; const MM = L.metrics && L.metrics[TEAM.espn], RR = L.ranks && L.ranks[TEAM.espn];
  if (M && MM) ['ortg', 'drtg', 'net', 'pace', 'efg', 'tovp', 'orbp', 'oefg'].forEach(function (k) { const mt = METRICS.filter(function (x) { return x[0] === k; })[0]; cmp.push({ k: k, name: mt[1], por: MM[k], porR: RR[k], opp: M[k], oppR: R[k] }); });
  return { id: id, abbr: next.opp.abbr, name: next.opp.name, logo: next.opp.logo, t: next.t, home: next.home, record: T ? { w: T.w, l: T.l } : null,
    last: T && T.last ? T.last.slice(-5) : [], leaders: leaders, cmp: cmp, h2h: h2h, inj: opp && opp.id === id ? opp.inj : null, teams: Object.keys(L.teams || {}).length };
}

/* ---------- app feed and player page ---------- */
function avgOf(logs) {
  const pl = logs.filter(function (l) { return !l.dnp; }), n = pl.length || 1, s = function (k) { return pl.reduce(function (a, l) { return a + (l[k] || 0); }, 0); };
  const fga = s('fga'), tpa = s('tpa'), fta = s('fta');
  return { gp: pl.length, min: r1(s('min') / n), pts: r1(s('pts') / n), reb: r1(s('reb') / n), ast: r1(s('ast') / n), stl: r1(s('stl') / n), blk: r1(s('blk') / n), tov: r1(s('tov') / n),
    fg: fga ? Math.round(1000 * s('fgm') / fga) / 10 : null, tp: tpa ? Math.round(1000 * s('tpm') / tpa) / 10 : null, ft: fta ? Math.round(1000 * s('ftm') / fta) / 10 : null,
    ts: (fga + 0.44 * fta) ? Math.round(1000 * s('pts') / (2 * (fga + 0.44 * fta))) / 10 : null, pm: r1(s('pm') / n), starts: pl.filter(function (l) { return l.st; }).length };
}
function zonesOf(shots, L) {
  const z = {};
  (shots || []).forEach(function (s) { const k = zoneOf(s[0], s[1], s[3] === 1), Z = z[k] = z[k] || [0, 0]; Z[1]++; if (s[2]) Z[0]++; });
  return ZONES.map(function (zz) { const k = zz[0], mine = z[k] || [0, 0], lg = (L.zones || {})[k] || [0, 0]; return { z: k, name: zz[1], m: mine[0], a: mine[1], pct: mine[1] ? Math.round(1000 * mine[0] / mine[1]) / 10 : null, lg: lg[1] ? Math.round(1000 * lg[0] / lg[1]) / 10 : null }; });
}
function feedView(now, sched, por, L, roster, leaders, standings, br, news, brief, vals, st, opp) {
  const games = sched.games || [], past = games.filter(function (g) { return g.state === 'post'; }), next = games.filter(function (g) { return g.state !== 'post'; })[0] || null;
  const lastG = past[past.length - 1] || null, lastStored = lastG ? por.games.filter(function (g) { return g.id === lastG.id; })[0] : null;
  const wins = past.filter(function (g) { return g.win; }).length, losses = past.filter(function (g) { return g.win === false; }).length;
  const conf = (standings.west || []).some(function (t) { return t.id === TEAM.espn; }) ? 'west' : 'east', ci = (standings[conf] || []).map(function (t) { return t.id; }).indexOf(TEAM.espn);
  const players = (roster.players || []).map(function (p) {
    const P = por.players[p.id], a = P ? avgOf(P.logs) : null, s = br && br.season_ ? br.season_[normName(p.name)] : null, h = (vals.players || {})[p.id] || [];
    return { id: p.id, name: p.name, short: p.short, jersey: p.jersey, pos: p.pos, head: p.head, age: p.age, inj: p.inj, salary: p.contract ? p.contract.salary : null, years: p.contract ? p.contract.years : null,
      avg: a, adv: s && s.adv ? { per: s.adv.per, ws: s.adv.ws, bpm: s.adv.bpm, ts: s.adv.ts } : null, value: h.length ? h[h.length - 1].v : null };
  }).sort(function (a, b) { return ((b.avg && b.avg.min) || 0) - ((a.avg && a.avg.min) || 0); });
  let lastBox = null;
  if (lastG && por.players) {
    lastBox = Object.keys(por.players).map(function (id) { const l = por.players[id].logs.filter(function (x) { return x.e === lastG.id && !x.dnp; })[0]; return l ? { id: id, n: por.players[id].name, pts: l.pts, reb: l.reb, ast: l.ast, min: l.min } : null; })
      .filter(Boolean).sort(function (a, b) { return b.pts - a.pts; }).slice(0, 5);
  }
  const ranks = {}; const M = L.metrics && L.metrics[TEAM.espn], R = L.ranks && L.ranks[TEAM.espn];
  METRICS.forEach(function (mt) { if (M) ranks[mt[0]] = { name: mt[1], v: M[mt[0]], r: R[mt[0]] }; });
  const league = Object.keys(L.metrics || {}).map(function (id) { return Object.assign({ id: id, abbr: L.teams[id].abbr, logo: L.teams[id].logo, g: L.teams[id].g }, L.metrics[id]); });
  const ms = [];
  if (leaders) Object.keys(leaders.cats).forEach(function (k) { leaders.cats[k].active.forEach(function (e) { if (e.next && e.r <= 60) ms.push({ a: e.a, n: e.n, cat: k, catName: leaders.cats[k].name, r: e.r, v: e.v, next: e.next }); }); });
  ms.sort(function (x, y) { return (x.next.gap / Math.max(1, x.v)) - (y.next.gap / Math.max(1, y.v)); });
  const statusList = Object.keys((st && st.status) || {}).map(function (k) { return Object.assign({ id: k }, st.status[k]); }).concat(Object.keys((st && st.newsStatus) || {}).map(function (k) { return Object.assign({ id: 'news:' + k }, st.newsStatus[k]); }));
  return { ok: true, updated: now, season: sched.season, coach: roster.coach || '', record: { w: wins, l: losses }, standing: ci >= 0 ? { conf: conf, seed: ci + 1 } : null,
    next: next, last: lastG ? Object.assign({}, lastG, { box: lastBox, ratings: lastStored ? { ortg: lastStored.ortg, drtg: lastStored.drtg } : null }) : null,
    live: st && st.live && st.live.state === 'in' ? st.live : null, schedule: games, roster: players, ranks: ranks, league: league, hist: L.hist || [],
    games: por.games.map(function (g) { return { id: g.id, d: g.d, opp: g.opp, home: g.home, pf: g.pf, pa: g.pa, win: g.win, ortg: g.ortg, drtg: g.drtg }; }),
    standings: standings, milestones: ms.slice(0, 12), leadersAt: leaders ? leaders.at : 0, pending: leaders ? leaders.pending : [],
    news: news, brief: brief, sources: statusList, leagueGames: L.games || 0, cap: SALARY_CAP, preview: previewOf(next, L, sched, opp) };
}
function playerPage(p, por, br, leaders, L, vals, news) {
  const P = por.players[p.id] || { logs: [] }, s = br && br.season_ ? br.season_[normName(p.name)] : null, t = br && br.totals ? br.totals[normName(p.name)] : null;
  const ranks = [];
  if (leaders) Object.keys(leaders.cats).forEach(function (k) { const e = leaders.cats[k].active.filter(function (x) { return x.a === p.id; })[0]; if (e) ranks.push({ cat: k, name: leaders.cats[k].name, r: e.r, v: e.v, next: e.next }); });
  const shots = (por.shots || {})[p.id] || [];
  const nameRe = new RegExp('\\b' + String(p.name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
  return { ok: true, p: p, avg: avgOf(P.logs), logs: P.logs.slice().sort(function (a, b) { return b.d - a.d; }), shots: shots.map(function (x) { return [x[0], x[1], x[2], x[3]]; }), zones: zonesOf(shots, L),
    adv: s && s.adv ? s.adv : null, franchise: t, ranks: ranks, values: vals, cap: SALARY_CAP, wsValue: WIN_SHARE_VALUE,
    onoff: por.onoff && por.onoff[p.id] ? { on: rateOf(por.onoff[p.id].on), off: rateOf(por.onoff[p.id].off), g: por.onoff[p.id].g } : null,
    clutch: por.clutch && por.clutch.players && por.clutch.players[p.id] ? Object.assign({ min: r1(por.clutch.players[p.id].sec / 60) }, por.clutch.players[p.id]) : null,
    partners: (function () { const nm = function (id) { return por.players[id] ? por.players[id].name : id; }, to = [], from = [];
      Object.keys(por.assists || {}).forEach(function (k) { const a = k.split('>'); if (a[0] === p.id) to.push({ id: a[1], n: nm(a[1]), c: por.assists[k] }); if (a[1] === p.id) from.push({ id: a[0], n: nm(a[0]), c: por.assists[k] }); });
      const srt = function (x, y) { return y.c - x.c; }; return { to: to.sort(srt).slice(0, 5), from: from.sort(srt).slice(0, 5) }; })(),
    news: news.filter(function (n) { return (n.who || []).indexOf(p.id) >= 0 || nameRe.test(n.t + ' ' + (n.x || '')); }).slice(0, 40) };
}

/* ======================================================================
 * Shared with BMERadar: feed parsing, storage, in-app reader, Web Push (VAPID / P-256)
 * ====================================================================== */
function decodeEntities(s) {
  return String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#x([0-9a-f]+);/gi, function (m, h) { return String.fromCharCode(parseInt(h, 16)); })
    .replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); })
    .replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}
function stripTags(s) { return decodeEntities(String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }
function tagText(block, names) {
  for (let i = 0; i < names.length; i++) {
    const m = block.match(new RegExp('<' + names[i] + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + names[i] + '>', 'i'));
    if (m) return m[1];
  }
  return '';
}
function attr(block, tag, name, where) {
  const re = new RegExp('<' + tag + '\\b([^>]*)>', 'gi'); let m;
  while ((m = re.exec(block))) {
    if (where && !where.test(m[1])) continue;
    const a = m[1].match(new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i')) || m[1].match(new RegExp(name + "\\s*=\\s*'([^']*)'", 'i'));
    if (a) return decodeEntities(a[1]);
  }
  return '';
}
function parseFeed(xml) {
  xml = String(xml || '');
  const atom = /<feed[\s>]/i.test(xml) && !/<rss[\s>]/i.test(xml);
  const blocks = xml.match(atom ? /<entry[\s>][\s\S]*?<\/entry>/gi : /<item[\s>][\s\S]*?<\/item>/gi) || [];
  return blocks.map(function (b) {
    let link = '';
    if (atom) link = attr(b, 'link', 'href', /rel\s*=\s*["']alternate["']/i) || attr(b, 'link', 'href');
    else link = stripTags(tagText(b, ['link'])) || attr(b, 'item', 'rdf:about') || stripTags(tagText(b, ['guid']));
    const descRaw = tagText(b, ['description', 'summary', 'content:encoded', 'content']);
    const fullRaw = [tagText(b, ['content:encoded']), tagText(b, ['content']), descRaw].sort(function (x, y) { return y.length - x.length; })[0] || '';
    const img = attr(b, 'media:content', 'url') || attr(b, 'media:thumbnail', 'url') || attr(b, 'enclosure', 'url', /type\s*=\s*["']image/i) ||
      ((decodeEntities(descRaw).match(/<img[^>]+src\s*=\s*["']([^"']+)["']/i) || [])[1] || '');
    return {
      title: stripTags(tagText(b, ['title', 'dc:title'])),
      link: link.trim(),
      guid: stripTags(tagText(b, ['guid', 'id'])),
      date: stripTags(tagText(b, ['pubDate', 'published', 'dc:date', 'updated', 'prism:publicationDate'])),
      desc: stripTags(descRaw),
      source: stripTags(tagText(b, ['source', 'prism:publicationName'])),
      image: /^https?:/.test(img) ? img : '',
      full: fullRaw.length > 800 ? decodeEntities(fullRaw).slice(0, 80000) : ''
    };
  }).filter(function (r) { return r.title && r.link; });
}
function parseDate(s, fallback) {
  s = String(s || '').trim();
  if (!s) return fallback;
  if (/^\d{8}$/.test(s)) return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8), 12);
  let t = Date.parse(s);
  if (isFinite(t)) return t;
  let m = s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] - 9 : 3, m[5] ? +m[5] : 0);
  m = s.match(/^([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})(?:,? (\d{1,2}):(\d{2})\s*([ap]m)?)?/i);
  if (m) {
    const mon = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(m[1].toLowerCase()) / 3;
    let h = m[4] ? +m[4] : 12; if (m[6] && /pm/i.test(m[6]) && h < 12) h += 12; if (m[6] && /am/i.test(m[6]) && h === 12) h = 0;
    if (mon >= 0) return Date.UTC(+m[3], mon, +m[2], h + 5, m[5] ? +m[5] : 0);   // US Eastern
  }
  return fallback;
}
function normTitle(t) { return String(t || '').toLowerCase().replace(/\s+[-–|]\s+[^-–|]+$/, '').replace(/[^\w぀-ヿ一-鿿]+/g, '').slice(0, 90); }
function hashId(s) { let h = 5381; s = String(s); for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
const STOP = ('the a an of for and to in on with by from at as is are be its new study shows show finds find using use used via into after over how why what could may can will first more than that this their these new about says said report reports device devices medical patients patient system wins win gets gains launches launch receives announces announced begins adds helps help team researchers scientists year years people data results human next-generation initiative company firm based near could would one two now just').split(' ');
const STOP_JA = ('開発 研究 発表 大学 技術 医療 患者 実証 活用 取得 成功 可能 世界 初 日本 国内 企業 研究所 研究グループ チーム 年度 令和 について お知らせ').split(' ');
function titleTokens(t) {
  const out = {};
  String(t || '').toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).forEach(function (w) { w = w.replace(/^-+|-+$/g, ''); if (w.length >= 3 && STOP.indexOf(w) < 0) out[w] = 1; });
  const ja = String(t || '').match(/[゠-ヿ]{3,}|[一-鿿]{2,}/g) || [];
  ja.forEach(function (w) { if (STOP_JA.indexOf(w) < 0) out[w] = 1; });
  return Object.keys(out);
}
function jaccard(a, b) {
  if (!a.length || !b.length) return 0;
  const set = {}; a.forEach(function (x) { set[x] = 1; });
  let inter = 0; b.forEach(function (x) { if (set[x]) inter++; });
  return inter / (a.length + b.length - inter);
}
function checkPass_(p) {
  const want = PropertiesService.getScriptProperties().getProperty('PASS');
  return !!want && typeof p === 'string' && p === want;
}
function dataFolder_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const f = DriveApp.createFolder(DATA_FOLDER);
  props.setProperty('FOLDER_ID', f.getId());
  return f;
}
function findFile_(folder, name) { const it = folder.getFilesByName(name); return it.hasNext() ? it.next() : null; }
function readJson_(name, fallback) {
  const f = findFile_(dataFolder_(), name);
  if (!f) return fallback;
  try { return JSON.parse(f.getBlob().getDataAsString()); } catch (e) { return fallback; }
}
function writeJson_(name, obj) {
  const folder = dataFolder_(), body = JSON.stringify(obj), f = findFile_(folder, name);
  if (f) f.setContent(body); else folder.createFile(name, body, MimeType.PLAIN_TEXT);
}
function cachePut_(key, str) {
  const c = CacheService.getScriptCache(), size = 90000, parts = {}, n = Math.ceil(str.length / size);
  if (n > 9) return;  // too large for the cache; served from Drive instead
  for (let i = 0; i < n; i++) parts[key + '_' + i] = str.slice(i * size, (i + 1) * size);
  parts[key + '_n'] = String(n);
  try { c.putAll(parts, 21600); } catch (e) {}
}
function cacheGet_(key) {
  const c = CacheService.getScriptCache(), n = +(c.get(key + '_n') || 0);
  if (!n) return null;
  const keys = []; for (let i = 0; i < n; i++) keys.push(key + '_' + i);
  const got = c.getAll(keys); let s = '';
  for (let i = 0; i < n; i++) { if (got[keys[i]] == null) return null; s += got[keys[i]]; }
  return s;
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';
function decodeHtml_(res) {
  const blob = res.getBlob(), head = blob.getDataAsString('ISO-8859-1').slice(0, 3000);
  const ct = String((res.getHeaders() || {})['Content-Type'] || (res.getHeaders() || {})['content-type'] || '');
  const cs = ((ct.match(/charset=([\w-]+)/i) || head.match(/<meta[^>]+charset=["']?([\w-]+)/i) || [])[1] || 'UTF-8').toUpperCase();
  try { return blob.getDataAsString(/SHIFT|SJIS/.test(cs) ? 'Shift_JIS' : /EUC/.test(cs) ? 'EUC-JP' : 'UTF-8'); } catch (e) { return res.getContentText(); }
}
function resolveGn_(url, it) {
  let err = '';
  try { const u = resolveGoogleNews_(url); if (u) return { url: u }; err = 'Google が応答しませんでした'; } catch (e) { err = String(e.message || e).slice(0, 60); }
  try { const u = bingFind_(it); if (u) return { url: u, via: 'bing' }; } catch (e) {}
  return { url: '', err: err };
}
function bingFind_(it) {
  if (!it || !it.t) return '';
  const ja = it.l === 'ja', q = '"' + it.t.slice(0, 120) + '"';
  const r = UrlFetchApp.fetch('https://www.bing.com/news/search?format=rss&q=' + encodeURIComponent(q) + (ja ? '&setlang=ja&cc=JP' : '&setlang=en-US&cc=US'), { muteHttpExceptions: true, headers: { 'User-Agent': UA } });
  if (r.getResponseCode() !== 200) return '';
  return bingPick(parseFeed(r.getContentText()), it.t, it.s);
}
function resolveGoogleNews_(url) {
  const id = (url.match(/articles\/([A-Za-z0-9_-]+)/) || [])[1];
  if (!id) return null;
  const local = decodeGnLocal(id);
  if (local) return local;
  // a recorded consent choice keeps Google from redirecting to consent.google.com
  const hdr = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36', Cookie: 'CONSENT=YES+cb.20240101-00-p0.en+FX+000; SOCS=CAESEwgDEgk0ODE3Nzk3MjQaAmVuIAEaBgiA_LyaBg' };
  const loc = (String(url).match(/[?&](hl=[^&]+&gl=[^&]+&ceid=[^&]+)/) || [])[1] || 'hl=en-US&gl=US&ceid=US:en';
  let page = '', sg, ts;
  ['https://news.google.com/rss/articles/' + id + '?' + loc, 'https://news.google.com/articles/' + id + '?' + loc].some(function (u) {
    const res = UrlFetchApp.fetch(u, { muteHttpExceptions: true, followRedirects: true, headers: hdr });
    if (res.getResponseCode() === 429) throw new Error('Google の回数制限');
    page = res.getContentText();
    const p = gnParams(page); sg = p.sg; ts = p.ts;
    return sg && ts;
  });
  if (!sg || !ts) { if (/consent\.google|before you continue|続行する前に/i.test(page)) throw new Error('Google の同意画面'); return null; }
  const r = UrlFetchApp.fetch('https://news.google.com/_/DotsSplashUi/data/batchexecute?rpcids=Fbv4je', { method: 'post', muteHttpExceptions: true,
    contentType: 'application/x-www-form-urlencoded;charset=UTF-8', payload: 'f.req=' + encodeURIComponent(gnBatchPayload(id, ts, sg)), headers: hdr });
  if (r.getResponseCode() === 429) throw new Error('Google の回数制限');
  return parseGnBatch(r.getContentText());
}
function metaContent(html, key) {
  const re = new RegExp('<meta[^>]+(?:property|name|itemprop)\\s*=\\s*["\']' + key.replace(/[:.]/g, '\\$&') + '["\'][^>]*>', 'i');
  const tag = (html.match(re) || [])[0];
  if (!tag) return '';
  return decodeEntities((tag.match(/content\s*=\s*"([^"]*)"/i) || tag.match(/content\s*=\s*'([^']*)'/i) || [])[1] || '').trim();
}
function absUrl(u, base) {
  u = decodeEntities(String(u || '').trim());
  if (!u || /^data:/i.test(u)) return '';
  if (/^https?:\/\//i.test(u)) return u;
  const m = String(base).match(/^(https?:\/\/[^\/]+)(\/[^?#]*)?/i); if (!m) return '';
  if (/^\/\//.test(u)) return 'https:' + u;
  if (/^\//.test(u)) return m[1] + u;
  return m[1] + (m[2] || '/').replace(/[^\/]*$/, '') + u;
}
const BOILER = /^(advertisement|sponsored|subscribe|sign up|sign in|log in|read more|related:|share this|copyright|all rights reserved|©|photo:|image:|credit:|getty images|this article (was|is)|click here|newsletter|cookie|we use cookies|follow us|もっと見る|関連記事|広告|この記事をシェア|会員登録|ログイン)/i;
function jsonLdBody(html) {
  const blocks = html.match(/<script[^>]+application\/ld\+json[^>]*>[\s\S]*?<\/script>/gi) || [];
  for (let i = 0; i < blocks.length; i++) {
    const txt = blocks[i].replace(/^<script[^>]*>/i, '').replace(/<\/script>$/i, '').trim();
    let j = null;
    // some sites put raw line breaks inside JSON strings; try a few repairs
    [txt, txt.replace(/\r?\n/g, '\\n').replace(/\t/g, ' '), txt.replace(/[\u0000-\u001f]+/g, ' ')].some(function (t) { try { j = JSON.parse(t); return true; } catch (e) { return false; } });
    if (!j) continue;
    try {
      const list = [].concat(j['@graph'] || j);
      for (let k = 0; k < list.length; k++) if (list[k] && typeof list[k].articleBody === 'string' && list[k].articleBody.length > 300) return list[k];
    } catch (e) {}
  }
  return null;
}
function extractArticle(html, url) {
  html = String(html || '');
  const title = metaContent(html, 'og:title') || stripTags(tagText(html, ['title'])) || '';
  const site = metaContent(html, 'og:site_name');
  const desc = metaContent(html, 'og:description') || metaContent(html, 'description');
  const image = absUrl(metaContent(html, 'og:image') || metaContent(html, 'twitter:image'), url);
  const date = metaContent(html, 'article:published_time') || metaContent(html, 'datePublished') || metaContent(html, 'citation_publication_date') || '';
  const paras = [];
  const ld = jsonLdBody(html);
  if (ld) {
    String(ld.articleBody).split(/\n\s*\n|\r?\n/).map(function (x) { return decodeEntities(x).replace(/\s+/g, ' ').trim(); }).filter(function (x) { return x.length > 1; }).forEach(function (x) { paras.push({ t: 'p', x: x }); });
  }
  if (!paras.length) {
    let body = html.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style|noscript|svg|nav|header|footer|aside|form|button|iframe|select)\b[\s\S]*?<\/\1>/gi, ' ');
    // arXiv abstract
    const abs = body.match(/<blockquote[^>]*class="[^"]*abstract[^"]*"[^>]*>([\s\S]*?)<\/blockquote>/i);
    if (abs) paras.push({ t: 'p', x: stripTags(abs[1]).replace(/^Abstract:\s*/i, '') });
    // pick the densest container: <article>, then main/role=main, then common content classes, else the body
    const cands = [];
    (body.match(/<article\b[\s\S]*?<\/article>/gi) || []).forEach(function (b) { cands.push(b); });
    const mm = body.match(/<main\b[\s\S]*?<\/main>/i); if (mm) cands.push(mm[0]);
    const re = /<(div|section)\b[^>]*(?:class|id)\s*=\s*["'][^"']*(article[-_]?body|entry[-_]content|post[-_]content|story[-_]body|article[-_]content|main[-_]content|content[-_]body|news[-_]body|articleBody|rich[-_]text|body[-_]text|text[-_]body)[^"']*["'][^>]*>/gi;
    let m; while ((m = re.exec(body))) cands.push(body.slice(m.index, m.index + 200000));
    cands.push(body);
    let best = null, bestLen = 0;
    cands.forEach(function (c) {
      const ps = collectParas(c, url);
      const len = ps.reduce(function (s, p) { return s + (p.t === 'p' ? p.x.length : 0); }, 0);
      if (len > bestLen * 1.6 || (!best && len)) { best = ps; bestLen = len; }   // earlier candidates are more specific
    });
    if (best && !abs) best.forEach(function (p) { paras.push(p); });
  }
  // de-duplicate repeated paragraphs and drop the title if repeated
  const seen = {}, out = [];
  paras.forEach(function (p) { const k = p.t + (p.x || p.src); if (seen[k] || (p.t !== 'img' && normTitle(p.x) === normTitle(title))) return; seen[k] = 1; out.push(p); });
  const text = out.filter(function (p) { return p.t === 'p'; }).map(function (p) { return p.x; }).join(' ');
  return { title: title, site: site, desc: desc, image: image, date: date, paras: out.slice(0, 120), chars: text.length };
}
function collectParas(block, url) {
  const out = [];
  let m, imgs = 0;
  const tagRe = /<(p|h2|h3|li|blockquote)\b[^>]*>([\s\S]*?)<\/\1>|<img\b([^>]*)>/gi;
  while ((m = tagRe.exec(block))) {
    if (m[3] != null) {
      if (imgs >= 6) continue;
      const a = m[3], src = (a.match(/\s(?:data-src|data-lazy-src|data-original|src)\s*=\s*["']([^"']+)["']/i) || [])[1];
      const w = +((a.match(/\swidth\s*=\s*["']?(\d+)/i) || [])[1] || 0);
      const u = absUrl(src, url);
      if (!u || /\.svg(\?|$)|logo|icon|avatar|sprite|pixel|tracking|1x1|blank\.gif/i.test(u) || (w && w < 240)) continue;
      out.push({ t: 'img', src: u, alt: decodeEntities((a.match(/\salt\s*=\s*["']([^"']*)["']/i) || [])[1] || '').slice(0, 200) }); imgs++;
      continue;
    }
    const tag = m[1].toLowerCase(), x = stripTags(m[2]);
    if (!x || BOILER.test(x)) continue;
    if (tag === 'h2' || tag === 'h3') { if (x.length < 120) out.push({ t: 'h', x: x }); continue; }
    if (tag === 'li' && x.length < 60) continue;
    if (x.length < 40 && !/[。！？」]$/.test(x)) continue;
    out.push({ t: 'p', x: x });
  }
  // drop a trailing run of headings / images without text
  while (out.length && out[out.length - 1].t !== 'p') out.pop();
  return out;
}
function gnParams(html) {
  const h = String(html || '').replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<!--[\s\S]*?-->/gi, '');
  const tags = h.match(/<[a-z][^>]*data-n-a-sg=[^>]*>/gi) || [];
  for (let i = 0; i < tags.length; i++) {
    const sg = (tags[i].match(/data-n-a-sg="([^"]+)"/) || [])[1], ts = (tags[i].match(/data-n-a-ts="([^"]+)"/) || [])[1];
    if (sg && ts) return { sg: sg, ts: ts };
  }
  return {};
}
function bingPick(items, title, source) {
  const tok = titleTokens(title);
  let best = '', bs = 0;
  items.forEach(function (r) {
    const m = String(r.link).match(/[?&]url=([^&]+)/), u = m ? decodeURIComponent(m[1]) : r.link;
    if (!/^https?:\/\//.test(u) || /bing\.com|msn\.com\/[a-z-]+\/news\/other/.test(u)) return;
    let sc = jaccard(tok, titleTokens(r.title.replace(/\s+[-|–]\s+[^-|–]+$/, '')));
    if (source && r.source && r.source.toLowerCase().indexOf(String(source).toLowerCase().slice(0, 6)) >= 0) sc += 0.15;
    if (sc > bs) { bs = sc; best = u; }
  });
  return bs >= 0.6 ? best : '';
}
function gnBatchPayload(id, ts, sg) {
  const inner = '["garturlreq",[["X","X",["X","X"],null,null,1,1,"US:en",null,1,null,null,null,null,null,0,1],"X","X",1,[1,1,1],1,1,null,0,0,null,0],"' + id + '",' + ts + ',"' + sg + '"]';
  return JSON.stringify([[['Fbv4je', inner, null, 'generic']]]);
}
function parseGnBatch(text) {
  try {
    const parts = String(text).split('\n\n');
    const arr = JSON.parse(parts[1] || parts[0].replace(/^\)\]\}'\s*/, ''));
    for (let i = 0; i < arr.length; i++) if (arr[i][0] === 'wrb.fr' && arr[i][2]) { const u = JSON.parse(arr[i][2])[1]; if (/^https?:\/\//.test(u)) return u; }
  } catch (e) {}
  const m = String(text).match(/https?:\\\\?\/\\\\?\/[^"\\]+/);
  return m ? m[0].replace(/\\\\?\//g, '/').replace(/\\/g, '') : null;
}
function decodeGnLocal(id) {
  try {
    let b = id.replace(/-/g, '+').replace(/_/g, '/'); while (b.length % 4) b += '=';
    const bytes = Utilities.base64Decode(b), str = bytes.map(function (x) { return String.fromCharCode(x & 255); }).join('');
    if (str.indexOf('AU_yqL') >= 0) return null;
    const m = str.match(/https?:\/\/[\x21-\x7e]+/);
    return m ? m[0].replace(/[\x00-\x1f\xd2\x01].*$/, '') : null;
  } catch (e) { return null; }
}
function jinaToArticle(text, url) {
  text = String(text || '');
  const title = ((text.match(/^Title:\s*(.+)$/m) || [])[1] || '').trim();
  const md = text.indexOf('Markdown Content:') >= 0 ? text.slice(text.indexOf('Markdown Content:') + 17) : text;
  const paras = [];
  let imgs = 0;
  md.split(/\n\s*\n/).forEach(function (blk) {
    blk = blk.trim(); if (!blk) return;
    const im = blk.match(/^!\[([^\]]*)\]\((https?:[^)\s]+)/);
    if (im) { if (imgs < 6 && !/logo|icon|avatar|sprite|pixel|\.svg/i.test(im[2])) { paras.push({ t: 'img', src: im[2], alt: im[1].slice(0, 200) }); imgs++; } return; }
    let x = blk.replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/[*_`]{1,3}/g, '').replace(/^>\s?/gm, '').replace(/\s+/g, ' ').trim();
    const h = blk.match(/^#{1,4}\s+(.+)/);
    if (h) { x = x.replace(/^#+\s*/, ''); if (x.length < 120 && x.length > 1 && normTitle(x) !== normTitle(title)) paras.push({ t: 'h', x: x }); return; }
    if (/^[-*+]\s|^\d+\.\s/.test(blk) && x.length < 80) return;            // navigation lists
    if (/^(=+|-+)$/.test(x) || BOILER.test(x)) return;
    if (x.length < 40 && !/[。！？」]$/.test(x)) return;
    if ((blk.match(/\]\(/g) || []).length > 3 && x.length < 200) return;     // link clouds
    paras.push({ t: 'p', x: x });
  });
  while (paras.length && paras[paras.length - 1].t !== 'p') paras.pop();
  return { title: title, site: '', desc: '', image: '', date: '', paras: paras.slice(0, 120), chars: paras.reduce(function (s, p) { return s + (p.t === 'p' ? p.x.length : 0); }, 0) };
}
function buildReaderResult(it, url, art, err) {
  const out = { ok: true, id: it.id, url: url || it.u, src: it.s, ty: it.ty, d: it.d, title: it.t, tj: it.tj || '', image: '', paras: [], partial: true, err: err || '' };
  if (art) {
    out.image = art.image || '';
    if (art.title && art.title.length > 8 && !/^(home|news|top)$/i.test(art.title)) out.title = art.title.replace(/\s+[|\-–—]\s+[^|\-–—]{2,40}$/, '');
    if (art.site) out.src = art.site;
    if (art.doi) out.doi = art.doi;
    if (art.desc && art.paras.length < 2) out.paras.push({ t: 'p', x: art.desc });
    out.paras = out.paras.concat(art.paras);
    out.partial = art.chars < 600;
    if (art.desc && art.paras.length >= 2 && it.ty === 'paper') out.lead = art.desc;
  }
  if (!out.paras.length && it.x) out.paras.push({ t: 'p', x: it.x });
  if (out.image && out.paras.some(function (p) { return p.t === 'img' && p.src === out.image; })) out.image = '';
  return out;
}
function vapid_() {
  const props = PropertiesService.getScriptProperties();
  let d = props.getProperty('VAPID_D'), pub = props.getProperty('VAPID_PUB');
  if (!d || !pub) {
    const seed = [Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Date.now()].join('');
    const dd = P256.mod(P256.bytesToBig(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, seed)), P256.n - BI1) + BI1;
    const Q = P256.affine(P256.mul(dd, P256.G));
    d = dd.toString(16); pub = P256.b64u([4].concat(P256.bigTo32(Q[0]), P256.bigTo32(Q[1])));
    props.setProperty('VAPID_D', d); props.setProperty('VAPID_PUB', pub);
  }
  return { d: BigInt('0x' + d), pub: pub };
}
function vapidJwt_(aud) {
  const cache = CacheService.getScriptCache(), ck = 'jwt_' + hashId(aud);
  const hit = cache.get(ck); if (hit) return hit;
  const v = vapid_(), enc = function (o) { return Utilities.base64EncodeWebSafe(JSON.stringify(o)).replace(/=+$/, ''); };
  let sub = 'mailto:bme-radar@example.com';
  try { const em = Session.getEffectiveUser().getEmail(); if (em) sub = 'mailto:' + em; } catch (e) {}
  const input = enc({ typ: 'JWT', alg: 'ES256' }) + '.' + enc({ aud: aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: sub });
  const jwt = input + '.' + P256.signB64u(input, v.d);
  cache.put(ck, jwt, 6 * 3600);
  return jwt;
}
function sendPush_(s) {
  const aud = s.endpoint.match(/^https:\/\/[^\/]+/)[0];
  const r = UrlFetchApp.fetch(s.endpoint, { method: 'post', muteHttpExceptions: true, contentType: 'application/octet-stream', payload: '',
    headers: { TTL: '43200', Urgency: 'high', Authorization: 'vapid t=' + vapidJwt_(aud) + ', k=' + vapid_().pub } });
  const code = r.getResponseCode();
  return { ok: code >= 200 && code < 300, code: code, gone: code === 404 || code === 410, body: code >= 300 ? String(r.getContentText() || '').replace(/\s+/g, ' ').slice(0, 160) : '' };
}
const BI0 = BigInt(0);
const BI1 = BigInt(1);
const BI2 = BigInt(2);
const BI3 = BigInt(3);
const BI4 = BigInt(4);
const BI8 = BigInt(8);
const P256 = (function () {
  const p = BigInt('0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff');
  const n = BigInt('0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551');
  const G = [BigInt('0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296'), BigInt('0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5'), BI1];
  const mod = function (a, m) { const r = a % m; return r >= BI0 ? r : r + m; };
  const inv = function (a, m) { let lm = BI1, hm = BI0, low = mod(a, m), high = m; while (low > BI1) { const r = high / low; const nm = hm - lm * r, nw = high - low * r; hm = lm; lm = nm; high = low; low = nw; } return mod(lm, m); };
  const dbl = function (P) {
    if (!P || P[1] === BI0) return null;
    const X = P[0], Y = P[1], Z = P[2], YY = Y * Y % p, S = BI4 * X * YY % p, ZZ = Z * Z % p, M = BI3 * mod(X - ZZ, p) * (X + ZZ) % p;
    const X3 = mod(M * M - BI2 * S, p); return [X3, mod(M * (S - X3) - BI8 * YY * YY, p), BI2 * Y * Z % p];
  };
  const add = function (P, Q) {
    if (!P) return Q; if (!Q) return P;
    const Z1Z1 = P[2] * P[2] % p, Z2Z2 = Q[2] * Q[2] % p, U1 = P[0] * Z2Z2 % p, U2 = Q[0] * Z1Z1 % p;
    const S1 = P[1] * Q[2] % p * Z2Z2 % p, S2 = Q[1] * P[2] % p * Z1Z1 % p;
    if (U1 === U2) return S1 === S2 ? dbl(P) : null;
    const H = mod(U2 - U1, p), R = mod(S2 - S1, p), HH = H * H % p, HHH = H * HH % p, V = U1 * HH % p;
    const X3 = mod(R * R - HHH - BI2 * V, p); return [X3, mod(R * (V - X3) - S1 * HHH, p), H * P[2] % p * Q[2] % p];
  };
  const mul = function (k, P) { let R = null, Q = P; while (k > BI0) { if (k & BI1) R = add(R, Q); Q = dbl(Q); k >>= BI1; } return R; };
  const affine = function (P) { const zi = inv(P[2], p), zi2 = zi * zi % p; return [P[0] * zi2 % p, P[1] * zi2 % p * zi % p]; };
  const bytesToBig = function (b) { let h = ''; for (let i = 0; i < b.length; i++) h += ((b[i] & 255) + 256).toString(16).slice(1); return BigInt('0x' + (h || '0')); };
  const bigTo32 = function (x) { const h = x.toString(16).padStart(64, '0'), out = []; for (let i = 0; i < 64; i += 2) out.push(parseInt(h.substr(i, 2), 16)); return out; };
  const b64u = function (bytes) { return Utilities.base64EncodeWebSafe(bytes.map(function (x) { return x > 127 ? x - 256 : x; })).replace(/=+$/, ''); };
  const sha = function (str) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, str, Utilities.Charset.UTF_8); };
  const signB64u = function (msg, d) {
    const e = bytesToBig(sha(msg));
    for (let tries = 0; tries < 8; tries++) {
      const k = mod(bytesToBig(sha(Utilities.getUuid() + Utilities.getUuid() + msg + d.toString(16) + tries)), n - BI1) + BI1;
      const R = affine(mul(k, G)), r = mod(R[0], n); if (r === BI0) continue;
      const s = mod(inv(k, n) * (e + r * d), n); if (s === BI0) continue;
      return b64u(bigTo32(r).concat(bigTo32(s)));
    }
    throw new Error('sign failed');
  };
  return { p: p, n: n, G: G, mod: mod, mul: mul, affine: affine, bytesToBig: bytesToBig, bigTo32: bigTo32, b64u: b64u, signB64u: signB64u };
})();

