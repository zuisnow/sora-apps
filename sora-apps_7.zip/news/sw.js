const C='news-80457048';
const FILES=['./','./index.html','./app.js','./projects.js','./config.js','./manifest.json','./icon-192.png','./icon-512.png','./icon-maskable.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(FILES)));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('news-')&&k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);
  if(e.request.method!=='GET'||u.origin!==self.location.origin||u.hostname.endsWith('script.google.com')||u.hostname.endsWith('googleusercontent.com')||e.request.destination==='image')return;
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(hit=>{const net=fetch(e.request).then(res=>{if(res.ok||res.type==='opaque'){const cp=res.clone();caches.open(C).then(c=>c.put(e.request,cp));}return res;}).catch(()=>hit);return hit||net;}));});
self.addEventListener('push',e=>{e.waitUntil((async()=>{let m={title:'BMERadar',body:'新しい記事があります',url:'./',tag:'radar'};
  try{const c=await caches.open('radar-conf');const r=await c.match('./__conf');const conf=r?await r.json():null;
    if(conf&&conf.url){const res=await fetch(conf.url+(conf.url.includes('?')?'&':'?')+'v=push-latest&t='+Date.now());const j=await res.json();if(j&&j.ok)m=Object.assign(m,j);}}catch(err){}
  await self.registration.showNotification(m.title,{body:m.body,icon:'icon-192.png',badge:'icon-192.png',tag:m.tag,renotify:true,data:{url:m.url}});})());});
self.addEventListener('notificationclick',e=>{e.notification.close();const url=new URL((e.notification.data&&e.notification.data.url)||'./',self.registration.scope).href;
  e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(ws=>{for(const w of ws){if(w.url.startsWith(self.registration.scope)&&'focus' in w){return w.focus().then(x=>x.navigate?x.navigate(url):x);}}return clients.openWindow(url);}));});
