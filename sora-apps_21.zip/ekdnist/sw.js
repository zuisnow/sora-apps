const C='ekd-9dbfc2a3';
const FILES=['./','./index.html','./app.js','./engine.js','./seed.js','./config.js','./manifest.json','./icon-192.png','./icon-512.png','./icon-maskable.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(FILES.map(u=>new Request(u,{cache:'reload'})))));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('ekd-')&&k!=='ekd-conf'&&k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
/* network first so a new upload shows up at once; the cache is only for offline */
self.addEventListener('fetch',e=>{const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==self.location.origin||r.destination==='image')return;
  const req=r.mode==='navigate'?r:new Request(r.url,{cache:'no-cache',credentials:r.credentials});
  e.respondWith(fetch(req).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(c=>c.put(r,cp));}return res;}).catch(()=>caches.match(r,{ignoreSearch:true}).then(hit=>hit||caches.match('./index.html'))));});
self.addEventListener('push',e=>{e.waitUntil((async()=>{let m={title:'EKDNist',body:'新しい情報があります',url:'./',tag:'ekd'};
  try{const c=await caches.open('ekd-conf');const r=await c.match('./__conf');const conf=r?await r.json():null;
    if(conf&&conf.url){const res=await fetch(conf.url+(conf.url.includes('?')?'&':'?')+'v=push-latest&t='+Date.now());const j=await res.json();if(j&&j.ok)m=Object.assign(m,j);}}catch(err){}
  await self.registration.showNotification(m.title,{body:m.body,icon:'icon-192.png',badge:'icon-192.png',tag:m.tag,renotify:true,data:{url:m.url}});})());});
self.addEventListener('notificationclick',e=>{e.notification.close();const url=new URL((e.notification.data&&e.notification.data.url)||'./',self.registration.scope).href;
  e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(ws=>{for(const w of ws){if(w.url.startsWith(self.registration.scope)&&'focus' in w){return w.focus().then(x=>x.navigate?x.navigate(url):x);}}return clients.openWindow(url);}));});
