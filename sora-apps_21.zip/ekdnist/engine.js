/* EKDNist analysis engine — runs in the browser (window.EK) and in node for tests.
 * Input: one compact DB per race series (see gas/ekdnist/db.gs). Everything else is computed here:
 * 区間偏差値, ペース, 順位変動, 同一選手の名寄せと学年の推定, 歴代ランキング, 大学記録, 走りの特徴, 似た選手, 箱根の区間・オーダー予想. */
(function (root) {
  'use strict';
  const EK = {};
  const VAR = { '髙': '高', '﨑': '崎', '𣘺': '橋', '槗': '橋', '𠮷': '吉', '邊': '辺', '邉': '辺', '濵': '浜', '瀨': '瀬', '德': '徳', '惠': '恵', '曻': '昇', '靑': '青', '冨': '富', '桒': '桑', '舘': '館', '嶋': '島', '嵜': '崎', 'ヶ': 'ケ' };
  const norm = s => String(s || '').replace(/[\s　・.．･]/g, '').split('').map(c => VAR[c] || c).join('');
  const isKana = s => /^[゠-ヿ\s　・.．A-Za-zＡ-Ｚ]+$/.test(String(s || '').trim());
  const keysOf = s => { s = String(s || '').trim(); if (!isKana(s)) return [norm(s)]; const t = s.split(/[\s　・.．]+/).filter(x => x.length >= 3 && /[゠-ヿ]/.test(x)); return t.length ? t.map(norm) : [norm(s)]; };
  EK.norm = norm;
  const mean = a => a.length ? a.reduce((s, x) => s + x, 0) / a.length : null;
  const sdev = a => { if (a.length < 2) return null; const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) * (x - m), 0) / (a.length - 1)); };
  const r1 = x => x == null ? null : Math.round(x * 10) / 10;
  EK.fmt = t => { if (t == null || !isFinite(t) || t <= 0) return ''; t = Math.round(t); const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`; };
  EK.pace = p => p ? `${Math.floor(p / 60)}'${String(Math.round(p % 60)).padStart(2, '0')}"/km` : '';
  const SHORT = { '青山学院大学': '青学大', '國學院大學': '國學院大', '駒澤大学': '駒大', '早稲田大学': '早大', '中央大学': '中大', '順天堂大学': '順大', '日本大学': '日大', '中央学院大学': '中央学大', '山梨学院大学': '山梨学大',
    '大東文化大学': '大東大', '東京農業大学': '東農大', '専修大学': '専大', '日本体育大学': '日体大', '法政大学': '法大', '国士舘大学': '国士大', '明治大学': '明大', '武蔵野学院大学': '武蔵野学大', '拓殖大学': '拓大',
    '明治学院大学': '明学大', '流通経済大学': '流経大', '亜細亜大学': '亜大', '芝浦工業大学': '芝浦工大', '慶應義塾大学': '慶大', '東京経済大学': '東経大', '東京大学': '東大', '関西大学': '関大', '関西学院大学': '関学大',
    '京都産業大学': '京産大', '立命館大学': '立命大', '大阪経済大学': '大経大', '広島経済大学': '広経大', '北海道大学': '北大', '愛知工業大学': '愛知工大', '神奈川大学': '神奈川大', '東京国際大学': '東京国際大',
    'アイビーリーグ選抜': 'アイビー', '関東学生連合': '学生連合' };
  EK.short = u => SHORT[u] || String(u || '').replace(/大学$|大學$/, '大');

  /* ---------- building the model ---------- */
  function academicYear(date, y, month) {
    const m = date ? +date.slice(5, 7) : month || 4;
    return m >= 4 ? y : y - 1;
  }
  function sinceOf(db, leg) { const s = db.since; if (s == null) return 0; return Array.isArray(s) ? (s[leg - 1] || 0) : s; }
  function legTags(db, leg, km) {
    const t = ((db.tags || [])[leg - 1] || []).slice();
    if (km) t.push(km < 10 ? '短距離' : km < 15 ? '中距離' : 'ロング');
    if (db.key === 'hakone') t.push(leg <= 5 ? '往路' : '復路');
    return t;
  }
  const MONTH = { hakone: 1, izumo: 10, zen: 11, yosen: 10, zsel: 6, morinomiya: 10, fujisan: 12, kwj: 10, oga: 6 };

  EK.build = function (dbs) {
    const M = { series: {}, runs: [], stats: {}, runners: {}, univ: {}, order: [] };
    const list = Object.values(dbs).filter(d => d && d.E);
    // Hakone first: its runner ids are the official ones, everyone else is matched onto them
    list.sort((a, b) => (a.key === 'hakone' ? -1 : b.key === 'hakone' ? 1 : 0));
    list.forEach(db => {
      M.series[db.key] = db; M.order.push(db.key);
      db.E.forEach(e => {
        const ay = academicYear(e.d, e.y, MONTH[db.key]), dms = e.d ? Date.parse(e.d) : Date.UTC(e.y, (MONTH[db.key] || 1) - 1, 2);
        e.ay = ay; e.dms = dms; e.key = db.key;
        const teamRank = {}; (e.T || []).forEach(t => { teamRank[t[0]] = t[1] || null; });
        e._rank = teamRank;
        // running order after each leg, from the cumulative times (teams that did not finish a leg drop out)
        const cum = {}, crs = [];
        (e.L || []).forEach((runs, i) => {
          runs.forEach(x => { const c = cum[x[0]] = cum[x[0]] || { t: 0, k: 0, op: !!x[6] }; if (x[3] > 0 && c.k === i) { c.t += x[3]; c.k++; } });
          const ranked = Object.keys(cum).filter(u => cum[u].k === i + 1 && !cum[u].op).sort((a, b) => cum[a].t - cum[b].t), m = {};
          ranked.forEach((u, k) => { m[u] = k + 1; }); crs.push(m);
        });
        e._cum = cum;
        (e.L || []).forEach((runs, i) => {
          const leg = i + 1, km = (e.dist && e.dist[i]) || (db.dist && db.since != null && e.n >= sinceOf(db, leg) ? db.dist[i] : null);
          runs.forEach(x => {
            const R = db.R[x[1]] || [''];
            M.runs.push({ s: db.key, n: e.n, y: e.y, ay, d: dms, leg, km, u: db.U[x[0]], nm: R[0], rid: R[1] || null, g: x[2] || null, t: x[3] || null, lr: x[4] || null,
              cr: crs[i][x[0]] || x[5] || null, pcr: i > 0 ? (crs[i - 1][x[0]] || null) : null, fr: x[7] || null,
              op: !!x[6], team: teamRank[x[0]] || null, cmp: e.n >= sinceOf(db, leg), tags: legTags(db, leg, km) });
          });
        });
        (e.I || []).forEach(x => {
          const R = db.R[x[1]] || [''];
          M.runs.push({ s: db.key, n: e.n, y: e.y, ay, d: dms, leg: 0, km: db.indivKm || null, u: db.U[x[2]], nm: R[0], rid: null, g: x[3] || null, t: x[4] || null, lr: x[0] || null, cr: null, pcr: null, op: false, team: teamRank[x[2]] || null, cmp: true, tags: db.indivKm ? [db.indivKm > 20 ? 'ハーフ' : '10000m', '個人'] : ['個人'] });
        });
        (e.A || []).forEach(x => {
          const R = db.R[x[1]] || [''], km = e.dist ? e.dist[x[0] - 1] : null;
          M.runs.push({ s: db.key, n: e.n, y: e.y, ay, d: dms, leg: x[0], km, u: db.U[x[2]], nm: R[0], rid: null, g: x[3] || null, t: x[4] || null, lr: 1, cr: null, pcr: null, op: false, team: teamRank[x[2]] || null, cmp: true, rec: !!x[5], awardOnly: true, tags: legTags(db, x[0], km) });
        });
      });
    });
    // distribution of each leg in each edition
    const groups = {};
    M.runs.forEach(r => { if (r.t > 0 && !r.awardOnly) (groups[r.s + '|' + r.n + '|' + r.leg] = groups[r.s + '|' + r.n + '|' + r.leg] || []).push(r.t); });
    Object.keys(groups).forEach(k => {
      const a = groups[k].slice().sort((x, y) => x - y), med = a[Math.floor(a.length / 2)], keep = a.filter(t => t <= med * 1.15);
      const m = mean(keep), sd = Math.max(sdev(keep) || 0, m * 0.006, 5);
      M.stats[k] = { n: a.length, best: a[0], med, mean: m, sd, times: a };
    });
    M.runs.forEach(r => {
      const S = M.stats[r.s + '|' + r.n + '|' + r.leg];
      if (S && r.t > 0 && S.n >= 5) { r.dev = Math.max(15, Math.min(90, 50 + 10 * (S.mean - r.t) / S.sd)); r.gap = r.t - S.best; }
      if (r.t > 0 && r.km) r.pace = r.t / r.km;
      if (r.lr === 1) r.award = true;
    });
    linkRunners(M);
    // universities
    M.runs.forEach(r => { const U = M.univ[r.u] = M.univ[r.u] || { name: r.u, runs: [], series: {} }; U.runs.push(r); U.series[r.s] = 1; });
    return M;
  };

  /* the same student across races: 公式ID (箱根) or name + university + a consistent entry year */
  function linkRunners(M) {
    const byKey = {};
    let nx = 0;
    const sorted = M.runs.slice().sort((a, b) => (a.s === 'hakone' ? 0 : 1) - (b.s === 'hakone' ? 0 : 1) || a.d - b.d);
    const entryOf = r => r.g && r.g <= 4 ? r.ay - r.g + 1 : null;
    sorted.forEach(r => {
      const keys = keysOf(r.nm).map(k => r.u + '|' + k);
      let P = null;
      if (r.rid) P = M.runners['h' + r.rid];
      if (!P) {
        const cand = [];
        keys.forEach(k => (byKey[k] || []).forEach(id => { if (cand.indexOf(id) < 0) cand.push(id); }));
        const e = entryOf(r);
        const fit = cand.map(id => M.runners[id]).filter(p => {
          if (r.rid && p.rid && p.rid !== r.rid) return false;
          if (e != null && p.entry != null && Math.abs(p.entry - e) > 0) return false;
          if (p.runs.some(x => x.s === r.s && x.n === r.n)) return false;
          const span = p.runs.map(x => x.ay); const lo = Math.min(...span), hi = Math.max(...span);
          if (r.ay - lo > 5 || hi - r.ay > 5) return false;
          if (p.entry != null && (r.ay - p.entry > 5 || r.ay < p.entry)) return false;
          return true;
        }).sort((a, b) => Math.abs(a.last - r.d) - Math.abs(b.last - r.d));
        P = fit[0] || null;
      }
      if (!P) {
        const id = r.rid ? 'h' + r.rid : 'x' + (++nx);
        P = M.runners[id] = { id, nm: r.nm, u: r.u, rid: r.rid, runs: [], entry: null, last: 0, women: !!(M.series[r.s] || {}).women };
      }
      P.runs.push(r); r.p = P.id; P.last = Math.max(P.last, r.d);
      if (P.entry == null && entryOf(r) != null) P.entry = entryOf(r);
      if (r.rid && !P.rid) P.rid = r.rid;
      if (r.nm.length > P.nm.length && !r.rid) P.nm = P.nm;   // keep the first spelling
      keys.forEach(k => { const l = byKey[k] = byKey[k] || []; if (l.indexOf(P.id) < 0) l.push(P.id); });
    });
    Object.values(M.runners).forEach(P => {
      P.runs.sort((a, b) => a.d - b.d || a.leg - b.leg);
      P.runs.forEach(r => { if (!r.g && P.entry != null) { const g = r.ay - P.entry + 1; if (g >= 1 && g <= 4) { r.g = g; r.gi = true; } } });
      const nm = P.runs.find(r => r.s === 'hakone') || P.runs.find(r => !/^[A-Z]\./.test(r.nm)) || P.runs[0];
      P.nm = nm.nm;
    });
  }

  /* ---------- what kind of runner ---------- */
  EK.profile = function (M, id) {
    const P = M.runners[id]; if (!P) return null;
    const runs = P.runs, dv = runs.filter(r => r.dev != null), now = Date.now();
    const w = r => 1 / (1 + Math.max(0, (now - r.d) / 3.15e10));
    const wavg = a => { const s = a.reduce((x, r) => x + w(r), 0); return s ? a.reduce((x, r) => x + r.dev * w(r), 0) / s : null; };
    const avg = mean(dv.map(r => r.dev)), cur = wavg(dv);
    const by = f => { const o = {}; dv.forEach(r => [].concat(f(r)).forEach(k => { if (!k) return; (o[k] = o[k] || []).push(r.dev); })); Object.keys(o).forEach(k => { o[k] = { n: o[k].length, avg: mean(o[k]), best: Math.max(...o[k]) }; }); return o; };
    const byTag = by(r => r.tags), byS = by(r => r.s), byG = by(r => r.g ? r.g + '年' : null);
    const moves = runs.filter(r => r.pcr && r.cr && !r.op).map(r => r.pcr - r.cr);
    const sd = sdev(dv.map(r => r.dev));
    let slope = null;
    if (dv.length >= 3 && (dv[dv.length - 1].d - dv[0].d) > 2.6e10) {
      const xs = dv.map(r => (r.d - dv[0].d) / 3.15e10), ys = dv.map(r => r.dev), mx = mean(xs), my = mean(ys);
      const sxx = xs.reduce((s, x) => s + (x - mx) * (x - mx), 0);
      if (sxx > 0) slope = xs.reduce((s, x, i) => s + (x - mx) * (ys[i] - my), 0) / sxx;
    }
    const pf = { P, runs, avg, cur, best: dv.length ? dv.slice().sort((a, b) => b.dev - a.dev)[0] : null, byTag, byS, byG, move: moves.length ? mean(moves) : null, moves: moves.length, sd, slope,
      awards: runs.filter(r => r.award && !r.op).length, top3: runs.filter(r => r.lr && r.lr <= 3 && !r.op).length, n: runs.length, ndev: dv.length };
    pf.grade = gradeNow(P);
    pf.labels = labels(pf);
    pf.vec = features(pf);
    return pf;
  };
  function gradeNow(P) {
    if (P.entry == null) return null;
    const d = new Date(), ay = d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1, g = ay - P.entry + 1;
    return g >= 1 && g <= 4 ? g : g > 4 ? 'OB' : null;
  }
  function labels(pf) {
    const out = [], T = pf.byTag, A = pf.avg;
    if (A == null) return out;
    const vs = (k, name, th) => { if (T[k] && T[k].n >= 1 && pf.ndev - T[k].n >= 1) { const d = T[k].avg - A; if (d >= th) out.push({ k: name + 'に強い', v: `${name}区間の偏差値 ${r1(T[k].avg)}（平均より +${r1(d)}）`, good: true }); else if (d <= -th) out.push({ k: name + 'は苦手', v: `${name}区間の偏差値 ${r1(T[k].avg)}（平均より ${r1(d)}）` }); } };
    vs('上り', '上り', 3); vs('下り', '下り', 3);
    if (T['ロング'] && (T['短距離'] || T['中距離'])) {
      const sh = T['短距離'] || T['中距離'], d = T['ロング'].avg - sh.avg;
      if (d >= 3) out.push({ k: 'ロング型', v: `15km以上で ${r1(T['ロング'].avg)}、それより短い区間で ${r1(sh.avg)}`, good: true });
      else if (d <= -3) out.push({ k: 'スピード型', v: `短い区間で ${r1(sh.avg)}、15km以上で ${r1(T['ロング'].avg)}`, good: true });
    }
    if (pf.move != null && pf.moves >= 2) { if (pf.move >= 1.5) out.push({ k: '順位を上げる走り', v: `襷を受けてから平均 ${r1(pf.move)} 人抜き（${pf.moves}区間）`, good: true }); else if (pf.move <= -1.5) out.push({ k: '順位を落としがち', v: `平均 ${r1(-pf.move)} 人に抜かれる（${pf.moves}区間）` }); }
    if (pf.sd != null && pf.ndev >= 3) { if (pf.sd < 3.5) out.push({ k: '安定感', v: `偏差値のばらつき ${r1(pf.sd)}（${pf.ndev}レース）`, good: true }); else if (pf.sd > 8) out.push({ k: '好不調の波', v: `偏差値のばらつき ${r1(pf.sd)}` }); }
    if (pf.byS.hakone && Object.keys(pf.byS).length > 1) { const others = pf.runs.filter(r => r.dev != null && r.s !== 'hakone').map(r => r.dev); const d = pf.byS.hakone.avg - mean(others); if (d >= 3) out.push({ k: '箱根で上積み', v: `箱根 ${r1(pf.byS.hakone.avg)} / ほかの大会 ${r1(mean(others))}`, good: true }); }
    if (pf.slope != null) { if (pf.slope >= 2) out.push({ k: '伸び盛り', v: `1年あたり偏差値 +${r1(pf.slope)}`, good: true }); else if (pf.slope <= -2) out.push({ k: '下降気味', v: `1年あたり偏差値 ${r1(pf.slope)}` }); }
    if (T['エース'] && T['エース'].avg >= 60) out.push({ k: 'エース区間で通用', v: `エース区間の偏差値 ${r1(T['エース'].avg)}（${T['エース'].n}回）`, good: true });
    if (pf.awards >= 2) out.push({ k: `区間賞 ${pf.awards}回`, v: '', good: true });
    if (pf.byG['1年'] && pf.byG['1年'].avg >= 60) out.push({ k: '1年目から主力', v: `1年時の偏差値 ${r1(pf.byG['1年'].avg)}`, good: true });
    return out;
  }
  function features(pf) {
    const T = pf.byTag, A = pf.avg; if (A == null) return null;
    const rel = k => T[k] ? T[k].avg - A : null;
    const long = T['ロング'] && (T['短距離'] || T['中距離']) ? T['ロング'].avg - (T['短距離'] || T['中距離']).avg : null;
    return [A, rel('上り'), rel('下り'), long, pf.move != null ? pf.move * 2 : null, pf.slope, pf.sd != null ? pf.sd / 2 : null];
  }
  const FEAT = ['全体の水準', '上り', '下り', '距離の得意', '順位の上げ下げ', '伸び方', '安定感'], FW = [1, 0.8, 0.8, 0.7, 0.5, 0.5, 0.4];
  EK.similar = function (M, id, k) {
    const me = EK.profile(M, id); if (!me || !me.vec) return [];
    const out = [];
    Object.keys(M.runners).forEach(oid => {
      if (oid === id) return;
      const P = M.runners[oid]; if (P.runs.filter(r => r.dev != null).length < 2 || P.women !== M.runners[id].women) return;
      const o = EK.profile(M, oid); if (!o.vec) return;
      let s = 0, n = 0; const parts = [];
      for (let i = 0; i < FEAT.length; i++) { if (me.vec[i] == null || o.vec[i] == null) continue; const d = (me.vec[i] - o.vec[i]) * FW[i]; s += d * d; n++; parts.push([i, Math.abs(d)]); }
      if (n < 2 || (me.vec.filter(v => v != null).length >= 3 && n < 3)) return;
      const dist = Math.sqrt(s / n) + (7 - n) * 0.6;
      parts.sort((a, b) => a[1] - b[1]);
      out.push({ id: oid, dist, pf: o, why: parts.slice(0, 2).map(p => FEAT[p[0]]) });
    });
    return out.sort((a, b) => a.dist - b.dist).slice(0, k || 8);
  };

  /* ---------- predictions for the next Hakone ---------- */
  EK.hakoneRef = function (M) {
    const db = M.series.hakone; if (!db) return null;
    const full = db.E.filter(e => e.L && e.L.length === 10).sort((a, b) => b.n - a.n);
    if (!full.length) return null;
    const ref = [];
    for (let leg = 1; leg <= 10; leg++) {
      const eds = full.filter(e => e.n >= sinceOf(db, leg)).slice(0, 3), use = eds.length ? eds : full.slice(0, 3);
      const S = use.map(e => M.stats['hakone|' + e.n + '|' + leg]).filter(Boolean);
      if (!S.length) { ref.push(null); continue; }
      ref.push({ leg, mean: mean(S.map(s => s.mean)), sd: mean(S.map(s => s.sd)), last: S[0].times, eds: use.map(e => e.n), km: db.dist ? db.dist[leg - 1] : null, tags: legTags(db, leg, db.dist ? db.dist[leg - 1] : null) });
    }
    return { ref, last: full[0] };
  };
  function legEstimate(pf, ref, recentOnly) {
    const now = Date.now(), dv = pf.runs.filter(r => r.dev != null && (!recentOnly || now - r.d < 2.2 * 3.15e10));
    if (!dv.length) return null;
    const w = r => 1 / (1 + (now - r.d) / 3.15e10) * (r.s === 'hakone' ? 1.3 : r.leg === 0 ? 0.8 : 1);
    const ws = dv.reduce((s, r) => s + w(r), 0), base = dv.reduce((s, r) => s + r.dev * w(r), 0) / ws;
    let adj = 0, k = 0;
    ref.tags.forEach(t => { const T = pf.byTag[t]; if (!T || pf.avg == null) return; adj += (T.avg - pf.avg) * T.n / (T.n + 2); k++; });
    const est = base + (k ? adj / k : 0) + (pf.slope != null ? Math.max(-2, Math.min(3, pf.slope)) * 0.3 : 0);
    return { est, n: dv.length };
  }
  EK.predictLegs = function (M, id) {
    const H = EK.hakoneRef(M), pf = EK.profile(M, id); if (!H || !pf) return [];
    return H.ref.map(ref => {
      if (!ref) return null;
      const e = legEstimate(pf, ref); if (!e) return null;
      const t = ref.mean - (e.est - 50) / 10 * ref.sd;
      return { leg: ref.leg, t, est: e.est, n: e.n, rank: 1 + ref.last.filter(x => x < t).length, of: ref.last.length, km: ref.km };
    }).filter(Boolean);
  };
  /* best order for one university: who runs which leg so that the predicted total is lowest */
  EK.predictTeam = function (M, univ, nextAy) {
    const H = EK.hakoneRef(M); if (!H) return null;
    const cands = Object.values(M.runners).filter(P => P.u === univ && P.runs.some(r => r.dev != null && nextAy - r.ay <= 1) && (P.entry == null ? P.runs.every(r => !r.g || nextAy - r.ay + r.g <= 4) : nextAy - P.entry + 1 <= 4 && nextAy - P.entry + 1 >= 1));
    const rows = cands.map(P => { const pf = EK.profile(M, P.id); return { id: P.id, nm: P.nm, g: P.entry != null ? nextAy - P.entry + 1 : null, est: H.ref.map(ref => { const e = ref && legEstimate(pf, ref, true); return e ? e.est : null; }) }; }).filter(r => r.est.some(x => x != null));
    const fill = 42;
    const val = (r, L) => { const ref = H.ref[L]; const d = r ? (r.est[L] != null ? r.est[L] : fill) : fill; return ref.mean - (d - 50) / 10 * ref.sd; };
    const legs = H.ref.map((x, i) => i).filter(i => H.ref[i]);
    // greedy, then swaps until nothing improves
    const asg = {}, used = {};
    const order = legs.slice().sort((a, b) => H.ref[b].sd - H.ref[a].sd);
    order.forEach(L => { let best = null; rows.forEach((r, i) => { if (used[i]) return; const v = val(r, L); if (!best || v < best.v) best = { i, v }; }); if (best) { asg[L] = best.i; used[best.i] = 1; } else asg[L] = -1; });
    let improved = true, guard = 0;
    while (improved && guard++ < 200) {
      improved = false;
      for (const a of legs) for (const b of legs) { if (a >= b) continue; const ia = asg[a], ib = asg[b]; const cur = val(rows[ia], a) + val(rows[ib], b), sw = val(rows[ib], a) + val(rows[ia], b); if (sw < cur - 0.01) { asg[a] = ib; asg[b] = ia; improved = true; } }
      for (const a of legs) rows.forEach((r, i) => { if (Object.values(asg).indexOf(i) >= 0) return; if (val(r, a) < val(rows[asg[a]], a) - 0.01) { asg[a] = i; improved = true; } });
    }
    const order10 = legs.map(L => { const r = rows[asg[L]]; return { leg: L + 1, id: r ? r.id : null, nm: r ? r.nm : '（データのない選手）', g: r ? r.g : null, t: val(r, L), est: r ? r.est[L] : null }; });
    return { univ, total: order10.reduce((s, x) => s + x.t, 0), order: order10, pool: rows.length, short: Math.max(0, 10 - rows.length) };
  };
  /* the field for the next Hakone: last year's top 10 + this autumn's 予選会 top 10 */
  EK.hakoneField = function (M) {
    const db = M.series.hakone, yo = M.series.yosen; if (!db) return null;
    const last = db.E.filter(e => e.T && e.T.length).sort((a, b) => b.n - a.n)[0]; if (!last) return null;
    const next = last.n + 1, nextAy = last.ay + 1;
    const seeds = last.T.filter(t => t[1] && t[1] <= 10).map(t => db.U[t[0]]);
    const yE = yo && yo.E.find(e => e.n === next), quals = yE && yE.T ? yE.T.filter(t => t[1] && t[1] <= 10).map(t => yo.U[t[0]]) : [];
    const teams = Array.from(new Set(seeds.concat(quals))).map(u => Object.assign(EK.predictTeam(M, u, nextAy) || { univ: u, total: null, order: [] }, { seed: seeds.indexOf(u) >= 0, qual: quals.indexOf(u) >= 0 }));
    teams.sort((a, b) => (a.total || 1e9) - (b.total || 1e9));
    return { next, nextAy, teams, haveYosen: !!yE };
  };

  /* ---------- records ---------- */
  EK.legRanking = function (M, s, leg, o) {
    o = o || {};
    let rs = M.runs.filter(r => r.s === s && r.leg === leg && r.t > 0 && (o.all || r.cmp) && !r.awardOnly && (!o.g || r.g === o.g) && (!o.u || r.u === o.u));
    rs.sort((a, b) => a.t - b.t);
    if (o.unique) { const seen = {}; rs = rs.filter(r => { if (seen[r.p]) return false; seen[r.p] = 1; return true; }); }
    return rs.slice(0, o.limit || 50);
  };
  EK.since = (M, s, leg) => sinceOf(M.series[s], leg);
  EK.winners = function (M, s) {
    const db = M.series[s]; if (!db) return [];
    const out = {};
    (db.H.W || []).forEach(w => { out[w[0]] = { n: w[0], y: w[1], u: w[2] >= 0 ? db.U[w[2]] : '', t: w[3] || null, u2: w[4] >= 0 ? db.U[w[4]] : '', u3: w[5] >= 0 ? db.U[w[5]] : '', cancel: !!w[6], out: w[7] || null, ret: w[8] || null }; });
    db.E.forEach(e => {
      const T = (e.T || []).filter(t => t[1]).sort((a, b) => a[1] - b[1]); if (!T.length) return;
      const o = out[e.n] = out[e.n] || { n: e.n, y: e.y };
      o.u = db.U[T[0][0]]; o.t = T[0][2] || o.t; o.out = T[0][3] || o.out; o.ret = T[0][4] || o.ret; o.y = e.y;
      if (T[1]) o.u2 = db.U[T[1][0]]; if (T[2]) o.u3 = db.U[T[2][0]];
      o.full = !!e.L || !!e.I;
    });
    return Object.values(out).sort((a, b) => b.n - a.n);
  };
  EK.winCounts = function (M, s) { const c = {}; EK.winners(M, s).forEach(w => { if (!w.u) return; (c[w.u] = c[w.u] || []).push(w); }); return Object.keys(c).map(u => ({ u, n: c[u].length, last: c[u][0] })).sort((a, b) => b.n - a.n || b.last.n - a.last.n); };
  EK.totalRanking = function (M, s, o) {
    o = o || {}; const db = M.series[s]; if (!db) return [];
    const minSince = db.since == null ? 0 : Array.isArray(db.since) ? Math.max(...db.since) : db.since;
    const out = [];
    db.E.forEach(e => { if (!o.all && e.n < minSince) return; (e.T || []).forEach(t => { if (t[2] > 0 && (t[1] || o.withOpen)) out.push({ n: e.n, y: e.y, u: db.U[t[0]], t: t[2], rank: t[1], out: t[3], ret: t[4] }); }); });
    return out.sort((a, b) => a.t - b.t).slice(0, o.limit || 50);
  };
  EK.awardCounts = function (M, s) {
    const byU = {}, byP = {};
    M.runs.forEach(r => { if (r.s !== s || !r.award || r.op) return; byU[r.u] = (byU[r.u] || 0) + 1; (byP[r.p] = byP[r.p] || []).push(r); });
    return { univ: Object.keys(byU).map(u => ({ u, n: byU[u] })).sort((a, b) => b.n - a.n), runners: Object.keys(byP).filter(p => byP[p].length >= 2).map(p => ({ p, runs: byP[p] })).sort((a, b) => b.runs.length - a.runs.length) };
  };
  EK.univRecords = function (M, u, s) {
    const db = M.series[s]; if (!db) return null;
    const legs = [];
    for (let leg = 1; leg <= (db.legs || 0); leg++) { const b = EK.legRanking(M, s, leg, { u, limit: 3 }); legs.push({ leg, best: b[0] || null, top: b, since: sinceOf(db, leg) }); }
    const tot = EK.totalRanking(M, s, { limit: 500 }).filter(x => x.u === u);
    const best = tot[0] || null;
    let members = [];
    if (best) { const e = db.E.find(x => x.n === best.n); const ui = db.U.indexOf(u); if (e && e.L) members = e.L.map((runs, i) => { const x = runs.find(z => z[0] === ui); return x ? M.runs.find(r => r.s === s && r.n === e.n && r.leg === i + 1 && r.u === u) : null; }); }
    const hist = db.E.filter(e => e.T).map(e => { const ui = db.U.indexOf(u), t = e.T.find(x => x[0] === ui); return t ? { n: e.n, y: e.y, rank: t[1] || null, t: t[2], op: !!t[5] } : null; }).filter(Boolean);
    const W = EK.winners(M, s).filter(w => w.u === u);
    return { legs, best, members, hist, wins: W, top3: hist.filter(h => h.rank && h.rank <= 3).length, top10: hist.filter(h => h.rank && h.rank <= 10).length, apps: hist.length,
      awards: M.runs.filter(r => r.s === s && r.u === u && r.award && !r.op).length };
  };
  EK.edition = function (M, s, n) {
    const db = M.series[s]; if (!db) return null;
    const e = db.E.find(x => x.n === n); if (!e) return null;
    const runs = M.runs.filter(r => r.s === s && r.n === n);
    const legs = [];
    (e.L || []).forEach((_, i) => legs.push(runs.filter(r => r.leg === i + 1).sort((a, b) => (a.t || 1e9) - (b.t || 1e9))));
    const teams = (e.T || []).map(t => ({ u: db.U[t[0]], rank: t[1] || null, t: t[2] || null, out: t[3] || null, ret: t[4] || null, op: !!t[5] }));
    if (s === 'hakone' && e.L && e.L.length === 10) teams.forEach(T => { if (!T.out) { const a = legs.slice(0, 5).map(l => (l.find(r => r.u === T.u) || {}).t); if (a.every(x => x)) T.out = a.reduce((x, y) => x + y, 0); } if (!T.ret && T.out && T.t) T.ret = T.t - T.out; });
    teams.sort((a, b) => (a.rank || 999) - (b.rank || 999) || (a.t || 1e9) - (b.t || 1e9));
    // running order by leg (for the chart)
    const bump = teams.filter(t => !t.op).map(t => ({ u: t.u, ranks: legs.map(l => { const r = l.find(x => x.u === t.u); return r ? r.cr : null; }) }));
    const indiv = runs.filter(r => r.leg === 0).sort((a, b) => a.lr - b.lr);
    const awards = runs.filter(r => r.awardOnly);
    return { db, e, teams, legs, bump, indiv, awards, stats: legs.map((_, i) => M.stats[s + '|' + n + '|' + (i + 1)] || null) };
  };
  /* this season's strongest: the average 区間偏差値 over the current academic year */
  EK.season = function (M, ay, o) {
    o = o || {};
    const byP = {};
    M.runs.forEach(r => { if (r.ay !== ay || r.dev == null || (o.women != null && !!(M.series[r.s] || {}).women !== o.women)) return; (byP[r.p] = byP[r.p] || []).push(r); });
    return Object.keys(byP).map(p => ({ p, P: M.runners[p], n: byP[p].length, avg: mean(byP[p].map(r => r.dev)), runs: byP[p] })).filter(x => x.n >= (o.min || 1)).sort((a, b) => b.avg - a.avg || b.n - a.n).slice(0, o.limit || 60);
  };
  EK.search = function (M, q, limit) {
    q = norm(q); if (!q) return [];
    const out = [];
    Object.values(M.runners).forEach(P => { const k = norm(P.nm); if (k.indexOf(q) >= 0 || P.runs.some(r => norm(r.nm).indexOf(q) >= 0)) out.push(P); });
    return out.sort((a, b) => b.last - a.last).slice(0, limit || 40);
  };
  EK.academicNow = () => { const d = new Date(); return d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1; };

  if (typeof module !== 'undefined') module.exports = EK; else root.EK = EK;
})(typeof window !== 'undefined' ? window : this);
