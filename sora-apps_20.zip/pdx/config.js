// PDXRadar 用 GAS のウェブアプリURLをここに貼ると、どの端末でも最初から取得先が入った状態になります。合言葉はアプリの設定画面で入力します。
window.PDX_CONFIG = { gasUrl: '' };
