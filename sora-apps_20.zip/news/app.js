'use strict';
/* BMERadar — reader for the feed built by gas/news/Code.gs */
const CATS=[['brain','脳・神経'],['imaging','医用画像'],['sensing','生体計測・ウェアラブル'],['implant','人工臓器・埋込機器'],['regen','再生医療・材料'],['robot','手術支援・ロボット・補綴'],['ai','AI・デジタルヘルス'],['therapy','治療機器・DDS']];
const CATN=Object.fromEntries(CATS);
const TYPES=[['all','すべて'],['news','ニュース'],['paper','論文'],['reg','承認・規制'],['trial','臨床試験'],['biz','企業・資金'],['acad','大学・学会・公募']];
const TYPEN=Object.fromEntries(TYPES);
const LS={cache:'radar-cache-v1',read:'radar-read-v1',bm:'radar-bm-v1',cfg:'radar-cfg-v1',prefs:'radar-prefs-v1',dev:'radar-dev-v1'};
const app=document.getElementById('app');
const st={view:'today',type:'all',cat:'',bci:false,q:'',stocks:null,stocksAt:0,range:'1M',openQ:'',briefKey:'',feed:null,loading:false,err:'',limit:50,msg:{},busy:'',search:false,
  older:[],olderDone:false,olderBusy:false,sr:null,open:{},seenAt:0,acct:'',dev:{mode:'list',id:''}};
const H=36e5;
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function lsGet(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch(e){return d;}}
function lsSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function cfg(){const c=lsGet(LS.cfg,{});
  return{url:c.url||(window.NEWS_CONFIG&&window.NEWS_CONFIG.gasUrl)||'',pass:c.pass||'',img:c.img!==false,group:c.group!==false,seen:c.seen||0,tr:c.tr||'under',inapp:c.inapp!==false,rdja:!!c.rdja,push:c.push||null};}
function setCfg(k,v){const c=lsGet(LS.cfg,{});c[k]=v;lsSet(LS.cfg,c);}
function prefs(){const p=lsGet(LS.prefs,{});return{watch:(p.watch||[]).slice(),muted:(p.muted||[]).slice(),tickers:p.tickers?p.tickers.slice():null,univ:p.univ?p.univ.slice():null,translate:p.translate!==false,reader3p:p.reader3p!==false,email:Object.assign({on:true,hour:7,to:'',max:15},p.email||{}),synced:!!p.synced};}
function setPrefs(p){lsSet(LS.prefs,p);wre=watchRe(p.watch);}
function watchRe(ws){ws=(ws||[]).filter(Boolean);return ws.length?new RegExp(ws.map(w=>w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'),'i'):null;}
let wre=watchRe(prefs().watch);
const isWatch=it=>!!(wre&&wre.test(it.t+' '+(it.tj||'')+' '+(it.x||'')+' '+it.s));
const readSet=new Set(lsGet(LS.read,[]));
function markRead(id){readSet.add(id);lsSet(LS.read,[...readSet].slice(-5000));}
function bmGet(){return lsGet(LS.bm,{updated:0,items:{}});}
const pad=n=>String(n).padStart(2,'0');
const WD='日月火水木金土';
function ago(ms){const m=Math.round((Date.now()-ms)/60000);if(m<1)return'たった今';if(m<60)return m+'分前';const h=Math.round(m/60);if(h<24)return h+'時間前';const d=new Date(ms);return `${d.getMonth()+1}/${d.getDate()}`;}
function dayKey(ms){const d=new Date(ms);return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;}
function dayLabel(ms){const d=new Date(ms),t=new Date(),y=new Date(t.getFullYear(),t.getMonth(),t.getDate()-1);
  const md=`${d.getMonth()+1}月${d.getDate()}日（${WD[d.getDay()]}）`;
  if(dayKey(ms)===dayKey(t.getTime()))return['今日',md];if(dayKey(ms)===dayKey(y.getTime()))return['昨日',md];return[md,''];}
function fmtWhen(ms){if(!ms)return'—';const d=new Date(ms);return `${d.getMonth()+1}/${d.getDate()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;}
function edOf(ms){const h=new Date(ms).getHours();return h>=4&&h<14?'am':'pm';}

/* ---------- sample shown before the GAS URL is set ---------- */
const now0=Date.now();
const SAMPLE={sample:true,updated:0,items:[
  {id:'s1',t:'（表示例）BCI と脳・神経の記事は「今日」と「BCI」の上のほうに並びます',s:'Google News',d:now0-2*H,f:now0,ty:'news',b:1,g:['brain','robot'],l:'ja',x:'同じ話題を複数の媒体が報じたときは1つにまとめ、件数を添えます。'},
  {id:'s2',t:'（表示例）FDA の 510(k)・PMA、PMDA や厚生労働省の発表は「承認・規制」に入ります',s:'FDA 510(k)',d:now0-5*H,f:now0,ty:'reg',g:['sensing'],l:'ja',x:''},
  {id:'s3',t:'（表示例）PubMed・Nature Biomedical Engineering・arXiv・bioRxiv の新着論文',s:'PubMed',d:now0-9*H,f:now0,ty:'paper',g:['imaging','ai'],l:'ja',x:''},
  {id:'s4',t:'（表示例）ClinicalTrials.gov に新しく登録された医療機器の臨床試験',s:'ClinicalTrials.gov',d:now0-20*H,f:now0,ty:'trial',g:['therapy'],l:'ja',x:''},
  {id:'s5',t:'（表示例）大学の研究成果、学会の演題募集、研究費の公募',s:'東京農工大学',d:now0-26*H,f:now0,ty:'acad',g:['regen'],l:'ja',x:''},
],highlights:['s2','s3','s4','s5'],brain:['s1'],bci:['s1'],trends:[],stats:[],sources:[]};

/* ---------- network ---------- */
function gasGet(params){const c=cfg();const u=new URL(c.url);Object.entries(params||{}).forEach(([k,v])=>{if(v!==''&&v!=null)u.searchParams.set(k,v);});u.searchParams.set('t',Date.now());
  return fetch(u.toString()).then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.error||'取得できませんでした');return j;});}
async function post(body){const c=cfg();if(!c.url)throw new Error('GAS の URL が未設定です');if(!c.pass)throw new Error('合言葉が未設定です');
  let r;try{r=await fetch(c.url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(Object.assign({pass:c.pass},body))});}catch(e){throw new Error('GAS に接続できません');}
  const j=await r.json();if(!j.ok)throw new Error(j.error==='auth'?'合言葉が違います':j.error==='busy'?'収集中です。少し待ってからもう一度':j.error||'失敗しました');return j;}
async function loadFeed(){const c=cfg();
  if(!st.feed){st.feed=lsGet(LS.cache,null)||(c.url?null:SAMPLE);}
  if(!c.url){st.feed=SAMPLE;render();return;}
  st.loading=true;st.err='';render();
  try{const j=await gasGet();j.fetchedAt=Date.now();st.feed=j;st.older=[];st.olderDone=false;lsSet(LS.cache,j);setTimeout(prefetchBodies,1500);}
  catch(e){st.err=navigator.onLine===false?'オフラインです。前回取得した記事を表示しています':'取得できませんでした。設定の URL を確認してください';}
  if(!st.feed)st.feed={items:[],highlights:[],brain:[],trends:[],stats:[],sources:[]};
  st.loading=false;render();}
function gotPrefs(j){st.acct=j.email||'';st.briefKey=j.briefKey||'';st.pushSt=j.push||null;setPrefs(Object.assign({},j.prefs,{synced:true}));}
async function syncPrefs(){const c=cfg();if(!c.url||!c.pass)return;try{gotPrefs(await post({action:'prefs-get',endpoint:c.push&&c.push.endpoint}));render();}catch(e){}}
async function loadStocks(force){const c=cfg();if(!c.url||(st.feed&&st.feed.sample))return;if(!force&&Date.now()-st.stocksAt<4*60e3)return;
  st.stocksAt=Date.now();try{st.stocks=await gasGet({v:'stocks'});lsSet('radar-stocks-v1',st.stocks);}catch(e){}if(st.view==='bci')render();}
let prefTimer=null;
function pushPrefs(){const q=prefs();const body={watch:q.watch,muted:q.muted,email:q.email,translate:q.translate,reader3p:q.reader3p};if(q.tickers)body.tickers=q.tickers;if(q.univ)body.univ=q.univ;return post({action:'prefs-set',prefs:body}).then(j=>{setPrefs(Object.assign({},j.prefs,{synced:true}));return j;});}
function savePrefs(p){setPrefs(Object.assign({},p,{synced:false}));render();
  const c=cfg();if(!c.url||!c.pass)return;clearTimeout(prefTimer);
  prefTimer=setTimeout(()=>{pushPrefs().then(()=>{st.msg.prefs=null;if(st.view==='settings')render();}).catch(e=>{st.msg.prefs=[e.message,1];render();});},1200);}
/* bookmarks and dev notes share the same sync pattern */
function syncer(key,load,save){let timer=null;
  return{get:()=>lsGet(key,{updated:0,items:{}}),
    put(o){o.updated=Date.now();lsSet(key,o);const c=cfg();if(c.url&&c.pass){clearTimeout(timer);timer=setTimeout(()=>{post({action:save,items:lsGet(key,{items:{}}).items}).then(j=>{const x=lsGet(key,{items:{}});x.updated=j.updated;lsSet(key,x);}).catch(()=>{});},2500);}},
    async pull(){const c=cfg();if(!c.url||!c.pass)return;try{const j=await post({action:load});const local=lsGet(key,{updated:0,items:{}});
      if((j.updated||0)>local.updated){lsSet(key,{updated:j.updated,items:j.items||{}});render();}
      else if(local.updated>(j.updated||0)&&Object.keys(local.items).length){const s=await post({action:save,items:local.items});local.updated=s.updated;lsSet(key,local);}}catch(e){}}};}
const BM=syncer(LS.bm,'bm-load','bm-save'),DEV=syncer(LS.dev,'dev-load','dev-save');
function findItem(id){return allItems().find(x=>x.id===id)||(st.sr&&st.sr.items.find(x=>x.id===id))||bmGet().items[id]||null;}
function toggleBm(id){const b=BM.get();if(b.items[id])delete b.items[id];else{const it=findItem(id);if(!it)return;b.items[id]=Object.assign({},it,{saved:Date.now()});}BM.put(b);render();}
async function loadOlder(){if(st.olderBusy||!cfg().url||st.feed.sample)return;st.olderBusy=true;render();
  const list=filtered(allItems());const before=list.length?Math.min(...list.map(i=>i.d)):Date.now();
  try{const j=await gasGet({v:'more',before,type:st.type==='all'?'':st.type,cat:st.cat,bci:st.bci?1:''});const have=new Set(allItems().map(i=>i.id));
    const add=j.items.filter(i=>!have.has(i.id));st.older=st.older.concat(add);if(!add.length)st.olderDone=true;st.limit=heads(filtered(allItems())).length;}
  catch(e){st.err='古い記事を読み込めませんでした';}
  st.olderBusy=false;render();}
async function searchArchive(){const q=st.q.trim();if(!q||!cfg().url||st.feed.sample)return;st.sr={q,items:[],loading:true};render();
  try{const j=await gasGet({v:'search',q,type:st.type==='all'?'':st.type,cat:st.cat,bci:st.bci?1:''});st.sr={q,items:j.items,more:j.more};}
  catch(e){st.sr={q,items:[],err:'検索できませんでした'};}render();}

/* ---------- selection ---------- */
function feedItems(){return st.feed?st.feed.items||[]:[];}
function allItems(){return feedItems().concat(st.older);}
function byId(){const m={};allItems().forEach(i=>m[i.id]=i);return m;}
function matchQ(it,q){if(!q)return true;const hay=(it.t+' '+(it.tj||'')+' '+(it.x||'')+' '+it.s+' '+(it.un||'')).toLowerCase();return q.toLowerCase().split(/\s+/).filter(Boolean).every(w=>hay.includes(w));}
function filtered(list){return list.filter(it=>(st.type==='all'||it.ty===st.type)&&(!st.cat||(it.g||[]).includes(st.cat))&&(!st.bci||it.b)&&matchQ(it,st.q));}
function heads(list){return cfg().group?list.filter(i=>!i.c):list;}
function children(id){return allItems().filter(i=>i.c===id).sort((a,b)=>a.d-b.d);}

/* ---------- pieces ---------- */
const ICON={refresh:'<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
  search:'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>',
  bm:'<svg viewBox="0 0 24 24"><path d="M6.5 3.5h11v17l-5.5-4-5.5 4z"/></svg>',
  back:'<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
  ext:'<svg viewBox="0 0 24 24"><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>'};
function titleOf(it){const c=cfg();return it.l!=='ja'&&it.tj&&c.tr==='main'?it.tj:it.t;}
function itemHtml(it,o){o=o||{};const c=cfg();
  const saved=!!bmGet().items[it.id],w=isWatch(it),ja=it.l==='ja',tj=!ja&&it.tj&&c.tr!=='off'?it.tj:'';
  const a=`href="${esc(it.u||'#')}" target="_blank" rel="noopener" data-read="${esc(it.id)}"`;
  const title=tj&&c.tr==='main'?`<a class="ttl ja" ${a}>${esc(tj)}</a><div class="tj en">${esc(it.t)}</div>`:`<a class="ttl ${ja?'ja':''}" ${a}>${esc(it.t)}</a>${tj?`<div class="tj">${esc(tj)}</div>`:''}`;
  const cats=(it.g||[]).slice(0,3).map(g=>CATN[g]).filter(Boolean).join(' / ');
  const img=c.img&&it.im?`<img class="thumb" src="${esc(it.im)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">`:'';
  const cov=it.n>1&&c.group?`<button class="cov" data-open="${esc(it.id)}">${st.open[it.id]?'閉じる':`ほか${it.n-1}件`}</button>`:'';
  const kids=st.open[it.id]?`<ul class="cluster">${children(it.id).map(k=>`<li><a href="${esc(k.u)}" target="_blank" rel="noopener" data-read="${esc(k.id)}"><b>${esc(k.s)}</b>${esc(titleOf(k))}</a></li>`).join('')}</ul>`:'';
  const isNew=st.seenAt&&it.f>st.seenAt&&!readSet.has(it.id);
  return `<article class="${readSet.has(it.id)?'read':''} ${o.lead?'lead':''}">
    <div class="meta">${isNew?'<i class="new" title="前回から"></i>':''}<span class="src">${esc(it.s)}</span><span>${ago(it.d)}</span>${it.ty!=='news'&&TYPEN[it.ty]?`<span class="k">${TYPEN[it.ty]}</span>`:''}${it.b?'<span class="k bci">BCI</span>':''}${it.un?`<button class="univ" data-term="${esc(it.un)}">${esc(it.un)}</button>`:''}${w?'<span class="w">ウォッチ</span>':''}${st.feed&&st.feed.sample?'<span class="smp">表示例</span>':''}${cov}</div>
    <div class="body">${title}${it.x&&!o.compact?`<div class="snip">${esc(it.x)}</div>`:''}${cats&&!o.nocat?`<div class="cats">${cats}</div>`:''}</div>
    <div class="side">${img}<button class="bm ${saved?'on':''}" data-bm="${esc(it.id)}" aria-label="${saved?'しおりを外す':'しおりを付ける'}">${ICON.bm}</button></div>${kids}</article>`;}
function compactList(items){return `<ul class="compact">${items.map(it=>`<li><a href="${esc(it.u||'#')}" target="_blank" rel="noopener" data-read="${esc(it.id)}"><span>${esc(it.s)}・${ago(it.d)}</span>${esc(titleOf(it))}</a></li>`).join('')}</ul>`;}
function listHtml(items,emptyText){if(!items.length)return `<p class="empty">${emptyText||'記事はまだありません'}</p>`;
  let h='',last='';for(const it of items){const k=dayKey(it.d);if(k!==last){last=k;const [a,b]=dayLabel(it.d);h+=`<div class="day">${a}${b?`<span>${b}</span>`:''}</div>`;}h+=itemHtml(it);}return h;}
const sec=(title,sub,right)=>`<div class="sec"><h2>${title}</h2>${sub||right?`<small>${right||sub}</small>`:''}</div>`;
function setupPanel(){return `<section class="panel"><h3>取得先を設定する</h3><ol>
  <li>ニュース用の GAS プロジェクトに gas/news/Code.gs を貼り、setup を一度実行</li><li>ウェブアプリとしてデプロイし、URL をコピー</li><li>「設定」に URL と合言葉を入れる</li></ol>
  <div class="row"><button class="btn pri" data-view="settings">設定を開く</button></div></section>`;}
const errHtml=()=>st.err?`<p class="msg bad">${esc(st.err)}</p>`:'';

/* ---------- 朝刊・夕刊（Claude のまとめ） ---------- */
function briefFresh(){const b=st.feed&&st.feed.brief;return b&&Date.now()-b.at<14*H?b:null;}
function briefLi(list){return list.map(x=>`<li>${esc(x.text)}${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener" data-rdu="${esc(x.url)}">記事</a>`:''}</li>`).join('');}
function edName(ed){return ed==='am'?'朝刊':'夕刊';}

/* ---------- 今日 ---------- */
function todayView(){const c=cfg(),f=st.feed||{items:[]},m=byId(),now=Date.now(),b=briefFresh();
  const d24=feedItems().filter(i=>i.d>=now-24*H);
  const tc={};d24.forEach(i=>tc[i.ty]=(tc[i.ty]||0)+1);
  const pick=ids=>(ids||[]).map(id=>m[id]).filter(Boolean);
  const brain=pick(f.brain),hi=pick(f.highlights);
  const shown=new Set(brain.concat(hi).map(i=>i.id));
  const watch=wre?heads(feedItems()).filter(i=>isWatch(i)&&!shown.has(i.id)).sort((a,b)=>b.d-a.d).slice(0,5):[];
  const t=new Date(),ed=b?(b.ed||edOf(b.at)):edOf(now);
  const edBlock=`<div class="ed"><div class="ed-k"><b>${edName(ed)}</b>${b?`<span>${b.points.length+b.bci.length} 本</span>`:'<span>まとめはまだ届いていません</span>'}</div>
    ${b?`${b.headline?`<p class="ed-h">${esc(b.headline)}</p>`:''}${b.points.length?`<ul class="ed-l">${briefLi(b.points)}</ul>`:''}${b.bci.length?`<div class="ed-s">BCI</div><ul class="ed-l">${briefLi(b.bci)}</ul>`:''}${b.watch?`<p class="ed-w">${esc(b.watch)}</p>`:''}<p class="ed-by">${fmtWhen(b.at)}</p>`:''}
    <p class="counts">過去24時間に <b class="num">${d24.length}</b> 件。${TYPES.slice(1).filter(([k])=>tc[k]).map(([k,n])=>`<button data-jump="${k}">${n} ${tc[k]}</button>`).join('・')}</p></div>`;
  return `<div class="g">${!c.url?setupPanel():''}${errHtml()}${edBlock}
    ${brain.length?sec('脳・神経','この3日間')+brain.map((it,i)=>itemHtml(it,{lead:i===0,compact:i>0,nocat:true})).join(''):''}
    ${hi.length?sec('注目','分野ごと')+hi.map(it=>itemHtml(it,{compact:true})).join(''):''}
    ${watch.length?sec('ウォッチ中の言葉',prefs().watch.slice(0,3).join('・'))+compactList(watch):''}
    ${!brain.length&&!hi.length?'<p class="empty">まだ記事がありません</p>':''}
    <div class="row" style="justify-content:center;margin-top:26px"><button class="btn" data-view="feed">新着をすべて見る</button></div></div>`;}

/* ---------- BCI ---------- */
const PRIVATE=[['Neuralink',/Neuralink/i],['Synchron',/\bSynchron\b|Stentrode/i],['Precision Neuroscience',/Precision Neuroscience/i],['Paradromics',/Paradromics/i],
  ['Science Corp.',/Science Corp/i],['Blackrock Neurotech',/Blackrock Neurotech/i],['Merge Labs',/Merge Labs/i],['BrainCo',/\bBrainCo\b/i],['INBRAIN',/\bINBRAIN\b/i],['Axoft',/Axoft/i],['Neurable',/Neurable/i],['Cognixion',/Cognixion/i]];
const RANGES=[['1M',31],['6M',183],['1Y',366]];
function rangeHist(q){const days=(RANGES.find(r=>r[0]===st.range)||RANGES[0])[1];const from=Date.now()-days*864e5;return (q.h||[]).filter(x=>x[0]>=from);}
const fmtP=(v,cur)=>v==null?'—':(cur==='JPY'?Math.round(v).toLocaleString():v>=1000?v.toLocaleString(undefined,{maximumFractionDigits:0}):v.toFixed(2));
function chgHtml(ch){if(ch==null||!isFinite(ch))return '<span class="chg">—</span>';return `<span class="chg ${ch>0?'up':ch<0?'dn':''}">${ch>0?'+':''}${ch.toFixed(2)}%</span>`;}
function lineSvg(h,W,Hh){if(h.length<2)return'';const xs=h.map(x=>x[0]),ys=h.map(x=>x[1]);const x0=xs[0],x1=xs[xs.length-1],lo=Math.min(...ys),hi=Math.max(...ys),sp=hi-lo||1;
  const X=t=>(t-x0)/(x1-x0||1)*(W-4)+2,Y=v=>Hh-3-(v-lo)/sp*(Hh-6);
  return `<svg viewBox="0 0 ${W} ${Hh}" preserveAspectRatio="none" aria-hidden="true"><path d="${h.map((p,i)=>(i?'L':'M')+X(p[0]).toFixed(1)+' '+Y(p[1]).toFixed(1)).join(' ')}" vector-effect="non-scaling-stroke"/></svg>`;}
function bigChart(q){const h=rangeHist(q);if(h.length<2)return '<p class="msg">履歴がありません</p>';
  const W=640,Hh=180,pl=8,pr=46,pt=10,pb=22,ys=h.map(x=>x[1]),lo=Math.min(...ys),hi=Math.max(...ys),pd=(hi-lo)*0.08||hi*0.02||1,a=lo-pd,b=hi+pd;
  const X=i=>pl+i/(h.length-1)*(W-pl-pr),Y=v=>pt+(Hh-pt-pb)*(1-(v-a)/(b-a));
  let g='';for(let k=0;k<=3;k++){const v=a+(b-a)*k/3;g+=`<line class="grid" x1="${pl}" x2="${W-pr}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}"/><text class="ax" x="${W-pr+6}" y="${(Y(v)+4).toFixed(1)}">${fmtP(v,q.cur)}</text>`;}
  const d=h.map((p,i)=>(i?'L':'M')+X(i).toFixed(1)+' '+Y(p[1]).toFixed(1)).join(' ');
  const lab=[0,Math.floor((h.length-1)/2),h.length-1].map(i=>{const t=new Date(h[i][0]);return `<text class="ax" x="${X(i).toFixed(1)}" y="${Hh-4}" text-anchor="${i===0?'start':i===h.length-1?'end':'middle'}">${st.range==='1M'?(t.getMonth()+1)+'/'+t.getDate():t.getFullYear()%100+'/'+(t.getMonth()+1)}</text>`;}).join('');
  const unit=q.cur==='JPY'?'円':q.cur==='USD'?'ドル':esc(q.cur||'');
  const hits=h.map((p,i)=>{const t=new Date(p[0]),w=(W-pl-pr)/(h.length-1);return `<rect x="${(X(i)-w/2).toFixed(1)}" y="${pt}" width="${w.toFixed(2)}" height="${Hh-pt-pb}" fill="transparent" data-tip="${t.getFullYear()}/${t.getMonth()+1}/${t.getDate()}" data-v="${fmtP(p[1],q.cur)}" data-u="${unit}" data-x="${X(i).toFixed(1)}" data-y="${Y(p[1]).toFixed(1)}"/>`;}).join('');
  return `<div class="chart qchart" data-chart="1"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="${esc(q.n)}の株価の推移">${g}<path class="qline" d="${d}"/><line class="xhair" x1="0" x2="0" y1="${pt}" y2="${Hh-pb}" style="display:none"/><circle class="xdot" r="4" style="display:none"/>${lab}${hits}</svg><div class="tip"></div></div>`;}
function stockRow(q){const h=rangeHist(q),pch=h.length>1?(h[h.length-1][1]-h[0][1])/h[0][1]*100:null,open=st.openQ===q.s;
  const news=open&&q.k?heads(allItems()).filter(it=>new RegExp(q.k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i').test(it.t+' '+(it.x||''))).sort((a,b)=>b.d-a.d).slice(0,5):[];
  return `<li class="q"><button class="qrow" data-q="${esc(q.s)}" aria-expanded="${open}">
    <span class="qn"><b>${esc(q.n)}</b><small>${esc(q.s)}${q.ex?'・'+esc(q.ex):''}</small></span><span class="qs">${lineSvg(h,84,28)}</span>
    <span class="qp"><b>${fmtP(q.p,q.cur)}</b>${q.ok===false&&!q.p?'<span class="chg">取得できません</span>':chgHtml(q.ch)}</span></button>
    ${open?`<div class="qd"><div class="qmeta"><span>${esc(st.range)}の変化 ${pch==null?'—':(pch>0?'+':'')+pch.toFixed(1)+'%'}</span><span>${q.cur||''}・${q.st==='REGULAR'?'取引中':'終値'}・${fmtWhen(q.t)}</span></div>${bigChart(q)}
      ${news.length?compactList(news):''}</div>`:''}</li>`;}
function bciView(){const c=cfg(),items=heads(allItems()).filter(i=>i.b).sort((a,b)=>b.d-a.d),b=briefFresh();
  const m=byId(),top=((st.feed&&st.feed.bci)||[]).map(id=>m[id]).filter(Boolean);
  const research=items.filter(i=>i.ty==='acad'||i.ty==='paper').slice(0,8);
  const topIds=new Set(top.map(i=>i.id).concat(research.map(i=>i.id)));
  const rest=items.filter(i=>!topIds.has(i.id)&&i.ty!=='acad'&&i.ty!=='paper').slice(0,10);
  const sq=st.stocks||lsGet('radar-stocks-v1',null),quotes=sq&&sq.quotes||[];
  const priv=PRIVATE.map(([n,re])=>{const hit=allItems().filter(it=>re.test(it.t+' '+(it.x||''))).sort((a,b)=>b.d-a.d);return{n,hit:hit[0],cnt:hit.length};});
  return `<div class="g">${!c.url?setupPanel():''}${errHtml()}
    ${b&&b.bci.length?`<div class="ed"><div class="ed-k"><b>${edName(b.ed||edOf(b.at))}・BCI</b><span>${fmtWhen(b.at)}</span></div><ul class="ed-l">${briefLi(b.bci)}</ul></div>`:''}
    ${sec('注目','この7日間')}${top.length?top.slice(0,6).map((it,i)=>itemHtml(it,{lead:i===0,compact:i>0,nocat:true})).join(''):'<p class="msg">まだありません</p>'}
    ${sec('株価',sq&&sq.updated?'15分ごと・'+fmtWhen(sq.updated):'')}
    <div class="rng">${RANGES.map(([k])=>`<button class="fb ${st.range===k?'on':''}" data-range="${k}">${k}</button>`).join('')}</div>
    ${quotes.length?`<ul class="qlist">${quotes.map(stockRow).join('')}</ul><p class="note">米国株はほぼリアルタイム、ほかは最大20分ほど遅れます。銘柄は設定で変えられます。</p>`:'<p class="msg">まだ株価がありません</p>'}
    ${sec('非上場の主要企業','資金調達や提携の記事で追う')}
    <ul class="plist">${priv.map(p=>`<li><button data-term="${esc(p.n)}"><b>${esc(p.n)}</b><span>${p.hit?esc(titleOf(p.hit)):'最近の記事はありません'}</span><em>${p.hit?ago(p.hit.d):''}${p.cnt?`・${p.cnt}件`:''}</em></button></li>`).join('')}</ul>
    ${sec('大学・研究機関の発表と論文')}${research.length?research.map(it=>itemHtml(it,{compact:true,nocat:true})).join(''):'<p class="msg">まだありません</p>'}
    ${sec('そのほかのBCIニュース')}${rest.length?compactList(rest):'<p class="msg">まだありません</p>'}
    <div class="row" style="justify-content:center;margin-top:26px"><button class="btn" data-act="bci-all">BCI の記事をすべて見る</button></div></div>`;}

/* ---------- 新着 ---------- */
function feedView(){const c=cfg();
  if(st.sr)return searchView();
  const base=allItems();
  const count=(ty,cat)=>heads(base.filter(it=>(ty==='all'||it.ty===ty)&&(!cat||(it.g||[]).includes(cat))&&(!st.bci||it.b)&&matchQ(it,st.q))).length;
  const shown=heads(filtered(base)).sort((a,b)=>b.d-a.d);
  const canOlder=c.url&&st.feed&&!st.feed.sample&&!st.olderDone;
  return `<div class="g"><div class="feed-top"><button class="back" data-view="today">${ICON.back}今日</button><span>すべての新着</span></div>
    ${st.search?`<div class="search"><input id="q" type="search" placeholder="キーワード（英語・日本語）" value="${esc(st.q)}" autocomplete="off" enterkeyhint="search"></div>
      ${st.q.trim()&&c.url?`<div class="sr-note"><span>読み込み済みの記事から ${shown.length} 件</span><button class="link" data-act="archive">過去1年分から探す</button></div>`:''}`:''}
    <div class="filt">${TYPES.map(([k,n])=>`<button class="fb ${st.type===k?'on':''}" data-type="${k}">${n}<small>${count(k,st.cat)}</small></button>`).join('')}</div>
    <div class="filt sub"><button class="fb ${st.bci?'on':''}" data-bcit="1">BCI だけ</button><button class="fb ${!st.cat?'on':''}" data-cat="">全分野</button>${CATS.map(([k,n])=>`<button class="fb ${st.cat===k?'on':''}" data-cat="${k}">${n}<small>${count(st.type,k)}</small></button>`).join('')}</div>
    ${!c.url?setupPanel():''}${errHtml()}
    ${listHtml(shown.slice(0,st.limit),st.q?'見つかりませんでした':'該当する記事はありません')}
    ${shown.length>st.limit?`<button class="btn more" data-more="1">さらに表示（残り ${shown.length-st.limit} 件）</button>`:
      canOlder?`<button class="btn more" data-act="older" ${st.olderBusy?'disabled':''}>${st.olderBusy?'読み込み中…':'さらに前の記事を読み込む'}</button>`:''}</div>`;}
function searchView(){const s=st.sr,list=cfg().group?s.items.filter(i=>!i.c):s.items;
  return `<div class="g"><div class="feed-top"><button class="back" data-view="today">${ICON.back}今日</button><span>検索</span></div><div class="search"><input id="q" type="search" value="${esc(st.q)}" autocomplete="off" enterkeyhint="search"></div>
    <div class="sr-note"><span>${s.loading?'検索しています…':s.err?esc(s.err):`過去1年分から「${esc(s.q)}」 ${list.length}${s.more?'+':''} 件${st.type!=='all'?'・'+TYPEN[st.type]:''}`}</span><button class="link" data-act="sr-close">閉じる</button></div>
    <div class="filt">${TYPES.map(([k,n])=>`<button class="fb ${st.type===k?'on':''}" data-type="${k}">${n}</button>`).join('')}</div>
    ${s.loading?'':listHtml(list,'見つかりませんでした')}</div>`;}
function savedView(){const items=Object.values(bmGet().items).sort((a,b)=>(b.saved||0)-(a.saved||0));
  return `<div class="g">${items.length?listHtml(items):'<p class="empty">しおりを付けた記事がここに並びます</p>'}</div>`;}

/* ---------- 開発 ---------- */
const STATUS=['アイデア','調べている','設計中','作っている','まとめ中','完了'];
const PROJ=window.PROJECTS||[];
function devAll(){return DEV.get();}
function devNote(id){return devAll().items[id]||null;}
function devSave(n){const o=devAll();n.updated=Date.now();o.items[n.id]=n;DEV.put(o);}
function devNew(fields){const id='n'+Date.now().toString(36);const n=Object.assign({id,title:'新しい開発ノート',status:'アイデア',goal:'',todos:[],links:[],memo:'',proj:'',created:Date.now()},fields||{});devSave(n);return n;}
function linkOf(it){return{id:it.id,t:titleOf(it),u:it.u,s:it.s};}
function claudePrompt(o){const lines=['医工学の開発の相談です。私は医工学を学んでいる大学2年生です。',`テーマ：${o.title}`];
  if(o.lead)lines.push(`概要：${o.lead}`);if(o.goal)lines.push(`目的：${o.goal}`);if(o.status)lines.push(`今の段階：${o.status}`);
  if(o.todos&&o.todos.length)lines.push('やること：\n'+o.todos.map(t=>`- ${t.done?'[済] ':''}${t.t}`).join('\n'));
  if(o.links&&o.links.length)lines.push('参考にしている記事：\n'+o.links.slice(0,6).map(l=>`- ${l.t}（${l.s}） ${l.u}`).join('\n'));
  if(o.memo)lines.push(`メモ：${o.memo.slice(0,800)}`);
  lines.push('お願い：学生が手の届く範囲で、構成案・必要な部品やデータ・作業の順番・つまずきやすい点・安全と倫理の注意を、具体的に提案してください。');
  return lines.join('\n\n');}
async function askClaude(text){let copied=false;try{await navigator.clipboard.writeText(text);copied=true;}catch(e){}
  window.open('https://claude.ai/new?q='+encodeURIComponent(text.slice(0,3500)),'_blank','noopener');
  st.msg.dev=[copied?'相談文をコピーして Claude を開きました。入力欄が空なら貼り付けて送ってください。':'Claude を開きました。'];render();}
function devListView(){const notes=Object.values(devAll().items).sort((a,b)=>b.updated-a.updated);
  return `${sec('開発ノート','',`<button class="link" data-dev="new">＋ 新しいノート</button>`)}
    ${notes.length?`<ul class="dev-list">${notes.map(n=>{const done=n.todos.filter(t=>t.done).length;return `<li><button data-dev="note:${esc(n.id)}"><b>${esc(n.title)}</b><span>${esc(n.status)}・${fmtWhen(n.updated)}${n.links.length?`・記事 ${n.links.length}`:''}</span><em>${n.todos.length?`${done}/${n.todos.length}`:''}</em></button></li>`;}).join('')}</ul>`:
      '<p class="note" style="margin-top:10px">記事を読んでいて「これを作ってみたい」と思ったら、記事の画面の下の「開発ノートに追加」から始められます。下のプロジェクトから始めることもできます。</p>'}
    ${sec('はじめてのプロジェクト','学生が手の届く範囲で')}
    <ul class="dev-list">${PROJ.map(p=>`<li><button data-dev="proj:${p.id}"><b>${esc(p.title)}</b><span>${p.level}・${esc(p.cost)}${p.hw?'':'・部品なし'}</span><em>›</em></button></li>`).join('')}</ul>`;}
function projView(p){const re=new RegExp(p.kw,'i'),rel=heads(allItems()).filter(it=>re.test(it.t+' '+(it.x||''))).sort((a,b)=>b.d-a.d).slice(0,5);
  return `<button class="back" data-dev="list">${ICON.back}開発</button><div class="proj"><h2>${esc(p.title)}</h2><p class="lead">${esc(p.lead)}</p>
    <dl class="facts"><dt>難しさ</dt><dd>${p.level}</dd><dt>費用の目安</dt><dd>${esc(p.cost)}</dd><dt>時間の目安</dt><dd>${esc(p.time)}</dd></dl>
    <h3>必要なもの</h3><ul>${p.parts.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>
    <h3>手順</h3><ol>${p.steps.map(x=>`<li>${esc(x)}</li>`).join('')}</ol>
    <h3>学べること</h3><ul>${p.learn.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>
    <h3>次の一歩</h3><ul>${p.next.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>
    ${p.hw?`<p class="warn">${esc(window.PROJECT_SAFETY||'')}</p>`:''}
    <p class="note">費用は通販での目安です。店や時期で変わります。</p>
    <div class="row"><button class="btn pri" data-dev="start:${p.id}">このプロジェクトで始める</button><button class="btn" data-dev="askp:${p.id}">Claude に相談する</button></div>
    ${rel.length?sec('関連する最近の記事')+compactList(rel):''}</div>`;}
function noteView(n){const opts=STATUS.map(s=>`<option ${n.status===s?'selected':''}>${s}</option>`).join('');
  return `<button class="back" data-dev="list">${ICON.back}開発</button><div class="proj">
    <label class="lbl" for="n_title">タイトル</label><input id="n_title" class="inp" data-nf="title" value="${esc(n.title)}">
    <div class="two"><div><label class="lbl" for="n_st">段階</label><select id="n_st" class="inp" data-nf="status">${opts}</select></div><div><label class="lbl">更新</label><p class="note" style="margin-top:12px">${fmtWhen(n.updated)}</p></div></div>
    <label class="lbl" for="n_goal">目的・作りたいもの</label><textarea id="n_goal" class="inp" data-nf="goal" placeholder="例：脳波で目を閉じたことを検出して、LED を点けたい">${esc(n.goal)}</textarea>
    <h3>やること</h3><ul class="todo">${n.todos.map((t,i)=>`<li class="${t.done?'done':''}"><input type="checkbox" data-todo="${i}" ${t.done?'checked':''} aria-label="済み"><span>${esc(t.t)}</span><button data-dev="deltodo:${i}" aria-label="消す">×</button></li>`).join('')}</ul>
    <div class="addrow"><input id="todo_add" class="inp" placeholder="やることを追加" autocomplete="off" enterkeyhint="done"><button class="btn" data-dev="addtodo">追加</button></div>
    <h3>参考にしている記事</h3>${n.links.length?`<ul class="compact">${n.links.map((l,i)=>`<li style="display:flex;align-items:center"><a href="${esc(l.u)}" target="_blank" rel="noopener" data-read="${esc(l.id)}" style="flex:1"><span>${esc(l.s)}</span>${esc(l.t)}</a><button class="bm" data-dev="dellink:${i}" aria-label="外す">×</button></li>`).join('')}</ul>`:'<p class="note">記事の画面の下の「開発ノートに追加」から入れられます。</p>'}
    <label class="lbl" for="n_memo">メモ</label><textarea id="n_memo" class="inp" data-nf="memo" placeholder="部品、調べたこと、つまずいたこと">${esc(n.memo)}</textarea>
    <div class="row"><button class="btn pri" data-dev="ask:${esc(n.id)}">Claude に相談する</button><button class="btn" data-dev="del:${esc(n.id)}">このノートを消す</button></div></div>`;}
function devView(){const d=st.dev;let body;
  if(d.mode==='proj'){const p=PROJ.find(x=>x.id===d.id);body=p?projView(p):devListView();}
  else if(d.mode==='note'){const n=devNote(d.id);body=n?noteView(n):devListView();}
  else body=devListView();
  return `<div class="g">${body}${st.msg.dev?`<p class="msg">${esc(st.msg.dev[0])}</p>`:''}</div>`;}
function devAction(a,e){const [k,v]=a.split(':');
  if(k==='list'){st.dev={mode:'list',id:''};}
  else if(k==='new'){const n=devNew();st.dev={mode:'note',id:n.id};}
  else if(k==='note'){st.dev={mode:'note',id:v};}
  else if(k==='proj'){st.dev={mode:'proj',id:v};}
  else if(k==='start'){const p=PROJ.find(x=>x.id===v);const n=devNew({title:p.title,goal:p.lead,proj:p.id,todos:p.steps.map(s=>({t:s,done:false})),memo:'必要なもの：\n'+p.parts.map(x=>'・'+x).join('\n')});st.dev={mode:'note',id:n.id};}
  else if(k==='askp'){const p=PROJ.find(x=>x.id===v);askClaude(claudePrompt({title:p.claude,lead:p.lead,todos:p.steps.map(s=>({t:s}))}));return;}
  else if(k==='ask'){const n=devNote(v);if(n)askClaude(claudePrompt(n));return;}
  else if(k==='del'){if(!confirm('このノートを消しますか？'))return;const o=devAll();delete o.items[v];DEV.put(o);st.dev={mode:'list',id:''};}
  else if(k==='addtodo'){addTodo();return;}
  else if(k==='deltodo'){const n=devNote(st.dev.id);n.todos.splice(+v,1);devSave(n);}
  else if(k==='dellink'){const n=devNote(st.dev.id);n.links.splice(+v,1);devSave(n);}
  st.msg.dev=null;render();if(k!=='deltodo'&&k!=='dellink')scrollTo(0,0);}
function addTodo(){const el=document.getElementById('todo_add');const v=(el&&el.value||'').trim();if(!v)return;const n=devNote(st.dev.id);n.todos.push({t:v,done:false});devSave(n);render();document.getElementById('todo_add')?.focus();}

/* ---------- 傾向 ---------- */
function barChart(stats){const W=640,Hh=150,pl=28,pb=20,pt=8,n=stats.length,max=Math.max(4,...stats.map(s=>s.total));
  const step=Math.pow(10,Math.floor(Math.log10(max)));const tick=[1,2,5,10].map(m=>m*step).find(t=>max/t<=4)||step;
  const top=Math.ceil(max/tick)*tick,y=v=>pt+(Hh-pt-pb)*(1-v/top),bw=(W-pl)/n;
  let g='';for(let v=0;v<=top;v+=tick)g+=`<line class="grid" x1="${pl}" x2="${W}" y1="${y(v)}" y2="${y(v)}"/><text class="ax" x="${pl-6}" y="${y(v)+4}" text-anchor="end">${v}</text>`;
  let b='';stats.forEach((s,i)=>{const x=pl+i*bw+1,w=Math.max(2,bw-2),h=Math.max(0,y(0)-y(s.total));
    if(h>0)b+=`<rect x="${x.toFixed(1)}" y="${y(s.total).toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" fill="var(--blue)"/>`;
    b+=`<rect x="${(pl+i*bw).toFixed(1)}" y="${pt}" width="${bw.toFixed(1)}" height="${Hh-pt-pb}" fill="transparent" data-tip="${+s.day.slice(5,7)}/${+s.day.slice(8)}" data-v="${s.total}"/>`;});
  let ax='';stats.forEach((s,i)=>{if((n-1-i)%7===0)ax+=`<text class="ax" x="${(pl+i*bw+bw/2).toFixed(1)}" y="${Hh-4}" text-anchor="middle">${+s.day.slice(5,7)}/${+s.day.slice(8)}</text>`;});
  return `<div class="chart" data-chart="1"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="30日間の1日あたり件数">${g}${b}${ax}</svg><div class="tip"></div></div>`;}
function spark(vals){const W=120,Hh=30,max=Math.max(1,...vals),n=vals.length;
  return `<svg viewBox="0 0 ${W} ${Hh}" preserveAspectRatio="none" aria-hidden="true"><path d="${vals.map((v,i)=>(i?'L':'M')+(i*(W-4)/(n-1)+2).toFixed(1)+' '+(Hh-3-(Hh-6)*v/max).toFixed(1)).join(' ')}" vector-effect="non-scaling-stroke"/></svg>`;}
function trendsView(){const f=st.feed||{},stats=f.stats||[],terms=f.trends||[];
  if(!stats.length)return `<div class="g">${!cfg().url?setupPanel():''}<p class="empty">収集が進むと、分野ごとの件数の推移と、増えている言葉がここに出ます</p></div>`;
  const sum=(a,b,fn)=>stats.slice(a,b).reduce((s,d)=>s+fn(d),0);
  const cells=CATS.map(([k,n])=>{const vals=stats.map(d=>d.cats[k]||0),w1=sum(23,30,d=>d.cats[k]||0),w0=sum(16,23,d=>d.cats[k]||0),diff=w1-w0;
    return `<button class="mcell" data-gocat="${k}"><div class="nm">${n}</div><div class="v"><b>${w1}</b><span>7日・前週${diff>=0?'+':''}${diff}</span></div>${spark(vals)}</button>`;}).join('');
  const tsum=TYPES.slice(1).map(([k,n])=>[n,sum(0,30,d=>d.types[k]||0),sum(23,30,d=>d.types[k]||0)]);
  const srcs=f.sources||[],okN=srcs.filter(s=>s.ok).length;
  return `<div class="g">
    ${sec('1日あたりの件数','30日間')}${barChart(stats)}
    <details class="tvw"><summary>種類別の件数を表で見る</summary><table class="tv"><tr><th>種類</th><th>30日</th><th>7日</th></tr>${tsum.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('')}</table></details>
    ${sec('分野ごと','線は30日間・押すと絞り込み')}<div class="mult">${cells}</div>
    ${sec('増えている言葉','直近3日・それ以前との比')}
    ${terms.length?`<ul class="terms">${terms.map(t=>`<li><button data-term="${esc(t.term)}"><span class="w">${esc(t.term)}</span><span class="n">${t.n}件</span><span class="r">×${t.rise}</span></button></li>`).join('')}</ul>`:'<p class="msg">まだ十分な記事がありません</p>'}
    <p class="note" style="margin-top:14px">収集元 ${srcs.length} か所のうち ${okN} か所から取得できています。</p></div>`;}

/* ---------- 通知（朝刊・夕刊） ---------- */
const isIOS=/iP(hone|ad|od)/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
const standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
function pushProblem(){if(isIOS&&!standalone)return 'iPhone では、Safari の共有 →「ホーム画面に追加」をしてから、ホーム画面の BMERadar を開くと設定できます。';
  if(!('serviceWorker' in navigator)||!('PushManager' in window)||!('Notification' in window))return 'このブラウザは通知に対応していません。';return '';}
function b64uToBytes(s){const b=atob(s.replace(/-/g,'+').replace(/_/g,'/')+'==='.slice((s.length+3)%4));return Uint8Array.from(b,ch=>ch.charCodeAt(0));}
const devLabel=()=>isIOS?'iPhone':/Android/.test(navigator.userAgent)?'Android':'PC';
async function pushEnable(am,pm){const perm=await Notification.requestPermission();
  if(perm!=='granted')throw new Error('通知が許可されませんでした。端末の設定で BMERadar の通知を許可してください。');
  const reg=await navigator.serviceWorker.ready,{key}=await gasGet({v:'vapid'});
  let sub=await reg.pushManager.getSubscription();
  if(sub){const k=sub.options&&sub.options.applicationServerKey;if(k&&btoa(String.fromCharCode(...new Uint8Array(k))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')!==key){await sub.unsubscribe();sub=null;}}
  if(!sub){try{sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64uToBytes(key)});}catch(err){throw new Error('通知の登録に失敗しました（'+(err&&err.name||'')+' '+(err&&err.message||'')+'）');}}
  await post({action:'push-sub',sub:sub.toJSON(),am,pm,label:devLabel()});setCfg('push',{endpoint:sub.endpoint,am,pm});}
async function pushDisable(){const p=cfg().push;try{const reg=await navigator.serviceWorker.ready,sub=await reg.pushManager.getSubscription();if(sub)await sub.unsubscribe();}catch(e){}
  if(p)try{await post({action:'push-unsub',endpoint:p.endpoint});}catch(e){}setCfg('push',null);}
async function writeSwConf(){try{if(!('caches' in window))return;const c=await caches.open('radar-conf');await c.put('./__conf',new Response(JSON.stringify({url:cfg().url}),{headers:{'Content-Type':'application/json'}}));}catch(e){}}

function pushStatusHtml(pp){const s=st.pushSt;const perm='Notification' in window?Notification.permission:'unsupported';
  const rows=[['この端末の通知の許可',perm==='granted'?'許可済み':perm==='denied'?'拒否（端末の設定で BMERadar の通知を許可してください）':perm==='default'?'まだ聞かれていません':'非対応']];
  if(pp&&s)rows.push(['GAS への登録',s.registered?'登録済み':'未登録（下のボタンでやり直してください）']);
  if(s)rows.push(['朝刊・夕刊の定期実行',s.morning&&s.evening?'あり':'なし（GAS で setup を実行してください）'],['登録されている端末',s.devices+'台']);
  return `<dl class="facts">${rows.map(r=>`<dt>${r[0]}</dt><dd>${esc(r[1])}</dd>`).join('')}</dl>`;}

/* ---------- 設定 ---------- */
function settingsView(){const c=cfg(),p=prefs(),f=st.feed||{},srcs=f.sources||[],pp=c.push,prob=pushProblem();
  const msg=k=>st.msg[k]?`<p class="msg ${st.msg[k][1]?'bad':''}">${esc(st.msg[k][0])}</p>`:'';
  const hours=Array.from({length:24},(_,h)=>`<option value="${h}" ${+p.email.hour===h?'selected':''}>${h}時</option>`).join('');
  const maxes=[10,15,20,30].map(n=>`<option value="${n}" ${+p.email.max===n?'selected':''}>${n}件ほど</option>`).join('');
  const needPass=!c.url||!c.pass?'<p class="note">GAS の URL と合言葉を入れると、ここの設定が GAS に保存されます。</p>':'';
  const groups=TYPES.slice(1).map(([k,n])=>{const list=srcs.filter(s=>s.type===k);if(!list.length)return'';
    return `<div class="src-group">${n}</div><table class="src-list">${list.map(s=>{const off=p.muted.includes(s.id);
      return `<tr class="${off?'off':''}"><td class="c"><input type="checkbox" data-mute="${esc(s.id)}" ${off?'':'checked'} aria-label="${esc(s.name)} を収集する"></td><td>${esc(s.name)}</td><td class="r ${off?'':s.ok?'ok':'ng'}">${off?'停止中':s.ok?(s.at?'+'+s.n:'—'):esc(s.error||'失敗')}</td></tr>`;}).join('')}</table>`;}).join('');
  const tg=(list,attr,cls)=>list.map((w,i)=>`<span class="tg">${esc(w)}<button data-${attr}="${i}" aria-label="${esc(w)} を外す">×</button></span>`).join('');
  return `<div class="g">
  <section class="panel"><h3>取得先</h3>
    <label class="lbl" for="s_url">ニュース用 GAS のウェブアプリ URL</label><input id="s_url" class="inp" data-cfg="url" inputmode="url" autocomplete="off" placeholder="https://script.google.com/macros/s/…/exec" value="${esc(c.url)}">
    <label class="lbl" for="s_pass">合言葉</label><input id="s_pass" class="inp" type="password" data-cfg="pass" autocomplete="off" value="${esc(c.pass)}">
    <div class="row"><button class="btn pri" data-act="reload" ${st.busy?'disabled':''}>保存して読み込む</button></div>${msg('conn')}</section>
  <section class="panel"><h3>通知（朝刊・夕刊）</h3>
    <p class="note">朝6時ごろに朝刊、夜7時ごろに夕刊として、その時点のまとめをこの端末に通知します（前後15分ほどずれます）。</p>
    ${pushStatusHtml(pp)}${prob?`<p class="msg">${esc(prob)}</p>`:pp?`<label class="chk"><input type="checkbox" data-push="am" ${pp.am?'checked':''}> 朝刊（6時ごろ）</label><label class="chk"><input type="checkbox" data-push="pm" ${pp.pm?'checked':''}> 夕刊（19時ごろ）</label>
      <div class="row"><button class="btn" data-act="push-test" ${st.busy?'disabled':''}>テスト通知を送る</button><button class="btn" data-act="push-off" ${st.busy?'disabled':''}>この端末の通知をやめる</button></div>`:
      `<div class="row"><button class="btn pri" data-act="push-on" ${st.busy||!c.pass?'disabled':''}>この端末で通知を受け取る</button></div>${c.pass?'':'<p class="note">先に合言葉を入れてください。</p>'}`}${msg('push')}</section>
  <section class="panel"><h3>ウォッチする言葉</h3>
    <p class="note">この言葉を含む記事には小さく「ウォッチ」と付き、「今日」の下のほうにまとまります。</p>
    <div class="tags">${tg(p.watch,'unwatch')||'<span class="note" style="margin:0">まだありません（例：Neuralink、EEG、photoacoustic）</span>'}</div>
    <div class="addrow"><input id="w_add" class="inp" placeholder="言葉を追加（、で区切って複数）" autocomplete="off" enterkeyhint="done"><button class="btn" data-act="watch-add">追加</button></div>${needPass}${msg('prefs')}</section>
  <section class="panel"><h3>注目する大学・研究機関</h3>
    <p class="note">ここに入れた大学・研究機関の医工学・脳・BCI に関する発表を、Google ニュースから2時間おきに集めます。記事に大学名が付き、押すとその大学の記事を探せます。</p>
    <div class="tags">${p.univ?tg(p.univ,'ununiv'):'<span class="note" style="margin:0">GAS につなぐと一覧が出ます</span>'}</div>
    <div class="addrow"><input id="u_add" class="inp" placeholder="例：信州大学、Duke University" autocomplete="off" enterkeyhint="done"><button class="btn" data-act="univ-add" ${p.univ?'':'disabled'}>追加</button></div></section>
  <section class="panel"><h3>表示</h3>
    <label class="lbl" for="s_tr">英語の見出しの日本語訳</label><select id="s_tr" class="inp" data-cfg="tr">${[['under','英語の下に添える'],['main','日本語を大きく、英語を下に'],['off','表示しない']].map(([k,n])=>`<option value="${k}" ${c.tr===k?'selected':''}>${n}</option>`).join('')}</select>
    <label class="chk"><input type="checkbox" data-pref="translate" ${p.translate?'checked':''}> GAS で英語の見出しを訳す（無料の Google 翻訳）</label>
    <label class="chk"><input type="checkbox" data-cfg="inapp" ${c.inapp?'checked':''}> 記事をアプリの中で開く</label>
    <label class="chk"><input type="checkbox" data-cfg="rdja" ${c.rdja?'checked':''}> 英語の記事は最初から日本語訳で開く</label>
    <label class="chk"><input type="checkbox" data-pref="reader3p" ${p.reader3p?'checked':''}> 本文を取り出せないときは読み取りサービス（r.jina.ai）も使う</label>
    <label class="chk"><input type="checkbox" data-cfg="group" ${c.group?'checked':''}> 同じ話題の記事を1つにまとめる</label>
    <label class="chk"><input type="checkbox" data-cfg="img" ${c.img?'checked':''}> 記事の画像を表示する</label></section>
  <section class="panel"><h3>株価を追う銘柄</h3>
    <p class="note">Yahoo Finance の記号で入れます（米国はそのまま、東証は 6849.T、豪州は .AX、ブリュッセルは .BR）。「記号 表示名」の形で追加。</p>
    <div class="tags">${(p.tickers||((st.stocks&&st.stocks.quotes)||[]).map(q=>({s:q.s,n:q.n,k:q.k}))).map((t,i)=>`<span class="tg">${esc(t.s)}<small>${esc(t.n)}</small><button data-untick="${i}" aria-label="${esc(t.s)} を外す">×</button></span>`).join('')}</div>
    <div class="addrow"><input id="t_add" class="inp" placeholder="例：CLPT ClearPoint Neuro" autocomplete="off" autocapitalize="characters" enterkeyhint="done"><button class="btn" data-act="tick-add">追加</button></div>${msg('tick')}</section>
  <section class="panel"><h3>まとめメール</h3>
    <label class="chk"><input type="checkbox" data-email="on" ${p.email.on?'checked':''}> 毎日メールでも受け取る</label>
    <div class="two"><div><label class="lbl" for="e_hour">届く時刻</label><select id="e_hour" class="inp" data-email="hour">${hours}</select></div>
      <div><label class="lbl" for="e_max">注目ニュースの数</label><select id="e_max" class="inp" data-email="max">${maxes}</select></div></div>
    <label class="lbl" for="e_to">送信先（空なら GAS の Google アカウント${st.acct?'：'+esc(st.acct):''}）</label><input id="e_to" class="inp" type="email" data-email="to" autocomplete="off" value="${esc(p.email.to)}">
    <div class="row"><button class="btn" data-act="digest-test" ${st.busy?'disabled':''}>いまテストメールを送る</button></div>${needPass}${msg('mail')}</section>
  <section class="panel"><h3>朝刊・夕刊のまとめ</h3>
    <p class="note">毎日 5:37 と 18:37 ごろに、その時点の新着から書かれます。</p>
    <p class="msg">${st.feed&&st.feed.brief?'最後のまとめ：'+fmtWhen(st.feed.brief.at)+'（'+edName(st.feed.brief.ed||edOf(st.feed.brief.at))+'）':'まだ届いていません'}</p></section>
  <section class="panel"><h3>収集元</h3><p class="note">最終収集 ${fmtWhen(f.updated)}・1時間ごと。チェックを外すと、その収集元を止めます。</p>
    <div class="row"><button class="btn" data-act="collect" ${st.busy?'disabled':''}>${st.busy==='collect'?'収集しています…':'今すぐ収集する'}</button></div>${msg('collect')}
    ${groups||'<p class="msg">まだ収集していません</p>'}</section>
  <section class="panel"><h3>アプリの更新</h3><p class="note">表示が古いまま、または崩れているときは、保存してあるアプリのファイルを捨てて最新の版を読み込み直します（設定やしおりは消えません）。</p>
    <div class="row"><button class="btn" data-act="hard-reload">最新の版を読み込み直す</button></div></section></div>`;}

/* ---------- render ---------- */
function render(){const nSaved=Object.keys(bmGet().items).length,t=new Date();
  const body={today:todayView,bci:bciView,feed:feedView,dev:devView,saved:savedView,trends:trendsView,settings:settingsView}[st.view]();
  const y=scrollY,ae=document.activeElement&&document.activeElement.id;
  app.innerHTML=`<header><div class="g"><div class="hd"><h1>BME<span>Radar</span></h1><span class="date">${t.getMonth()+1}月${t.getDate()}日（${WD[t.getDay()]}）</span><span class="sp"></span>
      <button class="ib ${st.search?'on':''}" data-act="search" aria-label="検索">${ICON.search}</button><button class="ib ${st.loading?'spin':''}" data-act="refresh" aria-label="再読み込み">${ICON.refresh}</button></div>
    <nav class="tabs">${[['today','今日'],['bci','BCI'],['saved','しおり'],['trends','推移'],['dev','開発'],['settings','設定']].map(([k,n])=>`<button class="tab ${st.view===k?'on':''}" data-view="${k}">${n}${k==='saved'&&nSaved?`<span class="n">${nSaved}</span>`:''}</button>`).join('')}</nav></div></header>${body}`;
  scrollTo(0,y);if(ae){const el=document.getElementById(ae);if(el){el.focus({preventScroll:true});if(el.setSelectionRange&&/text|search|password/.test(el.type)){const n=el.value.length;try{el.setSelectionRange(n,n);}catch(e){}}}}}
function go(view,o){Object.assign(st,{view,limit:50,sr:null},o||{});if(view==='bci')loadStocks();render();scrollTo(0,0);}

/* ---------- events ---------- */
app.addEventListener('click',async e=>{const t=e.target.closest('[data-type],[data-cat],[data-bm],[data-view],[data-act],[data-more],[data-read],[data-open],[data-jump],[data-gocat],[data-term],[data-unwatch],[data-untick],[data-ununiv],[data-q],[data-range],[data-bcit],[data-rdu],[data-dev]');if(!t)return;
  const d=t.dataset;
  if(d.dev){devAction(d.dev,e);return;}
  if(d.q){st.openQ=st.openQ===d.q?'':d.q;render();return;}
  if(d.range){st.range=d.range;render();return;}
  if(d.bcit){st.bci=!st.bci;st.limit=50;render();return;}
  if(d.ununiv!==undefined){const p=prefs();if(!p.univ)return;p.univ.splice(+d.ununiv,1);savePrefs(p);return;}
  if(d.untick!==undefined){const p=prefs();const list=p.tickers||((st.stocks&&st.stocks.quotes)||[]).map(q=>({s:q.s,n:q.n,k:q.k}));list.splice(+d.untick,1);p.tickers=list;savePrefs(p);st.stocksAt=0;setTimeout(()=>loadStocks(true),4000);return;}
  if(d.read){markRead(d.read);if(cfg().inapp){e.preventDefault();openReader(d.read);setTimeout(render,50);}else setTimeout(render,300);return;}
  if(d.rdu){const it=allItems().find(i=>i.u===d.rdu);if(it&&cfg().inapp){e.preventDefault();markRead(it.id);openReader(it.id);}return;}
  if(d.type){st.type=d.type;st.limit=50;if(st.sr)searchArchive();else render();return;}
  if(d.cat!==undefined){st.cat=d.cat;st.limit=50;render();return;}
  if(d.bm){toggleBm(d.bm);return;}
  if(d.open){st.open[d.open]=!st.open[d.open];render();return;}
  if(d.jump){go('feed',{type:d.jump,cat:'',bci:false});return;}
  if(d.gocat){go('feed',{type:'all',cat:d.gocat,bci:false});return;}
  if(d.term){go('feed',{type:'all',cat:'',bci:false,q:d.term,search:true});return;}
  if(d.view){st.msg={};if(d.view==='dev'&&st.view==='dev')st.dev={mode:'list',id:''};go(d.view);return;}
  if(d.more){st.limit+=50;render();return;}
  if(d.unwatch!==undefined){const p=prefs();p.watch.splice(+d.unwatch,1);savePrefs(p);return;}
  const a=d.act;
  if(a==='search'){st.search=!st.search;if(!st.search){st.q='';st.sr=null;}if(st.search)st.view='feed';render();if(st.search)document.getElementById('q')?.focus();}
  else if(a==='refresh'){loadFeed();BM.pull();DEV.pull();syncPrefs();loadStocks(true);}
  else if(a==='bci-all')go('feed',{type:'all',cat:'',bci:true});
  else if(a==='tick-add')addTicker();
  else if(a==='univ-add')addUniv();
  else if(a==='older')loadOlder();
  else if(a==='hard-reload'){try{const ks=await caches.keys();await Promise.all(ks.filter(k=>k!=='radar-conf').map(k=>caches.delete(k)));const rs=await navigator.serviceWorker.getRegistrations();await Promise.all(rs.map(r=>r.update().catch(()=>{})));}catch(err){}location.reload();}
  else if(a==='archive')searchArchive();
  else if(a==='sr-close'){st.sr=null;render();}
  else if(a==='watch-add')addWatch();
  else if(a==='reload'){st.msg={};st.feed=null;writeSwConf();await loadFeed();
    if(cfg().url&&cfg().pass){try{gotPrefs(await post({action:'prefs-get'}));st.msg.conn=['つながりました'];loadStocks(true);DEV.pull();}catch(err){st.msg.conn=[err.message,1];}}
    else if(cfg().url)st.msg.conn=[st.err?st.err:'読み込みました（合言葉なし：読むだけ）',!!st.err];
    BM.pull();render();}
  else if(a==='push-on'){st.busy='push';st.msg.push=['設定しています…'];render();
    try{await pushEnable(true,true);st.msg.push=['この端末で朝刊・夕刊を受け取ります。「テスト通知を送る」で確かめられます。'];await syncPrefs();}catch(err){st.msg.push=[err.message||String(err),1];}st.busy='';render();}
  else if(a==='push-off'){st.busy='push';render();await pushDisable();st.msg.push=['この端末の通知をやめました。'];await syncPrefs();st.busy='';render();}
  else if(a==='push-test'){st.busy='push';st.msg.push=['送っています…'];render();
    try{await post({action:'push-test',endpoint:cfg().push.endpoint});st.msg.push=['送りました。数秒で届きます。届かないときは端末の通知設定を確かめてください。'];}catch(err){st.msg.push=[err.message,1];}st.busy='';render();}
  else if(a==='digest-test'){st.busy='mail';st.msg.mail=['送っています…'];render();
    try{await pushPrefs();const j=await post({action:'digest-test'});st.msg.mail=[`${j.to} に送りました（${j.count}件）。届かないときは迷惑メールも見てください。`];}catch(err){st.msg.mail=[err.message,1];}
    st.busy='';render();}
  else if(a==='collect'){st.busy='collect';st.msg.collect=['収集しています（1〜4分）…'];render();
    try{const j=await post({action:'refresh'});st.msg.collect=[`新しい記事 ${j.added} 件${j.failed?`・取得できなかった収集元 ${j.failed} か所`:''}`];await loadFeed();}catch(err){st.msg.collect=[err.message,1];}
    st.busy='';render();}});
function addList(id,key,max,clean){const el=document.getElementById(id);const v=(el&&el.value||'').trim();const p=prefs();if(!v||!p[key])return;
  v.split(/[,、，]/).map(x=>clean(x)).filter(Boolean).forEach(w=>{if(!p[key].some(x=>x.toLowerCase()===w.toLowerCase()))p[key].push(w);});
  p[key]=p[key].slice(0,max);savePrefs(p);const el2=document.getElementById(id);if(el2){el2.value='';el2.focus();}}
const addUniv=()=>addList('u_add','univ',80,x=>x.replace(/["()]/g,'').trim());
const addWatch=()=>addList('w_add','watch',40,x=>x.trim());
function addTicker(){const el=document.getElementById('t_add');const v=(el&&el.value||'').trim();if(!v)return;const m=v.match(/^(\S+)\s*(.*)$/);const sym=m[1].toUpperCase();
  if(!/^[A-Z0-9.\-^=]+$/.test(sym)){st.msg.tick=['記号は英数字と . - だけです',1];render();return;}
  const p=prefs();const list=p.tickers||((st.stocks&&st.stocks.quotes)||[]).map(q=>({s:q.s,n:q.n,k:q.k}));
  if(!list.some(t=>t.s===sym))list.push({s:sym,n:m[2]||sym,k:m[2]||sym});p.tickers=list.slice(0,30);st.msg.tick=null;savePrefs(p);st.stocksAt=0;setTimeout(()=>loadStocks(true),5000);}
app.addEventListener('keydown',e=>{if(e.key!=='Enter'||e.isComposing)return;const id=e.target.id;
  if(id==='w_add'){e.preventDefault();addWatch();}
  else if(id==='t_add'){e.preventDefault();addTicker();}
  else if(id==='u_add'){e.preventDefault();addUniv();}
  else if(id==='todo_add'){e.preventDefault();addTodo();}
  else if(id==='q'&&st.q.trim()&&cfg().url&&!(st.feed&&st.feed.sample)){e.preventDefault();e.target.blur();searchArchive();}});
let qTimer=null,nTimer=null;
app.addEventListener('input',e=>{const t=e.target;
  if(t.id==='q'){st.q=t.value;st.limit=50;if(st.sr&&!st.q.trim())st.sr=null;clearTimeout(qTimer);qTimer=setTimeout(()=>{if(!st.sr)render();},150);}
  else if(t.dataset.nf&&t.tagName!=='SELECT'){clearTimeout(nTimer);const k=t.dataset.nf,v=t.value;nTimer=setTimeout(()=>{const n=devNote(st.dev.id);if(n){n[k]=v;devSave(n);}},500);}});
app.addEventListener('change',async e=>{const t=e.target,d=t.dataset;
  if(d.nf){const n=devNote(st.dev.id);if(n){n[d.nf]=t.value;devSave(n);}return;}
  if(d.todo!==undefined){const n=devNote(st.dev.id);n.todos[+d.todo].done=t.checked;devSave(n);render();return;}
  if(d.push){const p=Object.assign({},cfg().push);p[d.push]=t.checked;try{await pushEnable(p.am,p.pm);st.msg.push=['保存しました'];}catch(err){st.msg.push=[err.message,1];}render();return;}
  if(d.cfg){setCfg(d.cfg,t.type==='checkbox'?t.checked:t.value.trim());if(d.cfg==='url')writeSwConf();if(t.type==='checkbox'||t.tagName==='SELECT')render();return;}
  if(d.pref){const p=prefs();p[d.pref]=t.checked;savePrefs(p);return;}
  if(d.email){const p=prefs();p.email[d.email]=t.type==='checkbox'?t.checked:(d.email==='hour'||d.email==='max')?+t.value:t.value.trim();savePrefs(p);return;}
  if(d.mute){const p=prefs();p.muted=p.muted.filter(x=>x!==d.mute);if(!t.checked)p.muted.push(d.mute);savePrefs(p);}});
/* chart tooltip follows the pointer */
app.addEventListener('pointermove',e=>{const r=e.target.closest&&e.target.closest('[data-tip]'),ch=e.target.closest&&e.target.closest('[data-chart]');
  app.querySelectorAll('.tip').forEach(tp=>{if(!ch||!r||!ch.contains(tp)){tp.style.display='none';return;}
    const box=ch.getBoundingClientRect(),rb=r.getBoundingClientRect();tp.innerHTML=`${esc(r.dataset.tip)}<span>${esc(r.dataset.v)}${r.dataset.u==null?'件':esc(r.dataset.u)}</span>`;
    tp.style.display='block';tp.style.left=Math.min(box.width-40,Math.max(40,rb.left-box.left+rb.width/2))+'px';tp.style.top=Math.max(24,e.clientY-box.top-10)+'px';
    if(r.dataset.x){const xh=ch.querySelector('.xhair'),xd=ch.querySelector('.xdot');xh.setAttribute('x1',r.dataset.x);xh.setAttribute('x2',r.dataset.x);xh.style.display='';xd.setAttribute('cx',r.dataset.x);xd.setAttribute('cy',r.dataset.y);xd.style.display='';}});});
app.addEventListener('pointerleave',()=>{app.querySelectorAll('.tip').forEach(tp=>tp.style.display='none');app.querySelectorAll('.xhair,.xdot').forEach(x=>x.style.display='none');},true);
document.addEventListener('visibilitychange',()=>{if(document.hidden){setCfg('seen',Date.now());return;}
  if(st.feed&&!st.feed.sample&&Date.now()-(st.feed.fetchedAt||0)>15*60e3)loadFeed();if(st.view==='bci')loadStocks();});
setInterval(()=>{if(!document.hidden&&st.view==='bci')loadStocks();},5*60e3);
addEventListener('pagehide',()=>setCfg('seen',Date.now()));

/* ---------- in-app reader ---------- */
const rdEl=document.getElementById('reader');
const rd={id:'',it:null,data:null,loading:false,err:'',ja:false,devMsg:''};
const RDKEY='radar-reader-v1';
function rdCacheGet(k){const c=lsGet(RDKEY,{});return c[k]||null;}
function rdCachePut(k,v){const c=lsGet(RDKEY,{});c[k]=Object.assign({},v,{_at:Date.now()});let ks=Object.keys(c).sort((a,b)=>c[b]._at-c[a]._at);ks.slice(80).forEach(x=>delete c[x]);ks=ks.slice(0,80);
  for(let n=ks.length;n>=1;n=Math.floor(n*0.7)){try{localStorage.setItem(RDKEY,JSON.stringify(c));return;}catch(e){ks.slice(Math.max(1,Math.floor(n*0.7))).forEach(x=>delete c[x]);}}}
/* keep the texts of the articles most likely to be opened on the phone, so they open at once and offline */
let prefetching=false;
async function prefetchBodies(){const c=cfg();if(prefetching||!c.url||!st.feed||st.feed.sample)return;prefetching=true;
  try{const f=st.feed,m=byId(),have=lsGet(RDKEY,{});
    const ids=[...new Set([].concat(f.bci||[],f.brain||[],f.highlights||[],Object.keys(bmGet().items),feedItems().filter(i=>i.rd===1&&!i.c).sort((a,b)=>b.d-a.d).slice(0,30).map(i=>i.id)))].filter(id=>!have[id]&&(m[id]?m[id].rd>0:bmGet().items[id])).slice(0,40);
    if(ids.length){const j=await gasGet({v:'bodies',ids:ids.join(',')});Object.keys(j.items||{}).forEach(id=>rdCachePut(id,j.items[id]));}}
  catch(e){}prefetching=false;}
function openReader(id,fromPop){const it=findItem(id);if(!it)return;
  Object.assign(rd,{id,it,data:null,err:'',devMsg:'',ja:cfg().rdja&&it.l!=='ja'});
  if(!fromPop)history.pushState({rd:id},'');
  document.documentElement.classList.add('rd-open');rdEl.hidden=false;rdEl.scrollTop=0;loadReader();}
function closeReader(){rd.id='';rdEl.hidden=true;rdEl.innerHTML='';document.documentElement.classList.remove('rd-open');}
async function loadReader(){const id=rd.id,ja=rd.ja,k=id+(ja?'_ja':'');
  const hit=rdCacheGet(k);if(hit){rd.data=hit;rd.loading=false;renderReader();return;}
  const c=cfg();if(!c.url||(st.feed&&st.feed.sample)){rd.data=null;rd.err='GAS につなぐと、ここに記事の本文が表示されます。';renderReader();return;}
  rd.loading=true;renderReader();
  try{const j=await gasGet({v:'read',id,ja:ja?1:''});if(rd.id!==id)return;rd.data=j;rdCachePut(k,j);rd.err='';}
  catch(e){if(rd.id!==id)return;rd.err=navigator.onLine===false?'オフラインのため本文を読み込めません':'本文を取り出せませんでした';}
  rd.loading=false;renderReader();}
function renderReader(){if(!rd.id)return;const it=rd.it,d=rd.data,c=cfg(),ja=rd.ja;
  const url=(d&&d.url)||it.u,saved=!!bmGet().items[it.id],isJa=it.l==='ja';
  const title=ja&&d&&d.titleJa?d.titleJa:(d&&d.title)||it.t,sub=!isJa?(ja?(d&&d.title)||it.t:(it.tj&&c.tr!=='off'?it.tj:'')):'';
  const paras=(d&&d.paras)||[];
  const body=paras.map(p=>p.t==='img'?`<figure><img src="${esc(p.src)}" alt="${esc(p.alt||'')}" loading="lazy" referrerpolicy="no-referrer" onerror="this.parentNode.remove()">${p.alt?`<figcaption>${esc(p.alt)}</figcaption>`:''}</figure>`:
    p.t==='h'?`<h2>${esc(ja&&p.j?p.j:p.x)}</h2>`:`<p class="${ja&&p.j?'ja':''}">${esc(ja&&p.j?p.j:p.x)}</p>`).join('');
  const skel=rd.loading?`<div class="rd-skel">${'<i></i>'.repeat(7)}</div><p class="rd-note">${ja?'本文を取り出して日本語に訳しています…':'本文を取り出しています…'}</p>`:'';
  const fallback=!rd.loading&&!paras.length?`${it.x?`<p>${esc(it.x)}</p>`:''}<p class="rd-note">${esc(rd.err||'本文を取り出せませんでした')}</p>`:'';
  const notes=Object.values(devAll().items).sort((a,b)=>b.updated-a.updated);
  rdEl.innerHTML=`<div class="rd-bar"><button class="rd-back" data-rd="close" aria-label="戻る">${ICON.back}<span>戻る</span></button>
      ${!isJa?`<div class="rd-seg" role="group" aria-label="言語"><button class="${ja?'':'on'}" data-rd="en">原文</button><button class="${ja?'on':''}" data-rd="ja">日本語</button></div>`:''}
      <button class="bm ${saved?'on':''}" data-rd="bm" aria-label="${saved?'しおりを外す':'しおりを付ける'}">${ICON.bm}</button>
      <a class="ib" href="${esc(url)}" target="_blank" rel="noopener" aria-label="元のページを開く">${ICON.ext}</a></div>
    <article class="rd-body ${isJa||ja?'is-ja':''}"><div class="meta"><span class="src">${esc((d&&d.src)||it.s)}</span><span>${fmtWhen(it.d)}</span>${it.ty!=='news'&&TYPEN[it.ty]?`<span class="k">${TYPEN[it.ty]}</span>`:''}${it.b?'<span class="k bci">BCI</span>':''}</div>
      <h1 class="rd-title ${isJa||(ja&&d&&d.titleJa)?'ja':''}">${esc(title)}</h1>${d&&d.via?`<p class="rd-via">${d.via==='Europe PMC'?'要旨は Europe PMC から取り出しました':`元の記事を取り出せなかったため、同じ話題を報じた ${esc(d.via)} の記事を表示しています`}</p>`:''}${sub?`<p class="rd-sub ${ja?'en':''}">${esc(sub)}</p>`:''}
      ${d&&d.image&&c.img?`<figure class="rd-hero"><img src="${esc(d.image)}" alt="" referrerpolicy="no-referrer" onerror="this.parentNode.remove()"></figure>`:''}
      ${d&&d.lead?`<p class="rd-lead">${esc(d.lead)}</p>`:''}${skel}${body}${fallback}</article>
    <div class="rd-foot">${d&&d.partial&&paras.length?'<p class="rd-note">本文の一部だけ取り出せました（有料記事や動画のページなど）。続きは元のページで。</p>':''}${d&&d.trErr?'<p class="rd-note">翻訳の上限に達したため一部は原文です</p>':''}
      <div class="row">${d&&d.doi?`<a class="btn" href="${esc(d.doi)}" target="_blank" rel="noopener">論文のページ（DOI）</a>`:''}<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">元のページで読む</a></div>
      <div class="panel"><h3>開発ノートに追加</h3><p class="note">この記事を参考に何か作ってみるなら、ノートに入れておけます。</p>
        <div class="addrow"><select id="rd_note" class="inp"><option value="">新しいノートを作る</option>${notes.map(n=>`<option value="${esc(n.id)}">${esc(n.title)}</option>`).join('')}</select><button class="btn" data-rd="dev">追加</button></div>
        ${rd.devMsg?`<p class="msg">${esc(rd.devMsg)}</p>`:''}</div></div>`;}
rdEl.addEventListener('click',e=>{const t=e.target.closest('[data-rd]');if(!t)return;const a=t.dataset.rd;
  if(a==='close'){history.state&&history.state.rd?history.back():closeReader();}
  else if(a==='en'||a==='ja'){const ja=a==='ja';if(rd.ja===ja)return;rd.ja=ja;rd.data=null;loadReader();}
  else if(a==='bm'){toggleBm(rd.id);renderReader();}
  else if(a==='dev'){const sel=document.getElementById('rd_note').value,link=Object.assign(linkOf(rd.it),rd.data&&rd.data.url?{u:rd.data.url}:{});
    let n=sel?devNote(sel):null;
    if(!n){n=devNew({title:titleOf(rd.it).slice(0,60),goal:'',links:[link],status:'アイデア'});rd.devMsg='新しいノート「'+n.title+'」を作りました。「開発」タブで続きを書けます。';}
    else{if(!n.links.some(l=>l.id===link.id))n.links.push(link);devSave(n);rd.devMsg='「'+n.title+'」に追加しました。';}
    renderReader();}});
addEventListener('popstate',e=>{if(e.state&&e.state.rd)openReader(e.state.rd,true);else if(rd.id)closeReader();});
addEventListener('keydown',e=>{if(e.key==='Escape'&&rd.id){history.state&&history.state.rd?history.back():closeReader();}});

/* ---------- start ---------- */
st.seenAt=cfg().seen;st.stocks=lsGet('radar-stocks-v1',null);
if(/[?&]ed=/.test(location.search))st.view='today';
render();loadFeed();BM.pull();DEV.pull();syncPrefs();writeSwConf();
if('serviceWorker' in navigator&&location.protocol.startsWith('http')){const had=!!navigator.serviceWorker.controller;navigator.serviceWorker.register('./sw.js').then(r=>r.update()).catch(()=>{});
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(had)location.reload();});}
