/**
 * BMERadar — collector for biomedical-engineering news, papers, approvals, trials,
 * company news and university/academic notices. Brain and BCI items are ranked first.
 * Also tracks neurotech share prices and holds the Japanese daily brief written by a Claude scheduled task.
 * (Google Apps Script web app; the PWA in /news/ reads from it.)
 *
 *   GET  (no params)                        latest feed: last 4 days (+14 days of BCI) + highlights + trends + source status
 *   GET  ?v=more&before=<ms>&type=&cat=&bci=1   older items (index and monthly archive)
 *   GET  ?v=search&q=<words>&type=&cat=&bci=1   full search over the archive
 *   GET  ?v=stocks                          share prices (updated every 15 min)
 *   GET  ?v=brief-input                     compact list of the last 36 h for the brief writer
 *   GET  ?v=read&id=<item id>[&ja=1]        article text for the in-app reader (only items this radar collected)
 *   GET  ?v=vapid                           public key for Web Push;  ?v=push-latest  what the notification shows
 *   POST {pass, action:'push-sub'|'push-unsub'|'push-test'|'dev-load'|'dev-save', ...}
 *   POST {pass, action:'prefs-get'|'prefs-set'|'bm-load'|'bm-save'|'refresh'|'stocks'|'digest-test', ...}
 *   POST {key, action:'brief-save', brief:{...}}   (key = briefKey shown in the app's settings)
 *
 * First time: set PASS_PHRASE, run setup() once (registers the pass phrase, installs the hourly
 * collector, the 15-minute share prices and the morning digest, does the first collection), then
 * Deploy > New deployment > Web app (Execute as: Me / Who has access: Anyone).
 * To add or remove sources, edit SOURCES below.
 */
const PASS_PHRASE = 'ここを自分だけの合言葉に変える';
const APP_NAME = 'BMERadar';
const DATA_FOLDER = 'bme-radar-data';
const APP_URL = '';          // e.g. https://<user>.github.io/sora-apps/news/  (link at the bottom of the morning mail)
const INDEX_DAYS = 30, FEED_DAYS = 4, TIME_BUDGET_MS = 270000;

/* ---------- sources ----------
 * kind: rss | gnews | pubmed | fda510k | fdapma | fdarecall | ctgov
 * type: news | paper | reg | trial | biz | acad        every: hours between fetches
 * filter: bme (must look like biomedical engineering) | none (keep everything) | kw (must match kw)
 */
const GN = (id, name, q, extra) => Object.assign({ id: id, name: name, kind: 'gnews', q: q, type: 'news', every: 1, filter: 'bme' }, extra || {});
const PM = (id, name, term, extra) => Object.assign({ id: id, name: name, kind: 'pubmed', term: term, type: 'paper', every: 6, filter: 'bme' }, extra || {});
const NEUROTECH_KW = 'electrode|interface|stimulat|decod|implant|prosthe|optogenet|ultrasound|\\bEEG\\b|\\bECoG\\b|\\bMEG\\b|\\bf?MRI\\b|neuroimaging|recording (system|device)|probe|wearable|closed-loop|neuromodulat|neurotech|device|sensor|robot|exoskeleton|\\bBCI|brain[-‐‑–—\\s]{0,2}(computer|machine)|deep brain|\\bTMS\\b|\\btDCS\\b';
const SOURCES = [
  // --- brain first ---
  GN('gn-bci', 'Google News: BCI', '"brain-computer interface" OR "brain-machine interface" OR "neural interface" OR "brain implant"', { trust: true }),
  GN('gn-neurotech', 'Google News: ニューロテック企業', 'Neuralink OR Synchron OR "Precision Neuroscience" OR Paradromics OR "Blackrock Neurotech" OR Neuropace OR "Onward Medical" OR Motif Neurotech', { trust: true }),
  GN('gn-neuromod', 'Google News: 神経刺激', '"deep brain stimulation" OR neuromodulation OR "vagus nerve stimulation" OR "spinal cord stimulation" OR "transcranial magnetic stimulation" OR "focused ultrasound" brain'),
  GN('gn-neuroimaging', 'Google News: 脳計測', 'EEG device OR "brain imaging" OR "brain scan" technology OR neuroimaging OR "brain wearable"'),
  GN('gn-neuroprosth', 'Google News: 神経補綴・感覚', 'neuroprosthesis OR neuroprosthetic OR "retinal implant" OR "bionic eye" OR "spinal cord injury" implant OR "nerve stimulator" OR "cochlear implant"'),
  // --- the rest of biomedical engineering ---
  GN('gn-device', 'Google News: 医療機器・承認', '"medical device" OR "FDA clearance" OR "FDA clears" OR "breakthrough device designation" OR "De Novo" device'),
  GN('gn-sensing', 'Google News: 生体計測・ウェアラブル', 'wearable biosensor OR "continuous glucose monitor" OR "pulse oximeter" OR cuffless "blood pressure" OR "smart patch" health OR "remote patient monitoring"'),
  GN('gn-imaging', 'Google News: 医用画像', '"medical imaging" OR "MRI scanner" OR "ultrasound device" OR "photon-counting CT" OR "AI radiology" OR endoscopy device'),
  GN('gn-robot', 'Google News: 手術支援・ロボット・補綴', '"surgical robot" OR "robotic surgery" OR exoskeleton OR "bionic" prosthetic OR "rehabilitation robot"'),
  GN('gn-implant', 'Google News: 人工臓器・埋込機器', '"artificial heart" OR LVAD OR pacemaker OR "cochlear implant" OR "artificial pancreas" OR "implantable device" OR "heart valve" device'),
  GN('gn-regen', 'Google News: 再生医療・材料', '"tissue engineering" OR bioprinting OR organoid OR biomaterial OR hydrogel implant OR "organ-on-a-chip"'),
  GN('gn-digital', 'Google News: AI・デジタルヘルス', '"AI medical device" OR "software as a medical device" OR "digital therapeutics" OR "digital health" FDA'),
  GN('gn-therapy', 'Google News: 治療機器', '"drug delivery" device OR microneedle OR "proton therapy" OR ablation device OR "radiotherapy system"'),
  GN('gn-funding', 'Google News: 企業・資金調達', 'medtech raises OR "medical device" startup funding OR neurotech funding OR medtech acquisition', { type: 'biz' }),
  GN('gn-ja-bme', 'Google ニュース: 医工学', '医工学 OR 生体医工学 OR 医療機器 開発 OR 医療機器 研究', { lang: 'ja' }),
  GN('gn-ja-brain', 'Google ニュース: 脳・BMI', 'ブレイン・マシン・インターフェース OR ブレイン・コンピューター・インターフェース OR ニューロテック OR 脳波 デバイス OR 脳 インプラント', { lang: 'ja', trust: true }),
  GN('gn-ja-approval', 'Google ニュース: 承認・薬事', '医療機器 承認 OR プログラム医療機器 OR SaMD 承認 OR 医療機器 認証 取得', { lang: 'ja', type: 'reg' }),
  GN('gn-ja-wearable', 'Google ニュース: 生体計測', 'ウェアラブル 医療 OR 血糖 センサ OR パルスオキシメータ OR 血圧計 OR 生体センサ', { lang: 'ja' }),
  GN('gn-ja-startup', 'Google ニュース: 医療機器スタートアップ', '医療機器 スタートアップ 資金調達 OR ヘルステック 資金調達 OR 医療機器 買収', { lang: 'ja', type: 'biz' }),
  GN('gn-bci-research', 'Google News: BCI 研究発表', '("brain-computer interface" OR "brain-machine interface" OR "neural interface" OR neuroprosthesis OR "brain implant" OR "speech decoding") (university OR institute OR researchers OR scientists)', { type: 'acad', trust: true }),
  GN('gn-bci-money', 'Google News: BCI 企業の資金・評価額', '(Neuralink OR Synchron OR "Precision Neuroscience" OR Paradromics OR "Science Corp" OR "Blackrock Neurotech" OR "Merge Labs" OR BrainCo OR INBRAIN OR Axoft OR Neurable OR Kernel) (raises OR funding OR valuation OR IPO OR investors OR acquisition OR "Series")', { type: 'biz', trust: true }),
  GN('gn-ja-bci-research', 'Google ニュース: 脳・BMI の研究発表', '脳 解読 研究グループ OR ブレイン・マシン・インターフェース 研究 OR 脳波 解読 大学 OR 脳活動 計測 新手法 OR 神経 インターフェース 開発', { lang: 'ja', type: 'acad', trust: true }),
  GN('gn-ja-univ', 'Google ニュース: 大学の研究成果', '大学 発表 脳 計測 OR 大学 開発 医療機器 OR 大学 研究 ウェアラブル 医療 OR 大学 研究 手術支援ロボット', { lang: 'ja', type: 'acad' }),
  GN('gn-ja-academia', 'Google ニュース: 学会・公募', '生体医工学会 OR 医工学 シンポジウム OR 医療機器 公募 OR AMED 公募 医療機器', { lang: 'ja', type: 'acad', filter: 'none' }),
  // industry press
  { id: 'medtechdive', name: 'MedTech Dive', kind: 'rss', url: 'https://www.medtechdive.com/feeds/news/', type: 'news', every: 1, filter: 'none' },
  { id: 'fierce', name: 'Fierce Biotech MedTech', kind: 'rss', url: 'https://www.fiercebiotech.com/rss/medtech/xml', type: 'news', every: 2, filter: 'none' },
  { id: 'massdevice', name: 'MassDevice', kind: 'rss', url: 'https://www.massdevice.com/feed/', type: 'news', every: 2, filter: 'none' },
  { id: 'mdo', name: 'Medical Design & Outsourcing', kind: 'rss', url: 'https://feeds.feedburner.com/MedicalDesignAndOutsourcing', type: 'news', every: 2, filter: 'none' },
  { id: 'medgadget', name: 'Medgadget', kind: 'rss', url: 'https://www.medgadget.com/feed', type: 'news', every: 2, filter: 'none' },
  { id: 'mobihealth', name: 'MobiHealthNews', kind: 'rss', url: 'https://www.mobihealthnews.com/rss.xml', type: 'news', every: 3, filter: 'bme' },
  { id: 'stat-tech', name: 'STAT Health Tech', kind: 'rss', url: 'https://www.statnews.com/category/health-tech/feed/', type: 'news', every: 2, filter: 'bme' },
  { id: 'spectrum', name: 'IEEE Spectrum', kind: 'rss', url: 'https://spectrum.ieee.org/feeds/topic/biomedical.rss', type: 'news', every: 3, filter: 'none' },
  { id: 'nn-neurotech', name: 'Neuroscience News', kind: 'rss', url: 'https://neurosciencenews.com/neuroscience-topics/neurotech/feed/', type: 'news', every: 2, filter: 'none' },
  { id: 'sd-devices', name: 'ScienceDaily: Medical Devices', kind: 'rss', url: 'https://www.sciencedaily.com/rss/health_medicine/medical_devices.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-imaging', name: 'ScienceDaily: Medical Imaging', kind: 'rss', url: 'https://www.sciencedaily.com/rss/health_medicine/medical_imaging.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-medtech', name: 'ScienceDaily: Medical Technology', kind: 'rss', url: 'https://www.sciencedaily.com/rss/matter_energy/medical_technology.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-bci', name: 'ScienceDaily: BCI', kind: 'rss', url: 'https://www.sciencedaily.com/rss/mind_brain/brain-computer_interfaces.xml', type: 'news', every: 3, filter: 'none' },
  { id: 'sd-wearable', name: 'ScienceDaily: Wearable', kind: 'rss', url: 'https://www.sciencedaily.com/rss/matter_energy/wearable_technology.xml', type: 'news', every: 3, filter: 'bme' },
  { id: 'sd-neuro', name: 'ScienceDaily: Neuroscience', kind: 'rss', url: 'https://www.sciencedaily.com/rss/mind_brain/neuroscience.xml', type: 'news', every: 3, filter: 'kw', kw: NEUROTECH_KW },
  { id: 'monoist', name: 'MONOist', kind: 'rss', url: 'https://rss.itmedia.co.jp/rss/2.0/monoist.xml', type: 'news', every: 3, filter: 'bme', lang: 'ja' },
  // papers and preprints
  { id: 'nbme', name: 'Nature Biomedical Engineering', kind: 'rss', url: 'https://www.nature.com/natbiomedeng.rss', type: 'paper', every: 6, filter: 'none', tier: 3 },
  { id: 'npjdm', name: 'npj Digital Medicine', kind: 'rss', url: 'https://www.nature.com/npjdigitalmed.rss', type: 'paper', every: 6, filter: 'none', tier: 2 },
  { id: 'jne', name: 'Journal of Neural Engineering', kind: 'rss', url: 'https://iopscience.iop.org/journal/rss/1741-2552', type: 'paper', every: 6, filter: 'none', tier: 2 },
  PM('pm-journals', 'PubMed: 主要医工学誌', '("IEEE Trans Biomed Eng"[ta] OR "IEEE J Biomed Health Inform"[ta] OR "IEEE Trans Neural Syst Rehabil Eng"[ta] OR "IEEE Trans Med Imaging"[ta] OR "J Neural Eng"[ta] OR "Sci Transl Med"[ta] OR "Nat Biomed Eng"[ta] OR "Biomaterials"[ta] OR "Lancet Digit Health"[ta] OR "Sci Robot"[ta] OR "Med Image Anal"[ta] OR "Biosens Bioelectron"[ta] OR "Ann Biomed Eng"[ta])', { tier: 2, ret: 80 }),
  PM('pm-brain', 'PubMed: 脳・神経工学', '("brain-computer interface"[tiab] OR "brain-machine interface"[tiab] OR "neural interface"[tiab] OR intracortical[tiab] OR neuroprosthe*[tiab] OR "deep brain stimulation"[tiab] OR "transcranial magnetic stimulation"[tiab] OR "spinal cord stimulation"[tiab] OR "vagus nerve stimulation"[tiab] OR "neural decoding"[tiab])', { ret: 60 }),
  PM('pm-sensing', 'PubMed: 生体計測・ウェアラブル', '(wearable[tiab] OR "continuous glucose monitoring"[tiab] OR "pulse oximetry"[tiab] OR photoplethysmograph*[tiab] OR "cuffless blood pressure"[tiab] OR biosensor*[tiab]) AND (device*[tiab] OR sensor*[tiab] OR system[tiab]) AND (patient*[tiab] OR clinical[tiab] OR health*[tiab] OR human*[tiab] OR monitoring[tiab]) NOT (food[tiab] OR milk[tiab] OR meat[tiab] OR crop*[tiab] OR soil[tiab])', { ret: 50 }),
  PM('pm-robot', 'PubMed: ロボット・補綴', '("surgical robot*"[tiab] OR "robot-assisted"[tiab] OR exoskeleton*[tiab] OR "prosthetic hand"[tiab] OR "powered prosthesis"[tiab] OR "rehabilitation robot*"[tiab])', { ret: 40 }),
  PM('pm-implant', 'PubMed: 人工臓器・埋込機器', '("artificial heart"[tiab] OR "ventricular assist device"[tiab] OR "cochlear implant*"[tiab] OR "artificial pancreas"[tiab] OR "implantable"[tiab] AND device*[tiab])', { ret: 40 }),
  PM('pm-imaging', 'PubMed: 医用画像・AI', '("deep learning"[tiab] OR "foundation model"[tiab]) AND (MRI[tiab] OR "computed tomography"[tiab] OR ultrasound[tiab] OR endoscop*[tiab] OR "medical image*"[tiab])', { ret: 40 }),
  PM('pm-regen', 'PubMed: 組織工学・材料', '("tissue engineering"[tiab] OR bioprint*[tiab] OR "organ-on-a-chip"[tiab] OR (scaffold*[tiab] AND regenerat*[tiab]))', { ret: 40 }),
  { id: 'arxiv', name: 'arXiv', kind: 'rss', url: 'https://export.arxiv.org/api/query?sortBy=submittedDate&sortOrder=descending&max_results=60&search_query=' + encodeURIComponent('abs:"brain-computer interface" OR abs:"neural decoding" OR abs:"intracortical" OR abs:"medical image" OR abs:"wearable sensor" OR abs:"biomedical signal" OR abs:"surgical robot" OR abs:"photoplethysmography"'), type: 'paper', every: 6, filter: 'none' },
  { id: 'biorxiv-bioeng', name: 'bioRxiv Bioengineering', kind: 'rss', url: 'https://connect.biorxiv.org/biorxiv_xml.php?subject=bioengineering', type: 'paper', every: 6, filter: 'none' },
  { id: 'biorxiv-neuro', name: 'bioRxiv Neuroscience', kind: 'rss', url: 'https://connect.biorxiv.org/biorxiv_xml.php?subject=neuroscience', type: 'paper', every: 6, filter: 'kw', kw: NEUROTECH_KW },
  // approvals and regulation
  { id: 'fda-510k', name: 'FDA 510(k)', kind: 'fda510k', type: 'reg', every: 6, filter: 'none' },
  { id: 'fda-pma', name: 'FDA PMA 承認', kind: 'fdapma', type: 'reg', every: 12, filter: 'none', tier: 3 },
  { id: 'fda-recall', name: 'FDA クラスIリコール', kind: 'fdarecall', type: 'reg', every: 12, filter: 'none' },
  { id: 'fda-press', name: 'FDA Press', kind: 'rss', url: 'https://www.fda.gov/about-fda/contact-fda/stay-informed/rss-feeds/press-releases/rss.xml', type: 'reg', every: 3, filter: 'kw', kw: 'device|diagnostic|digital|software|implant|AI\\b|artificial intelligence|neuro|brain|monitor' },
  { id: 'pmda', name: 'PMDA', kind: 'rss', url: 'https://www.pmda.go.jp/rss_008.xml', type: 'reg', every: 6, filter: 'kw', kw: 'device|SaMD|medical device|regenerative|AI|プログラム|医療機器|再生医療' },
  { id: 'mhlw', name: '厚生労働省', kind: 'rss', url: 'https://www.mhlw.go.jp/stf/news.rdf', type: 'reg', every: 3, filter: 'kw', kw: '医療機器|プログラム医療機器|再生医療|デジタルヘルス|薬事|医療ＤＸ|医療DX|ＡＩ.{0,6}医療|AI.{0,6}医療', lang: 'ja' },
  // clinical trials
  { id: 'ctgov', name: 'ClinicalTrials.gov', kind: 'ctgov', type: 'trial', every: 6, filter: 'none' },
  // universities, academic, calls
  { id: 'tuat-research', name: '東京農工大学 研究成果', un: '東京農工大学', kind: 'rss', url: 'http://www.tuat.ac.jp/NEWS/research/rss.xml', type: 'acad', every: 6, filter: 'none', lang: 'ja', tier: 2 },
  { id: 'tuat-event', name: '東京農工大学 イベント', un: '東京農工大学', kind: 'rss', url: 'http://www.tuat.ac.jp/event/rss.xml', type: 'acad', every: 12, filter: 'none', lang: 'ja' },
  { id: 'mit-neuro', name: 'MIT News: Neuroscience', un: 'MIT', kind: 'rss', url: 'https://news.mit.edu/rss/topic/neuroscience', type: 'acad', every: 3, filter: 'bme' },
  { id: 'riken', name: '理化学研究所 プレスリリース', un: '理化学研究所', kind: 'rss', url: 'https://www.riken.jp/feed/press_feed/', type: 'acad', every: 3, filter: 'bme', lang: 'ja' },
  { id: 'univ-journal', name: '大学ジャーナル', kind: 'rss', url: 'https://univ-journal.jp/feed/', type: 'acad', every: 3, filter: 'bme', lang: 'ja' },
  { id: 'jst-portal', name: 'JST サイエンスポータル', kind: 'rss', url: 'https://scienceportal.jst.go.jp/feed/rss.xml', type: 'acad', every: 3, filter: 'bme', lang: 'ja' },
  { id: 'nih-guide', name: 'NIH 公募', kind: 'rss', url: 'https://grants.nih.gov/grants/guide/newsfeed/fundingopps.xml', type: 'acad', every: 12, filter: 'bme' },
];

/* ---------- universities and institutes (editable in the app; each group becomes a Google News search) ---------- */
const DEFAULT_UNIVS = ['東京大学', '京都大学', '大阪大学', '東北大学', '東京科学大学', '慶應義塾大学', '早稲田大学', '名古屋大学', '九州大学', '北海道大学', '筑波大学', '神戸大学',
  '東京農工大学', '理化学研究所', '産業技術総合研究所', '情報通信研究機構', '国際電気通信基礎技術研究所',
  'MIT', 'Stanford', 'Caltech', 'Harvard', 'Johns Hopkins', 'Carnegie Mellon', 'UC San Francisco', 'UC Davis', 'University of Pittsburgh', 'Brown University',
  'Northwestern University', 'University of Michigan', 'EPFL', 'ETH Zurich', 'Wyss Center', 'Imperial College', 'University College London', 'Max Planck'];
const UNIV_TOPIC_JA = '(脳 OR 神経 OR 医療機器 OR 医工学 OR BMI OR ブレイン OR 生体 OR インプラント OR 義手 OR リハビリ OR 再生医療 OR 診断 OR センサ)';
const UNIV_TOPIC_EN = '("brain-computer interface" OR "brain implant" OR neural OR neuroprosthetic OR neurotechnology OR "medical device" OR biomedical OR implant OR prosthetic OR wearable OR "spinal cord")';
const isJaName = function (n) { return /[぀-ヿ一-鿿]/.test(n); };
function univSources(names) {
  const out = [];
  [['ja', names.filter(isJaName)], ['en', names.filter(function (n) { return !isJaName(n); })]].forEach(function (g) {
    for (let i = 0; i < g[1].length; i += 6) {
      const part = g[1].slice(i, i + 6);
      const q = '(' + part.map(function (n) { return /\s/.test(n) ? '"' + n + '"' : n; }).join(' OR ') + ') ' + (g[0] === 'ja' ? UNIV_TOPIC_JA : UNIV_TOPIC_EN);
      out.push(GN('gn-univ-' + g[0] + '-' + hashId(part.join('|')), (g[0] === 'ja' ? 'Google ニュース: ' : 'Google News: ') + part.slice(0, 2).join('・') + (part.length > 2 ? ' ほか' + (part.length - 2) : ''), q,
        { type: 'acad', every: 2, lang: g[0] === 'ja' ? 'ja' : undefined, univ: 1 }));
    }
  });
  return out;
}
function allSources_(prefs) { return SOURCES.concat(univSources(prefs.univ)); }
function univRegex(names) {
  if (!names || !names.length) return null;
  return new RegExp(names.map(function (n) { const e = n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); return isJaName(n) ? e : '\\b' + e + '\\b'; }).join('|'));
}
function markUniv(items, re, srcUn) {
  items.forEach(function (it) {
    const m = re && (it.t + ' ' + (it.x || '') + ' ' + it.s).match(re);
    if (m) it.un = m[0]; else if (srcUn[it.sid]) it.un = srcUn[it.sid]; else delete it.un;
  });
}

/* ---------- categories ---------- */
const CATS = {
  brain: { name: '脳・神経', re: /brain|neur(o|al|on)|cortex|cortical|cerebr|spinal cord|\bEEG\b|\bBCIs?\b|\bBMIs?\b(?![\s-]*(index|score|value|of))|deep brain|\bDBS\b|\bTMS\b|epilep|parkinson|alzheimer|dementia|stroke|\bALS\b|seizure|neuromodulat|optogenet|vagus|cochlear|retinal prosthe|脳|神経|脊髄|てんかん|パーキンソン|認知症|脳卒中/i },
  imaging: { name: '医用画像', re: /\bf?MRI\b|\bCT\b|computed tomograph|ultrasound|ultrasonograph|\bPET\b|x-ray|radiograph|radiolog|mammograph|endoscop|\bOCT\b|optical coherence|photoacoustic|imaging|画像|内視鏡|超音波|MRI|ＣＴ/i },
  sensing: { name: '生体計測・ウェアラブル', re: /wearable|biosensor|sensor|smartwatch|\bECG\b|\bEKG\b|electrocardiog|\bPPG\b|photoplethysm|pulse oxim|oximet|SpO2|blood pressure|cuffless|glucose monitor|\bCGM\b|sweat|remote (patient )?monitoring|ウェアラブル|センサ|血圧|血糖|パルスオキシ|心電|生体計測/i },
  implant: { name: '人工臓器・埋込機器', re: /implant|pacemaker|defibrillator|\bLVAD\b|ventricular assist|artificial (heart|pancreas|kidney|organ|lung|retina)|cochlear|stent|heart valve|\bTAVR\b|dialys|catheter|人工(心臓|臓器|膵臓|関節|網膜)|インプラント|ステント|カテーテル|ペースメーカ|人工内耳/i },
  regen: { name: '再生医療・材料', re: /tissue engineer|regenerat|scaffold|biomaterial|hydrogel|bioprint|organoid|organ[-\s]on[-\s]a[-\s]chip|stem cell|\biPS|biofabricat|biodegradable|再生医療|組織工学|バイオマテリアル|足場材料|オルガノイド|iPS/i },
  robot: { name: '手術支援・ロボット・補綴', re: /robot|exoskeleton|prosthe(sis|tic|ses)|bionic|da vinci|teleoperat|haptic|rehabilitat|ロボット|義手|義足|リハビリ|外骨格/i },
  ai: { name: 'AI・デジタルヘルス', re: /\bAI\b|artificial intelligence|machine learning|deep learning|neural network|foundation model|language model|\bLLMs?\b|digital health|telehealth|telemedicine|software as a medical device|\bSaMD\b|digital therapeut|人工知能|機械学習|深層学習|生成AI|デジタルヘルス|プログラム医療機器|遠隔医療|ＡＩ/i },
  therapy: { name: '治療機器・DDS', re: /drug delivery|microneedle|nanoparticle|radiotherapy|radiation therapy|proton therapy|ablation|laser|focused ultrasound|\bHIFU\b|electroporation|photodynamic|hyperthermia|infusion pump|insulin pump|ドラッグデリバリー|マイクロニードル|放射線治療|陽子線|アブレーション|レーザー/i },
};
const STRONG_RE = /biomedical engineer|bioengineer|medical device|medtech|med-tech|neurotech|brain[-‐‑–—\s]{0,2}(computer|machine) interface|neural interface|\bBCIs?\b|\bSaMD\b|510\(k\)|De Novo|医工学|生体医工|医療機器|プログラム医療機器|ニューロテック|ブレイン.?(マシン|コンピュータ)/i;
const MED_RE = /patient|clinical|clinic|medical|medicine|health|disease|disorder|surgery|surgical|surgeon|hospital|therap|diagnos|cancer|tumou?r|cardiac|cardio|heart|arrhythm|atrial|\bECG\b|\bEKG\b|brain|neuro|epilep|parkinson|alzheimer|dementia|diabet|glucose|insulin|stroke|injur|paraly|rehabilit|blood|organ|tissue|lung|pulmon|respirat|kidney|renal|liver|retina|hearing|wound|bone|ortho|spine|spinal|pain|sleep apnea|\bFDA\b|PMDA|医療|患者|病院|治療|診断|疾患|手術|がん|心臓|脳|神経|糖尿病|リハビリ|臨床|健康/i;
const ENG_RE = /device|sensor|imaging|implant|robot|wearable|algorithm|\bAI\b|machine learning|engineer|material|scaffold|electrode|ultrasound|laser|chip|stimulat|prosthe|system|3D[- ]print|bioprint|nanoparticle|microneedle|catheter|stent|monitor|interface|platform|software|デバイス|機器|装置|センサ|ロボット|電極|材料|システム|ソフトウェア|AI|ＡＩ|開発|技術/i;
const BIZ_RE = /\braises?\b|\bfunding\b|series [a-e]\b|acqui(re|res|red|sition)|merger|\bIPO\b|investment round|financing|資金調達|買収|出資|上場|シリーズ[A-EＡ-Ｅ]/i;
const REG_RE = /FDA (clear|approv|grant|authori)|510\(k\)|De Novo|\bPMA\b|CE mark|breakthrough device|recall|承認(を)?取得|薬事承認|製造販売承認|認証取得|PMDA/i;
const BCI_RE = /brain[-‐‑–—\s]{0,2}(computer|machine) interface|\bBCIs?\b|neural interface|neuroprosthe|brain implant|intracortical|\bECoG\b|electrocorticograph|utah array|speech decod|neural decod|Neuralink|\bSynchron\b|Stentrode|Precision Neuroscience|Paradromics|Blackrock Neurotech|BrainGate|Science Corp|Merge Labs|\bBrainCo\b|\bINBRAIN\b|Axoft|Neurable|Cognixion|ブレイン.?(マシン|コンピュータ)|ＢＭＩ|\bBMI\b(?![\s-]*(index|score|value|of|値))|脳波.{0,6}(操作|解読|入力)|脳.{0,4}(インプラント|解読)/i;
const NOT_BME_RE = /brain[-\s]inspired|neuromorphic|brainstorm|brain drain|brain ?rot|brain teaser|neural network (chip|processor)|AI chip|large language model|chatbot/i;
const TOP_SOURCES = /Nature|Science|NEJM|Lancet|Cell|IEEE Trans|J Neural Eng|Journal of Neural Engineering/i;

/* ========== setup / triggers ========== */
function setup() {
  if (!PASS_PHRASE || PASS_PHRASE.indexOf('ここを') === 0) throw new Error('PASS_PHRASE を書き換えてから実行してください');
  const props = PropertiesService.getScriptProperties();
  props.setProperty('PASS', PASS_PHRASE);
  dataFolder_();
  installTriggers_(getPrefs_().email.hour);
  briefKey_();
  vapid_();
  try { updateStocks(); } catch (e) { Logger.log('株価: ' + e); }
  const r = collect_({ force: true });
  Logger.log('準備完了: ' + JSON.stringify(r));
}
function installTriggers_(hour) {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    const h = t.getHandlerFunction(); if (['updateNews', 'sendDigest', 'updateStocks', 'pushMorning', 'pushEvening'].indexOf(h) >= 0) ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('pushMorning').timeBased().atHour(6).nearMinute(0).everyDays(1).inTimezone('Asia/Tokyo').create();
  ScriptApp.newTrigger('pushEvening').timeBased().atHour(19).nearMinute(0).everyDays(1).inTimezone('Asia/Tokyo').create();
  ScriptApp.newTrigger('updateNews').timeBased().everyHours(1).create();
  ScriptApp.newTrigger('updateStocks').timeBased().everyMinutes(15).create();
  ScriptApp.newTrigger('sendDigest').timeBased().atHour(hour).everyDays(1).inTimezone('Asia/Tokyo').create();
}
/* hourly trigger */
function updateNews() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(2000)) return { busy: true };
  try { return collect_({}); } finally { lock.releaseLock(); }
}

/* ========== web endpoints ========== */
function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    if (p.v === 'more') return json_(queryArchive_({ before: +p.before || Date.now(), type: p.type || '', cat: p.cat || '', bci: p.bci === '1', q: '', limit: 150 }));
    if (p.v === 'search') return json_(queryArchive_({ before: Date.now() + 864e5, type: p.type || '', cat: p.cat || '', bci: p.bci === '1', q: String(p.q || ''), limit: 200, months: 12 }));
    if (p.v === 'stocks') { const c = cacheGet_('stocks'); return c ? ContentService.createTextOutput(c).setMimeType(ContentService.MimeType.JSON) : json_(readJson_('stocks.json', { ok: true, updated: 0, quotes: [] })); }
    if (p.v === 'brief-input') return json_(briefInput(readJson_('index.json', { items: [] }).items, Date.now(), +p.h || 36));
    if (p.v === 'read') return json_(readArticle_(String(p.id || ''), p.ja === '1'));
    if (p.v === 'vapid') return json_({ ok: true, key: vapid_().pub });
    if (p.v === 'push-latest') return json_(pushMessage_(Date.now()));
    let body = cacheGet_('feed');
    if (!body) { body = JSON.stringify(readJson_('feed.json', { ok: true, updated: 0, items: [], highlights: [], brain: [], trends: [], stats: [], sources: [] })); cachePut_('feed', body); }
    return ContentService.createTextOutput(body).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}
function doPost(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'bad request' }); }
  if (req.action === 'brief-save') {
    if (!req.key || req.key !== briefKey_()) return json_({ ok: false, error: 'auth' });
    const b = sanitizeBrief(req.brief);
    if (!b) return json_({ ok: false, error: 'bad brief' });
    writeJson_('brief.json', b);
    const lock = LockService.getScriptLock();
    if (lock.tryLock(20000)) { try { rebuild_(); } finally { lock.releaseLock(); } }
    return json_({ ok: true, at: b.at });
  }
  if (!checkPass_(req.pass)) return json_({ ok: false, error: 'auth' });
  try {
    switch (req.action) {
      case 'prefs-get': return json_({ ok: true, prefs: getPrefs_(), email: Session.getEffectiveUser().getEmail(), briefKey: briefKey_() });
      case 'prefs-set': {
        const old = getPrefs_(), p = sanitizePrefs_(Object.assign({}, old, req.prefs || {}));
        PropertiesService.getScriptProperties().setProperty('PREFS', JSON.stringify(p));
        if (p.email.hour !== old.email.hour) installTriggers_(p.email.hour);
        if (JSON.stringify(p.tickers) !== JSON.stringify(old.tickers)) { try { updateStocks(true); } catch (e) {} }
        if (JSON.stringify(p.watch) !== JSON.stringify(old.watch) || JSON.stringify(p.univ) !== JSON.stringify(old.univ)) { const lock = LockService.getScriptLock(); if (lock.tryLock(10000)) { try { rebuild_(); } finally { lock.releaseLock(); } } }
        return json_({ ok: true, prefs: p });
      }
      case 'bm-load': return json_(Object.assign({ ok: true }, readJson_('bookmarks.json', { updated: 0, items: {} })));
      case 'bm-save': { const o = { updated: Date.now(), items: req.items || {} }; writeJson_('bookmarks.json', o); return json_({ ok: true, updated: o.updated }); }
      case 'refresh': { const r = updateNews(); return json_(r.busy ? { ok: false, error: 'busy' } : Object.assign({ ok: true }, r)); }
      case 'force': { const lock = LockService.getScriptLock(); if (!lock.tryLock(2000)) return json_({ ok: false, error: 'busy' }); try { return json_(Object.assign({ ok: true }, collect_({ force: true }))); } finally { lock.releaseLock(); } }
      case 'stocks': return json_(Object.assign({ ok: true }, updateStocks(true)));
      case 'push-sub': return json_(Object.assign({ ok: true }, pushSubscribe_(req.sub, req.am !== false, req.pm !== false, String(req.label || '').slice(0, 40))));
      case 'push-unsub': { const subs = readJson_('subs.json', { list: [] }); subs.list = subs.list.filter(function (x) { return x.endpoint !== req.endpoint; }); writeJson_('subs.json', subs); return json_({ ok: true }); }
      case 'push-test': { const subs = readJson_('subs.json', { list: [] }).list.filter(function (x) { return x.endpoint === req.endpoint; }); if (!subs.length) return json_({ ok: false, error: 'この端末は通知に登録されていません' }); const r = sendPush_(subs[0]); return json_({ ok: r.ok, code: r.code, error: r.ok ? '' : '通知サービスが受け付けませんでした (' + r.code + ')' }); }
      case 'dev-load': return json_(Object.assign({ ok: true }, readJson_('devnotes.json', { updated: 0, items: {} })));
      case 'dev-save': { const o = { updated: Date.now(), items: req.items || {} }; writeJson_('devnotes.json', o); return json_({ ok: true, updated: o.updated }); }
      case 'digest-test': { const r = sendDigest(true); return json_(Object.assign({ ok: true }, r)); }
      default: return json_({ ok: false, error: 'unknown action' });
    }
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

/* ========== preferences ========== */
function getPrefs_() {
  let p = {};
  try { p = JSON.parse(PropertiesService.getScriptProperties().getProperty('PREFS') || '{}'); } catch (e) {}
  return sanitizePrefs_(p);
}
function sanitizePrefs_(p) {
  const e = p.email || {};
  return {
    watch: (Array.isArray(p.watch) ? p.watch : []).map(function (s) { return String(s).trim(); }).filter(function (s) { return s; }).slice(0, 40),
    muted: Array.isArray(p.muted) ? p.muted.slice(0, 100) : [],
    tickers: (Array.isArray(p.tickers) ? p.tickers : DEFAULT_TICKERS).map(function (t) { return { s: String(t.s || '').trim().toUpperCase().slice(0, 16), n: String(t.n || t.s || '').trim().slice(0, 40), k: String(t.k || '').slice(0, 60) }; }).filter(function (t) { return /^[A-Z0-9.\-^=]+$/.test(t.s); }).slice(0, 30),
    translate: p.translate !== false,
    univ: (Array.isArray(p.univ) ? p.univ : DEFAULT_UNIVS).map(function (s) { return String(s).replace(/["()]/g, '').trim().slice(0, 60); }).filter(function (s) { return s; }).slice(0, 80),
    email: { on: e.on !== false, hour: Math.max(0, Math.min(23, isFinite(+e.hour) && e.hour !== '' ? +e.hour : 7)), to: String(e.to || '').trim(), max: Math.max(5, Math.min(40, +e.max || 15)) }
  };
}
function markBci(items) { items.forEach(function (it) { const b = BCI_RE.test(it.t + ' ' + (it.x || '')) ? 1 : 0; if (b) { it.b = 1; if (it.g.indexOf('brain') < 0) it.g.unshift('brain'); } else delete it.b; }); }
function markWatch(items, wre) { items.forEach(function (it) { it.w = wre && wre.test(it.t + ' ' + (it.x || '') + ' ' + it.s) ? 1 : 0; }); }
/* rebuild feed.json from the index without fetching (after the watch list changes) */
function rebuild_() {
  const now = Date.now(), index = readJson_('index.json', { items: [] }), state = readJson_('state.json', { last: {}, status: {} });
  const pr = getPrefs_(), srcUn = {};
  allSources_(pr).forEach(function (s) { if (s.un) srcUn[s.id] = s.un; });
  markUniv(index.items, univRegex(pr.univ), srcUn);
  markWatch(index.items, watchRegex(pr.watch));
  writeJson_('index.json', index);
  const feed = buildFeed(index.items, state, now, allSources_(getPrefs_()));
  feed.brief = readJson_('brief.json', null);
  writeJson_('feed.json', feed); cachePut_('feed', JSON.stringify(feed));
}
function briefKey_() {
  const props = PropertiesService.getScriptProperties();
  let k = props.getProperty('BRIEF_KEY');
  if (!k) { k = Utilities.getUuid().replace(/-/g, ''); props.setProperty('BRIEF_KEY', k); }
  return k;
}
function watchRegex(words) {
  if (!words || !words.length) return null;
  return new RegExp(words.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|'), 'i');
}

/* ========== collection ========== */
function collect_(opts) {
  const t0 = Date.now(), now = Date.now();
  const state = readJson_('state.json', { last: {}, status: {} });
  const index = readJson_('index.json', { items: [] });
  const prefs = getPrefs_(), wre = watchRegex(prefs.watch);
  const byId = {}, byTitle = {};
  index.items.forEach(function (it) { byId[it.id] = it; byTitle[normTitle(it.t)] = it.id; });
  const recent = index.items.filter(function (it) { return it.d > now - 3 * 864e5; }).map(function (it) { return { it: it, tok: titleTokens(it.t) }; });
  const sources = allSources_(prefs);
  const due = sources.filter(function (s) {
    if (prefs.muted.indexOf(s.id) >= 0) return false;
    return opts.force || !state.last[s.id] || now - state.last[s.id] >= s.every * 36e5 - 6 * 6e4;
  });
  const fresh = [];
  const ingest = function (src, raws) {
    let n = 0;
    raws.slice(0, src.ret || 80).forEach(function (r) {
      const it = normalizeItem(r, src, now);
      if (!it) return;
      const nt = normTitle(it.t);
      if (byId[it.id] || byTitle[nt]) return;
      it.sc = scoreItem(it, src);
      assignCluster(it, recent);
      byId[it.id] = it; byTitle[nt] = it.id; fresh.push(it); n++;
    });
    return n;
  };
  // network sources, a dozen at a time
  const net = due.filter(function (s) { return s.kind !== 'pubmed'; });
  for (let i = 0; i < net.length && Date.now() - t0 < TIME_BUDGET_MS; i += 12) {
    const chunk = net.slice(i, i + 12);
    let res = [];
    const reqOf = function (s) { return { url: sourceUrl(s, now), muteHttpExceptions: true, followRedirects: true, headers: { 'User-Agent': 'Mozilla/5.0 (compatible; bme-radar/1.0)' } }; };
    try { res = UrlFetchApp.fetchAll(chunk.map(reqOf)); }
    catch (err) {
      // one bad address makes fetchAll throw for the whole batch: fetch one by one instead
      res = chunk.map(function (s) { try { const q = reqOf(s), u = q.url; delete q.url; return UrlFetchApp.fetch(u, q); } catch (e) { return { error: String(e.message || e).replace(/: https?:\/\/\S+/, '').slice(0, 80) }; } });
    }
    chunk.forEach(function (s, k) {
      try {
        if (res[k].error) { state.status[s.id] = { ok: false, error: res[k].error, at: now }; return; }
        const code = res[k].getResponseCode();
        if (code === 404 && /^fda/.test(s.kind)) { state.status[s.id] = { ok: true, n: 0, at: now }; state.last[s.id] = now; return; }  // openFDA: no matches
        if (code >= 400) { state.status[s.id] = { ok: false, error: 'HTTP ' + code, at: now }; return; }
        const raws = parseSource(s, res[k].getContentText());
        state.status[s.id] = { ok: true, n: ingest(s, raws), seen: raws.length, at: now };
        state.last[s.id] = now;
      } catch (err) { state.status[s.id] = { ok: false, error: String(err && err.message || err).slice(0, 100), at: now }; }
    });
  }
  // PubMed politely, one request at a time
  due.filter(function (s) { return s.kind === 'pubmed'; }).forEach(function (s) {
    if (Date.now() - t0 > TIME_BUDGET_MS) return;
    try {
      const raws = pubmedFetch_(s);
      state.status[s.id] = { ok: true, n: ingest(s, raws), seen: raws.length, at: now };
      state.last[s.id] = now;
    } catch (err) { state.status[s.id] = { ok: false, error: String(err && err.message || err).slice(0, 100), at: now }; }
    Utilities.sleep(400);
  });
  // keep 30 days in the index; everything also goes to the monthly archive
  const cutoff = now - INDEX_DAYS * 864e5;
  const items = Object.keys(byId).map(function (k) { return byId[k]; }).filter(function (it) { return it.d >= cutoff; }).sort(function (a, b) { return b.d - a.d; });
  refreshClusterCounts(items);
  markBci(items);
  const srcUn = {}; sources.forEach(function (s) { if (s.un) srcUn[s.id] = s.un; });
  markUniv(items, univRegex(prefs.univ), srcUn);
  markWatch(items, wre);
  if (prefs.translate) translateItems_(items, t0);
  writeJson_('index.json', { updated: now, items: items });
  if (fresh.length) archiveAppend_(fresh);
  state.updated = now;
  writeJson_('state.json', state);
  const feed = buildFeed(items, state, now, sources);
  feed.brief = readJson_('brief.json', null);
  writeJson_('feed.json', feed);
  cachePut_('feed', JSON.stringify(feed));
  return { added: fresh.length, fetched: due.length, total: items.length, ms: Date.now() - t0, failed: due.filter(function (s) { return state.status[s.id] && !state.status[s.id].ok; }).length };
}

function sourceUrl(s, now) {
  if (s.kind === 'rss') return s.url;
  if (s.kind === 'gnews') return 'https://news.google.com/rss/search?q=' + encodeURIComponent(s.q + ' when:3d') + (s.lang === 'ja' ? '&hl=ja&gl=JP&ceid=JP:ja' : '&hl=en-US&gl=US&ceid=US:en');
  const ymd = function (ms) { const d = new Date(ms); return d.getUTCFullYear() + ('0' + (d.getUTCMonth() + 1)).slice(-2) + ('0' + d.getUTCDate()).slice(-2); };
  if (s.kind === 'fda510k') return 'https://api.fda.gov/device/510k.json?limit=100&sort=decision_date:desc&search=decision_date:[' + ymd(now - 10 * 864e5) + '+TO+' + ymd(now) + ']';
  if (s.kind === 'fdapma') return 'https://api.fda.gov/device/pma.json?limit=100&sort=decision_date:desc&search=decision_date:[' + ymd(now - 30 * 864e5) + '+TO+' + ymd(now) + ']';
  if (s.kind === 'fdarecall') return 'https://api.fda.gov/device/enforcement.json?limit=50&sort=report_date:desc&search=report_date:[' + ymd(now - 30 * 864e5) + '+TO+' + ymd(now) + ']+AND+classification:%22Class+I%22';
  if (s.kind === 'ctgov') {
    const from = new Date(now - 4 * 864e5).toISOString().slice(0, 10);
    return 'https://clinicaltrials.gov/api/v2/studies?pageSize=100&sort=StudyFirstPostDate:desc&filter.advanced=' + encodeURIComponent('AREA[InterventionType]DEVICE AND AREA[StudyFirstPostDate]RANGE[' + from + ',MAX]');
  }
  return '';
}
function parseSource(s, text) {
  switch (s.kind) {
    case 'rss': case 'gnews': return parseFeed(text);
    case 'fda510k': return fda510kItems(JSON.parse(text));
    case 'fdapma': return fdaPmaItems(JSON.parse(text));
    case 'fdarecall': return fdaRecallItems(JSON.parse(text));
    case 'ctgov': return ctgovItems(JSON.parse(text));
  }
  return [];
}
function pubmedFetch_(s) {
  const base = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
  const r1 = UrlFetchApp.fetch(base + 'esearch.fcgi?db=pubmed&retmode=json&sort=pub_date&datetype=edat&reldate=3&retmax=' + (s.ret || 60) + '&term=' + encodeURIComponent(s.term), { muteHttpExceptions: true });
  if (r1.getResponseCode() >= 400) throw new Error('HTTP ' + r1.getResponseCode());
  const ids = ((JSON.parse(r1.getContentText()).esearchresult || {}).idlist) || [];
  if (!ids.length) return [];
  Utilities.sleep(350);
  const r2 = UrlFetchApp.fetch(base + 'esummary.fcgi?db=pubmed&retmode=json&id=' + ids.join(','), { muteHttpExceptions: true });
  if (r2.getResponseCode() >= 400) throw new Error('HTTP ' + r2.getResponseCode());
  return pubmedSummaryToItems(JSON.parse(r2.getContentText()));
}

/* ========== Japanese titles (Google translation built into Apps Script, free) ========== */
function translateItems_(items, t0) {
  const todo = items.filter(function (it) { return it.l !== 'ja' && it.tj == null && it.d > Date.now() - 4 * 864e5; })
    .sort(function (a, b) { return (b.b || 0) - (a.b || 0) || b.sc - a.sc; }).slice(0, 240);
  for (let i = 0; i < todo.length && Date.now() - t0 < TIME_BUDGET_MS + 20000; i += 30) {
    const batch = todo.slice(i, i + 30);
    try {
      const out = LanguageApp.translate(batch.map(function (it) { return it.t.replace(/\s*\n\s*/g, ' '); }).join('\n'), 'en', 'ja').split(/\n/);
      if (out.length === batch.length) batch.forEach(function (it, k) { it.tj = out[k].trim(); });
      else batch.forEach(function (it) { try { it.tj = LanguageApp.translate(it.t, 'en', 'ja'); } catch (e) { it.tj = ''; } });
    } catch (err) { Logger.log('translate: ' + err); break; }
  }
}

/* ========== share prices (Yahoo Finance chart API, Stooq as a fallback for US/JP) ========== */
const DEFAULT_TICKERS = [
  { s: 'CLPT', n: 'ClearPoint Neuro', k: 'ClearPoint' }, { s: 'NPCE', n: 'NeuroPace', k: 'NeuroPace' }, { s: 'CBLL', n: 'Ceribell', k: 'Ceribell' },
  { s: 'ONWD.BR', n: 'ONWARD Medical', k: 'ONWARD' }, { s: 'INSP', n: 'Inspire Medical', k: 'Inspire Medical' }, { s: 'LIVN', n: 'LivaNova', k: 'LivaNova' },
  { s: 'BWAY', n: 'BrainsWay', k: 'BrainsWay' }, { s: 'NMTC', n: 'NeuroOne', k: 'NeuroOne' }, { s: 'WLDS', n: 'Wearable Devices', k: 'Wearable Devices' },
  { s: 'HYPR', n: 'Hyperfine', k: 'Hyperfine' }, { s: 'BFLY', n: 'Butterfly Network', k: 'Butterfly Network' }, { s: 'MDT', n: 'Medtronic', k: 'Medtronic' },
  { s: 'BSX', n: 'Boston Scientific', k: 'Boston Scientific' }, { s: 'ABT', n: 'Abbott', k: 'Abbott' }, { s: 'COH.AX', n: 'Cochlear', k: 'Cochlear' },
  { s: '6849.T', n: '日本光電', k: '日本光電' }, { s: 'NVDA', n: 'NVIDIA', k: 'NVIDIA' }
];
function updateStocks(force) {
  const props = PropertiesService.getScriptProperties();
  const last = +(props.getProperty('STOCKS_AT') || 0);
  if (force !== true && Date.now() - last < 13 * 6e4) return { skipped: true };
  const tickers = getPrefs_().tickers, prev = readJson_('stocks.json', { quotes: [] });
  const old = {}; prev.quotes.forEach(function (q) { old[q.s] = q; });
  const res = UrlFetchApp.fetchAll(tickers.map(function (t) {
    return { url: 'https://query1.finance.yahoo.com/v8/finance/chart/' + encodeURIComponent(t.s) + '?range=1y&interval=1d&includePrePost=false', muteHttpExceptions: true, headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36' } };
  }));
  let failed = 0;
  const quotes = tickers.map(function (t, i) {
    let q = null;
    try { if (res[i].getResponseCode() === 200) q = yahooChartToQuote(JSON.parse(res[i].getContentText())); } catch (e) {}
    if (!q) { try { q = stooqQuote_(t.s, old[t.s]); } catch (e) {} }
    if (!q) { failed++; const o = old[t.s]; return Object.assign({}, o || {}, { s: t.s, n: t.n, k: t.k, ok: false, error: 'HTTP ' + (res[i].getResponseCode ? res[i].getResponseCode() : '?') }); }
    return Object.assign(q, { s: t.s, n: t.n, k: t.k, ok: true });
  });
  const out = { ok: true, updated: Date.now(), quotes: quotes };
  writeJson_('stocks.json', out); cachePut_('stocks', JSON.stringify(out));
  props.setProperty('STOCKS_AT', String(Date.now()));
  return { quotes: quotes.length, failed: failed };
}
function stooqQuote_(sym, old) {
  let st = null;
  if (/^[A-Z]+$/.test(sym)) st = sym.toLowerCase() + '.us';
  else if (/^\d{4}\.T$/.test(sym)) st = sym.slice(0, 4) + '.jp';
  if (!st) return null;
  const r = UrlFetchApp.fetch('https://stooq.com/q/d/l/?s=' + st + '&i=d', { muteHttpExceptions: true });
  if (r.getResponseCode() !== 200) return null;
  return stooqCsvToQuote(r.getContentText());
}

/* ========== in-app reader ========== */
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';
function findItem_(id) {
  if (!/^[a-z0-9]{3,14}$/.test(id)) return null;
  const hit = function (list) { for (let i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; };
  let it = hit(readJson_('index.json', { items: [] }).items);
  if (it) return it;
  const bm = readJson_('bookmarks.json', { items: {} }).items || {};
  if (bm[id] && bm[id].u) return bm[id];
  for (let m = 0; m < 4 && !it; m++) { const d = new Date(); d.setMonth(d.getMonth() - m); it = hit(readJson_('archive_' + monthKey(d.getTime()) + '.json', { items: [] }).items); }
  return it;
}
function readArticle_(id, ja) {
  const key = 'rd_' + id + (ja ? '_ja' : '');
  const cached = cacheGet_(key);
  if (cached) return JSON.parse(cached);
  const it = findItem_(id);
  if (!it) return { ok: false, error: 'not found' };
  let art = null, url = it.u, err = '';
  try {
    if (/news\.google\.com\/(rss\/)?articles\//.test(url)) url = resolveGoogleNews_(url) || url;
    let m;
    if ((m = url.match(/pubmed\.ncbi\.nlm\.nih\.gov\/(\d+)/))) {
      const r = UrlFetchApp.fetch('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=' + m[1], { muteHttpExceptions: true });
      art = parsePubmedXml(r.getContentText());
    } else if ((m = url.match(/clinicaltrials\.gov\/study\/(NCT\d+)/))) {
      const r = UrlFetchApp.fetch('https://clinicaltrials.gov/api/v2/studies/' + m[1], { muteHttpExceptions: true });
      art = ctgovStudyToArticle(JSON.parse(r.getContentText()));
    } else if (!/news\.google\.com/.test(url)) {
      const r = UrlFetchApp.fetch(url, { muteHttpExceptions: true, followRedirects: true, headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9,ja;q=0.8' } });
      if (r.getResponseCode() >= 400) err = 'HTTP ' + r.getResponseCode();
      else art = extractArticle(decodeHtml_(r), url);
    }
  } catch (e) { err = String(e && e.message || e).slice(0, 120); }
  const out = buildReaderResult(it, url, art, err);
  if (ja && out.paras.length) translateParas_(out);
  const str = JSON.stringify(out);
  cachePut_(key, str);
  return out;
}
function decodeHtml_(res) {
  const blob = res.getBlob(), head = blob.getDataAsString('ISO-8859-1').slice(0, 3000);
  const ct = String((res.getHeaders() || {})['Content-Type'] || (res.getHeaders() || {})['content-type'] || '');
  const cs = ((ct.match(/charset=([\w-]+)/i) || head.match(/<meta[^>]+charset=["']?([\w-]+)/i) || [])[1] || 'UTF-8').toUpperCase();
  try { return blob.getDataAsString(/SHIFT|SJIS/.test(cs) ? 'Shift_JIS' : /EUC/.test(cs) ? 'EUC-JP' : 'UTF-8'); } catch (e) { return res.getContentText(); }
}
function translateParas_(out) {
  const batch = [], idx = [];
  out.paras.forEach(function (p, i) { if (p.t !== 'img' && !/[぀-ヿ一-鿿]/.test(p.x)) { batch.push(p.x.replace(/\s*\n\s*/g, ' ')); idx.push(i); } });
  for (let i = 0; i < batch.length; i += 25) {
    const part = batch.slice(i, i + 25);
    try {
      let tr = LanguageApp.translate(part.join('\n'), 'en', 'ja').split('\n');
      if (tr.length !== part.length) tr = part.map(function (x) { try { return LanguageApp.translate(x, 'en', 'ja'); } catch (e) { return ''; } });
      tr.forEach(function (x, k) { out.paras[idx[i + k]].j = x.trim(); });
    } catch (e) { out.trErr = String(e.message || e).slice(0, 80); break; }
  }
  if (out.title && !/[぀-ヿ一-鿿]/.test(out.title)) { try { out.titleJa = LanguageApp.translate(out.title, 'en', 'ja'); } catch (e) {} }
  out.ja = true;
}
/* news.google.com/rss/articles/<id> → publisher URL */
function resolveGoogleNews_(url) {
  const id = (url.match(/articles\/([A-Za-z0-9_-]+)/) || [])[1];
  if (!id) return null;
  const local = decodeGnLocal(id);
  if (local) return local;
  const page = UrlFetchApp.fetch('https://news.google.com/rss/articles/' + id, { muteHttpExceptions: true, headers: { 'User-Agent': UA } }).getContentText();
  const sg = (page.match(/data-n-a-sg="([^"]+)"/) || [])[1], ts = (page.match(/data-n-a-ts="([^"]+)"/) || [])[1];
  if (!sg || !ts) return null;
  const r = UrlFetchApp.fetch('https://news.google.com/_/DotsSplashUi/data/batchexecute', { method: 'post', muteHttpExceptions: true,
    contentType: 'application/x-www-form-urlencoded;charset=UTF-8', payload: 'f.req=' + encodeURIComponent(gnBatchPayload(id, ts, sg)), headers: { 'User-Agent': UA } });
  return parseGnBatch(r.getContentText());
}

/* ========== Web Push: 朝刊 6:00 / 夕刊 19:00 ==========
 * No payload is sent (Apps Script has no AES-GCM), so the service worker fetches ?v=push-latest when a push arrives.
 * VAPID needs ES256 signatures; Apps Script has no EC crypto, so P-256 ECDSA is implemented below with BigInt. */
function vapid_() {
  const props = PropertiesService.getScriptProperties();
  let d = props.getProperty('VAPID_D'), pub = props.getProperty('VAPID_PUB');
  if (!d || !pub) {
    const seed = [Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Date.now()].join('');
    const dd = P256.mod(P256.bytesToBig(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, seed)), P256.n - 1n) + 1n;
    const Q = P256.affine(P256.mul(dd, P256.G));
    d = dd.toString(16); pub = P256.b64u([4].concat(P256.bigTo32(Q[0]), P256.bigTo32(Q[1])));
    props.setProperty('VAPID_D', d); props.setProperty('VAPID_PUB', pub);
  }
  return { d: BigInt('0x' + d), pub: pub };
}
function vapidJwt_(aud) {
  const cache = CacheService.getScriptCache(), ck = 'jwt_' + hashId(aud);
  const hit = cache.get(ck); if (hit) return hit;
  const v = vapid_(), enc = function (o) { return Utilities.base64EncodeWebSafe(JSON.stringify(o)).replace(/=+$/, ''); };
  let sub = 'mailto:bme-radar@example.com';
  try { const em = Session.getEffectiveUser().getEmail(); if (em) sub = 'mailto:' + em; } catch (e) {}
  const input = enc({ typ: 'JWT', alg: 'ES256' }) + '.' + enc({ aud: aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: sub });
  const jwt = input + '.' + P256.signB64u(input, v.d);
  cache.put(ck, jwt, 6 * 3600);
  return jwt;
}
function pushSubscribe_(sub, am, pm, label) {
  if (!sub || !/^https:\/\//.test(sub.endpoint || '')) throw new Error('bad subscription');
  const subs = readJson_('subs.json', { list: [] });
  subs.list = subs.list.filter(function (x) { return x.endpoint !== sub.endpoint; });
  subs.list.push({ endpoint: sub.endpoint, am: am, pm: pm, label: label, at: Date.now() });
  subs.list = subs.list.slice(-10);
  writeJson_('subs.json', subs);
  return { count: subs.list.length };
}
function sendPush_(s) {
  const aud = s.endpoint.match(/^https:\/\/[^\/]+/)[0];
  const r = UrlFetchApp.fetch(s.endpoint, { method: 'post', muteHttpExceptions: true, contentType: 'application/octet-stream', payload: '',
    headers: { TTL: '43200', Urgency: 'high', Authorization: 'vapid t=' + vapidJwt_(aud) + ', k=' + vapid_().pub } });
  const code = r.getResponseCode();
  return { ok: code >= 200 && code < 300, code: code, gone: code === 404 || code === 410 };
}
function pushAll_(ed) {
  const subs = readJson_('subs.json', { list: [] });
  let sent = 0;
  const keep = subs.list.filter(function (s) {
    if (!s[ed]) return true;
    try { const r = sendPush_(s); if (r.ok) sent++; return !r.gone; } catch (e) { return true; }
  });
  if (keep.length !== subs.list.length) { subs.list = keep; writeJson_('subs.json', subs); }
  return { sent: sent };
}
function pushMorning() { return pushAll_('am'); }
function pushEvening() { return pushAll_('pm'); }
function pushMessage_(now) {
  const jstH = new Date(now + 9 * 36e5).getUTCHours(), ed = jstH >= 4 && jstH < 14 ? 'am' : 'pm';
  const feed = readJson_('feed.json', { items: [], highlights: [] }), b = feed.brief;
  const title = APP_NAME + ' ' + (ed === 'am' ? '朝刊' : '夕刊');
  let body = '';
  if (b && b.at > now - 8 * 36e5 && b.headline) body = b.headline + (b.points && b.points[0] ? '\n' + b.points[0].text : '');
  else {
    const m = {}; (feed.items || []).forEach(function (it) { m[it.id] = it; });
    const ids = (feed.bci || []).slice(0, 1).concat(feed.highlights || []);
    body = ids.map(function (id) { return m[id]; }).filter(Boolean).slice(0, 2).map(function (it) { return it.tj || it.t; }).join('\n');
  }
  const n = (feed.items || []).filter(function (it) { return it.f > now - 13 * 36e5; }).length;
  return { ok: true, title: title, body: (body || '新しい記事があります').slice(0, 160) + (n ? '\n新着 ' + n + ' 件' : ''), url: './?ed=' + ed, tag: 'radar-' + ed };
}

/* ========== archive & queries ========== */
function monthKey(ms) { const d = new Date(ms + 9 * 36e5); return d.getUTCFullYear() + '-' + ('0' + (d.getUTCMonth() + 1)).slice(-2); }
function archiveAppend_(fresh) {
  const groups = {};
  fresh.forEach(function (it) { const k = monthKey(it.d); (groups[k] = groups[k] || []).push(it); });
  Object.keys(groups).forEach(function (k) {
    const name = 'archive_' + k + '.json', cur = readJson_(name, { items: [] });
    const seen = {}; cur.items.forEach(function (it) { seen[it.id] = 1; });
    groups[k].forEach(function (it) { if (!seen[it.id]) cur.items.push(it); });
    writeJson_(name, cur);
  });
}
function queryArchive_(o) {
  const out = [], seen = {};
  const terms = String(o.q || '').toLowerCase().split(/\s+/).filter(function (t) { return t; });
  const match = function (it) {
    if (it.d >= o.before) return false;
    if (o.type && it.ty !== o.type) return false;
    if (o.cat && (it.g || []).indexOf(o.cat) < 0) return false;
    if (o.bci && !it.b) return false;
    if (terms.length) { const hay = (it.t + ' ' + (it.tj || '') + ' ' + (it.x || '') + ' ' + it.s + ' ' + (it.un || '')).toLowerCase(); for (let i = 0; i < terms.length; i++) if (hay.indexOf(terms[i]) < 0) return false; }
    return true;
  };
  const push = function (list) { for (let i = 0; i < list.length; i++) { const it = list[i]; if (!seen[it.id] && match(it)) { seen[it.id] = 1; out.push(it); } } };
  push(readJson_('index.json', { items: [] }).items);
  const months = o.months || 3;
  for (let m = 0; m < months && out.length < o.limit; m++) {
    const d = new Date(Math.min(o.before, Date.now())); d.setMonth(d.getMonth() - m);
    push(readJson_('archive_' + monthKey(d.getTime()) + '.json', { items: [] }).items);
  }
  out.sort(function (a, b) { return b.d - a.d; });
  return { ok: true, items: out.slice(0, o.limit), more: out.length > o.limit };
}

/* ========== morning digest ========== */
function sendDigest(force) {
  const prefs = getPrefs_();
  if (!prefs.email.on && force !== true) return { sent: false, reason: 'off' };
  const props = PropertiesService.getScriptProperties();
  const since = Math.max(Date.now() - 36 * 36e5, +(props.getProperty('LAST_DIGEST') || 0) || 0);
  const items = readJson_('index.json', { items: [] }).items.filter(function (it) { return (it.f || it.d) >= since; });
  markWatch(items, watchRegex(prefs.watch));
  const brief = readJson_('brief.json', null);
  const html = digestHtml(items, prefs, Date.now(), brief && brief.at > Date.now() - 20 * 36e5 ? brief : null);
  const to = prefs.email.to || Session.getEffectiveUser().getEmail();
  const d = new Date(Date.now() + 9 * 36e5);
  MailApp.sendEmail({ to: to, subject: APP_NAME + ' ' + (d.getUTCMonth() + 1) + '/' + d.getUTCDate() + '｜新着 ' + items.length + ' 件', htmlBody: html, name: APP_NAME });
  props.setProperty('LAST_DIGEST', String(Date.now()));
  return { sent: true, to: to, count: items.length };
}

/* run this from the editor to check the morning mail; the log shows where it went or the error */
function testMail() { Logger.log(JSON.stringify(sendDigest(true))); }

/* ========== helpers: storage, cache, json ========== */
function checkPass_(p) {
  const want = PropertiesService.getScriptProperties().getProperty('PASS');
  return !!want && typeof p === 'string' && p === want;
}
function dataFolder_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const f = DriveApp.createFolder(DATA_FOLDER);
  props.setProperty('FOLDER_ID', f.getId());
  return f;
}
function findFile_(folder, name) { const it = folder.getFilesByName(name); return it.hasNext() ? it.next() : null; }
function readJson_(name, fallback) {
  const f = findFile_(dataFolder_(), name);
  if (!f) return fallback;
  try { return JSON.parse(f.getBlob().getDataAsString()); } catch (e) { return fallback; }
}
function writeJson_(name, obj) {
  const folder = dataFolder_(), body = JSON.stringify(obj), f = findFile_(folder, name);
  if (f) f.setContent(body); else folder.createFile(name, body, MimeType.PLAIN_TEXT);
}
function cachePut_(key, str) {
  const c = CacheService.getScriptCache(), size = 90000, parts = {}, n = Math.ceil(str.length / size);
  if (n > 9) return;  // too large for the cache; served from Drive instead
  for (let i = 0; i < n; i++) parts[key + '_' + i] = str.slice(i * size, (i + 1) * size);
  parts[key + '_n'] = String(n);
  try { c.putAll(parts, 21600); } catch (e) {}
}
function cacheGet_(key) {
  const c = CacheService.getScriptCache(), n = +(c.get(key + '_n') || 0);
  if (!n) return null;
  const keys = []; for (let i = 0; i < n; i++) keys.push(key + '_' + i);
  const got = c.getAll(keys); let s = '';
  for (let i = 0; i < n; i++) { if (got[keys[i]] == null) return null; s += got[keys[i]]; }
  return s;
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

/* ======================================================================
 * Pure functions below (no Apps Script services) — also run in tests.
 * ====================================================================== */
function decodeEntities(s) {
  return String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#x([0-9a-f]+);/gi, function (m, h) { return String.fromCharCode(parseInt(h, 16)); })
    .replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); })
    .replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}
function stripTags(s) { return decodeEntities(String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }
function tagText(block, names) {
  for (let i = 0; i < names.length; i++) {
    const m = block.match(new RegExp('<' + names[i] + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + names[i] + '>', 'i'));
    if (m) return m[1];
  }
  return '';
}
function attr(block, tag, name, where) {
  const re = new RegExp('<' + tag + '\\b([^>]*)>', 'gi'); let m;
  while ((m = re.exec(block))) {
    if (where && !where.test(m[1])) continue;
    const a = m[1].match(new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i')) || m[1].match(new RegExp(name + "\\s*=\\s*'([^']*)'", 'i'));
    if (a) return decodeEntities(a[1]);
  }
  return '';
}
/* RSS 2.0, RSS 1.0 (RDF) and Atom */
function parseFeed(xml) {
  xml = String(xml || '');
  const atom = /<feed[\s>]/i.test(xml) && !/<rss[\s>]/i.test(xml);
  const blocks = xml.match(atom ? /<entry[\s>][\s\S]*?<\/entry>/gi : /<item[\s>][\s\S]*?<\/item>/gi) || [];
  return blocks.map(function (b) {
    let link = '';
    if (atom) link = attr(b, 'link', 'href', /rel\s*=\s*["']alternate["']/i) || attr(b, 'link', 'href');
    else link = stripTags(tagText(b, ['link'])) || attr(b, 'item', 'rdf:about') || stripTags(tagText(b, ['guid']));
    const descRaw = tagText(b, ['description', 'summary', 'content:encoded', 'content']);
    const img = attr(b, 'media:content', 'url') || attr(b, 'media:thumbnail', 'url') || attr(b, 'enclosure', 'url', /type\s*=\s*["']image/i) ||
      ((decodeEntities(descRaw).match(/<img[^>]+src\s*=\s*["']([^"']+)["']/i) || [])[1] || '');
    return {
      title: stripTags(tagText(b, ['title', 'dc:title'])),
      link: link.trim(),
      guid: stripTags(tagText(b, ['guid', 'id'])),
      date: stripTags(tagText(b, ['pubDate', 'published', 'dc:date', 'updated', 'prism:publicationDate'])),
      desc: stripTags(descRaw),
      source: stripTags(tagText(b, ['source', 'prism:publicationName'])),
      image: /^https?:/.test(img) ? img : ''
    };
  }).filter(function (r) { return r.title && r.link; });
}
function parseDate(s, fallback) {
  s = String(s || '').trim();
  if (!s) return fallback;
  if (/^\d{8}$/.test(s)) return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8), 12);
  let t = Date.parse(s);
  if (isFinite(t)) return t;
  let m = s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] - 9 : 3, m[5] ? +m[5] : 0);
  m = s.match(/^([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})(?:,? (\d{1,2}):(\d{2})\s*([ap]m)?)?/i);
  if (m) {
    const mon = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(m[1].toLowerCase()) / 3;
    let h = m[4] ? +m[4] : 12; if (m[6] && /pm/i.test(m[6]) && h < 12) h += 12; if (m[6] && /am/i.test(m[6]) && h === 12) h = 0;
    if (mon >= 0) return Date.UTC(+m[3], mon, +m[2], h + 5, m[5] ? +m[5] : 0);   // US Eastern
  }
  return fallback;
}
function pubmedSummaryToItems(sum) {
  const res = sum.result || {}, uids = res.uids || [];
  return uids.map(function (id) {
    const r = res[id] || {};
    const authors = (r.authors || []).slice(0, 3).map(function (a) { return a.name; }).join(', ') + ((r.authors || []).length > 3 ? ' et al.' : '');
    return { title: stripTags(r.title || ''), link: 'https://pubmed.ncbi.nlm.nih.gov/' + id + '/', guid: 'pmid:' + id, date: r.sortpubdate || r.epubdate || r.pubdate || '', desc: authors, source: r.fulljournalname || r.source || 'PubMed', image: '' };
  }).filter(function (r) { return r.title; });
}
function fda510kItems(j) {
  return (j.results || []).map(function (r) {
    const panel = r.advisory_committee_description || r.advisory_committee || '';
    return { title: (r.device_name || '').trim() + ' — ' + (r.applicant || '').trim(), link: 'https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfpmn/pmn.cfm?ID=' + r.k_number, guid: r.k_number,
      date: r.decision_date || '', desc: '510(k) ' + r.k_number + '・' + panel + (r.decision_description ? '・' + r.decision_description : ''), source: 'FDA 510(k)', panel: r.advisory_committee || '', image: '' };
  });
}
function fdaPmaItems(j) {
  return (j.results || []).filter(function (r) { return !r.supplement_number; }).map(function (r) {
    return { title: (r.trade_name || r.generic_name || '').trim() + ' — ' + (r.applicant || '').trim(), link: 'https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfpma/pma.cfm?id=' + r.pma_number, guid: r.pma_number,
      date: r.decision_date || '', desc: 'PMA ' + r.pma_number + ' 承認・' + (r.generic_name || '') + '・' + (r.advisory_committee_description || ''), source: 'FDA PMA', panel: r.advisory_committee || '', image: '' };
  });
}
function fdaRecallItems(j) {
  return (j.results || []).map(function (r) {
    const prod = String(r.product_description || '').replace(/\s+/g, ' ').slice(0, 140);
    return { title: 'Class I recall: ' + prod + ' — ' + (r.recalling_firm || ''), link: 'https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfRES/res.cfm', guid: r.recall_number || prod,
      date: r.report_date || r.recall_initiation_date || '', desc: String(r.reason_for_recall || '').slice(0, 300), source: 'FDA Recall', image: '' };
  });
}
function ctgovItems(j) {
  return (j.studies || []).map(function (st) {
    const p = st.protocolSection || {}, id = p.identificationModule || {}, cond = (p.conditionsModule || {}).conditions || [];
    const sp = ((p.sponsorCollaboratorsModule || {}).leadSponsor || {}).name || '';
    const iv = ((p.armsInterventionsModule || {}).interventions || []).filter(function (x) { return x.type === 'DEVICE'; }).map(function (x) { return x.name; }).slice(0, 3);
    const date = ((p.statusModule || {}).studyFirstPostDateStruct || {}).date || '';
    const sum = String(((p.descriptionModule || {}).briefSummary) || '').replace(/\s+/g, ' ');
    return { title: id.briefTitle || id.officialTitle || '', link: 'https://clinicaltrials.gov/study/' + id.nctId, guid: id.nctId, date: date,
      desc: [cond.slice(0, 3).join(', '), iv.length ? 'Device: ' + iv.join(', ') : '', sp ? 'Sponsor: ' + sp : ''].filter(function (x) { return x; }).join(' ・ ') + (sum ? ' — ' + sum : ''), source: 'ClinicalTrials.gov', image: '' };
  }).filter(function (r) { return r.title; });
}

function classify(text) {
  const g = [];
  Object.keys(CATS).forEach(function (k) { if (CATS[k].re.test(text)) g.push(k); });
  return g;
}
function isBme(text) {
  if (STRONG_RE.test(text)) return true;
  if (NOT_BME_RE.test(text)) return false;
  return MED_RE.test(text) && ENG_RE.test(text);
}
function normTitle(t) { return String(t || '').toLowerCase().replace(/\s+[-–|]\s+[^-–|]+$/, '').replace(/[^\w぀-ヿ一-鿿]+/g, '').slice(0, 90); }
function hashId(s) { let h = 5381; s = String(s); for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
const STOP = ('the a an of for and to in on with by from at as is are be its new study shows show finds find using use used via into after over how why what could may can will first more than that this their these new about says said report reports device devices medical patients patient system wins win gets gains launches launch receives announces announced begins adds helps help team researchers scientists year years people data results human next-generation initiative company firm based near could would one two now just').split(' ');
const STOP_JA = ('開発 研究 発表 大学 技術 医療 患者 実証 活用 取得 成功 可能 世界 初 日本 国内 企業 研究所 研究グループ チーム 年度 令和 について お知らせ').split(' ');
function titleTokens(t) {
  const out = {};
  String(t || '').toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).forEach(function (w) { w = w.replace(/^-+|-+$/g, ''); if (w.length >= 3 && STOP.indexOf(w) < 0) out[w] = 1; });
  const ja = String(t || '').match(/[゠-ヿ]{3,}|[一-鿿]{2,}/g) || [];
  ja.forEach(function (w) { if (STOP_JA.indexOf(w) < 0) out[w] = 1; });
  return Object.keys(out);
}
function normalizeItem(r, src, now) {
  let title = r.title, source = r.source || src.name;
  if (src.kind === 'gnews') { const m = title.match(/^(.*)\s+-\s+([^-]{2,60})$/); if (m) { title = m[1]; if (!r.source) source = m[2]; } }
  if (!title) return null;
  const desc = src.kind === 'gnews' ? '' : String(r.desc || '').replace(/\s+/g, ' ');
  const text = title + ' ' + desc;
  if (src.filter === 'bme' && !(src.trust && CATS.brain.re.test(text)) && !isBme(text)) return null;
  if (src.filter === 'kw' && (!new RegExp(src.kw, 'i').test(text) || NOT_BME_RE.test(text))) return null;
  let d = parseDate(r.date, now);
  if (d > now + 864e5) d = now;
  let ty = src.type;
  if (ty === 'news' && BIZ_RE.test(title)) ty = 'biz';
  else if (ty === 'news' && REG_RE.test(title)) ty = 'reg';
  let g = classify(text);
  if (r.panel === 'NE' && g.indexOf('brain') < 0) g.unshift('brain');
  const ja = src.lang === 'ja' || /[぀-ヿ]/.test(title);
  const it = { id: hashId(r.link || r.guid || title), t: title, u: r.link, s: source, sid: src.id, d: d, f: now,
    x: desc.length > 300 ? desc.slice(0, 297) + '…' : desc, im: r.image || '', ty: ty, g: g, l: ja ? 'ja' : 'en', pn: r.panel || '' };
  if (BCI_RE.test(text)) { it.b = 1; if (g.indexOf('brain') < 0) g.unshift('brain'); }
  return it;
}
function scoreItem(it, src) {
  let s = { news: 14, paper: 12, reg: 18, trial: 8, biz: 13, acad: 12 }[it.ty] || 10;
  if (src.kind === 'fdapma') s += 22;
  if (src.kind === 'fda510k') s += it.pn === 'NE' ? 8 : -4;
  if (src.kind === 'fdarecall') s += 8;
  if (src.tier) s += src.tier * 4;
  if (it.ty === 'paper' && TOP_SOURCES.test(it.s)) s += 8;
  if (it.g.indexOf('brain') >= 0) s += 22;
  if (it.b) s += 12;
  s += Math.min(3, it.g.length) * 2;
  if (src.id && src.id.indexOf('tuat') === 0) s += 10;
  return s;
}
function jaccard(a, b) {
  if (!a.length || !b.length) return 0;
  const set = {}; a.forEach(function (x) { set[x] = 1; });
  let inter = 0; b.forEach(function (x) { if (set[x]) inter++; });
  return inter / (a.length + b.length - inter);
}
function assignCluster(it, recent) {
  const tok = titleTokens(it.t);
  let best = null, bs = 0;
  for (let i = 0; i < recent.length; i++) {
    const o = recent[i];
    if (o.it.ty === 'paper' || o.it.ty === 'trial' || it.ty === 'paper' || it.ty === 'trial') continue;
    const s = jaccard(tok, o.tok);
    if (s > bs) { bs = s; best = o; }
  }
  if (best && bs >= 0.5) it.c = best.it.c || best.it.id;
  recent.push({ it: it, tok: tok });
}
function refreshClusterCounts(items) {
  const cnt = {}, ids = {};
  items.forEach(function (it) { ids[it.id] = 1; });
  items.forEach(function (it) { if (it.c && !ids[it.c]) delete it.c; if (it.c) cnt[it.c] = (cnt[it.c] || 0) + 1; });
  items.forEach(function (it) { it.n = cnt[it.id] ? cnt[it.id] + 1 : 0; });
}
function effScore(it, now) {
  const ageH = Math.max(0, (now - it.d) / 36e5);
  return (it.sc || 0) + (it.w ? 30 : 0) + (it.n ? Math.min(5, it.n - 1) * 6 : 0) - ageH * 0.35;
}
function pickTop(list, now, n, perCat) {
  const ranked = list.filter(function (it) { return !it.c; }).sort(function (a, b) { return effScore(b, now) - effScore(a, now); });
  const used = {}, out = [];
  for (let i = 0; i < ranked.length && out.length < n; i++) {
    const it = ranked[i], k = (it.g[0] || it.ty);
    if (perCat && (used[k] || 0) >= perCat) continue;
    used[k] = (used[k] || 0) + 1; out.push(it);
  }
  return out;
}
function trendTerms(items, now) {
  const recent = {}, base = {};
  items.forEach(function (it) {
    const age = (now - it.d) / 864e5, tok = titleTokens(it.t);
    tok.forEach(function (w) { if (/^\d+$/.test(w)) return; if (age <= 3) recent[w] = (recent[w] || 0) + 1; else if (age <= 30) base[w] = (base[w] || 0) + 1; });
  });
  return Object.keys(recent).filter(function (w) { return recent[w] >= 3; }).map(function (w) {
    const b = (base[w] || 0) / 9;   // per 3 days over the previous 27 days
    return { term: w, n: recent[w], rise: Math.round((recent[w] + 1) / (b + 1) * 10) / 10, s: (recent[w] + 1) / (b + 1) * Math.log(recent[w] + 1) };
  }).sort(function (a, b) { return b.s - a.s; }).slice(0, 16).map(function (o) { return { term: o.term, n: o.n, rise: o.rise }; });
}
function dailyStats(items, now) {
  const days = [];
  for (let i = 29; i >= 0; i--) {
    const t = now - i * 864e5, k = new Date(t + 9 * 36e5).toISOString().slice(0, 10);
    days.push({ day: k, total: 0, cats: {}, types: {} });
  }
  const pos = {}; days.forEach(function (d, i) { pos[d.day] = i; });
  items.forEach(function (it) {
    const k = new Date(it.d + 9 * 36e5).toISOString().slice(0, 10), i = pos[k];
    if (i == null) return;
    const d = days[i]; d.total++; d.types[it.ty] = (d.types[it.ty] || 0) + 1;
    it.g.forEach(function (g) { d.cats[g] = (d.cats[g] || 0) + 1; });
  });
  return days;
}
function yahooChartToQuote(j) {
  const r = j && j.chart && j.chart.result && j.chart.result[0];
  if (!r || !r.meta) return null;
  const m = r.meta, ts = r.timestamp || [], cl = ((r.indicators || {}).quote || [{}])[0].close || [];
  const hist = [];
  for (let i = 0; i < ts.length; i++) if (cl[i] != null) hist.push([ts[i] * 1000, Math.round(cl[i] * 1000) / 1000]);
  const price = m.regularMarketPrice != null ? m.regularMarketPrice : (hist.length ? hist[hist.length - 1][1] : null);
  if (price == null) return null;
  const qt = (m.regularMarketTime || 0) * 1000;
  // previous close: last daily close strictly before the quote's trading day
  const dayOf = function (ms) { return new Date(ms + (m.gmtoffset || 0) * 1000).toISOString().slice(0, 10); };
  let prev = null;
  for (let i = hist.length - 1; i >= 0; i--) if (dayOf(hist[i][0]) < dayOf(qt || hist[hist.length - 1][0])) { prev = hist[i][1]; break; }
  if (prev == null) prev = m.chartPreviousClose || m.previousClose || null;
  return { p: price, pc: prev, ch: prev ? Math.round((price - prev) / prev * 10000) / 100 : null, cur: m.currency || '', ex: m.exchangeName || '', t: qt, st: m.marketState || '', h: hist };
}
function stooqCsvToQuote(csv) {
  const rows = String(csv || '').trim().split(/\r?\n/).slice(1).map(function (l) { return l.split(','); }).filter(function (c) { return c.length >= 5 && isFinite(+c[4]); });
  if (rows.length < 2) return null;
  const hist = rows.slice(-260).map(function (c) { return [Date.parse(c[0] + 'T21:00:00Z'), +c[4]]; });
  const p = hist[hist.length - 1][1], pc = hist[hist.length - 2][1];
  return { p: p, pc: pc, ch: Math.round((p - pc) / pc * 10000) / 100, cur: '', ex: 'Stooq', t: hist[hist.length - 1][0], st: 'CLOSED', h: hist };
}
/* brief written by the Claude scheduled task: {headline, points:[{text,url}], bci:[{text,url}], watch:'...'} */
function sanitizeBrief(b) {
  if (!b || typeof b !== 'object') return null;
  const clean = function (s, n) { return String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n); };
  const list = function (a) { return (Array.isArray(a) ? a : []).slice(0, 12).map(function (x) { return { text: clean(x && x.text, 400), url: /^https?:\/\//.test(String(x && x.url)) ? clean(x.url, 600) : '' }; }).filter(function (x) { return x.text; }); };
  const jstH = new Date(Date.now() + 9 * 36e5).getUTCHours();
  const out = { at: Date.now(), ed: jstH >= 4 && jstH < 14 ? 'am' : 'pm', headline: clean(b.headline, 160), points: list(b.points), bci: list(b.bci), watch: clean(b.watch, 600), by: clean(b.by || 'Claude', 40) };
  return out.points.length || out.bci.length ? out : null;
}
function briefInput(items, now, hours) {
  hours = Math.max(6, Math.min(48, hours || 36));
  const recent = items.filter(function (it) { return it.f >= now - hours * 36e5 && !it.c; }).sort(function (a, b) { return effScore(b, now) - effScore(a, now); }).slice(0, 140);
  return { ok: true, now: now, hours: hours, count: recent.length, items: recent.map(function (it) {
    return { t: it.t, tj: it.tj || '', s: it.s, ty: it.ty, g: it.g, bci: it.b ? 1 : 0, n: it.n || 0, x: (it.x || '').slice(0, 200), u: it.u, d: new Date(it.d).toISOString().slice(0, 16) };
  }) };
}
function buildFeed(items, state, now, sourceList) {
  const recent = items.filter(function (it) { return it.d >= now - FEED_DAYS * 864e5 || (it.b && it.d >= now - 14 * 864e5); });
  const last36 = recent.filter(function (it) { return it.d >= now - 36 * 36e5; });
  const brain = pickTop(items.filter(function (it) { return it.d >= now - 72 * 36e5 && it.g.indexOf('brain') >= 0; }), now, 8, 0);
  const highlights = pickTop(last36.filter(function (it) { return brain.indexOf(it) < 0; }), now, 12, 3);
  const sources = (sourceList || SOURCES).map(function (s) { const st = state.status[s.id] || {}; return { id: s.id, name: s.name, type: s.type, ok: st.ok !== false, n: st.n || 0, seen: st.seen || 0, error: st.error || '', at: st.at || 0, every: s.every }; });
  const bci = pickTop(items.filter(function (it) { return it.b && it.d >= now - 7 * 864e5; }), now, 10, 0);
  return { ok: true, updated: now, items: recent, highlights: highlights.map(function (it) { return it.id; }), brain: brain.map(function (it) { return it.id; }), bci: bci.map(function (it) { return it.id; }),
    trends: trendTerms(items, now), stats: dailyStats(items, now), sources: sources,
    cats: Object.keys(CATS).map(function (k) { return { id: k, name: CATS[k].name }; }) };
}
function escHtml(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
const TYPE_JA = { news: 'ニュース', paper: '論文', reg: '承認・規制', trial: '臨床試験', biz: '企業・資金', acad: '大学・学会・公募' };
function digestHtml(items, prefs, now, brief) {
  const fmt = function (ms) { const d = new Date(ms + 9 * 36e5); return (d.getUTCMonth() + 1) + '/' + d.getUTCDate(); };
  const row = function (it) {
    const cats = it.g.slice(0, 3).map(function (g) { return CATS[g] ? CATS[g].name : g; }).join(' / ');
    return '<tr><td style="padding:10px 0;border-bottom:1px solid #e3e7ee">' +
      '<div style="font-size:11px;color:#6b7a90;margin-bottom:3px">' + escHtml(TYPE_JA[it.ty] || '') + '　' + escHtml(it.s) + '　' + fmt(it.d) + (it.n > 1 ? '　ほか' + (it.n - 1) + '件の報道' : '') + '</div>' +
      '<a href="' + escHtml(it.u) + '" style="font-size:15px;line-height:1.45;color:#0b2a5b;text-decoration:none;font-weight:600">' + escHtml(it.t) + '</a>' +
      (it.tj ? '<div style="font-size:13px;color:#4a5872;margin-top:2px">' + escHtml(it.tj) + '</div>' : '') +
      (cats ? '<div style="font-size:11px;color:#3f6fb5;margin-top:3px">' + escHtml(cats) + '</div>' : '') + '</td></tr>';
  };
  const section = function (title, list, accent) {
    if (!list.length) return '';
    return '<h2 style="font-size:14px;margin:26px 0 4px;padding-left:8px;border-left:4px solid ' + accent + ';color:#0b1120">' + escHtml(title) + '</h2><table style="width:100%;border-collapse:collapse">' + list.map(row).join('') + '</table>';
  };
  const max = prefs.email.max || 15, used = {};
  const take = function (list, n) { const out = []; for (let i = 0; i < list.length && out.length < n; i++) { const it = list[i]; if (used[it.id] || it.c) continue; used[it.id] = 1; out.push(it); } return out; };
  const byScore = items.slice().sort(function (a, b) { return effScore(b, now) - effScore(a, now); });
  const watch = take(byScore.filter(function (it) { return it.w; }), 10);
  const bci = take(byScore.filter(function (it) { return it.b; }), 6);
  const brain = take(byScore.filter(function (it) { return it.g.indexOf('brain') >= 0; }), 5);
  const top = take(byScore.filter(function (it) { return it.ty === 'news'; }), Math.max(5, max - 8));
  const reg = take(byScore.filter(function (it) { return it.ty === 'reg'; }), 6);
  const biz = take(byScore.filter(function (it) { return it.ty === 'biz'; }), 4);
  const acad = take(byScore.filter(function (it) { return it.ty === 'acad'; }), 4);
  const paper = take(byScore.filter(function (it) { return it.ty === 'paper'; }), 6);
  const trial = take(byScore.filter(function (it) { return it.ty === 'trial'; }), 4);
  const counts = {}; items.forEach(function (it) { counts[it.ty] = (counts[it.ty] || 0) + 1; });
  const summary = Object.keys(TYPE_JA).filter(function (k) { return counts[k]; }).map(function (k) { return TYPE_JA[k] + ' ' + counts[k]; }).join('　');
  return '<div style="font-family:-apple-system,\'Hiragino Sans\',\'Noto Sans JP\',sans-serif;max-width:640px;margin:0 auto;color:#1b2232">' +
    '<div style="background:#0b1120;color:#fff;padding:18px 20px"><div style="font-size:12px;letter-spacing:.2em;color:#7aa7ff">BMERADAR</div>' +
    '<div style="font-size:20px;font-weight:700;margin-top:4px">' + fmt(now) + ' の医工学</div><div style="font-size:12px;color:#a9b6c9;margin-top:6px">' + escHtml(summary || '新着なし') + '</div></div>' +
    '<div style="padding:0 20px 24px">' +
    briefHtml(brief) + section('ウォッチ中のキーワード', watch, '#e5b53a') + section('BCI', bci, '#3987e5') + section('脳・神経', brain, '#7aa7ff') + section('注目ニュース', top, '#5fc9b8') +
    section('承認・規制', reg, '#f0a35e') + section('論文', paper, '#a9b6c9') + section('企業・資金', biz, '#c48cf0') +
    section('大学・学会・公募', acad, '#d9c95f') + section('臨床試験', trial, '#ef7f9a') +
    (APP_URL ? '<p style="margin-top:28px"><a href="' + escHtml(APP_URL) + '" style="color:#0b2a5b">アプリで全部見る</a></p>' : '') +
    '</div></div>';
}

function briefHtml(b) {
  if (!b) return '';
  const li = function (x) { return '<li style="margin:6px 0">' + escHtml(x.text) + (x.url ? ' <a href="' + escHtml(x.url) + '" style="color:#3f6fb5">記事</a>' : '') + '</li>'; };
  return '<div style="margin-top:20px;padding:14px 16px;background:#f2f5fa;border-left:4px solid #0b2a5b">' +
    '<div style="font-size:11px;color:#6b7a90;letter-spacing:.1em">今日のまとめ（' + escHtml(b.by || 'Claude') + '）</div>' +
    (b.headline ? '<div style="font-size:16px;font-weight:700;margin-top:4px;color:#0b1120">' + escHtml(b.headline) + '</div>' : '') +
    (b.points.length ? '<ul style="padding-left:18px;margin:8px 0 0;font-size:14px;line-height:1.6">' + b.points.map(li).join('') + '</ul>' : '') +
    (b.bci.length ? '<div style="font-size:12px;font-weight:700;margin-top:10px;color:#3987e5">BCI</div><ul style="padding-left:18px;margin:4px 0 0;font-size:14px;line-height:1.6">' + b.bci.map(li).join('') + '</ul>' : '') +
    (b.watch ? '<div style="font-size:13px;margin-top:8px;color:#4a5872">' + escHtml(b.watch) + '</div>' : '') + '</div>';
}

/* ---------- reader: pure helpers ---------- */
function gnBatchPayload(id, ts, sg) {
  const inner = '["garturlreq",[["X","X",["X","X"],null,null,1,1,"US:en",null,1,null,null,null,null,null,0,1],"X","X",1,[1,1,1],1,1,null,0,0,null,0],"' + id + '",' + ts + ',"' + sg + '"]';
  return JSON.stringify([[['Fbv4je', inner, null, 'generic']]]);
}
function parseGnBatch(text) {
  try {
    const parts = String(text).split('\n\n');
    const arr = JSON.parse(parts[1] || parts[0].replace(/^\)\]\}'\s*/, ''));
    for (let i = 0; i < arr.length; i++) if (arr[i][0] === 'wrb.fr' && arr[i][2]) { const u = JSON.parse(arr[i][2])[1]; if (/^https?:\/\//.test(u)) return u; }
  } catch (e) {}
  const m = String(text).match(/https?:\\\\?\/\\\\?\/[^"\\]+/);
  return m ? m[0].replace(/\\\\?\//g, '/').replace(/\\/g, '') : null;
}
/* older Google News ids carry the URL in the base64 payload */
function decodeGnLocal(id) {
  try {
    let b = id.replace(/-/g, '+').replace(/_/g, '/'); while (b.length % 4) b += '=';
    const bytes = Utilities.base64Decode(b), str = bytes.map(function (x) { return String.fromCharCode(x & 255); }).join('');
    if (str.indexOf('AU_yqL') >= 0) return null;
    const m = str.match(/https?:\/\/[\x21-\x7e]+/);
    return m ? m[0].replace(/[\x00-\x1f\xd2\x01].*$/, '') : null;
  } catch (e) { return null; }
}
function metaContent(html, key) {
  const re = new RegExp('<meta[^>]+(?:property|name|itemprop)\\s*=\\s*["\']' + key.replace(/[:.]/g, '\\$&') + '["\'][^>]*>', 'i');
  const tag = (html.match(re) || [])[0];
  if (!tag) return '';
  return decodeEntities((tag.match(/content\s*=\s*"([^"]*)"/i) || tag.match(/content\s*=\s*'([^']*)'/i) || [])[1] || '').trim();
}
function absUrl(u, base) {
  u = decodeEntities(String(u || '').trim());
  if (!u || /^data:/i.test(u)) return '';
  if (/^https?:\/\//i.test(u)) return u;
  const m = String(base).match(/^(https?:\/\/[^\/]+)(\/[^?#]*)?/i); if (!m) return '';
  if (/^\/\//.test(u)) return 'https:' + u;
  if (/^\//.test(u)) return m[1] + u;
  return m[1] + (m[2] || '/').replace(/[^\/]*$/, '') + u;
}
const BOILER = /^(advertisement|sponsored|subscribe|sign up|sign in|log in|read more|related:|share this|copyright|all rights reserved|©|photo:|image:|credit:|getty images|this article (was|is)|click here|newsletter|cookie|we use cookies|follow us|もっと見る|関連記事|広告|この記事をシェア|会員登録|ログイン)/i;
function jsonLdBody(html) {
  const blocks = html.match(/<script[^>]+application\/ld\+json[^>]*>[\s\S]*?<\/script>/gi) || [];
  for (let i = 0; i < blocks.length; i++) {
    const txt = blocks[i].replace(/^<script[^>]*>/i, '').replace(/<\/script>$/i, '').trim();
    let j = null;
    // some sites put raw line breaks inside JSON strings; try a few repairs
    [txt, txt.replace(/\r?\n/g, '\\n').replace(/\t/g, ' '), txt.replace(/[\u0000-\u001f]+/g, ' ')].some(function (t) { try { j = JSON.parse(t); return true; } catch (e) { return false; } });
    if (!j) continue;
    try {
      const list = [].concat(j['@graph'] || j);
      for (let k = 0; k < list.length; k++) if (list[k] && typeof list[k].articleBody === 'string' && list[k].articleBody.length > 300) return list[k];
    } catch (e) {}
  }
  return null;
}
/* generic article extraction without a DOM */
function extractArticle(html, url) {
  html = String(html || '');
  const title = metaContent(html, 'og:title') || stripTags(tagText(html, ['title'])) || '';
  const site = metaContent(html, 'og:site_name');
  const desc = metaContent(html, 'og:description') || metaContent(html, 'description');
  const image = absUrl(metaContent(html, 'og:image') || metaContent(html, 'twitter:image'), url);
  const date = metaContent(html, 'article:published_time') || metaContent(html, 'datePublished') || metaContent(html, 'citation_publication_date') || '';
  const paras = [];
  const ld = jsonLdBody(html);
  if (ld) {
    String(ld.articleBody).split(/\n\s*\n|\r?\n/).map(function (x) { return decodeEntities(x).replace(/\s+/g, ' ').trim(); }).filter(function (x) { return x.length > 1; }).forEach(function (x) { paras.push({ t: 'p', x: x }); });
  }
  if (!paras.length) {
    let body = html.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style|noscript|svg|nav|header|footer|aside|form|button|iframe|select)\b[\s\S]*?<\/\1>/gi, ' ');
    // arXiv abstract
    const abs = body.match(/<blockquote[^>]*class="[^"]*abstract[^"]*"[^>]*>([\s\S]*?)<\/blockquote>/i);
    if (abs) paras.push({ t: 'p', x: stripTags(abs[1]).replace(/^Abstract:\s*/i, '') });
    // pick the densest container: <article>, then main/role=main, then common content classes, else the body
    const cands = [];
    (body.match(/<article\b[\s\S]*?<\/article>/gi) || []).forEach(function (b) { cands.push(b); });
    const mm = body.match(/<main\b[\s\S]*?<\/main>/i); if (mm) cands.push(mm[0]);
    const re = /<(div|section)\b[^>]*(?:class|id)\s*=\s*["'][^"']*(article[-_]?body|entry[-_]content|post[-_]content|story[-_]body|article[-_]content|main[-_]content|content[-_]body|news[-_]body|articleBody|rich[-_]text|body[-_]text|text[-_]body)[^"']*["'][^>]*>/gi;
    let m; while ((m = re.exec(body))) cands.push(body.slice(m.index, m.index + 200000));
    cands.push(body);
    let best = null, bestLen = 0;
    cands.forEach(function (c) {
      const ps = collectParas(c, url);
      const len = ps.reduce(function (s, p) { return s + (p.t === 'p' ? p.x.length : 0); }, 0);
      if (len > bestLen * 1.6 || (!best && len)) { best = ps; bestLen = len; }   // earlier candidates are more specific
    });
    if (best && !abs) best.forEach(function (p) { paras.push(p); });
  }
  // de-duplicate repeated paragraphs and drop the title if repeated
  const seen = {}, out = [];
  paras.forEach(function (p) { const k = p.t + (p.x || p.src); if (seen[k] || (p.t !== 'img' && normTitle(p.x) === normTitle(title))) return; seen[k] = 1; out.push(p); });
  const text = out.filter(function (p) { return p.t === 'p'; }).map(function (p) { return p.x; }).join(' ');
  return { title: title, site: site, desc: desc, image: image, date: date, paras: out.slice(0, 120), chars: text.length };
}
function collectParas(block, url) {
  const out = [];
  let m, imgs = 0;
  const tagRe = /<(p|h2|h3|li|blockquote)\b[^>]*>([\s\S]*?)<\/\1>|<img\b([^>]*)>/gi;
  while ((m = tagRe.exec(block))) {
    if (m[3] != null) {
      if (imgs >= 6) continue;
      const a = m[3], src = (a.match(/\s(?:data-src|data-lazy-src|data-original|src)\s*=\s*["']([^"']+)["']/i) || [])[1];
      const w = +((a.match(/\swidth\s*=\s*["']?(\d+)/i) || [])[1] || 0);
      const u = absUrl(src, url);
      if (!u || /\.svg(\?|$)|logo|icon|avatar|sprite|pixel|tracking|1x1|blank\.gif/i.test(u) || (w && w < 240)) continue;
      out.push({ t: 'img', src: u, alt: decodeEntities((a.match(/\salt\s*=\s*["']([^"']*)["']/i) || [])[1] || '').slice(0, 200) }); imgs++;
      continue;
    }
    const tag = m[1].toLowerCase(), x = stripTags(m[2]);
    if (!x || BOILER.test(x)) continue;
    if (tag === 'h2' || tag === 'h3') { if (x.length < 120) out.push({ t: 'h', x: x }); continue; }
    if (tag === 'li' && x.length < 60) continue;
    if (x.length < 40 && !/[。！？」]$/.test(x)) continue;
    out.push({ t: 'p', x: x });
  }
  // drop a trailing run of headings / images without text
  while (out.length && out[out.length - 1].t !== 'p') out.pop();
  return out;
}
function parsePubmedXml(xml) {
  xml = String(xml || '');
  const title = stripTags(tagText(xml, ['ArticleTitle']));
  const journal = stripTags(tagText(xml, ['Title']));
  const abs = xml.match(/<AbstractText\b[^>]*>[\s\S]*?<\/AbstractText>/gi) || [];
  const paras = [];
  abs.forEach(function (a) { const label = (a.match(/Label="([^"]+)"/) || [])[1]; if (label) paras.push({ t: 'h', x: label.charAt(0) + label.slice(1).toLowerCase() }); paras.push({ t: 'p', x: stripTags(a) }); });
  const authors = (xml.match(/<Author\b[\s\S]*?<\/Author>/gi) || []).slice(0, 8).map(function (a) { return (stripTags(tagText(a, ['LastName'])) + ' ' + stripTags(tagText(a, ['Initials']))).trim(); }).filter(function (x) { return x; });
  const doi = stripTags((xml.match(/<ArticleId IdType="doi">([\s\S]*?)<\/ArticleId>/) || [])[1] || '');
  return { title: title, site: journal, desc: authors.join(', ') + (authors.length >= 8 ? ' et al.' : ''), image: '', date: '', paras: paras, chars: paras.reduce(function (s, p) { return s + p.x.length; }, 0), doi: doi ? 'https://doi.org/' + doi : '' };
}
function ctgovStudyToArticle(j) {
  const p = (j && j.protocolSection) || {}, id = p.identificationModule || {}, d = p.descriptionModule || {}, s = p.statusModule || {};
  const paras = [];
  const add = function (h, x) { if (x) { paras.push({ t: 'h', x: h }); String(x).split(/\n\s*\n/).forEach(function (y) { y = y.replace(/\s+/g, ' ').trim(); if (y) paras.push({ t: 'p', x: y }); }); } };
  add('Summary', d.briefSummary);
  add('Conditions', ((p.conditionsModule || {}).conditions || []).join(', '));
  add('Interventions', ((p.armsInterventionsModule || {}).interventions || []).map(function (x) { return x.type + ': ' + x.name + (x.description ? ' — ' + x.description : ''); }).join('\n\n'));
  const design = p.designModule || {};
  add('Status', [s.overallStatus, (design.phases || []).join('/'), design.enrollmentInfo ? 'Enrollment ' + design.enrollmentInfo.count : '', (s.startDateStruct || {}).date ? 'Start ' + s.startDateStruct.date : ''].filter(function (x) { return x; }).join(' ・ '));
  add('Sponsor', ((p.sponsorCollaboratorsModule || {}).leadSponsor || {}).name);
  add('Details', String(d.detailedDescription || '').slice(0, 3000));
  return { title: id.officialTitle || id.briefTitle || '', site: 'ClinicalTrials.gov', desc: '', image: '', date: (s.studyFirstPostDateStruct || {}).date || '', paras: paras, chars: paras.reduce(function (a, b) { return a + b.x.length; }, 0) };
}
function buildReaderResult(it, url, art, err) {
  const out = { ok: true, id: it.id, url: url || it.u, src: it.s, ty: it.ty, d: it.d, title: it.t, tj: it.tj || '', image: '', paras: [], partial: true, err: err || '' };
  if (art) {
    out.image = art.image || '';
    if (art.title && art.title.length > 8 && !/^(home|news|top)$/i.test(art.title)) out.title = art.title.replace(/\s+[|\-–—]\s+[^|\-–—]{2,40}$/, '');
    if (art.site) out.src = art.site;
    if (art.doi) out.doi = art.doi;
    if (art.desc && art.paras.length < 2) out.paras.push({ t: 'p', x: art.desc });
    out.paras = out.paras.concat(art.paras);
    out.partial = art.chars < 600;
    if (art.desc && art.paras.length >= 2 && it.ty === 'paper') out.lead = art.desc;
  }
  if (!out.paras.length && it.x) out.paras.push({ t: 'p', x: it.x });
  if (out.image && out.paras.some(function (p) { return p.t === 'img' && p.src === out.image; })) out.image = '';
  return out;
}

/* ---------- P-256 ECDSA (for VAPID) ---------- */
const P256 = (function () {
  const p = BigInt('0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff');
  const n = BigInt('0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551');
  const G = [BigInt('0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296'), BigInt('0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5'), 1n];
  const mod = function (a, m) { const r = a % m; return r >= 0n ? r : r + m; };
  const inv = function (a, m) { let lm = 1n, hm = 0n, low = mod(a, m), high = m; while (low > 1n) { const r = high / low; const nm = hm - lm * r, nw = high - low * r; hm = lm; lm = nm; high = low; low = nw; } return mod(lm, m); };
  const dbl = function (P) {
    if (!P || P[1] === 0n) return null;
    const X = P[0], Y = P[1], Z = P[2], YY = Y * Y % p, S = 4n * X * YY % p, ZZ = Z * Z % p, M = 3n * mod(X - ZZ, p) * (X + ZZ) % p;
    const X3 = mod(M * M - 2n * S, p); return [X3, mod(M * (S - X3) - 8n * YY * YY, p), 2n * Y * Z % p];
  };
  const add = function (P, Q) {
    if (!P) return Q; if (!Q) return P;
    const Z1Z1 = P[2] * P[2] % p, Z2Z2 = Q[2] * Q[2] % p, U1 = P[0] * Z2Z2 % p, U2 = Q[0] * Z1Z1 % p;
    const S1 = P[1] * Q[2] % p * Z2Z2 % p, S2 = Q[1] * P[2] % p * Z1Z1 % p;
    if (U1 === U2) return S1 === S2 ? dbl(P) : null;
    const H = mod(U2 - U1, p), R = mod(S2 - S1, p), HH = H * H % p, HHH = H * HH % p, V = U1 * HH % p;
    const X3 = mod(R * R - HHH - 2n * V, p); return [X3, mod(R * (V - X3) - S1 * HHH, p), H * P[2] % p * Q[2] % p];
  };
  const mul = function (k, P) { let R = null, Q = P; while (k > 0n) { if (k & 1n) R = add(R, Q); Q = dbl(Q); k >>= 1n; } return R; };
  const affine = function (P) { const zi = inv(P[2], p), zi2 = zi * zi % p; return [P[0] * zi2 % p, P[1] * zi2 % p * zi % p]; };
  const bytesToBig = function (b) { let h = ''; for (let i = 0; i < b.length; i++) h += ((b[i] & 255) + 256).toString(16).slice(1); return BigInt('0x' + (h || '0')); };
  const bigTo32 = function (x) { const h = x.toString(16).padStart(64, '0'), out = []; for (let i = 0; i < 64; i += 2) out.push(parseInt(h.substr(i, 2), 16)); return out; };
  const b64u = function (bytes) { return Utilities.base64EncodeWebSafe(bytes.map(function (x) { return x > 127 ? x - 256 : x; })).replace(/=+$/, ''); };
  const sha = function (str) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, str, Utilities.Charset.UTF_8); };
  const signB64u = function (msg, d) {
    const e = bytesToBig(sha(msg));
    for (let tries = 0; tries < 8; tries++) {
      const k = mod(bytesToBig(sha(Utilities.getUuid() + Utilities.getUuid() + msg + d.toString(16) + tries)), n - 1n) + 1n;
      const R = affine(mul(k, G)), r = mod(R[0], n); if (r === 0n) continue;
      const s = mod(inv(k, n) * (e + r * d), n); if (s === 0n) continue;
      return b64u(bigTo32(r).concat(bigTo32(s)));
    }
    throw new Error('sign failed');
  };
  return { p: p, n: n, G: G, mod: mod, mul: mul, affine: affine, bytesToBig: bytesToBig, bigTo32: bigTo32, b64u: b64u, signB64u: signB64u };
})();
