/**
 * PDXRadar — everything about the Portland Trail Blazers in one place
 * (Google Apps Script web app; the PWA in /pdx/ reads from it).
 *
 * Data: Basketball-Reference (schedule, box scores, play-by-play, shot charts, roster, injuries, salaries,
 * contracts, league team ratings, standings, franchise totals and history) and Blazers news feeds.
 * Live scores during a game are read by the app itself, in the browser.
 * From the play-by-play this script also builds what Basketball-Reference does not total up: five-man units,
 * on/off, clutch, assist pairs, shot types, and-ones, putbacks, turnovers / fouls / violations by type,
 * charges drawn, kicked balls and an estimate of each team's time of possession.
 *
 * Basketball-Reference asks for no more than 20 requests a minute; this script waits 3.5 s between pages
 * and reads at most a dozen pages per run.
 *
 *   GET  (no params)            app feed
 *   GET  ?v=player&id=<br id>   player page          GET ?v=game&id=<br game id>  game page
 *   GET  ?v=leaders             franchise leaderboards
 *   GET  ?v=team                lineups, on/off, clutch, assist pairs, play-by-play counts, franchise history
 *   GET  ?v=read&id=<news id>   in-app reader        GET ?v=vapid / ?v=push-latest / ?v=brief-input
 *   POST {pass, action:'prefs-get'|'refresh'|'push-sub'|'push-unsub'|'push-test'}
 *   POST {key, action:'brief-save', brief:{...}}
 *
 * First time: set PASS_PHRASE, run setup() once, then Deploy > New deployment > Web app
 * (Execute as: Me / Who has access: Anyone). checkBr() logs what was read from one game.
 */
const PASS_PHRASE = 'ここを自分だけの合言葉に変える';
const APP_NAME = 'PDXRadar';
const DATA_FOLDER = 'pdx-radar-data';
const TEAM = { id: 'POR', abbr: 'POR', br: 'POR', name: 'Trail Blazers' };
const BR = 'https://www.basketball-reference.com';
const SALARY_CAP = 164961000;                       // 2026-27 salary cap
const WIN_SHARE_VALUE = SALARY_CAP * 30 / 1230;     // ≈ $4.0M: league payroll at the cap ÷ all wins in a season
const MIN_SALARY = 1300000;
const BR_GAP_MS = 3500, BR_MAX_PER_RUN = 12;
const UA_DESKTOP = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36';

/* news sources */
const NEWS_SOURCES = [
  { id: 'gn-blazers', name: 'Google News: Trail Blazers', kind: 'gnews', q: '"Trail Blazers" OR "Blazers" Portland NBA' },
  { id: 'gn-moves', name: 'Google News: moves', kind: 'gnews', q: 'Blazers (trade OR signs OR waive OR extension OR contract OR "free agent" OR rumor)' },
  { id: 'gn-injury', name: 'Google News: injuries', kind: 'gnews', q: 'Blazers (injury OR injured OR "out for" OR questionable OR surgery OR "injury report")' },
  { id: 'blazersedge', name: "Blazer's Edge", kind: 'rss', url: 'https://www.blazersedge.com/rss/current.xml' },
  { id: 'hoopsrumors', name: 'Hoops Rumors', kind: 'rss', url: 'https://www.hoopsrumors.com/portland-trail-blazers/feed' },
  { id: 'ripcity', name: 'Rip City Project', kind: 'rss', url: 'https://ripcityproject.com/feed' },
  { id: 'hoopshype', name: 'HoopsHype', kind: 'rss', url: 'https://hoopshype.com/team/portland-trail-blazers/feed/' },
  { id: 'yahoo', name: 'Yahoo Sports', kind: 'rss', url: 'https://sports.yahoo.com/nba/teams/por/rss/' },
  { id: 'blazersland', name: 'Blazersland', kind: 'rss', url: 'https://www.blazersland.com/feed/' },
  { id: 'gn-remix', name: 'Google News: Rip City Remix', kind: 'gnews', q: '"Rip City Remix" OR (Blazers "two-way") OR (Blazers "G League")' }
];
const NEWS_CATS = [
  ['remix', /Rip City Remix|G League|G-League|\bassign(s|ed)? to\b|recall(s|ed)? from/i],
  ['move', /\btrade[sd]?\b|\bsigns?\b|\bsigned\b|\bwaive[sd]?\b|extension|contract|free agen|buyout|two-way|rumou?r|\bdeal\b|acquire|option|re-sign/i],
  ['injury', /injur|\bout\b.*(game|week|month|indefinitely)|questionable|doubtful|surgery|sprain|strain|ankle|knee|hamstring|concussion|return(s|ed)? (to|from)|injury report|day-to-day/i],
  ['off', /foundation|charity|community|interview|podcast|family|wedding|engaged|baby|fashion|music|album|camp\b|donat|hometown|\bwife\b|\bson\b|\bdaughter\b|birthday|documentary|book|faith|business|investment|sneaker|shoe deal|endorse/i],
  ['game', /\bvs\.?\b|\bbeat\b|\bloss\b|\bwin\b|\bfall\b|preview|recap|takeaways|observations|score|halftime|overtime|game \d|\d{2,3}-\d{2,3}/i]
];

/* ========== setup / triggers ========== */
function setup() {
  if (!PASS_PHRASE || PASS_PHRASE.indexOf('ここを') === 0) throw new Error('PASS_PHRASE を書き換えてから実行してください');
  PropertiesService.getScriptProperties().setProperty('PASS', PASS_PHRASE);
  dataFolder_(); briefKey_(); vapid_();
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'tick') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('tick').timeBased().everyMinutes(10).create();
  const r = tick(true);
  Logger.log('準備完了: ' + JSON.stringify(r) + '（過去の試合は10分ごとに2試合ずつ取り込みます）');
}
/* every 10 minutes: hourly / daily pages as they come due, the game just finished, then older games with the pages left */
const JOBS = [   // [key, every (ms), pages needed, function]
  ['schedule', 55 * 6e4, 1, function (st) { return updateSchedule_(st); }],
  ['team', 55 * 6e4, 1, function (st) { return updateTeam_(st); }],
  ['news', 55 * 6e4, 0, function (st) { return updateNews_(st); }],
  ['league', 20 * 36e5, 1, function () { return updateLeague_(); }],
  ['opponent', 3 * 36e5, 2, function () { return updateOpponent_(); }],
  ['franchise', 20 * 36e5, 2, function (st) { return updateFranchise_(st); }],
  ['contracts', 20 * 36e5, 1, function () { return updateContracts_(); }],
  ['values', 20 * 36e5, 0, function () { return snapshotValues_(); }]
];
function tick(force) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(3000)) return { busy: true };
  const t0 = Date.now(), log = {};
  BR_COUNT_ = 0;
  try {
    const st = readJson_('state.json', { porDone: {}, started: {}, live: null, status: {}, at: {} });
    st.started = st.started || {}; st.at = st.at || {}; st.status = st.status || {}; st.porDone = st.porDone || {};
    const now = Date.now();
    safe_(st, 'games', function () { log.games = updateGames_(st, true); });            // a game that just ended comes first
    JOBS.forEach(function (j) {
      if (!(force === true || !st.at[j[0]] || now - st.at[j[0]] > j[1])) return;
      if (brLeft_() < j[2]) return;                                                   // not enough pages left: next run
      safe_(st, j[0], function () { log[j[0]] = j[3](st); st.at[j[0]] = Date.now(); });
    });
    safe_(st, 'backfill', function () { log.backfill = updateGames_(st, false); });   // older games with what is left
    safe_(st, 'leaders', function () { log.leaders = updateLeaders_(st); });
    st.updated = now;
    writeJson_('state.json', st);
    buildFeed_(st);
    log.pages = BR_COUNT_; log.ms = Date.now() - t0;
    return log;
  } finally { lock.releaseLock(); }
}
function safe_(st, key, fn) {
  try { fn(); st.status[key] = { ok: true, at: Date.now() }; }
  catch (e) { st.status[key] = { ok: false, at: Date.now(), error: errText(e).slice(0, 140) }; Logger.log(key + ': ' + e); }
}

/* ========== Basketball-Reference, read politely ========== */
let BR_COUNT_ = 0, BR_LAST_ = 0;
function br_(path, allow404) {
  if (BR_COUNT_ >= BR_MAX_PER_RUN) throw new Error('page budget for this run used up');
  const wait = BR_LAST_ + BR_GAP_MS - Date.now(); if (BR_LAST_ && wait > 0) Utilities.sleep(wait);
  BR_COUNT_++; BR_LAST_ = Date.now();
  const r = UrlFetchApp.fetch(BR + path, { muteHttpExceptions: true, followRedirects: true });
  const code = r.getResponseCode();
  if (code === 404 && allow404) return null;
  if (code === 429) throw new Error('Basketball-Reference: too many requests (429), will retry later');
  if (code >= 400) throw new Error('Basketball-Reference HTTP ' + code + ' ' + path);
  return r.getContentText();
}
function brLeft_() { return BR_MAX_PER_RUN - BR_COUNT_; }
function season_() { const s = readJson_('schedule.json', {}).season; if (s) return s; const d = new Date(); return d.getMonth() >= 8 ? d.getFullYear() + 1 : d.getFullYear(); }
/* "2026-10-22" + "10:00p" (US Eastern) → ms */
function etMs_(day, time) {
  const m = String(time || '').match(/(\d+):(\d+)\s*([ap])/i); let h = 19, mi = 0;
  if (m) { h = (+m[1] % 12) + (/p/i.test(m[3]) ? 12 : 0); mi = +m[2]; }
  const d = String(day || '').match(/(\d{4})-(\d{2})-(\d{2})/); if (!d) return Date.parse(day) || 0;
  return Utilities.parseDate(d[1] + '-' + d[2] + '-' + d[3] + ' ' + ('0' + h).slice(-2) + ':' + ('0' + mi).slice(-2), 'America/New_York', 'yyyy-MM-dd HH:mm').getTime();
}
function etDate_(ms) { return Utilities.formatDate(new Date(ms), 'America/New_York', 'yyyyMMdd'); }

/* ========== schedule ========== */
function updateSchedule_(st) {
  const season = season_();
  const games = brSchedule(br_('/teams/' + TEAM.br + '/' + season + '_games.html'), etMs_);
  if (!games.length) throw new Error('no games found on the schedule page');
  st.season = season;
  writeJson_('schedule.json', { at: Date.now(), season: season, games: games });
  return games.length;
}
/* ========== games: tip-off push, finished games, backfill ========== */
function updateGames_(st, freshOnly) {
  const sched = readJson_('schedule.json', { games: [] }), games = sched.games, now = Date.now();
  // tip-off: at the scheduled time (Basketball-Reference has no live data; the app reads live scores itself)
  games.forEach(function (g) {
    if (!st.started[g.id] && g.state === 'pre' && now >= g.t && now - g.t < 30 * 6e4) { st.started[g.id] = 1; notify_('start', startMessageSched(g)); st.live = { id: g.id, state: 'in', at: now }; }
  });
  const todo = games.filter(function (g) { return !st.porDone[g.id] && (g.state === 'post' || now > g.t + 2.25 * 36e5) && g.t < now && (!freshOnly || now - g.t < 18 * 36e5); }).sort(function (a, b) { return b.t - a.t; });
  let done = 0;
  for (let i = 0; i < todo.length && done < (freshOnly ? 1 : 3) && brLeft_() >= 3; i++) {
    const g = todo[i], fresh = now - g.t < 18 * 36e5;   // finished within the day: notify and refresh tables
    const box = br_('/boxscores/' + g.id + '.html', true);
    if (!box || !/box-[A-Z]{3}-game-basic/.test(box)) { if (fresh || g.state !== 'post') continue; st.porDone[g.id] = 'missing'; continue; }
    const p = brBox(box, g.id); if (!p) continue;
    p.date = g.t;
    try { p.plays = brPbp(br_('/boxscores/pbp/' + g.id + '.html', true) || '', p); } catch (e) { p.plays = []; }
    try { p.shots = brShots(br_('/boxscores/shot-chart/' + g.id + '.html', true) || '', p); } catch (e) { p.shots = []; }
    const por = readJson_('por.json', { games: [], players: {}, shots: {} });
    const before = fresh ? leaderRanksSnapshot_() : null;
    ingestPorGame(p, por); writeJson_('por.json', por); writeJson_('game_' + g.id + '.json', gameView(p));
    st.porDone[g.id] = 1; done++;
    if (fresh) {
      g.state = 'post'; g.pf = (p.teams.filter(function (t) { return t.id === TEAM.id; })[0] || {}).score; g.pa = (p.teams.filter(function (t) { return t.id !== TEAM.id; })[0] || {}).score; g.win = g.pf > g.pa;
      writeJson_('schedule.json', sched);
      notify_('final', finalMessage(p, por)); st.pendingMilestones = before; st.live = null; st.at.league = 0; st.at.franchise = 0; st.at.team = 0;   // fresh tables right after the game
    }
  }
  return { read: done, waiting: todo.length - done };
}
function startMessageSched(g) { return { title: 'Tip-off ' + TEAM.abbr + ' ' + (g.home ? 'vs' : '@') + ' ' + g.opp.abbr, body: 'Blazers ' + (g.home ? 'vs ' : 'at ') + g.opp.name + ' is starting', url: './' }; }

/* ========== league ratings and standings (one page) ========== */
function updateLeague_() {
  const lg = brLeague(br_('/leagues/NBA_' + season_() + '.html'));
  if (!Object.keys(lg.metrics).length) throw new Error('team ratings table not found on the league page');
  const L = leagueFromBr(readJson_('league.json', null), lg, etDate_(Date.now()));
  writeJson_('league.json', L);
  writeJson_('standings.json', Object.assign({ at: Date.now() }, lg.standings));
  return { teams: Object.keys(lg.metrics).length, zones: L.zonesFrom };
}

/* ========== roster, injuries, salaries, season stats (team page, hourly) ========== */
function updateTeam_(st) {
  const season = season_(), html = br_('/teams/' + TEAM.br + '/' + season + '.html'), tp = brTeamPage(html, season);
  if (!tp.roster.length) throw new Error('roster table not found');
  const k = readJson_('contracts.json', { players: {} }).players;
  tp.roster.forEach(function (p) { const c = k[p.id]; if (c) { p.contracts = c.contracts; if (p.contract) p.contract.years = c.contracts.length; else if (c.contracts[0]) p.contract = { salary: c.contracts[0].s, years: c.contracts.length, option: 0, trade: null }; } });
  const old = readJson_('roster.json', { players: [] }).players;
  if (old.length) rosterChanges(old, tp.roster).forEach(function (m) { notify_('moves', m); });
  writeJson_('roster.json', { at: Date.now(), coach: tp.coach, players: tp.roster });
  // this season's per-game and advanced rows, used for value estimates and the franchise totals catch-up
  const per = brTableRows(html, /^per_game(_stats)?$/), adv = brTableRows(html, /^advanced$/), seasonRows = {};
  per.forEach(function (r) { const n = r.player || r.name_display; if (n) seasonRows[normName(n)] = { name: n, g: +(r.g || r.games || 0) }; });
  adv.forEach(function (r) { const n = r.player || r.name_display; if (!n) return; const kk = normName(n); seasonRows[kk] = Object.assign(seasonRows[kk] || { name: n, g: +(r.g || r.games || 0) }, { adv: brAdvanced(r) }); });
  const b = readJson_('bbref.json', { totals: {} }); b.season = season; b.season_ = seasonRows; b.seasonAt = Date.now(); writeJson_('bbref.json', b);
  return tp.roster.length;
}
function updateContracts_() {
  const c = brContracts(br_('/contracts/' + TEAM.br + '.html'), season_());
  writeJson_('contracts.json', { at: Date.now(), players: c });
  return Object.keys(c).length;
}
/* ========== franchise totals (daily) and season-by-season history (weekly) ========== */
function updateFranchise_(st) {
  const franchise = brTableRows(br_('/teams/' + TEAM.br + '/players.html'), /^(players|franchise_register|players_\w*)$/);
  const totals = {}; franchise.forEach(function (r) { const n = r.player || r.name_display; if (n && r.pts !== '') totals[normName(n)] = brNumbers(r, n); });
  if (!Object.keys(totals).length) throw new Error('Could not read the franchise totals table');
  const b = readJson_('bbref.json', {}); b.at = Date.now(); b.totals = totals;
  if (!st.weekly || Date.now() - st.weekly > 6.5 * 864e5 || !(b.history || []).length) {
    try { const h = brHistory(brTableRows(br_('/teams/' + TEAM.br + '/'), new RegExp('^' + TEAM.br + '$'), 'season')); if (h.length > 10) { b.history = h; st.weekly = Date.now(); } } catch (e) {}
  }
  writeJson_('bbref.json', b);
  return Object.keys(totals).length;
}
/* ========== next opponent (every 3 hours while the game is within 4 days) ========== */
function updateOpponent_() {
  const now = Date.now(), next = readJson_('schedule.json', { games: [] }).games.filter(function (g) { return g.state !== 'post' && g.t > now - 3 * 36e5; })[0];
  if (!next || !next.opp || !next.opp.id || next.t - now > 4 * 864e5) return 'none';
  const season = season_(), tp = brTeamPage(br_('/teams/' + next.opp.id + '/' + season + '.html'), season);
  let last = [];
  try { last = brLastResults(brSchedule(br_('/teams/' + next.opp.id + '/' + season + '_games.html'), etMs_), 5); } catch (e) {}
  writeJson_('opp.json', { id: next.opp.id, at: now, coach: tp.coach, last: last,
    leaders: tp.perGame.filter(function (p) { return p.gp > 0; }).sort(function (a, b) { return b.pts - a.pts; }).slice(0, 5),
    inj: tp.roster.filter(function (p) { return p.inj; }).map(function (p) { return { id: p.id, name: p.name, pos: p.pos, status: p.inj.status, detail: p.inj.detail, ret: '' }; }) });
  return next.opp.abbr;
}

/* run from the editor: every table on the league and contracts pages, its rows and columns (for fixing the readers) */
function checkTables() {
  BR_COUNT_ = 0; const out = [];
  [['league', '/leagues/NBA_' + season_() + '.html'], ['contracts', '/contracts/' + TEAM.br + '.html']].forEach(function (pg) {
    const html = br_(pg[1]), raw = html.replace(/<!--|-->/g, '');
    out.push(pg[0] + ': ' + html.length + ' chars, comments ' + (html.match(/<!--/g) || []).length);
    const tre = /<table\b[^>]*\bid="([^"]+)"[^>]*>([\s\S]*?)<\/table>/gi; let m;
    while ((m = tre.exec(raw))) {
      const rows = m[2].match(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi) || [];
      const data = rows.filter(function (r) { return /<td\b/i.test(r); });
      const first = data[0] || '';
      out.push('  ' + m[1] + ': ' + rows.length + ' rows, ' + data.length + ' with cells; stats ' + (first.match(/data-stat="[^"]+"/g) || []).slice(0, 18).map(function (x) { return x.slice(11, -1); }).join(' '));
      if (/advanced|contracts|per_game-team/.test(m[1])) out.push('    first row: ' + first.replace(/\s+/g, ' ').slice(0, 420));
    }
  });
  Logger.log(out.join('\n'));
  return out;
}

/* run from the editor after setup: what was read from the latest Blazers game (send this log when something looks off) */
function checkBr() {
  BR_COUNT_ = 0;
  const g = readJson_('schedule.json', { games: [] }).games.filter(function (x) { return x.state === 'post'; }).pop();
  if (!g) { Logger.log('no finished game on the schedule yet'); return; }
  const p = brBox(br_('/boxscores/' + g.id + '.html'), g.id);
  const out = ['game ' + g.id + ': ' + (p ? p.teams.map(function (t) { return t.abbr + ' ' + t.score + ' (' + (p.players[t.id] || []).length + ' players, FGA ' + t.stats.fga + ')'; }).join(' / ') : 'box score not parsed')];
  if (p) {
    p.plays = brPbp(br_('/boxscores/pbp/' + g.id + '.html'), p);
    const subs = p.plays.filter(function (x) { return /enters the game/.test(x.txt); }).length, fga = p.plays.filter(function (x) { return x.fga; }).length;
    out.push('plays ' + p.plays.length + ', subs ' + subs + ', shots ' + fga + ', last score ' + (p.plays.length ? p.plays[p.plays.length - 1].as + '-' + p.plays[p.plays.length - 1].hs : '-'));
    const a = pbpAnalyze(p); out.push(a ? 'lineup seconds ' + Math.round(a.total) + ' (2880 = 48 min), quarters ' + JSON.stringify(a.quarters) : 'lineups: not enough plays');
    const ev = pbpEvents(p); if (ev) out.push('possession POR ' + Math.round(ev.top.POR) + 's / OPP ' + Math.round(ev.top.OPP) + 's; events ' + Object.keys(ev.team.POR).sort().join(', '));
    p.shots = brShots(br_('/boxscores/shot-chart/' + g.id + '.html'), p);
    out.push('shot chart ' + p.shots.length + ' shots, with player ' + p.shots.filter(function (s) { return s.pid; }).length + ', sample ' + JSON.stringify(p.shots.slice(0, 2)));
    const unknown = p.plays.filter(function (x) { return !(x.fga || x.fta || /rebound|Turnover|foul|Violation|enters the game|Jump ball|timeout|Start of|End of|ejected|Instant Replay|heave/i.test(x.txt)); }).slice(0, 5).map(function (x) { return x.txt; });
    if (unknown.length) out.push('not classified: ' + unknown.join(' | '));
  }
  // league and contracts pages: which tables are there
  [['league', '/leagues/NBA_' + season_() + '.html'], ['contracts', '/contracts/' + TEAM.br + '.html']].forEach(function (pg) {
    try {
      const html = br_(pg[1]), ids = (html.match(/<table\b[^>]*\bid="[^"]+"/g) || []).map(function (t) { return t.match(/id="([^"]+)"/)[1]; });
      out.push(pg[0] + ' tables: ' + ids.join(', '));
      if (pg[0] === 'league') { const lg = brLeague(html); out.push('league parsed: ' + Object.keys(lg.metrics).length + ' teams, standings W ' + lg.standings.west.length + ' / E ' + lg.standings.east.length + ', shooting ' + (lg.zones ? 'yes' : 'no') + (lg.metrics[TEAM.id] ? ', POR ' + JSON.stringify(lg.metrics[TEAM.id]) : ''));
        brRows(html, /./).filter(function (r) { return brTeamOf(r.team_h || r.team_name_h || r.name_display_h) === TEAM.id; }).slice(0, 8).forEach(function (r) { out.push('  ' + r._table + ': ' + Object.keys(r).filter(function (k) { return !/^_|_h$|_c$|_id$/.test(k); }).slice(0, 26).join(' ')); }); }
      else { const c = brContracts(html, season_()); out.push('contracts parsed: ' + Object.keys(c).length + ' players' + (Object.keys(c)[0] ? ', e.g. ' + Object.keys(c)[0] + ' ' + JSON.stringify(c[Object.keys(c)[0]]) : ''));
        brRows(html, /./).filter(function (r) { return r.player_h || r.name_display_h; }).slice(0, 2).forEach(function (r) { out.push('  ' + r._table + ': ' + Object.keys(r).filter(function (k) { return !/^_|_h$|_c$|_id$/.test(k); }).join(' ')); }); }
    } catch (e) { out.push(pg[0] + ': ' + errText(e)); }
  });
  Logger.log(out.join('\n'));
  return out;
}
/* ========== franchise leaderboards (Basketball-Reference totals + games played since) ========== */
function updateLeaders_(st) {
  const br = readJson_('bbref.json', null);
  if (!br) return 'no bbref';
  const por = readJson_('por.json', { games: [], players: {} }), roster = readJson_('roster.json', { players: [] }).players;
  const boards = buildLeaders(br, por, roster);
  const prev = readJson_('leaders.json', null);
  if (st.pendingMilestones && prev) milestoneMessages(st.pendingMilestones, boards).forEach(function (m) { notify_('records', m); });
  st.pendingMilestones = null;
  writeJson_('leaders.json', Object.assign({ at: Date.now(), brAt: br.at }, boards));
  return Object.keys(boards.cats).length;
}
function leaderRanksSnapshot_() { const l = readJson_('leaders.json', null); return l ? l.active : null; }

/* ========== market value (estimated from Win Shares) and contracts ========== */
function snapshotValues_() {
  const br = readJson_('bbref.json', null), roster = readJson_('roster.json', { players: [] }).players, por = readJson_('por.json', { games: [] });
  const vals = readJson_('values.json', { players: {} }), day = Utilities.formatDate(new Date(), 'Asia/Tokyo', 'yyyy-MM-dd');
  roster.forEach(function (p) {
    const s = br && br.season_ ? br.season_[normName(p.name)] : null;
    const v = marketValue(s && s.adv ? s.adv.ws : null, por.games.length, p);
    const h = vals.players[p.id] = vals.players[p.id] || [];
    const row = { d: day, ws: v.ws, v: v.value, s: p.contract ? p.contract.salary : null, t: p.contract ? p.contract.trade : null };
    if (h.length && h[h.length - 1].d === day) h[h.length - 1] = row; else h.push(row);
    if (h.length > 400) h.splice(0, h.length - 400);
  });
  writeJson_('values.json', vals);
  return roster.length;
}

/* ========== news ========== */
function updateNews_(st) {
  const idx = readJson_('news.json', { items: [] }), roster = readJson_('roster.json', { players: [] }).players;
  const seen = {}; idx.items.forEach(function (it) { seen[it.id] = 1; seen['t:' + normTitle(it.t)] = 1; });
  const now = Date.now(), fresh = [], status = st.newsStatus = st.newsStatus || {};
  const nameRe = rosterNameRegex(roster);
  const add = function (r, src) {
    const it = newsItem(r, src, now, nameRe, roster);
    if (!it || seen[it.id] || seen['t:' + normTitle(it.t)]) return 0;
    seen[it.id] = 1; seen['t:' + normTitle(it.t)] = 1; fresh.push(it); return 1;
  };
  // player queries for off-court and individual news, a few players per query
  const players = roster.map(function (p) { return '"' + p.name + '"'; });
  const srcs = NEWS_SOURCES.slice();
  for (let i = 0; i < players.length; i += 5) srcs.push({ id: 'gn-players-' + (i / 5), name: 'Google News: players ' + (i / 5 + 1), kind: 'gnews', q: '(' + players.slice(i, i + 5).join(' OR ') + ')' });
  const reqs = srcs.map(function (s) { return { url: s.kind === 'gnews' ? 'https://news.google.com/rss/search?q=' + encodeURIComponent(s.q + ' when:3d') + '&hl=en-US&gl=US&ceid=US:en' : s.url, muteHttpExceptions: true, headers: { 'User-Agent': UA_DESKTOP } }; });
  let res = [];
  try { res = UrlFetchApp.fetchAll(reqs); }
  catch (e) { res = reqs.map(function (q) { try { const u = q.url; delete q.url; return UrlFetchApp.fetch(u, q); } catch (err) { return { error: errText(err).replace(/: https?:\/\/\S+/, '').slice(0, 80) }; } }); }
  srcs.forEach(function (s, k) {
    try {
      if (res[k].error) { status[s.id] = { ok: false, error: res[k].error, name: s.name }; return; }
      const code = res[k].getResponseCode();
      if (code >= 400) { status[s.id] = { ok: false, error: 'HTTP ' + code, name: s.name }; return; }
      const raws = parseFeed(res[k].getContentText());
      let n = 0; raws.slice(0, 60).forEach(function (r) { n += add(r, s); });
      status[s.id] = { ok: true, n: n, name: s.name };
    } catch (e) { status[s.id] = { ok: false, error: errText(e).slice(0, 80), name: s.name }; }
  });
  const items = fresh.concat(idx.items).filter(function (it) { return it.d > now - 45 * 864e5; }).sort(function (a, b) { return b.d - a.d; }).slice(0, 1500);
  writeJson_('news.json', { at: now, items: items });
  // contract / trade news is pushed (a few per hour at most)
  fresh.filter(function (it) { return it.cat === 'move' && /official|signs|signed|traded|waive|extension|agree/i.test(it.t); }).slice(0, 2).forEach(function (it) { notify_('moves', { title: 'Roster move', body: it.t, url: './?n=' + it.id }); });
  return fresh.length;
}

/* ========== in-app reader ========== */
function readNews_(id) {
  const key = 'rd_' + id, hit = cacheGet_(key);
  if (hit) return JSON.parse(hit);
  const it = readJson_('news.json', { items: [] }).items.filter(function (x) { return x.id === id; })[0];
  if (!it) return { ok: false, error: 'not found' };
  let url = it.u, best = null, err = '';
  const better = function (a, u) { if (a && (!best || a.chars > best.chars)) { best = a; best.url = u; } };
  const get = function (u) { const r = UrlFetchApp.fetch(u, { muteHttpExceptions: true, followRedirects: true, headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' } }); if (r.getResponseCode() >= 400) throw new Error('HTTP ' + r.getResponseCode()); return decodeHtml_(r); };
  try {
    if (/news\.google\.com\/(rss\/)?articles\//.test(url)) { const g = resolveGn_(url, it); if (g.url) url = g.url; else err = 'Could not resolve the Google News link (' + g.err + ')'; }
    if (!/news\.google\.com/.test(url)) { const html = get(url), a = extractArticle(html, url); better(a, url);
      const amp = absUrl((html.match(/<link[^>]+rel=["']amphtml["'][^>]*>/i) || [''])[0].replace(/^.*href=["']([^"']+)["'].*$/i, '$1'), url);
      if (a.chars < 700 && amp) { try { better(extractArticle(get(amp), amp), url); } catch (e) {} } }
  } catch (e) { err = errText(e).slice(0, 100); }
  if ((!best || best.chars < 500)) {
    try { const r = UrlFetchApp.fetch('https://r.jina.ai/' + url, { muteHttpExceptions: true, headers: { 'X-Return-Format': 'markdown' } });
      if (r.getResponseCode() === 200) { const t = r.getContentText(), src = ((t.match(/^URL Source:\s*(\S+)/m) || [])[1] || url); better(jinaToArticle(t, src), src); } } catch (e) {}
  }
  const out = buildReaderResult({ id: it.id, u: url, s: it.s, ty: 'news', d: it.d, t: it.t, x: it.x }, best ? best.url : url, best, err);
  cachePut_(key, JSON.stringify(out));
  return out;
}

/* ========== notifications ========== */
const PUSH_TYPES = ['start', 'final', 'records', 'moves', 'brief'];
function notify_(type, msg) {
  if (!msg) return;
  const ev = readJson_('events.json', { list: [] });
  const e = { type: type, title: msg.title, body: msg.body, url: msg.url || './', at: Date.now(), tag: 'pdx-' + type };
  ev.list.unshift(e); ev.list = ev.list.slice(0, 60);
  writeJson_('events.json', ev);
  const subs = readJson_('subs.json', { list: [] });
  const keep = subs.list.filter(function (s) {
    if (s.types && s.types[type] === false) return true;
    try { const r = sendPush_(s); return !r.gone; } catch (err) { return true; }
  });
  if (keep.length !== subs.list.length) { subs.list = keep; writeJson_('subs.json', subs); }
}
function pushLatest_() {
  const e = readJson_('events.json', { list: [] }).list[0];
  return e ? { ok: true, title: e.title, body: e.body, url: e.url, tag: e.tag } : { ok: true, title: APP_NAME, body: 'New update', url: './', tag: 'pdx' };
}

/* ========== web endpoints ========== */
/* ========== web endpoints ========== */
function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    switch (p.v) {
      case 'player': return json_(playerView_(String(p.id || '')));
      case 'game': return json_(readJson_('game_' + String(p.id || '').replace(/[^0-9A-Z]/g, '') + '.json', { ok: false, error: 'not found' }));
      case 'live': return json_({ ok: true, none: true });   // live scores are read by the app in the browser
      case 'leaders': return json_(readJson_('leaders.json', { ok: false }));
      case 'team': return json_(teamPage(readJson_('por.json', { games: [], players: {} }), readJson_('roster.json', { players: [] }).players, readJson_('bbref.json', null)));
      case 'read': return json_(readNews_(String(p.id || '')));
      case 'vapid': return json_({ ok: true, key: vapid_().pub });
      case 'push-latest': return json_(pushLatest_());
      case 'brief-input': return json_(briefInput_());
    }
    let body = cacheGet_('feed');
    if (!body) { body = JSON.stringify(readJson_('feed.json', { ok: true, empty: true })); cachePut_('feed', body); }
    return ContentService.createTextOutput(body).setMimeType(ContentService.MimeType.JSON);
  } catch (err) { return json_({ ok: false, error: String(err && err.message || err) }); }
}
function doPost(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'bad request' }); }
  if (req.action === 'brief-save') {
    if (!req.key || req.key !== briefKey_()) return json_({ ok: false, error: 'auth' });
    const b = sanitizeBrief(req.brief);
    if (!b) return json_({ ok: false, error: 'bad brief' });
    writeJson_('brief.json', b);
    notify_('brief', { title: APP_NAME + ' morning brief', body: b.headline || (b.points[0] && b.points[0].text) || '', url: './' });
    const lock = LockService.getScriptLock(); if (lock.tryLock(15000)) { try { buildFeed_(readJson_('state.json', {})); } finally { lock.releaseLock(); } }
    return json_({ ok: true, at: b.at });
  }
  if (!checkPass_(req.pass)) return json_({ ok: false, error: 'auth' });
  try {
    switch (req.action) {
      case 'prefs-get': { const subs = readJson_('subs.json', { list: [] }).list, me = subs.filter(function (x) { return x.endpoint === req.endpoint; })[0];
        return json_({ ok: true, briefKey: briefKey_(), push: { devices: subs.length, registered: !!me, types: me ? me.types : null, tick: ScriptApp.getProjectTriggers().some(function (t) { return t.getHandlerFunction() === 'tick'; }) } }); }
      case 'refresh': { const r = tick(true); return json_(r.busy ? { ok: false, error: 'busy' } : Object.assign({ ok: true }, r)); }
      case 'push-sub': {
        if (!req.sub || !/^https:\/\//.test(req.sub.endpoint || '')) return json_({ ok: false, error: 'bad subscription' });
        const subs = readJson_('subs.json', { list: [] }), types = {};
        PUSH_TYPES.forEach(function (t) { types[t] = !(req.types && req.types[t] === false); });
        subs.list = subs.list.filter(function (x) { return x.endpoint !== req.sub.endpoint; }).concat([{ endpoint: req.sub.endpoint, types: types, label: String(req.label || '').slice(0, 30), at: Date.now() }]).slice(-10);
        writeJson_('subs.json', subs); return json_({ ok: true, count: subs.list.length });
      }
      case 'push-unsub': { const subs = readJson_('subs.json', { list: [] }); subs.list = subs.list.filter(function (x) { return x.endpoint !== req.endpoint; }); writeJson_('subs.json', subs); return json_({ ok: true }); }
      case 'push-test': {
        const s = readJson_('subs.json', { list: [] }).list.filter(function (x) { return x.endpoint === req.endpoint; })[0];
        if (!s) return json_({ ok: false, error: 'This device is not registered' });
        const ev = readJson_('events.json', { list: [] }); ev.list.unshift({ type: 'test', title: APP_NAME, body: 'Test notification', url: './', at: Date.now(), tag: 'pdx-test' }); writeJson_('events.json', ev);
        const r = sendPush_(s); return json_({ ok: r.ok, code: r.code, error: r.ok ? '' : 'The push service rejected it (' + r.code + ')' + (r.body ? ': ' + r.body : '') });
      }
      default: return json_({ ok: false, error: 'unknown action' });
    }
  } catch (err) { return json_({ ok: false, error: String(err && err.message || err) }); }
}

/* ========== views for the app ========== */
function buildFeed_(st) {
  const sched = readJson_('schedule.json', { games: [] }), por = readJson_('por.json', { games: [], players: {} }), L = readJson_('league.json', newLeague());
  const roster = readJson_('roster.json', { players: [] }), leaders = readJson_('leaders.json', null), standings = readJson_('standings.json', {}), br = readJson_('bbref.json', null);
  const news = readJson_('news.json', { items: [] }).items.slice(0, 120), brief = readJson_('brief.json', null), vals = readJson_('values.json', { players: {} });
  const feed = feedView(Date.now(), sched, por, L, roster, leaders, standings, br, news, brief, vals, st, readJson_('opp.json', null));
  writeJson_('feed.json', feed); cachePut_('feed', JSON.stringify(feed));
  return feed;
}
function playerView_(id) {
  const roster = readJson_('roster.json', { players: [] }).players, por = readJson_('por.json', { games: [], players: {}, shots: {} });
  const p = roster.filter(function (x) { return x.id === id; })[0] || (por.players[id] ? { id: id, name: por.players[id].name } : null);
  if (!p) return { ok: false, error: 'not found' };
  const br = readJson_('bbref.json', null), leaders = readJson_('leaders.json', null), L = readJson_('league.json', newLeague());
  const vals = readJson_('values.json', { players: {} }).players[id] || [], news = readJson_('news.json', { items: [] }).items;
  return playerPage(p, por, br, leaders, L, vals, news);
}
function briefInput_() {
  const f = readJson_('feed.json', {}), since = Date.now() - 30 * 36e5;
  return { ok: true, now: Date.now(), record: f.record, last: f.last, next: f.next, standing: f.standing, ranks: f.ranks, milestones: (f.milestones || []).slice(0, 8),
    injuries: (f.roster || []).filter(function (p) { return p.inj; }).map(function (p) { return { name: p.name, inj: p.inj }; }),
    news: (f.news || []).filter(function (n) { return n.d >= since; }).slice(0, 60).map(function (n) { return { t: n.t, s: n.s, cat: n.cat, u: n.u, who: n.who }; }) };
}
function briefKey_() {
  const props = PropertiesService.getScriptProperties();
  let k = props.getProperty('BRIEF_KEY');
  if (!k) { k = Utilities.getUuid().replace(/-/g, ''); props.setProperty('BRIEF_KEY', k); }
  return k;
}

/* ======================================================================
 * Pure functions (no Apps Script services) — also run in the tests.
 * ====================================================================== */
const NUM = function (v) { const n = parseFloat(String(v == null ? '' : v).replace(/,/g, '')); return isFinite(n) ? n : 0; };
const MADE = function (s) { const m = String(s || '').match(/(\d+)\s*-\s*(\d+)/); return m ? [+m[1], +m[2]] : [0, 0]; };
const r1 = function (x) { return Math.round(x * 10) / 10; };
function normName(n) {
  return String(n || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\*/g, '').replace(/\b(jr|sr|ii|iii|iv)\b\.?/g, '').replace(/[^a-z ]/g, '').replace(/\s+/g, ' ').trim();
}

function clockSec(c) { c = String(c || ''); if (c.indexOf(':') >= 0) { const a = c.split(':'); return NUM(a[0]) * 60 + NUM(a[1]); } return NUM(c); }
function periodLen(per) { return per <= 4 ? 720 : 300; }
function elapsedAt(per, sec) { return (per <= 4 ? (per - 1) * 720 : 2880 + (per - 5) * 300) + periodLen(per) - sec; }
function possOf(s) { return s ? s.fga - s.oreb + s.tov + 0.44 * s.fta : 0; }

/* shot zones on ESPN's half court (feet; basket at x=25, y≈4.75) */
const ZONES = [['RA', 'Restricted area'], ['PAINT', 'Paint'], ['MID_L', 'Mid-range left'], ['MID_C', 'Mid-range center'], ['MID_R', 'Mid-range right'], ['C3_L', 'Left corner 3'], ['C3_R', 'Right corner 3'], ['AB3_L', 'Left wing 3'], ['AB3_C', 'Top of key 3'], ['AB3_R', 'Right wing 3']];
function zoneOf(x, y, three) {
  const dx = x - 25, dy = y - 4.75, d = Math.sqrt(dx * dx + dy * dy), ang = Math.atan2(dx, dy) * 180 / Math.PI;
  if (three || d > 23.6) { if (y < 14) return dx < 0 ? 'C3_L' : 'C3_R'; return ang < -22 ? 'AB3_L' : ang > 22 ? 'AB3_R' : 'AB3_C'; }
  if (d < 4) return 'RA';
  if (Math.abs(dx) <= 8 && y <= 19) return 'PAINT';
  return ang < -30 ? 'MID_L' : ang > 30 ? 'MID_R' : 'MID_C';
}

/* ---------- Blazers games ---------- */
function ingestPorGame(p, por) {
  if (por.games.some(function (g) { return g.id === p.id; })) return false;
  const me = p.teams.filter(function (t) { return t.id === TEAM.id; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.id; })[0];
  if (!me || !op) return false;
  const poss = (possOf(me.stats) + possOf(op.stats)) / 2 || 1;
  const gi = por.games.length;
  por.games.push({ id: p.id, d: p.date, home: me.home, opp: op.abbr, oppName: op.name, oppLogo: op.logo, pf: me.score, pa: op.score, win: me.score > op.score,
    poss: r1(poss), ortg: r1(100 * me.score / poss), drtg: r1(100 * op.score / poss), s: me.stats, os: op.stats });
  (p.players[TEAM.id] || []).forEach(function (pl) {
    const P = por.players[pl.id] = por.players[pl.id] || { name: pl.name, logs: [] };
    P.name = pl.name; P.jersey = pl.jersey; P.pos = pl.pos; P.head = pl.head || P.head;
    if (pl.dnp || !pl.min) { P.logs.push({ e: p.id, d: p.date, o: op.abbr, h: me.home, dnp: pl.reason || 'DNP' }); return; }
    P.logs.push({ e: p.id, d: p.date, o: op.abbr, h: me.home, w: me.score > op.score, st: pl.starter, min: pl.min, pts: pl.pts || 0, reb: pl.reb || 0, ast: pl.ast || 0, stl: pl.stl || 0, blk: pl.blk || 0, tov: pl.tov || 0,
      fgm: pl.fgm || 0, fga: pl.fga || 0, tpm: pl.tpm || 0, tpa: pl.tpa || 0, ftm: pl.ftm || 0, fta: pl.fta || 0, oreb: pl.oreb || 0, dreb: pl.dreb || 0, pf: pl.pf || 0, pm: pl.pm || 0 });
  });
  por.shots = por.shots || {};
  const shotList = p.shots && p.shots.length ? p.shots.filter(function (s) { return s.tid === TEAM.id && s.pid; }).map(function (s) { return { pid: s.pid, x: s.x, y: s.y, made: s.made, three: s.three }; })
    : p.plays.filter(function (pl) { return pl.shot && pl.tid === TEAM.id && pl.pid; });
  shotList.forEach(function (pl) { (por.shots[pl.pid] = por.shots[pl.pid] || []).push([pl.x, pl.y, pl.made ? 1 : 0, pl.three ? 1 : 0, gi]); });
  try { ingestPbp_(p, por, por.games[gi]); } catch (e) { por.games[gi].pbpErr = String(e && e.message || e).slice(0, 80); }
  return true;
}

/* ---------- play-by-play: lineups, on/off, clutch, assists, quarters ----------
 * Who is on the floor is rebuilt from substitutions ("X enters the game for Y"). ESPN does not list the five
 * players at the start of a quarter, so they are inferred: anyone who appears in the quarter before being
 * subbed in was already on the floor. Points come from score changes, so free throws and and-ones count. */
const SUB_RE = /^(.+?) enters the game for (.+?)\.?$/i, AST_RE = /\((?:assist by ([^()]+?)|([^()]+?) assists?)\)/i;
function pbpAnalyze(p) {
  const me = p.teams.filter(function (t) { return t.id === TEAM.id; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.id; })[0];
  const box = (p.players[TEAM.id] || []).filter(function (x) { return !x.dnp; });
  if (!me || !op || !box.length || p.plays.length < 60) return null;
  const mine = {}, byName = {}; box.forEach(function (x) { mine[x.id] = 1; byName[normName(x.name)] = x.id; if (x.short) byName[normName(x.short)] = byName[normName(x.short)] || x.id; });
  const idOf = function (name, fallback) { const k = byName[normName(name)]; return k || (fallback && mine[fallback] ? fallback : ''); };
  const subOf = function (ev) {
    const m = SUB_RE.exec(ev.txt); if (!m && !/substitution/i.test(ev.typ)) return null;
    // links in the text give the ids directly (incoming first); names are the fallback
    const inn = mine[ev.pids[0]] ? ev.pids[0] : m ? idOf(m[1], '') : '', out = mine[ev.pids[1]] ? ev.pids[1] : m ? idOf(m[2], '') : '';
    return inn && out ? { inn: inn, out: out } : null;
  };
  const pers = []; p.plays.forEach(function (ev) { if (ev.per >= 1) (pers[ev.per - 1] = pers[ev.per - 1] || []).push(ev); });
  const stints = {}, clutch = { sec: 0, pf: 0, pa: 0, players: {} }, assists = {}, quarters = [];
  let cur = box.filter(function (x) { return x.starter; }).map(function (x) { return x.id; }).slice(0, 5), hs = 0, as = 0, lastEnd = cur.slice();
  const myScore = function () { return me.home ? hs : as; }, opScore = function () { return me.home ? as : hs; };
  const stint = function () { const k = cur.slice().sort().join(','); return stints[k] = stints[k] || { sec: 0, pf: 0, pa: 0 }; };
  const cp = function (id) { return clutch.players[id] = clutch.players[id] || { pts: 0, fgm: 0, fga: 0, tpm: 0, tpa: 0, ftm: 0, fta: 0, ast: 0, sec: 0 }; };
  for (let pi = 0; pi < pers.length; pi++) {
    const evs = pers[pi] || [], per = pi + 1;
    if (per > 1) {   // infer who started this period
      const start = [], seenIn = {};
      for (let i = 0; i < evs.length && start.length < 5; i++) {
        const sb = subOf(evs[i]);
        if (sb) { if (!seenIn[sb.out] && start.indexOf(sb.out) < 0) start.push(sb.out); seenIn[sb.inn] = 1; continue; }
        evs[i].pids.forEach(function (id) { if (mine[id] && !seenIn[id] && start.indexOf(id) < 0 && start.length < 5) start.push(id); });
      }
      lastEnd.forEach(function (id) { if (start.length < 5 && start.indexOf(id) < 0 && !seenIn[id]) start.push(id); });
      cur = start.slice(0, 5);
    }
    const q0 = [myScore(), opScore()];
    let lastSec = periodLen(per);
    const clutchNow = function (sec) { return per >= 4 && sec <= 300 && Math.abs(myScore() - opScore()) <= 5; };
    const run = function (sec) {   // time passes from lastSec down to sec with the current five
      const dt = Math.max(0, lastSec - sec); if (!dt) return;
      if (cur.length === 5) stint().sec += dt;
      if (clutchNow(lastSec)) { clutch.sec += dt; cur.forEach(function (id) { cp(id).sec += dt; }); }
      lastSec = sec;
    };
    evs.forEach(function (ev) {
      run(ev.sec);
      const inClutch = clutchNow(ev.sec);
      if (ev.hs != null && ev.as != null && (ev.hs !== hs || ev.as !== as) && ev.hs >= hs && ev.as >= as) {
        const dm = (me.home ? ev.hs - hs : ev.as - as), dop = (me.home ? ev.as - as : ev.hs - hs);
        if (cur.length === 5) { const S = stint(); S.pf += dm; S.pa += dop; }
        if (inClutch) { clutch.pf += dm; clutch.pa += dop; }
        hs = ev.hs; as = ev.as;
      }
      if (ev.tid === TEAM.id && mine[ev.pids[0]]) {
        const shooter = ev.pids[0];
        if (ev.fga && ev.made) {
          const am = AST_RE.exec(ev.txt), a = am ? (mine[ev.pids[1]] && ev.pids[1] !== shooter ? ev.pids[1] : idOf(am[1] || am[2], '')) : '';
          if (a && a !== shooter) { const k = a + '>' + shooter; assists[k] = (assists[k] || 0) + 1; if (inClutch) cp(a).ast++; }
        }
        if (inClutch) {
          const c = cp(shooter);
          if (ev.fga) { c.fga++; if (ev.three) c.tpa++; if (ev.made) { c.fgm++; c.pts += ev.three ? 3 : 2; if (ev.three) c.tpm++; } }
          else if (ev.fta) { c.fta++; if (ev.made) { c.ftm++; c.pts++; } }
        }
      }
      const sb = ev.tid === TEAM.id || !ev.tid ? subOf(ev) : null;
      if (sb) { const i = cur.indexOf(sb.out); if (i >= 0) cur[i] = sb.inn; else if (cur.indexOf(sb.inn) < 0 && cur.length < 5) cur.push(sb.inn); }
    });
    run(0);
    quarters.push([myScore() - q0[0], opScore() - q0[1]]);
    lastEnd = cur.slice();
  }
  const total = Object.keys(stints).reduce(function (s, k) { return s + stints[k].sec; }, 0);
  return { stints: stints, total: total, clutch: clutch, assists: assists, quarters: quarters };
}
function addRate_(o, sec, pf, pa, poss) { o.sec = (o.sec || 0) + sec; o.pf = (o.pf || 0) + pf; o.pa = (o.pa || 0) + pa; o.poss = (o.poss || 0) + poss; return o; }
function ingestPbp_(p, por, g) {
  const a = pbpAnalyze(p); if (!a || a.total < 1500) return false;
  const me = p.teams.filter(function (t) { return t.id === TEAM.id; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.id; })[0];
  const pps = ((possOf(me.stats) + possOf(op.stats)) / 2) / (a.total || 1);   // possessions per second of this game
  por.lineups = por.lineups || {}; por.onoff = por.onoff || {}; por.assists = por.assists || {};
  por.clutch = por.clutch || { g: 0, w: 0, l: 0, sec: 0, pf: 0, pa: 0, poss: 0, players: {} };
  const tot = { sec: 0, pf: 0, pa: 0 };
  Object.keys(a.stints).forEach(function (k) {
    const S = a.stints[k]; tot.sec += S.sec; tot.pf += S.pf; tot.pa += S.pa;
    const L = por.lineups[k] = por.lineups[k] || { g: 0, sec: 0, pf: 0, pa: 0, poss: 0, last: '' };
    addRate_(L, S.sec, S.pf, S.pa, S.sec * pps); if (L.last !== p.id) { L.g++; L.last = p.id; }
  });
  const ids = {}; Object.keys(a.stints).forEach(function (k) { k.split(',').forEach(function (id) { ids[id] = 1; }); });
  Object.keys(ids).forEach(function (id) {
    const on = { sec: 0, pf: 0, pa: 0 };
    Object.keys(a.stints).forEach(function (k) { if (k.split(',').indexOf(id) >= 0) { on.sec += a.stints[k].sec; on.pf += a.stints[k].pf; on.pa += a.stints[k].pa; } });
    const O = por.onoff[id] = por.onoff[id] || { on: {}, off: {}, g: 0 };
    addRate_(O.on, on.sec, on.pf, on.pa, on.sec * pps); addRate_(O.off, tot.sec - on.sec, tot.pf - on.pf, tot.pa - on.pa, (tot.sec - on.sec) * pps); O.g++;
  });
  Object.keys(a.assists).forEach(function (k) { por.assists[k] = (por.assists[k] || 0) + a.assists[k]; });
  if (a.clutch.sec > 0) {
    const C = por.clutch; C.g++; if (g.win) C.w++; else C.l++;
    addRate_(C, a.clutch.sec, a.clutch.pf, a.clutch.pa, a.clutch.sec * pps);
    Object.keys(a.clutch.players).forEach(function (id) { const s = a.clutch.players[id], P = C.players[id] = C.players[id] || {}; Object.keys(s).forEach(function (k) { P[k] = (P[k] || 0) + s[k]; }); });
  }
  g.q = a.quarters; g.clutch = a.clutch.sec > 0; g.pbp = 1;
  const ev = pbpEvents(p);
  if (ev) {
    por.ev = por.ev || {}; por.tev = por.tev || { POR: {}, OPP: {} }; por.top = por.top || { POR: 0, OPP: 0, nPOR: 0, nOPP: 0, g: 0 };
    Object.keys(ev.players).forEach(function (id) {
      por.ev[id] = mergeCounts_(por.ev[id] || {}, ev.players[id]);
      const P = por.players[id]; if (P) { const l = P.logs.filter(function (x) { return x.e === p.id; })[0]; if (l) l.ev = ev.players[id]; }
    });
    mergeCounts_(por.tev.POR, ev.team.POR); mergeCounts_(por.tev.OPP, ev.team.OPP);
    por.top.POR += ev.top.POR; por.top.OPP += ev.top.OPP; por.top.nPOR += ev.possN.POR; por.top.nOPP += ev.possN.OPP; por.top.g++;
    g.top = [Math.round(ev.top.POR), Math.round(ev.top.OPP)];
  }
  return true;
}
function newLeague() { return { teams: {}, zones: {}, hist: [], ranks: {}, games: 0, players: {} }; }
const METRICS = [['ortg', 'Off rating', 1], ['drtg', 'Def rating', -1], ['net', 'Net rating', 1], ['pace', 'Pace', 1], ['efg', 'eFG%', 1], ['tovp', 'TOV%', -1], ['orbp', 'ORB%', 1], ['ftr', 'FT rate', 1], ['oefg', 'Opp eFG%', -1], ['ppg', 'Points', 1], ['oppg', 'Opp points', -1]];
function teamMetrics(T) {
  const g = T.g || 1, poss = T.poss || 1;
  return { ortg: r1(100 * T.pts / poss), drtg: r1(100 * T.opp / poss), net: r1(100 * (T.pts - T.opp) / poss), pace: r1(poss / g),
    efg: Math.round(1000 * (T.fgm + 0.5 * T.tpm) / (T.fga || 1)) / 10, tovp: Math.round(1000 * T.tov / poss) / 10, orbp: Math.round(1000 * T.oreb / ((T.oreb + T.odreb) || 1)) / 10,
    ftr: Math.round(1000 * T.ftm / (T.fga || 1)) / 10, oefg: Math.round(1000 * (T.ofgm + 0.5 * T.otpm) / (T.ofga || 1)) / 10, ppg: r1(T.pts / g), oppg: r1(T.opp / g) };
}
function recomputeLeague(L, day) {
  const ids = Object.keys(L.teams), m = {};
  ids.forEach(function (id) { m[id] = teamMetrics(L.teams[id]); });
  const ranks = {};
  METRICS.forEach(function (mt) {
    const k = mt[0], dir = mt[2];
    const sorted = ids.slice().sort(function (a, b) { return dir * (m[b][k] - m[a][k]); });
    sorted.forEach(function (id, i) { (ranks[id] = ranks[id] || {})[k] = i + 1; });
  });
  L.metrics = m; L.ranks = ranks;
  if (m[TEAM.id]) {
    const d = day.slice(0, 4) + '-' + day.slice(4, 6) + '-' + day.slice(6, 8);
    const row = { d: d, g: L.teams[TEAM.id].g, m: m[TEAM.id], r: ranks[TEAM.id] };
    if (L.hist.length && L.hist[L.hist.length - 1].d === d) L.hist[L.hist.length - 1] = row; else L.hist.push(row);
    L.hist.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
  }
}

/* ---------- live / game views and messages ---------- */
function teamLine(t) { return { id: t.id, abbr: t.abbr, name: t.name, logo: t.logo, home: t.home, score: t.score, s: t.stats }; }
function boxRows(list) { return (list || []).map(function (p) { return p.dnp ? { id: p.id, n: p.short || p.name, dnp: p.reason || 'DNP' } : { id: p.id, n: p.short || p.name, st: p.starter, min: p.min, pts: p.pts, reb: p.reb, ast: p.ast, stl: p.stl, blk: p.blk, tov: p.tov, fg: (p.fgm || 0) + '-' + (p.fga || 0), tp: (p.tpm || 0) + '-' + (p.tpa || 0), ft: (p.ftm || 0) + '-' + (p.fta || 0), pm: p.pm }; }); }
function gameRatings(p) {
  const me = p.teams.filter(function (t) { return t.id === TEAM.id; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.id; })[0];
  if (!me || !op) return null;
  const poss = (possOf(me.stats) + possOf(op.stats)) / 2;
  return poss ? { poss: r1(poss), ortg: r1(100 * me.score / poss), drtg: r1(100 * op.score / poss) } : null;
}
function liveView(p) {
  return { ok: true, id: p.id, status: p.status, teams: p.teams.map(teamLine), box: (function () { const o = {}; Object.keys(p.players).forEach(function (k) { o[k] = boxRows(p.players[k]); }); return o; })(),
    ratings: gameRatings(p), last: p.plays.slice(-8).reverse().map(function (x) { return { per: x.per, clk: x.clk, txt: x.txt, tid: x.tid }; }), at: Date.now() };
}
function gameView(p) {
  const v = liveView(p);
  v.shots = p.shots && p.shots.length ? p.shots.map(function (x) { return [x.x, x.y, x.made ? 1 : 0, x.three ? 1 : 0, x.tid === TEAM.id ? 1 : 0, x.pid]; })
    : p.plays.filter(function (x) { return x.shot; }).map(function (x) { return [x.x, x.y, x.made ? 1 : 0, x.three ? 1 : 0, x.tid === TEAM.id ? 1 : 0, x.pid]; });
  v.scoring = p.plays.filter(function (x) { return x.sc; }).map(function (x) { return [x.per, x.clk, x.hs, x.as]; });
  v.last = p.plays.filter(function (x) { return x.sc && x.sv >= 2; }).slice(-12).reverse().map(function (x) { return { per: x.per, clk: x.clk, txt: x.txt, tid: x.tid }; });
  v.venue = p.venue;
  // line score and game flow (Blazers margin over game time, in minutes)
  const me = p.teams.filter(function (t) { return t.id === TEAM.id; })[0];
  if (me) {
    const qs = [], flow = [[0, 0]]; let h = 0, a = 0, per = 1, q0 = [0, 0];
    p.plays.forEach(function (x) {
      if (x.per !== per && x.per > per) { qs.push([(me.home ? h : a) - q0[0], (me.home ? a : h) - q0[1]]); q0 = [me.home ? h : a, me.home ? a : h]; per = x.per; }
      if (x.hs != null && x.as != null && (x.hs !== h || x.as !== a) && x.hs >= h && x.as >= a) { h = x.hs; a = x.as; flow.push([r1(elapsedAt(x.per, x.sec) / 60), (me.home ? h - a : a - h)]); }
    });
    if (p.plays.length) qs.push([(me.home ? h : a) - q0[0], (me.home ? a : h) - q0[1]]);
    v.quarters = qs.length && qs.reduce(function (s, q) { return s + q[0]; }, 0) === me.score ? qs : null;
    if (!v.quarters && p.lineScore && p.lineScore.length === 2) { const a = p.lineScore[0], b = p.lineScore[1]; v.quarters = a.slice(0, -1).map(function (x, i) { return me.home ? [b[i], x] : [x, b[i]]; }); }
    v.flow = flow.length > 10 ? flow : null;
  }
  return v;
}
function vsLine(p) {
  const me = p.teams.filter(function (t) { return t.id === TEAM.id; })[0] || {}, op = p.teams.filter(function (t) { return t.id !== TEAM.id; })[0] || {};
  return { me: me, op: op, at: me.home ? 'vs' : '@' };
}
function startMessage(p) { const v = vsLine(p); return { title: 'Tip-off ' + TEAM.abbr + ' ' + v.at + ' ' + v.op.abbr, body: 'Blazers vs ' + v.op.name + ' is underway' + (p.venue ? ' at ' + p.venue : ''), url: './?g=' + p.id }; }
function finalMessage(p, por) {
  const v = vsLine(p), win = v.me.score > v.op.score;
  const pl = (p.players[TEAM.id] || []).filter(function (x) { return !x.dnp; }).sort(function (a, b) { return (b.pts || 0) - (a.pts || 0); }).slice(0, 2);
  const rec = por ? por.games.filter(function (g) { return g.win; }).length + '-' + por.games.filter(function (g) { return !g.win; }).length : '';
  return { title: (win ? 'Win ' : 'Loss ') + TEAM.abbr + ' ' + v.me.score + '-' + v.op.score + ' ' + v.op.abbr,
    body: pl.map(function (x) { return (x.short || x.name) + ' ' + x.pts + ' pts' + (x.reb >= 10 ? ' ' + x.reb + ' reb' : '') + (x.ast >= 8 ? ' ' + x.ast + ' ast' : ''); }).join(', ') + (rec ? ' (' + rec + ')' : ''), url: './?g=' + p.id };
}

/* ---------- roster ---------- */
function rosterChanges(old, cur) {
  const om = {}, cm = {}, out = [];
  old.forEach(function (p) { om[p.id] = p; }); cur.forEach(function (p) { cm[p.id] = p; });
  cur.forEach(function (p) { if (!om[p.id]) out.push({ title: 'Added', body: p.name + ' joined the roster' + (p.contract ? ' (' + money(p.contract.salary) + ')' : ''), url: './?p=' + p.id }); });
  old.forEach(function (p) { if (!cm[p.id]) out.push({ title: 'Left', body: p.name + ' is off the roster', url: './' }); });
  cur.forEach(function (p) {
    const o = om[p.id]; if (!o) return;
    const a = o.inj ? o.inj.status : '', b = p.inj ? p.inj.status : '';
    if (a !== b) out.push({ title: b ? 'Injury: ' + p.name : 'Back: ' + p.name, body: b ? b + (p.inj.detail ? ': ' + p.inj.detail : '') : 'Off the injury report', url: './?p=' + p.id });
    if (o.contract && p.contract && o.contract.salary !== p.contract.salary) out.push({ title: 'Contract: ' + p.name, body: 'Salary changed from ' + money(o.contract.salary) + ' to ' + money(p.contract.salary), url: './?p=' + p.id });
  });
  return out;
}
function money(v) { if (v == null) return '—'; return v >= 1e6 ? '$' + (Math.round(v / 1e5) / 10) + 'M' : '$' + Math.round(v / 1e3) + 'K'; }

/* ---------- Basketball-Reference tables ---------- */
function brTableRows(html, idRe, key) {
  html = String(html || '').replace(/<!--|-->/g, '');
  const out = [], tre = /<table\b[^>]*\bid="([^"]+)"[^>]*>([\s\S]*?)<\/table>/gi;
  let m;
  while ((m = tre.exec(html))) {
    if (!idRe.test(m[1])) continue;
    const rows = m[2].match(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi) || [];
    rows.forEach(function (r) {
      if (/class="[^"]*\bthead\b/.test(r)) return;
      const o = {}, cre = /<(td|th)\b[^>]*data-stat="([^"]+)"[^>]*>([\s\S]*?)<\/\1>/gi; let c;
      while ((c = cre.exec(r))) { if (o[c[2]] == null) o[c[2]] = stripTags(c[3]).replace(/\*$/, '').trim(); }
      if (key ? o[key] : (o.player || o.name_display)) out.push(o);
    });
  }
  return out;
}
const BR_TOTAL_KEYS = ['g', 'mp', 'fg', 'fga', 'fg3', 'fg3a', 'ft', 'fta', 'orb', 'trb', 'ast', 'stl', 'blk', 'tov', 'pf', 'pts'];
function brNumbers(r, name) {
  const o = { name: name, from: r.year_min || r.from || '', to: r.year_max || r.to || '' };
  BR_TOTAL_KEYS.forEach(function (k) { const v = r[k] != null ? r[k] : r[k === 'g' ? 'games' : k]; o[k] = NUM(v); });
  return o;
}
/* franchise history: one row per season from /teams/POR/ */
function brHistory(rows) {
  const pick = function (r, ks) { for (let i = 0; i < ks.length; i++) if (r[ks[i]] != null && r[ks[i]] !== '') return r[ks[i]]; return ''; };
  return rows.filter(function (r) { return /^\d{4}-\d{2}$/.test(r.season || ''); }).map(function (r) {
    return { s: r.season, w: NUM(pick(r, ['wins', 'w'])), l: NUM(pick(r, ['losses', 'l'])), fin: pick(r, ['rank_team', 'finish']), po: pick(r, ['rank_team_playoffs', 'playoffs']),
      coach: pick(r, ['coaches', 'coach']).replace(/\s*\(\d+-\d+\)/g, ''), top: pick(r, ['top_ws']), ortg: NUM(pick(r, ['off_rtg'])) || null, drtg: NUM(pick(r, ['def_rtg'])) || null, srs: pick(r, ['srs']) };
  }).sort(function (a, b) { return a.s < b.s ? 1 : -1; });
}
function brAdvanced(r) {
  const o = {};
  [['per', 'per'], ['ts', 'ts_pct'], ['usg', 'usg_pct'], ['ows', 'ows'], ['dws', 'dws'], ['ws', 'ws'], ['ws48', 'ws_per_48'], ['obpm', 'obpm'], ['dbpm', 'dbpm'], ['bpm', 'bpm'], ['vorp', 'vorp'], ['ast_pct', 'ast_pct'], ['trb_pct', 'trb_pct'], ['tov_pct', 'tov_pct'], ['mp', 'mp']]
    .forEach(function (k) { if (r[k[1]] != null && r[k[1]] !== '') o[k[0]] = NUM(r[k[1]]); });
  return o;
}

/* ---------- franchise leaderboards ---------- */
/* GAS reports fetch errors in the account's language; the app is English */
function errText(e) {
  const m = String(e && e.message || e || '');
  const map = [[/使用できないアドレス|Address unavailable/i, 'Address unavailable'], [/無効な引数|Invalid argument/i, 'Invalid argument'], [/タイムアウト|timed? ?out/i, 'Timed out'],
    [/使用回数|too many times|quota/i, 'Daily quota exceeded'], [/帯域幅|bandwidth/i, 'Bandwidth quota exceeded'], [/DNS/i, 'DNS error'], [/SSL/i, 'SSL error']];
  for (let i = 0; i < map.length; i++) if (map[i][0].test(m)) return map[i][1];
  return /[\u3040-\u30ff\u4e00-\u9fff]/.test(m) ? 'Fetch failed' : m;
}
function ordinal(n) { const v = n % 100; return n + ((v >= 11 && v <= 13) ? 'th' : (['th', 'st', 'nd', 'rd'][n % 10] || 'th')); }
const LEADER_CATS = [['pts', 'Points', 'pts', 1000], ['trb', 'Rebounds', 'reb', 500], ['ast', 'Assists', 'ast', 500], ['stl', 'Steals', 'stl', 100], ['blk', 'Blocks', 'blk', 100], ['fg3', '3-pointers', 'tpm', 100], ['g', 'Games', 'g', 100], ['mp', 'Minutes', 'min', 5000], ['ft', 'Free throws', 'ftm', 500], ['fg', 'Field goals', 'fgm', 500]];
function buildLeaders(br, por, roster) {
  const active = {};   // normName → { id, name, add: {...} }
  roster.forEach(function (p) { active[normName(p.name)] = { id: p.id, name: p.name, add: {} }; });
  // games Basketball-Reference has not counted yet: those after its season game count, in date order
  Object.keys(por.players || {}).forEach(function (pid) {
    const P = por.players[pid], k = normName(P.name), a = active[k]; if (!a) return;
    const s = br.season_ && br.season_[k], gBR = s ? s.g : 0;
    const played = P.logs.filter(function (l) { return !l.dnp; }).sort(function (x, y) { return x.d - y.d; }), extra = played.slice(gBR);
    LEADER_CATS.forEach(function (c) { a.add[c[0]] = extra.reduce(function (sum, l) { return sum + (c[2] === 'g' ? 1 : (l[c[2]] || 0)); }, 0); });
    a.extra = extra.length;
  });
  const cats = {}, act = {};
  LEADER_CATS.forEach(function (c) {
    const k = c[0];
    const list = Object.keys(br.totals).map(function (nk) {
      const t = br.totals[nk], a = active[nk];
      return { n: t.name, v: Math.round((t[k] || 0) + (a ? a.add[k] || 0 : 0)), a: a ? a.id : '', y: t.from + (t.to && t.to !== t.from ? '–' + t.to : '') };
    }).filter(function (e) { return e.v > 0; }).sort(function (x, y) { return y.v - x.v; });
    list.forEach(function (e, i) { e.r = i + 1; });
    const actives = list.filter(function (e) { return e.a; });
    cats[k] = { name: c[1], top: list.slice(0, 30), active: actives.map(function (e) { const above = e.r > 1 ? list[e.r - 2] : null; return { a: e.a, n: e.n, v: e.v, r: e.r, next: above ? { n: above.n, v: above.v, gap: above.v - e.v + 1 } : null, step: c[3] }; }) };
    actives.forEach(function (e) { (act[e.a] = act[e.a] || {})[k] = { r: e.r, v: e.v }; });
  });
  // players on the roster who have never played for Portland before are not in the table yet
  return { cats: cats, active: act, pending: Object.keys(active).filter(function (k) { return !br.totals[k]; }).map(function (k) { return active[k].name; }) };
}
function milestoneMessages(before, boards) {
  const out = [];
  Object.keys(boards.active).forEach(function (id) {
    Object.keys(boards.active[id]).forEach(function (k) {
      const now = boards.active[id][k], was = before && before[id] && before[id][k], cat = boards.cats[k], c = LEADER_CATS.filter(function (x) { return x[0] === k; })[0];
      if (!was) return;
      const e = cat.active.filter(function (x) { return x.a === id; })[0]; if (!e) return;
      if (now.r < was.r && now.r <= 50) {
        const passed = cat.top[now.r] ? cat.top[now.r].n : '';
        out.push({ title: 'Franchise record: ' + e.n, body: 'Now ' + ordinal(now.r) + ' all-time in ' + c[1].toLowerCase() + ' (' + now.v.toLocaleString() + (passed ? ', passing ' + passed : '') + ')', url: './?p=' + id });
      }
      const step = c[3];
      if (Math.floor(now.v / step) > Math.floor(was.v / step) && now.v >= step) out.push({ title: 'Milestone: ' + e.n, body: 'Reached ' + (Math.floor(now.v / step) * step).toLocaleString() + ' career ' + c[1].toLowerCase() + ' with Portland', url: './?p=' + id });
    });
  });
  return out.slice(0, 4);
}

/* ---------- market value ---------- */
function marketValue(ws, teamGames, p) {
  if (ws == null) return { ws: null, value: null };
  const pace = teamGames >= 5 ? ws * 82 / teamGames : ws * 82 / Math.max(5, teamGames);
  return { ws: ws, value: Math.round(Math.max(MIN_SALARY, pace * WIN_SHARE_VALUE) / 1e4) * 1e4 };
}

/* ---------- news ---------- */
function rosterNameRegex(roster) {
  const names = [];
  roster.forEach(function (p) { names.push(p.name); const last = String(p.name).split(' ').slice(-1)[0]; if (last.length >= 5) names.push(last); });
  return names.length ? new RegExp('\\b(' + names.map(function (n) { return n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')\\b', 'i') : null;
}
function newsItem(r, src, now, nameRe, roster) {
  let title = r.title, source = r.source || src.name;
  if (src.kind === 'gnews') { const m = String(title).match(/^(.*)\s+-\s+([^-]{2,60})$/); if (m) { title = m[1]; if (!r.source) source = m[2]; } }
  if (!title || !r.link) return null;
  const desc = src.kind === 'gnews' ? '' : String(r.desc || '').replace(/\s+/g, ' ').slice(0, 300);
  const text = title + ' ' + desc;
  if (!/blazers|portland|rip city|\bPOR\b/i.test(text) && !(nameRe && nameRe.test(text))) return null;
  let d = parseDate(r.date, now); if (d > now + 864e5) d = now;
  let cat = 'other';
  for (let i = 0; i < NEWS_CATS.length; i++) if (NEWS_CATS[i][1].test(title)) { cat = NEWS_CATS[i][0]; break; }
  const who = [];
  (roster || []).forEach(function (p) { const last = String(p.name).split(' ').slice(-1)[0]; if (new RegExp('\\b' + p.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i').test(text) || (last.length >= 5 && new RegExp('\\b' + last + '\\b', 'i').test(title))) who.push(p.id); });
  return { id: hashId(r.link || title), t: title, u: r.link, s: source, sid: src.id, d: d, x: desc.length > 280 ? desc.slice(0, 277) + '…' : desc, im: r.image || '', cat: cat, who: who.slice(0, 4) };
}

/* ---------- brief written by the Claude scheduled task ---------- */
function sanitizeBrief(b) {
  if (!b || typeof b !== 'object') return null;
  const clean = function (s, n) { return String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n); };
  const list = function (a) { return (Array.isArray(a) ? a : []).slice(0, 10).map(function (x) { return { text: clean(x && x.text, 400), url: /^https?:\/\//.test(String(x && x.url)) ? clean(x.url, 600) : '' }; }).filter(function (x) { return x.text; }); };
  const out = { at: Date.now(), headline: clean(b.headline, 160), points: list(b.points), players: list(b.players), watch: clean(b.watch, 600) };
  return out.points.length ? out : null;
}


/* ---------- team page: lineups, on/off, clutch, assist pairs, franchise history ---------- */
function rateOf(o) { const poss = o.poss || 0; return poss > 0 ? { min: r1(o.sec / 60), pf: o.pf, pa: o.pa, ortg: r1(100 * o.pf / poss), drtg: r1(100 * o.pa / poss), net: r1(100 * (o.pf - o.pa) / poss) } : { min: r1((o.sec || 0) / 60), pf: o.pf || 0, pa: o.pa || 0, ortg: null, drtg: null, net: null }; }
function teamPage(por, roster, br) {
  const nm = {}; Object.keys(por.players || {}).forEach(function (id) { nm[id] = por.players[id].name; });
  (roster || []).forEach(function (p) { nm[p.id] = p.name; });
  const short = function (id) { const n = nm[id] || id, a = String(n).split(' '); return a.length > 1 ? a[0][0] + '. ' + a.slice(1).join(' ') : n; };
  const onRoster = {}; (roster || []).forEach(function (p) { onRoster[p.id] = 1; });
  const lineups = Object.keys(por.lineups || {}).map(function (k) { const L = por.lineups[k]; return Object.assign({ ids: k.split(','), names: k.split(',').map(short), g: L.g }, rateOf(L)); })
    .filter(function (l) { return l.min >= 1; }).sort(function (a, b) { return b.min - a.min; }).slice(0, 40);
  const onoff = Object.keys(por.onoff || {}).map(function (id) { const O = por.onoff[id], on = rateOf(O.on), off = rateOf(O.off);
    return { id: id, n: nm[id] || id, g: O.g, onMin: on.min, on: on, off: off, diff: on.net != null && off.net != null ? r1(on.net - off.net) : null, cur: !!onRoster[id] }; })
    .filter(function (x) { return x.onMin >= 5; }).sort(function (a, b) { return b.onMin - a.onMin; });
  const C = por.clutch || { g: 0, w: 0, l: 0, sec: 0, pf: 0, pa: 0, poss: 0, players: {} };
  const clutch = Object.assign({ g: C.g, w: C.w, l: C.l }, rateOf(C), { players: Object.keys(C.players || {}).map(function (id) { const q = C.players[id];
    return { id: id, n: nm[id] || id, min: r1(q.sec / 60), pts: q.pts, fgm: q.fgm, fga: q.fga, tpm: q.tpm, tpa: q.tpa, ftm: q.ftm, fta: q.fta, ast: q.ast }; })
    .filter(function (x) { return x.min > 0 || x.pts > 0; }).sort(function (a, b) { return b.pts - a.pts || b.min - a.min; }) });
  const assists = Object.keys(por.assists || {}).map(function (k) { const a = k.split('>'); return { from: a[0], to: a[1], fromN: short(a[0]), toN: short(a[1]), n: por.assists[k] }; })
    .sort(function (a, b) { return b.n - a.n; }).slice(0, 40);
  const games = (por.games || []).slice().sort(function (a, b) { return a.d - b.d; }).map(function (g) { return { id: g.id, d: g.d, opp: g.opp, home: g.home, win: g.win, pf: g.pf, pa: g.pa, q: g.q || null, clutch: !!g.clutch }; });
  const tp = por.top || { POR: 0, OPP: 0, nPOR: 0, nOPP: 0, g: 0 };
  const events = Object.keys(por.ev || {}).map(function (id) { return { id: id, n: nm[id] || id, cur: !!onRoster[id], gp: ((por.players[id] || {}).logs || []).filter(function (l) { return !l.dnp; }).length, c: por.ev[id] }; });
  // single-game bests this season
  const HIGH = [['pts', 'Points'], ['reb', 'Rebounds'], ['ast', 'Assists'], ['stl', 'Steals'], ['blk', 'Blocks'], ['tpm', '3-pointers'], ['oreb', 'Offensive rebounds'], ['min', 'Minutes'], ['shot:dunk:m', 'Dunks'], ['and1', 'And-ones']];
  const highs = []; HIGH.forEach(function (h) {
    let best = null;
    Object.keys(por.players || {}).forEach(function (id) { (por.players[id].logs || []).forEach(function (l) { if (l.dnp) return; const v = h[0].indexOf(':') > 0 || h[0] === 'and1' ? ((l.ev || {})[h[0]] || 0) : (l[h[0]] || 0); if (v > 0 && (!best || v > best.v)) best = { stat: h[0], name: h[1], id: id, n: nm[id] || id, v: v, e: l.e, d: l.d, o: l.o, h: l.h }; }); });
    if (best) highs.push(best);
  });
  return { ok: true, lineups: lineups, onoff: onoff, clutch: clutch, assists: assists, games: games, pbpGames: (por.games || []).filter(function (g) { return g.pbp; }).length, highs: highs,
    events: events, teamEv: por.tev || null, possession: tp.g ? { g: tp.g, por: r1(tp.POR / tp.g / 60), opp: r1(tp.OPP / tp.g / 60), perPor: tp.nPOR ? r1(tp.POR / tp.nPOR) : null, perOpp: tp.nOPP ? r1(tp.OPP / tp.nOPP) : null } : null,
    history: (br && br.history) || [], historyAt: br ? br.at : 0 };
}

/* ---------- next opponent ---------- */
function previewOf(next, L, sched, opp) {
  if (!next || !next.opp || !next.opp.id) return null;
  const id = next.opp.id, T = (L.teams || {})[id], M = L.metrics && L.metrics[id], R = L.ranks && L.ranks[id], ok = opp && opp.id === id;
  const h2h = (sched.games || []).filter(function (g) { return g.opp && g.opp.id === id && g.state === 'post'; }).map(function (g) { return { id: g.id, t: g.t, home: g.home, win: g.win, pf: g.pf, pa: g.pa }; });
  const cmp = []; const MM = L.metrics && L.metrics[TEAM.id], RR = L.ranks && L.ranks[TEAM.id];
  if (M && MM) ['ortg', 'drtg', 'net', 'pace', 'efg', 'tovp', 'orbp', 'oefg'].forEach(function (k) { const mt = METRICS.filter(function (x) { return x[0] === k; })[0]; cmp.push({ k: k, name: mt[1], por: MM[k], porR: RR[k], opp: M[k], oppR: R[k] }); });
  return { id: id, abbr: next.opp.abbr, name: (T && T.name) || next.opp.name, logo: next.opp.logo, t: next.t, home: next.home, record: T ? { w: T.w, l: T.l } : null,
    last: ok ? opp.last || [] : [], leaders: ok ? (opp.leaders || []).slice(0, 4) : [], cmp: cmp, h2h: h2h, inj: ok ? opp.inj : null, teams: Object.keys(L.teams || {}).length };
}

/* ---------- app feed and player page ---------- */
function avgOf(logs) {
  const pl = logs.filter(function (l) { return !l.dnp; }), n = pl.length || 1, s = function (k) { return pl.reduce(function (a, l) { return a + (l[k] || 0); }, 0); };
  const fga = s('fga'), tpa = s('tpa'), fta = s('fta');
  return { gp: pl.length, min: r1(s('min') / n), pts: r1(s('pts') / n), reb: r1(s('reb') / n), ast: r1(s('ast') / n), stl: r1(s('stl') / n), blk: r1(s('blk') / n), tov: r1(s('tov') / n),
    fg: fga ? Math.round(1000 * s('fgm') / fga) / 10 : null, tp: tpa ? Math.round(1000 * s('tpm') / tpa) / 10 : null, ft: fta ? Math.round(1000 * s('ftm') / fta) / 10 : null,
    ts: (fga + 0.44 * fta) ? Math.round(1000 * s('pts') / (2 * (fga + 0.44 * fta))) / 10 : null, pm: r1(s('pm') / n), starts: pl.filter(function (l) { return l.st; }).length };
}
function zonesOf(shots, L) {
  const z = {};
  (shots || []).forEach(function (s) { const k = zoneOf(s[0], s[1], s[3] === 1), Z = z[k] = z[k] || [0, 0]; Z[1]++; if (s[2]) Z[0]++; });
  return ZONES.map(function (zz) { const k = zz[0], mine = z[k] || [0, 0], lg = (L.zones || {})[k] || [0, 0]; return { z: k, name: zz[1], m: mine[0], a: mine[1], pct: mine[1] ? Math.round(1000 * mine[0] / mine[1]) / 10 : null, lg: lg[1] ? Math.round(1000 * lg[0] / lg[1]) / 10 : null }; });
}
function feedView(now, sched, por, L, roster, leaders, standings, br, news, brief, vals, st, opp) {
  const games = sched.games || [], past = games.filter(function (g) { return g.state === 'post'; }), next = games.filter(function (g) { return g.state !== 'post'; })[0] || null;
  const lastG = past[past.length - 1] || null, lastStored = lastG ? por.games.filter(function (g) { return g.id === lastG.id; })[0] : null;
  const wins = past.filter(function (g) { return g.win; }).length, losses = past.filter(function (g) { return g.win === false; }).length;
  const conf = (standings.west || []).some(function (t) { return t.id === TEAM.id; }) ? 'west' : 'east', ci = (standings[conf] || []).map(function (t) { return t.id; }).indexOf(TEAM.id);
  const players = (roster.players || []).map(function (p) {
    const P = por.players[p.id], a = P ? avgOf(P.logs) : null, s = br && br.season_ ? br.season_[normName(p.name)] : null, h = (vals.players || {})[p.id] || [];
    return { id: p.id, name: p.name, short: p.short, jersey: p.jersey, pos: p.pos, head: p.head, age: p.age, inj: p.inj, salary: p.contract ? p.contract.salary : null, years: p.contract ? p.contract.years : null,
      avg: a, adv: s && s.adv ? { per: s.adv.per, ws: s.adv.ws, bpm: s.adv.bpm, ts: s.adv.ts } : null, value: h.length ? h[h.length - 1].v : null };
  }).sort(function (a, b) { return ((b.avg && b.avg.min) || 0) - ((a.avg && a.avg.min) || 0); });
  let lastBox = null;
  if (lastG && por.players) {
    lastBox = Object.keys(por.players).map(function (id) { const l = por.players[id].logs.filter(function (x) { return x.e === lastG.id && !x.dnp; })[0]; return l ? { id: id, n: por.players[id].name, pts: l.pts, reb: l.reb, ast: l.ast, min: l.min } : null; })
      .filter(Boolean).sort(function (a, b) { return b.pts - a.pts; }).slice(0, 5);
  }
  const ranks = {}; const M = L.metrics && L.metrics[TEAM.id], R = L.ranks && L.ranks[TEAM.id];
  METRICS.forEach(function (mt) { if (M) ranks[mt[0]] = { name: mt[1], v: M[mt[0]], r: R[mt[0]] }; });
  const league = Object.keys(L.metrics || {}).map(function (id) { return Object.assign({ id: id, abbr: L.teams[id].abbr, logo: L.teams[id].logo, g: L.teams[id].g }, L.metrics[id]); });
  const ms = [];
  if (leaders) Object.keys(leaders.cats).forEach(function (k) { leaders.cats[k].active.forEach(function (e) { if (e.next && e.r <= 60) ms.push({ a: e.a, n: e.n, cat: k, catName: leaders.cats[k].name, r: e.r, v: e.v, next: e.next }); }); });
  ms.sort(function (x, y) { return (x.next.gap / Math.max(1, x.v)) - (y.next.gap / Math.max(1, y.v)); });
  const statusList = Object.keys((st && st.status) || {}).map(function (k) { return Object.assign({ id: k }, st.status[k]); }).concat(Object.keys((st && st.newsStatus) || {}).map(function (k) { return Object.assign({ id: 'news:' + k }, st.newsStatus[k]); }));
  return { ok: true, updated: now, season: sched.season, coach: roster.coach || '', record: { w: wins, l: losses }, standing: ci >= 0 ? { conf: conf, seed: ci + 1 } : null,
    next: next, last: lastG ? Object.assign({}, lastG, { box: lastBox, ratings: lastStored ? { ortg: lastStored.ortg, drtg: lastStored.drtg } : null }) : null,
    live: st && st.live && st.live.state === 'in' ? st.live : null, schedule: games, roster: players, ranks: ranks, league: league, hist: L.hist || [],
    games: por.games.map(function (g) { return { id: g.id, d: g.d, opp: g.opp, home: g.home, pf: g.pf, pa: g.pa, win: g.win, ortg: g.ortg, drtg: g.drtg }; }),
    standings: standings, milestones: ms.slice(0, 12), leadersAt: leaders ? leaders.at : 0, pending: leaders ? leaders.pending : [],
    news: news, brief: brief, sources: statusList, leagueGames: L.games || 0, cap: SALARY_CAP, preview: previewOf(next, L, sched, opp) };
}
function playerPage(p, por, br, leaders, L, vals, news) {
  const P = por.players[p.id] || { logs: [] }, s = br && br.season_ ? br.season_[normName(p.name)] : null, t = br && br.totals ? br.totals[normName(p.name)] : null;
  const ranks = [];
  if (leaders) Object.keys(leaders.cats).forEach(function (k) { const e = leaders.cats[k].active.filter(function (x) { return x.a === p.id; })[0]; if (e) ranks.push({ cat: k, name: leaders.cats[k].name, r: e.r, v: e.v, next: e.next }); });
  const shots = (por.shots || {})[p.id] || [];
  const nameRe = new RegExp('\\b' + String(p.name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i');
  return { ok: true, p: p, avg: avgOf(P.logs), logs: P.logs.slice().sort(function (a, b) { return b.d - a.d; }), shots: shots.map(function (x) { return [x[0], x[1], x[2], x[3]]; }), zones: zonesOf(shots, L),
    adv: s && s.adv ? s.adv : null, franchise: t, ranks: ranks, values: vals, cap: SALARY_CAP, wsValue: WIN_SHARE_VALUE,
    ev: (por.ev || {})[p.id] || null,
    onoff: por.onoff && por.onoff[p.id] ? { on: rateOf(por.onoff[p.id].on), off: rateOf(por.onoff[p.id].off), g: por.onoff[p.id].g } : null,
    clutch: por.clutch && por.clutch.players && por.clutch.players[p.id] ? Object.assign({ min: r1(por.clutch.players[p.id].sec / 60) }, por.clutch.players[p.id]) : null,
    partners: (function () { const nm = function (id) { return por.players[id] ? por.players[id].name : id; }, to = [], from = [];
      Object.keys(por.assists || {}).forEach(function (k) { const a = k.split('>'); if (a[0] === p.id) to.push({ id: a[1], n: nm(a[1]), c: por.assists[k] }); if (a[1] === p.id) from.push({ id: a[0], n: nm(a[0]), c: por.assists[k] }); });
      const srt = function (x, y) { return y.c - x.c; }; return { to: to.sort(srt).slice(0, 5), from: from.sort(srt).slice(0, 5) }; })(),
    news: news.filter(function (n) { return (n.who || []).indexOf(p.id) >= 0 || nameRe.test(n.t + ' ' + (n.x || '')); }).slice(0, 40) };
}

/* ======================================================================
 * Basketball-Reference pages → PDXRadar data (pure functions, also run in the tests)
 * Pages: /teams/POR/<season>_games.html, /boxscores/<id>.html, /boxscores/pbp/<id>.html,
 *        /boxscores/shot-chart/<id>.html, /leagues/NBA_<season>.html, /teams/<T>/<season>.html, /contracts/POR.html
 * ====================================================================== */

/* every <tr> of the tables whose id matches: { stat: text, stat_h: first link, stat_c: csk, _cls: row class } */
function brRows(html, idRe) {
  html = String(html || '').replace(/<!--|-->/g, '');
  const out = [], tre = /<table\b[^>]*\bid="([^"]+)"[^>]*>([\s\S]*?)<\/table>/gi;
  let m;
  while ((m = tre.exec(html))) {
    if (!idRe.test(m[1])) continue;
    const body = m[2], rows = body.match(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi) || [];
    const footAt = body.search(/<tfoot\b/i);
    let pos = 0;
    rows.forEach(function (r) {
      const at = body.indexOf(r, pos); pos = at + r.length;
      const o = { _table: m[1], _cls: ((r.match(/^<tr\b[^>]*class="([^"]*)"/i) || [])[1] || ''), _foot: footAt >= 0 && at > footAt };
      const cre = /<(td|th)\b([^>]*)>([\s\S]*?)<\/\1>/gi; let c;
      while ((c = cre.exec(r))) {
        const ds = (c[2].match(/data-stat="([^"]+)"/) || [])[1]; if (!ds || o[ds] != null) continue;
        o[ds] = stripTags(c[3]).replace(/ /g, ' ').replace(/\*$/, '').trim();
        const h = (c[3].match(/href=["']([^"']+)["']/) || [])[1]; if (h) o[ds + '_h'] = h;   // the site uses both quote styles
        const k = (c[2].match(/\bcsk="([^"]*)"/) || [])[1]; if (k != null) o[ds + '_c'] = k;
        const ap = (c[2].match(/data-append-csv="([^"]+)"/) || [])[1]; if (ap) o[ds + '_id'] = ap;
      }
      out.push(o);
    });
  }
  return out;
}
const brPid = function (href) { const m = String(href || '').match(/\/players\/\w\/([a-z0-9.']+)\.html/i); return m ? m[1] : ''; };
const brTeamOf = function (href) { const m = String(href || '').match(/\/teams\/([A-Z]{3})\//); return m ? m[1] : ''; };
const brHead = function (pid) { return pid ? 'https://www.basketball-reference.com/req/202106291/images/headshots/' + pid + '.jpg' : ''; };
/* team logos from ESPN's image CDN (loaded by the browser) */
const ESPN_ABBR = { BRK: 'bkn', CHO: 'cha', GSW: 'gs', NOP: 'no', NYK: 'ny', PHO: 'phx', SAS: 'sa', UTA: 'utah', WAS: 'wsh' };
function teamLogo(abbr) { return 'https://a.espncdn.com/i/teamlogos/nba/500/' + (ESPN_ABBR[abbr] || String(abbr).toLowerCase()) + '.png'; }
function shortName(n) { const a = String(n || '').trim().split(/\s+/); return a.length > 1 ? a[0][0] + '. ' + a.slice(1).join(' ') : String(n || ''); }

/* ---------- schedule: /teams/POR/<season>_games.html ---------- */
function brSchedule(html, toMs) {
  return brRows(html, /^games(_playoffs)?$/).filter(function (r) { return r.date_game && !/thead/.test(r._cls); }).map(function (r) {
    const box = (r.box_score_text_h || '').match(/\/boxscores\/(\w+)\.html/), opp = brTeamOf(r.opp_name_h) || (r.opp_name_c || '').slice(0, 3);
    const day = (r.date_game_c || '').replace(/-/g, '') || '';
    const home = r.game_location !== '@';
    const id = box ? box[1] : (day + '0' + (home ? TEAM.id : opp));
    const done = !!r.game_result;
    return { id: id, t: toMs(r.date_game_c || r.date_game, r.game_start_time || ''), home: home, reg: r._table === 'games', po: r._table !== 'games',
      opp: { id: opp, abbr: opp, name: r.opp_name || opp, logo: teamLogo(opp) }, state: done ? 'post' : 'pre', completed: done, detail: done ? (r.game_result === 'W' ? 'W' : 'L') + (r.overtimes ? ' ' + r.overtimes : '') : '',
      pf: done ? NUM(r.pts) : null, pa: done ? NUM(r.opp_pts) : null, win: done ? r.game_result === 'W' : null, venue: '', tv: r.network || '' };
  }).sort(function (a, b) { return a.t - b.t; });
}

/* ---------- box score: /boxscores/<id>.html ---------- */
const BR_BOX = { mp: 'min', pts: 'pts', fg: 'fgm', fga: 'fga', fg3: 'tpm', fg3a: 'tpa', ft: 'ftm', fta: 'fta', orb: 'oreb', drb: 'dreb', trb: 'reb', ast: 'ast', stl: 'stl', blk: 'blk', tov: 'tov', pf: 'pf', plus_minus: 'pm' };
function brBox(html, id) {
  const home = id.slice(-3), tables = {}, order = [];
  brRows(html, /^box-[A-Z]{3}-game-basic$/).forEach(function (r) { const t = r._table.split('-')[1]; if (!tables[t]) { tables[t] = []; order.push(t); } tables[t].push(r); });
  if (order.length !== 2) return null;
  const names = (String(html).match(/<strong>\s*<a[^>]*href=["']\/teams\/[A-Z]{3}\/\d{4}\.html["'][^>]*>([^<]+)<\/a>/g) || []).map(function (s) { return stripTags(s).trim(); });
  const scores = (String(html).match(/<div class="score">\s*(\d+)\s*<\/div>/g) || []).map(function (s) { return NUM(stripTags(s)); });
  const meta = String(html).match(/<div class="scorebox_meta">\s*<div>([^<]+)<\/div>\s*<div>([^<]+)<\/div>/);
  const players = {}, teams = [];
  order.forEach(function (abbr, i) {
    let starter = true; const list = [], tot = {};
    tables[abbr].forEach(function (r) {
      if (/thead/.test(r._cls) || r.player === 'Reserves') { starter = false; return; }
      if (r._foot || /Team Totals/i.test(r.player || '')) { Object.keys(BR_BOX).forEach(function (k) { if (r[k] != null) tot[BR_BOX[k]] = NUM(r[k]); }); return; }
      const pid = r.player_id || brPid(r.player_h);
      if (!r.player || !pid) return;   // header rows (Starters) have no player link
      const o = { id: pid, name: r.player, short: shortName(r.player), jersey: '', pos: '', head: brHead(pid), starter: starter, dnp: !!r.reason || !r.mp, reason: r.reason || '' };
      if (!o.dnp) Object.keys(BR_BOX).forEach(function (k) { if (r[k] == null) return; o[BR_BOX[k]] = k === 'mp' ? (r.mp_c ? Math.round(NUM(r.mp_c) / 60) : NUM(String(r.mp).split(':')[0])) : NUM(r[k]); });
      list.push(o);
    });
    players[abbr] = list;
    teams.push({ id: abbr, abbr: abbr, name: names[i] || abbr, logo: teamLogo(abbr), home: abbr === home, score: scores[i] != null ? scores[i] : (tot.pts || 0),
      stats: { fgm: tot.fgm || 0, fga: tot.fga || 0, tpm: tot.tpm || 0, tpa: tot.tpa || 0, ftm: tot.ftm || 0, fta: tot.fta || 0, oreb: tot.oreb || 0, dreb: tot.dreb || 0, reb: tot.reb || 0, ast: tot.ast || 0, stl: tot.stl || 0, blk: tot.blk || 0, tov: tot.tov || 0, pf: tot.pf || 0, paint: 0, fast: 0 } });
  });
  const ls = brRows(html, /^line_score$/).filter(function (r) { return r.team || r.T; });
  const date = id.slice(0, 4) + '-' + id.slice(4, 6) + '-' + id.slice(6, 8);
  return { id: id, date: Date.parse(date + 'T23:00:00Z'), status: { state: 'post', completed: true, detail: 'Final', period: 4, clock: '0.0' }, teams: teams, players: players, plays: [], shots: [],
    venue: meta ? meta[2].split(',')[0].trim() : '', lineScore: ls.length === 2 ? ls.map(function (r) { return Object.keys(r).filter(function (k) { return /^\d$|^OT\d?$/i.test(k); }).map(function (k) { return NUM(r[k]); }); }) : null };
}

/* ---------- play-by-play: /boxscores/pbp/<id>.html ----------
 * 6 cells per play: time | away action | away +pts | score "away-home" | home +pts | home action */
function brPbp(html, p) {
  const away = p.teams.filter(function (t) { return !t.home; })[0], home = p.teams.filter(function (t) { return t.home; })[0];
  const tb = (String(html).match(/<table\b[^>]*id="pbp"[^>]*>([\s\S]*?)<\/table>/i) || [])[1] || '';
  const rows = tb.match(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi) || [];
  const plays = []; let per = 0, hs = 0, as = 0;
  rows.forEach(function (r) {
    const qid = r.match(/<tr\b[^>]*id="q(\d+)"/); if (qid) { per = +qid[1]; return; }
    const cells = []; const cre = /<(td|th)\b([^>]*)>([\s\S]*?)<\/\1>/gi; let c;
    while ((c = cre.exec(r))) cells.push({ a: c[2], h: c[3] });
    if (cells.length < 2 || !/^\d+:\d+(\.\d)?$/.test(stripTags(cells[0].h).trim())) return;
    const clk = stripTags(cells[0].h).trim();
    let act = '', tid = '';
    if (cells.length >= 6) {
      const sc = stripTags(cells[3].h).match(/(\d+)\s*-\s*(\d+)/); if (sc) { as = +sc[1]; hs = +sc[2]; }
      if (stripTags(cells[1].h).replace(/ /g, '').trim()) { act = cells[1].h; tid = away.id; } else { act = cells[5].h; tid = home.id; }
    } else { act = cells[1].h; tid = ''; }
    if (!per) per = 1;
    const txt = decodeEntities(stripTags(act)).replace(/ /g, ' ').replace(/\s+/g, ' ').trim(); if (!txt) return;
    const pids = (act.match(/\/players\/\w\/[a-z0-9.']+\.html/gi) || []).map(brPid);
    const shotM = txt.match(/\b(makes|misses) (2|3)-pt ([a-z -]+?)(?: from (\d+) ft| at rim|$|\s*\()/i), ftM = /free throw/i.test(txt) && /\b(makes|misses)\b/i.test(txt);
    const made = /\bmakes\b/i.test(txt);
    plays.push({ per: per, clk: clk, sec: clockSec(clk), tid: tid, txt: txt, typ: shotM ? shotM[3].trim().toLowerCase() : '', sc: made, sv: made ? (ftM ? 1 : shotM ? +shotM[2] : 0) : 0, hs: hs, as: as,
      pid: pids[0] || '', pids: pids, shot: false, fga: !!shotM, fta: !!ftM, three: !!(shotM && shotM[2] === '3'), made: made, dist: shotM && shotM[4] != null ? +shotM[4] : (shotM && / at rim/i.test(txt) ? 0 : null), x: null, y: null });
  });
  return plays;
}

/* ---------- shot chart: /boxscores/shot-chart/<id>.html → feet on our half court (hoop at 25, 4.75) ---------- */
function brShots(html, p) {
  const out = [], names = {};
  Object.keys(p.players).forEach(function (t) { p.players[t].forEach(function (x) { names[normName(x.name)] = { id: x.id, t: t }; }); });
  const areas = String(html).split(/<div[^>]*id="shots-([A-Z]{3})"[^>]*>/);
  for (let i = 1; i < areas.length; i += 2) {
    const team = areas[i], re = /<div\b((?:[^>"]|"[^"]*")*)>/gi; let m; const raw = [];
    while ((m = re.exec(areas[i + 1]))) {
      const a = m[1]; if (!/class="[^"]*tooltip/.test(a)) continue;
      const st = (a.match(/style="([^"]*)"/) || [])[1] || '', top = NUM((st.match(/top:\s*(-?[\d.]+)px/) || [])[1]), left = NUM((st.match(/left:\s*(-?[\d.]+)px/) || [])[1]);
      const tip = decodeEntities(String((a.match(/tip="([^"]*)"/) || [])[1] || '')).replace(/<br\s*\/?>/gi, '|');
      const cls = (a.match(/class="([^"]*)"/) || [])[1] || '', pidC = (cls.match(/\bp-([a-z0-9.']+)/) || [])[1] || '';
      const who = (tip.split('|')[1] || '').match(/^(.+?) (made|missed) (2|3)-pointer(?: from (\d+) ft)?/);
      const pl = pidC ? { id: pidC } : who ? names[normName(who[1])] : null;
      raw.push({ top: top, left: left, made: /\bmake\b/.test(cls) || (who && who[2] === 'made'), three: who ? who[3] === '3' : false, dist: who && who[4] != null ? +who[4] : null, pid: pl ? pl.id : '', per: (tip.match(/^(\d)/) || [])[1] ? +tip[0] : 0 });
    }
    // calibrate the hoop from shots taken at 0–1 ft, so the drawing matches whatever image size the page uses
    const near = raw.filter(function (s) { return s.dist != null && s.dist <= 1; });
    const hx = near.length ? near.reduce(function (s, x) { return s + x.left; }, 0) / near.length : 245, hy = near.length ? near.reduce(function (s, x) { return s + x.top; }, 0) / near.length : 45;
    raw.forEach(function (s) {
      const x = 25 + (s.left - hx) / 10, y = 4.75 + (s.top - hy) / 10;
      if (x < -2 || x > 52 || y < -2 || y > 47) return;
      out.push({ tid: team, pid: s.pid, x: Math.max(0, Math.min(50, Math.round(x * 10) / 10)), y: Math.max(0, Math.round(y * 10) / 10), made: !!s.made, three: s.three, dist: s.dist });
    });
  }
  return out;
}

/* ---------- league: /leagues/NBA_<season>.html → ratings for every team, standings, league shooting ---------- */
function brLeague(html) {
  const teams = {}, metrics = {};
  // tables are found by what they contain, not by id (Basketball-Reference renames ids now and then)
  const all = brRows(html, /./), tm = function (r) { return brTeamOf(r.team_h || r.team_name_h || r.name_display_h); };
  const adv = all.filter(function (r) { return r.off_rtg != null && r.def_rtg != null && tm(r); });
  const pg = all.filter(function (r) { return r.pts != null && tm(r) && /per_game/i.test(r._table) && !/opp/i.test(r._table); });
  const opg = all.filter(function (r) { return (r.opp_pts != null || r.pts != null) && tm(r) && /per_game/i.test(r._table) && /opp/i.test(r._table); });
  const ppg = {}, oppg = {};
  pg.forEach(function (r) { const t = tm(r); if (t && ppg[t] == null) ppg[t] = NUM(r.pts); });
  opg.forEach(function (r) { const t = tm(r); if (t && oppg[t] == null) oppg[t] = NUM(r.opp_pts || r.pts); });
  adv.forEach(function (r) {
    const t = tm(r); if (!t || metrics[t]) return;
    const pct = function (v) { const n = NUM(v); return n < 1.5 ? Math.round(n * 1000) / 10 : n; };
    teams[t] = { abbr: t, name: (r.team || r.team_name || r.name_display || t).replace(/\*$/, ''), logo: teamLogo(t), w: NUM(r.wins), l: NUM(r.losses), g: NUM(r.wins) + NUM(r.losses) };
    metrics[t] = { ortg: NUM(r.off_rtg), drtg: NUM(r.def_rtg), net: r.net_rtg != null && r.net_rtg !== '' ? NUM(r.net_rtg) : r1(NUM(r.off_rtg) - NUM(r.def_rtg)), pace: NUM(r.pace),
      efg: pct(r.efg_pct), tovp: NUM(r.tov_pct), orbp: NUM(r.orb_pct), ftr: pct(r.ft_rate), oefg: pct(r.opp_efg_pct), ppg: ppg[t] || r1(NUM(r.off_rtg) * NUM(r.pace) / 100) || null, oppg: oppg[t] || r1(NUM(r.def_rtg) * NUM(r.pace) / 100) || null, srs: NUM(r.srs), mov: NUM(r.mov) };
  });
  const stand = { west: [], east: [] };
  [['E', 'east'], ['W', 'west']].forEach(function (c) {
    stand[c[1]] = all.filter(function (r) { return new RegExp('^confs?_standings_' + c[0] + '$', 'i').test(r._table) && tm(r); }).map(function (r) {
      const t = tm(r); return { id: t, abbr: t, name: (r.team_name || '').replace(/\s*\(\d+\)\s*$/, '').replace(/\*$/, ''), logo: teamLogo(t), w: NUM(r.wins), l: NUM(r.losses), pct: r.win_loss_pct || '', gb: r.gb || '', streak: '' };
    }).sort(function (a, b) { return (b.w / Math.max(1, b.w + b.l)) - (a.w / Math.max(1, a.w + a.l)); });
    stand[c[1]].forEach(function (t, i) { t.seed = i + 1; });
  });
  // league shooting by distance → our zones (approximate: BR splits by distance, not by court area)
  const sh = all.filter(function (r) { return /shoot/i.test(r._table) && !/opp/i.test(r._table) && /league average/i.test(r.team || r.team_name || r.name_display || ''); })[0];
  let zones = null;
  if (sh) {
    const g = function (re) { const k = Object.keys(sh).filter(function (x) { return re.test(x) && /pct/.test(x); })[0]; const v = k ? NUM(sh[k]) : 0; return v ? (v < 1.5 ? v * 100 : v) : null; };
    const ra = g(/00_03|0_3/), pa = g(/03_10|3_10/), m1 = g(/10_16/), m2 = g(/16_xx|16_3/), c3 = g(/corner/), t3 = g(/fg3_pct(?!_corner)|^fg3a?_pct$/);
    const mid = m1 && m2 ? (m1 + m2) / 2 : (m1 || m2);
    const z = function (v) { return v ? [Math.round(v * 10), 1000] : null; };
    zones = { RA: z(ra), PAINT: z(pa), MID_L: z(mid), MID_C: z(mid), MID_R: z(mid), C3_L: z(c3 || t3), C3_R: z(c3 || t3), AB3_L: z(t3), AB3_C: z(t3), AB3_R: z(t3) };
    Object.keys(zones).forEach(function (k) { if (!zones[k]) delete zones[k]; });
  }
  return { teams: teams, metrics: metrics, standings: stand, zones: zones };
}
const LEAGUE_ZONE_DEFAULT = { RA: [660, 1000], PAINT: [440, 1000], MID_L: [420, 1000], MID_C: [420, 1000], MID_R: [420, 1000], C3_L: [385, 1000], C3_R: [385, 1000], AB3_L: [355, 1000], AB3_C: [355, 1000], AB3_R: [355, 1000] };
function rankLeague(metrics) {
  const ids = Object.keys(metrics), ranks = {};
  METRICS.forEach(function (mt) {
    const k = mt[0], dir = mt[2];
    ids.filter(function (id) { return metrics[id][k] != null; }).sort(function (a, b) { return dir * (metrics[b][k] - metrics[a][k]); }).forEach(function (id, i) { (ranks[id] = ranks[id] || {})[k] = i + 1; });
  });
  return ranks;
}

/* ---------- team page: /teams/<T>/<season>.html → roster, injuries, salaries, per-game leaders, coach ---------- */
function brTeamPage(html, season) {
  const roster = brRows(html, /^roster$/).filter(function (r) { return r.player; }).map(function (r) {
    const pid = r.player_id || brPid(r.player_h), b = r.birth_date_c || '';
    let age = null; if (/^\d{8}$/.test(b)) { const by = +b.slice(0, 4), bm = +b.slice(4, 6), bd = +b.slice(6, 8), now = new Date(); age = now.getFullYear() - by - ((now.getMonth() + 1 < bm || (now.getMonth() + 1 === bm && now.getDate() < bd)) ? 1 : 0); }
    return { id: pid, name: r.player.replace(/\s*\(TW\)\s*$/, ''), short: shortName(r.player.replace(/\s*\(TW\)\s*$/, '')), jersey: r.number || '', pos: r.pos || '', age: age, ht: r.height || '', wt: r.weight ? r.weight + ' lb' : '',
      exp: r.years_experience === 'R' ? 0 : (r.years_experience !== '' && r.years_experience != null ? NUM(r.years_experience) : null), head: brHead(pid), birth: r.birth_country ? String(r.birth_country).toUpperCase() : '', college: r.college || '',
      twoWay: /\(TW\)/.test(r.player), inj: null, contract: null, contracts: [] };
  });
  const byId = {}; roster.forEach(function (p) { byId[p.id] = p; });
  brRows(html, /^injuries$/).forEach(function (r) {
    const pid = r.player_id || brPid(r.player_h), p = byId[pid]; if (!p) return;
    const note = r.note || r.injury || '', st = (note.match(/^(Out For Season|Out|Day To Day|Day-To-Day|Questionable|Doubtful|Probable)/i) || [])[1] || 'Out';
    p.inj = { status: st.replace(/To/g, 'to').replace(/^day to day$/i, 'Day-to-day'), detail: note.replace(/^[^(]*\(([^)]+)\).*$/, '$1') !== note ? note.replace(/^[^(]*\(([^)]+)\).*$/, '$1') : note.slice(0, 120), ret: '', note: note.slice(0, 300), at: r.date_update || '' };
  });
  brRows(html, /^salaries2$/).forEach(function (r) { const pid = r.player_id || brPid(r.player_h), p = byId[pid]; if (p && r.salary) p.contract = { salary: NUM(String(r.salary).replace(/[$,]/g, '')), years: null, option: 0, trade: null }; });
  const perGame = brRows(html, /^per_game(_stats)?$/).filter(function (r) { return (r.player || r.name_display) && !r._foot; }).map(function (r) {
    const n = r.player || r.name_display, pid = r.player_id || r.name_display_id || brPid(r.player_h || r.name_display_h);
    return { id: pid, n: n, gp: NUM(r.g || r.games), min: NUM(r.mp_per_g), pts: NUM(r.pts_per_g), reb: NUM(r.trb_per_g), ast: NUM(r.ast_per_g) };
  });
  const coach = (String(html).match(/<strong>\s*Coach:\s*<\/strong>\s*<a[^>]*>([^<]+)<\/a>/i) || [])[1] || '';
  return { roster: roster, perGame: perGame, coach: coach };
}
/* ---------- contracts: /contracts/POR.html ---------- */
function brContracts(html, season) {
  const out = {};
  brRows(html, /./).forEach(function (r) {
    const pid = r.player_id || brPid(r.player_h) || r.name_display_id || brPid(r.name_display_h) || (/^[a-z]+\d\d$/.test(r.player_c || '') ? r.player_c : ''); if (!pid || out[pid] || !Object.keys(r).some(function (k) { return /^y\d$/.test(k); })) return;
    const yrs = []; for (let i = 1; i <= 6; i++) { const v = r['y' + i]; if (v) yrs.push({ y: season + i - 1, s: NUM(String(v).replace(/[$,]/g, '')) }); }
    out[pid] = { contracts: yrs.filter(function (y) { return y.s > 0; }), guaranteed: NUM(String(r.remain_gtd || '').replace(/[$,]/g, '')) || null };
  });
  return out;
}
/* ---------- a team's results, for the opponent preview ---------- */
function brLastResults(sched, n) { return sched.filter(function (g) { return g.state === 'post'; }).slice(-(n || 5)).map(function (g) { return { id: g.id, d: g.t, o: g.opp.abbr, h: g.home, w: g.win, pf: g.pf, pa: g.pa }; }); }

/* ======================================================================
 * Every event in the play-by-play, counted per player — the part Basketball-Reference does not total up:
 * shot types (dunks, layups, hooks, tip-ins), and-ones, putbacks, assisted makes, who blocked whom,
 * turnovers and fouls by type, fouls and charges drawn, violations (kicked ball, goaltending, lane …),
 * jump balls, technicals, ejections, plus an estimate of each team's time of possession.
 * ====================================================================== */
function evAdd_(o, k, n) { o[k] = (o[k] || 0) + (n == null ? 1 : n); }
function pbpEvents(p) {
  const me = p.teams.filter(function (t) { return t.id === TEAM.id; })[0], op = p.teams.filter(function (t) { return t.id !== TEAM.id; })[0];
  if (!me || !op || p.plays.length < 60) return null;
  const mine = {}; (p.players[TEAM.id] || []).forEach(function (x) { mine[x.id] = 1; });
  const pl = {}, team = { POR: {}, OPP: {} }, side = function (tid) { return tid === TEAM.id ? 'POR' : tid ? 'OPP' : ''; };
  const P = function (id) { return pl[id] = pl[id] || {}; };
  const add = function (id, k, n) { if (mine[id]) evAdd_(P(id), k, n); };
  const plays = p.plays;
  let lastMake = null, lastOreb = null;
  // possession clock: who has the ball between events (estimate)
  let poss = '', possT = 0; const top = { POR: 0, OPP: 0 }, cnt = { POR: 0, OPP: 0 };
  const tOf = function (e) { return elapsedAt(e.per, e.sec); };
  const give = function (s, t) { if (t > possT && (poss || s)) top[poss || s] += t - possT; if (s && s !== poss) cnt[s]++; poss = s; possT = t; };   // dead time at a quarter start goes to whoever gets the ball
  plays.forEach(function (e, i) {
    const t = tOf(e), x = e.txt, a = e.pids[0], b = e.pids[1], S = side(e.tid), T = S ? team[S] : null;
    if (e.fga) {
      if (S && poss !== S) give(S, t);
      const kind = /dunk/i.test(e.typ) ? 'dunk' : /layup|finger roll/i.test(e.typ) ? 'layup' : /hook/i.test(e.typ) ? 'hook' : /tip|putback/i.test(e.typ) ? 'tip' : /jump|fadeaway|pullup|step back|floating/i.test(e.typ) ? 'jumper' : 'other';
      add(a, 'shot:' + kind + ':a'); if (e.made) add(a, 'shot:' + kind + ':m');
      if (T) { evAdd_(T, 'shot:' + kind + ':a'); if (e.made) evAdd_(T, 'shot:' + kind + ':m'); }
      if (e.dist != null) { const bk = e.three ? '3pt' : e.dist <= 3 ? '0-3' : e.dist <= 9 ? '4-9' : e.dist <= 16 ? '10-16' : '17+'; add(a, 'dist:' + bk + ':a'); if (e.made) add(a, 'dist:' + bk + ':m'); }
      if (e.made) {
        if (/\(assist by /i.test(x) || /assists?\)/i.test(x)) { add(a, 'astd'); add(b, 'ast'); if (T) evAdd_(T, 'astd'); } else { add(a, 'unast'); if (T) evAdd_(T, 'unast'); }
        if (lastOreb && lastOreb.id === a && t - lastOreb.t <= 3) { add(a, 'putback'); if (T) evAdd_(T, 'putback'); }
        lastMake = { id: a, t: t, tid: e.tid };
        give(S === 'POR' ? 'OPP' : 'POR', t);
      }
      const bm = x.match(/\(block by /i); if (bm && b) { add(b, 'blk'); add(a, 'blkd'); const oT = team[S === 'POR' ? 'OPP' : 'POR']; evAdd_(oT, 'blk'); }
    } else if (e.fta) {
      const tech = /technical|flagrant|clear path/i.test(x) ? ':tech' : '';
      add(a, 'ft' + tech + ':a'); if (e.made) add(a, 'ft' + tech + ':m');
      const last = /(\d) of (\d)/.exec(x); if (e.made && last && last[1] === last[2] && !tech) give(S === 'POR' ? 'OPP' : 'POR', t);
    } else if (/^(Offensive|Defensive) rebound by/i.test(x)) {
      const off = /^Offensive/i.test(x);
      if (a) add(a, off ? 'reb:off' : 'reb:def'); else if (T) evAdd_(T, off ? 'reb:team-off' : 'reb:team-def');
      if (T) evAdd_(T, off ? 'reb:off' : 'reb:def');
      if (off) lastOreb = { id: a, t: t }; else { give(S, t); lastOreb = null; }
    } else if (/^Turnover by/i.test(x)) {
      const ty = ((x.match(/^Turnover by [^(]*\(([^;)]+)/i) || [])[1] || 'other').trim().toLowerCase();
      if (a) add(a, 'tov:' + ty); if (T) evAdd_(T, 'tov:' + ty);
      const st = x.match(/steal by /i); if (st && b) { add(b, 'stl'); evAdd_(team[S === 'POR' ? 'OPP' : 'POR'], 'stl'); }
      give(S === 'POR' ? 'OPP' : 'POR', t);
    } else if (/foul by/i.test(x)) {
      const ty = (x.match(/^(.*?)\s*foul by/i) || [])[1].trim().toLowerCase() || 'personal';
      if (a) add(a, 'foul:' + ty); if (T) evAdd_(T, 'foul:' + ty);
      if (/\(drawn by /i.test(x) && b) { add(b, 'drawn'); if (/charge/i.test(ty)) add(b, 'charge'); if (/shooting/i.test(ty) && lastMake && lastMake.id === b && t - lastMake.t <= 1) { add(b, 'and1'); evAdd_(team[S === 'POR' ? 'OPP' : 'POR'], 'and1'); } }
      if (/technical/i.test(ty) && a) add(a, 'tech');
      if (/flagrant/i.test(ty) && a) add(a, 'flagrant');
    } else if (/^Violation by/i.test(x)) {
      const ty = ((x.match(/\(([^)]+)\)/) || [])[1] || 'other').trim().toLowerCase();
      if (a) add(a, 'viol:' + ty); if (T) evAdd_(T, 'viol:' + ty);
    } else if (/^Jump ball:/i.test(x)) {
      e.pids.slice(0, 2).forEach(function (id) { add(id, 'jump'); });
      const g = x.match(/\(([^)]+) gains possession\)/i); if (g && e.pids[2]) { const gs = mine[e.pids[2]] ? 'POR' : 'OPP'; give(gs, t); }
    } else if (/ejected/i.test(x)) { add(a, 'ejected'); }
    else if (/timeout/i.test(x)) { const s2 = /portland|trail blazers/i.test(x) ? 'POR' : 'OPP'; evAdd_(team[s2], 'timeout'); }
    else if (/^End of/i.test(x)) { give('', t); }
  });
  give('', tOf(plays[plays.length - 1]));
  return { players: pl, team: team, top: top, possN: cnt };
}
function mergeCounts_(into, from) { Object.keys(from || {}).forEach(function (k) { into[k] = (into[k] || 0) + from[k]; }); return into; }

/* league table from the league page; one row of Blazers history per day */
function leagueFromBr(old, lg, day) {
  const L = { teams: lg.teams, metrics: lg.metrics, ranks: rankLeague(lg.metrics), zones: lg.zones || (old && old.zones && Object.keys(old.zones).length ? old.zones : LEAGUE_ZONE_DEFAULT),
    zonesFrom: lg.zones ? 'league' : 'default', hist: (old && old.hist) || [], games: Object.keys(lg.teams).reduce(function (s, k) { return s + lg.teams[k].g; }, 0) / 2, players: (old && old.players) || {} };
  const m = L.metrics[TEAM.id];
  if (m && L.teams[TEAM.id].g > 0) {
    const d = day.slice(0, 4) + '-' + day.slice(4, 6) + '-' + day.slice(6, 8), row = { d: d, g: L.teams[TEAM.id].g, m: m, r: L.ranks[TEAM.id] };
    const last = L.hist[L.hist.length - 1];
    if (last && last.g === row.g) L.hist[L.hist.length - 1] = Object.assign(row, { d: last.d }); else L.hist.push(row);
  }
  return L;
}

/* ======================================================================
 * Shared with BMERadar: feed parsing, storage, in-app reader, Web Push (VAPID / P-256)
 * ====================================================================== */
function decodeEntities(s) {
  return String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#x([0-9a-f]+);/gi, function (m, h) { return String.fromCharCode(parseInt(h, 16)); })
    .replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); })
    .replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}
function stripTags(s) { return decodeEntities(String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }
function tagText(block, names) {
  for (let i = 0; i < names.length; i++) {
    const m = block.match(new RegExp('<' + names[i] + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + names[i] + '>', 'i'));
    if (m) return m[1];
  }
  return '';
}
function attr(block, tag, name, where) {
  const re = new RegExp('<' + tag + '\\b([^>]*)>', 'gi'); let m;
  while ((m = re.exec(block))) {
    if (where && !where.test(m[1])) continue;
    const a = m[1].match(new RegExp(name + '\\s*=\\s*"([^"]*)"', 'i')) || m[1].match(new RegExp(name + "\\s*=\\s*'([^']*)'", 'i'));
    if (a) return decodeEntities(a[1]);
  }
  return '';
}
function parseFeed(xml) {
  xml = String(xml || '');
  const atom = /<feed[\s>]/i.test(xml) && !/<rss[\s>]/i.test(xml);
  const blocks = xml.match(atom ? /<entry[\s>][\s\S]*?<\/entry>/gi : /<item[\s>][\s\S]*?<\/item>/gi) || [];
  return blocks.map(function (b) {
    let link = '';
    if (atom) link = attr(b, 'link', 'href', /rel\s*=\s*["']alternate["']/i) || attr(b, 'link', 'href');
    else link = stripTags(tagText(b, ['link'])) || attr(b, 'item', 'rdf:about') || stripTags(tagText(b, ['guid']));
    const descRaw = tagText(b, ['description', 'summary', 'content:encoded', 'content']);
    const fullRaw = [tagText(b, ['content:encoded']), tagText(b, ['content']), descRaw].sort(function (x, y) { return y.length - x.length; })[0] || '';
    const img = attr(b, 'media:content', 'url') || attr(b, 'media:thumbnail', 'url') || attr(b, 'enclosure', 'url', /type\s*=\s*["']image/i) ||
      ((decodeEntities(descRaw).match(/<img[^>]+src\s*=\s*["']([^"']+)["']/i) || [])[1] || '');
    return {
      title: stripTags(tagText(b, ['title', 'dc:title'])),
      link: link.trim(),
      guid: stripTags(tagText(b, ['guid', 'id'])),
      date: stripTags(tagText(b, ['pubDate', 'published', 'dc:date', 'updated', 'prism:publicationDate'])),
      desc: stripTags(descRaw),
      source: stripTags(tagText(b, ['source', 'prism:publicationName'])),
      image: /^https?:/.test(img) ? img : '',
      full: fullRaw.length > 800 ? decodeEntities(fullRaw).slice(0, 80000) : ''
    };
  }).filter(function (r) { return r.title && r.link; });
}
function parseDate(s, fallback) {
  s = String(s || '').trim();
  if (!s) return fallback;
  if (/^\d{8}$/.test(s)) return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8), 12);
  let t = Date.parse(s);
  if (isFinite(t)) return t;
  let m = s.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] - 9 : 3, m[5] ? +m[5] : 0);
  m = s.match(/^([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})(?:,? (\d{1,2}):(\d{2})\s*([ap]m)?)?/i);
  if (m) {
    const mon = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(m[1].toLowerCase()) / 3;
    let h = m[4] ? +m[4] : 12; if (m[6] && /pm/i.test(m[6]) && h < 12) h += 12; if (m[6] && /am/i.test(m[6]) && h === 12) h = 0;
    if (mon >= 0) return Date.UTC(+m[3], mon, +m[2], h + 5, m[5] ? +m[5] : 0);   // US Eastern
  }
  return fallback;
}
function normTitle(t) { return String(t || '').toLowerCase().replace(/\s+[-–|]\s+[^-–|]+$/, '').replace(/[^\w぀-ヿ一-鿿]+/g, '').slice(0, 90); }
function hashId(s) { let h = 5381; s = String(s); for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
const STOP = ('the a an of for and to in on with by from at as is are be its new study shows show finds find using use used via into after over how why what could may can will first more than that this their these new about says said report reports device devices medical patients patient system wins win gets gains launches launch receives announces announced begins adds helps help team researchers scientists year years people data results human next-generation initiative company firm based near could would one two now just').split(' ');
const STOP_JA = ('開発 研究 発表 大学 技術 医療 患者 実証 活用 取得 成功 可能 世界 初 日本 国内 企業 研究所 研究グループ チーム 年度 令和 について お知らせ').split(' ');
function titleTokens(t) {
  const out = {};
  String(t || '').toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).forEach(function (w) { w = w.replace(/^-+|-+$/g, ''); if (w.length >= 3 && STOP.indexOf(w) < 0) out[w] = 1; });
  const ja = String(t || '').match(/[゠-ヿ]{3,}|[一-鿿]{2,}/g) || [];
  ja.forEach(function (w) { if (STOP_JA.indexOf(w) < 0) out[w] = 1; });
  return Object.keys(out);
}
function jaccard(a, b) {
  if (!a.length || !b.length) return 0;
  const set = {}; a.forEach(function (x) { set[x] = 1; });
  let inter = 0; b.forEach(function (x) { if (set[x]) inter++; });
  return inter / (a.length + b.length - inter);
}
function checkPass_(p) {
  const want = PropertiesService.getScriptProperties().getProperty('PASS');
  return !!want && typeof p === 'string' && p === want;
}
function dataFolder_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const f = DriveApp.createFolder(DATA_FOLDER);
  props.setProperty('FOLDER_ID', f.getId());
  return f;
}
function findFile_(folder, name) { const it = folder.getFilesByName(name); return it.hasNext() ? it.next() : null; }
function readJson_(name, fallback) {
  const f = findFile_(dataFolder_(), name);
  if (!f) return fallback;
  try { return JSON.parse(f.getBlob().getDataAsString()); } catch (e) { return fallback; }
}
function writeJson_(name, obj) {
  const folder = dataFolder_(), body = JSON.stringify(obj), f = findFile_(folder, name);
  if (f) f.setContent(body); else folder.createFile(name, body, MimeType.PLAIN_TEXT);
}
function cachePut_(key, str) {
  const c = CacheService.getScriptCache(), size = 90000, parts = {}, n = Math.ceil(str.length / size);
  if (n > 9) return;  // too large for the cache; served from Drive instead
  for (let i = 0; i < n; i++) parts[key + '_' + i] = str.slice(i * size, (i + 1) * size);
  parts[key + '_n'] = String(n);
  try { c.putAll(parts, 21600); } catch (e) {}
}
function cacheGet_(key) {
  const c = CacheService.getScriptCache(), n = +(c.get(key + '_n') || 0);
  if (!n) return null;
  const keys = []; for (let i = 0; i < n; i++) keys.push(key + '_' + i);
  const got = c.getAll(keys); let s = '';
  for (let i = 0; i < n; i++) { if (got[keys[i]] == null) return null; s += got[keys[i]]; }
  return s;
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';
function decodeHtml_(res) {
  const blob = res.getBlob(), head = blob.getDataAsString('ISO-8859-1').slice(0, 3000);
  const ct = String((res.getHeaders() || {})['Content-Type'] || (res.getHeaders() || {})['content-type'] || '');
  const cs = ((ct.match(/charset=([\w-]+)/i) || head.match(/<meta[^>]+charset=["']?([\w-]+)/i) || [])[1] || 'UTF-8').toUpperCase();
  try { return blob.getDataAsString(/SHIFT|SJIS/.test(cs) ? 'Shift_JIS' : /EUC/.test(cs) ? 'EUC-JP' : 'UTF-8'); } catch (e) { return res.getContentText(); }
}
function resolveGn_(url, it) {
  let err = '';
  try { const u = resolveGoogleNews_(url); if (u) return { url: u }; err = 'Google が応答しませんでした'; } catch (e) { err = String(e.message || e).slice(0, 60); }
  try { const u = bingFind_(it); if (u) return { url: u, via: 'bing' }; } catch (e) {}
  return { url: '', err: err };
}
function bingFind_(it) {
  if (!it || !it.t) return '';
  const ja = it.l === 'ja', q = '"' + it.t.slice(0, 120) + '"';
  const r = UrlFetchApp.fetch('https://www.bing.com/news/search?format=rss&q=' + encodeURIComponent(q) + (ja ? '&setlang=ja&cc=JP' : '&setlang=en-US&cc=US'), { muteHttpExceptions: true, headers: { 'User-Agent': UA } });
  if (r.getResponseCode() !== 200) return '';
  return bingPick(parseFeed(r.getContentText()), it.t, it.s);
}
function resolveGoogleNews_(url) {
  const id = (url.match(/articles\/([A-Za-z0-9_-]+)/) || [])[1];
  if (!id) return null;
  const local = decodeGnLocal(id);
  if (local) return local;
  // a recorded consent choice keeps Google from redirecting to consent.google.com
  const hdr = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36', Cookie: 'CONSENT=YES+cb.20240101-00-p0.en+FX+000; SOCS=CAESEwgDEgk0ODE3Nzk3MjQaAmVuIAEaBgiA_LyaBg' };
  const loc = (String(url).match(/[?&](hl=[^&]+&gl=[^&]+&ceid=[^&]+)/) || [])[1] || 'hl=en-US&gl=US&ceid=US:en';
  let page = '', sg, ts;
  ['https://news.google.com/rss/articles/' + id + '?' + loc, 'https://news.google.com/articles/' + id + '?' + loc].some(function (u) {
    const res = UrlFetchApp.fetch(u, { muteHttpExceptions: true, followRedirects: true, headers: hdr });
    if (res.getResponseCode() === 429) throw new Error('Google の回数制限');
    page = res.getContentText();
    const p = gnParams(page); sg = p.sg; ts = p.ts;
    return sg && ts;
  });
  if (!sg || !ts) { if (/consent\.google|before you continue|続行する前に/i.test(page)) throw new Error('Google の同意画面'); return null; }
  const r = UrlFetchApp.fetch('https://news.google.com/_/DotsSplashUi/data/batchexecute?rpcids=Fbv4je', { method: 'post', muteHttpExceptions: true,
    contentType: 'application/x-www-form-urlencoded;charset=UTF-8', payload: 'f.req=' + encodeURIComponent(gnBatchPayload(id, ts, sg)), headers: hdr });
  if (r.getResponseCode() === 429) throw new Error('Google の回数制限');
  return parseGnBatch(r.getContentText());
}
function metaContent(html, key) {
  const re = new RegExp('<meta[^>]+(?:property|name|itemprop)\\s*=\\s*["\']' + key.replace(/[:.]/g, '\\$&') + '["\'][^>]*>', 'i');
  const tag = (html.match(re) || [])[0];
  if (!tag) return '';
  return decodeEntities((tag.match(/content\s*=\s*"([^"]*)"/i) || tag.match(/content\s*=\s*'([^']*)'/i) || [])[1] || '').trim();
}
function absUrl(u, base) {
  u = decodeEntities(String(u || '').trim());
  if (!u || /^data:/i.test(u)) return '';
  if (/^https?:\/\//i.test(u)) return u;
  const m = String(base).match(/^(https?:\/\/[^\/]+)(\/[^?#]*)?/i); if (!m) return '';
  if (/^\/\//.test(u)) return 'https:' + u;
  if (/^\//.test(u)) return m[1] + u;
  return m[1] + (m[2] || '/').replace(/[^\/]*$/, '') + u;
}
const BOILER = /^(advertisement|sponsored|subscribe|sign up|sign in|log in|read more|related:|share this|copyright|all rights reserved|©|photo:|image:|credit:|getty images|this article (was|is)|click here|newsletter|cookie|we use cookies|follow us|もっと見る|関連記事|広告|この記事をシェア|会員登録|ログイン)/i;
function jsonLdBody(html) {
  const blocks = html.match(/<script[^>]+application\/ld\+json[^>]*>[\s\S]*?<\/script>/gi) || [];
  for (let i = 0; i < blocks.length; i++) {
    const txt = blocks[i].replace(/^<script[^>]*>/i, '').replace(/<\/script>$/i, '').trim();
    let j = null;
    // some sites put raw line breaks inside JSON strings; try a few repairs
    [txt, txt.replace(/\r?\n/g, '\\n').replace(/\t/g, ' '), txt.replace(/[\u0000-\u001f]+/g, ' ')].some(function (t) { try { j = JSON.parse(t); return true; } catch (e) { return false; } });
    if (!j) continue;
    try {
      const list = [].concat(j['@graph'] || j);
      for (let k = 0; k < list.length; k++) if (list[k] && typeof list[k].articleBody === 'string' && list[k].articleBody.length > 300) return list[k];
    } catch (e) {}
  }
  return null;
}
function extractArticle(html, url) {
  html = String(html || '');
  const title = metaContent(html, 'og:title') || stripTags(tagText(html, ['title'])) || '';
  const site = metaContent(html, 'og:site_name');
  const desc = metaContent(html, 'og:description') || metaContent(html, 'description');
  const image = absUrl(metaContent(html, 'og:image') || metaContent(html, 'twitter:image'), url);
  const date = metaContent(html, 'article:published_time') || metaContent(html, 'datePublished') || metaContent(html, 'citation_publication_date') || '';
  const paras = [];
  const ld = jsonLdBody(html);
  if (ld) {
    String(ld.articleBody).split(/\n\s*\n|\r?\n/).map(function (x) { return decodeEntities(x).replace(/\s+/g, ' ').trim(); }).filter(function (x) { return x.length > 1; }).forEach(function (x) { paras.push({ t: 'p', x: x }); });
  }
  if (!paras.length) {
    let body = html.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style|noscript|svg|nav|header|footer|aside|form|button|iframe|select)\b[\s\S]*?<\/\1>/gi, ' ');
    // arXiv abstract
    const abs = body.match(/<blockquote[^>]*class="[^"]*abstract[^"]*"[^>]*>([\s\S]*?)<\/blockquote>/i);
    if (abs) paras.push({ t: 'p', x: stripTags(abs[1]).replace(/^Abstract:\s*/i, '') });
    // pick the densest container: <article>, then main/role=main, then common content classes, else the body
    const cands = [];
    (body.match(/<article\b[\s\S]*?<\/article>/gi) || []).forEach(function (b) { cands.push(b); });
    const mm = body.match(/<main\b[\s\S]*?<\/main>/i); if (mm) cands.push(mm[0]);
    const re = /<(div|section)\b[^>]*(?:class|id)\s*=\s*["'][^"']*(article[-_]?body|entry[-_]content|post[-_]content|story[-_]body|article[-_]content|main[-_]content|content[-_]body|news[-_]body|articleBody|rich[-_]text|body[-_]text|text[-_]body)[^"']*["'][^>]*>/gi;
    let m; while ((m = re.exec(body))) cands.push(body.slice(m.index, m.index + 200000));
    cands.push(body);
    let best = null, bestLen = 0;
    cands.forEach(function (c) {
      const ps = collectParas(c, url);
      const len = ps.reduce(function (s, p) { return s + (p.t === 'p' ? p.x.length : 0); }, 0);
      if (len > bestLen * 1.6 || (!best && len)) { best = ps; bestLen = len; }   // earlier candidates are more specific
    });
    if (best && !abs) best.forEach(function (p) { paras.push(p); });
  }
  // de-duplicate repeated paragraphs and drop the title if repeated
  const seen = {}, out = [];
  paras.forEach(function (p) { const k = p.t + (p.x || p.src); if (seen[k] || (p.t !== 'img' && normTitle(p.x) === normTitle(title))) return; seen[k] = 1; out.push(p); });
  const text = out.filter(function (p) { return p.t === 'p'; }).map(function (p) { return p.x; }).join(' ');
  return { title: title, site: site, desc: desc, image: image, date: date, paras: out.slice(0, 120), chars: text.length };
}
function collectParas(block, url) {
  const out = [];
  let m, imgs = 0;
  const tagRe = /<(p|h2|h3|li|blockquote)\b[^>]*>([\s\S]*?)<\/\1>|<img\b([^>]*)>/gi;
  while ((m = tagRe.exec(block))) {
    if (m[3] != null) {
      if (imgs >= 6) continue;
      const a = m[3], src = (a.match(/\s(?:data-src|data-lazy-src|data-original|src)\s*=\s*["']([^"']+)["']/i) || [])[1];
      const w = +((a.match(/\swidth\s*=\s*["']?(\d+)/i) || [])[1] || 0);
      const u = absUrl(src, url);
      if (!u || /\.svg(\?|$)|logo|icon|avatar|sprite|pixel|tracking|1x1|blank\.gif/i.test(u) || (w && w < 240)) continue;
      out.push({ t: 'img', src: u, alt: decodeEntities((a.match(/\salt\s*=\s*["']([^"']*)["']/i) || [])[1] || '').slice(0, 200) }); imgs++;
      continue;
    }
    const tag = m[1].toLowerCase(), x = stripTags(m[2]);
    if (!x || BOILER.test(x)) continue;
    if (tag === 'h2' || tag === 'h3') { if (x.length < 120) out.push({ t: 'h', x: x }); continue; }
    if (tag === 'li' && x.length < 60) continue;
    if (x.length < 40 && !/[。！？」]$/.test(x)) continue;
    out.push({ t: 'p', x: x });
  }
  // drop a trailing run of headings / images without text
  while (out.length && out[out.length - 1].t !== 'p') out.pop();
  return out;
}
function gnParams(html) {
  const h = String(html || '').replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<!--[\s\S]*?-->/gi, '');
  const tags = h.match(/<[a-z][^>]*data-n-a-sg=[^>]*>/gi) || [];
  for (let i = 0; i < tags.length; i++) {
    const sg = (tags[i].match(/data-n-a-sg="([^"]+)"/) || [])[1], ts = (tags[i].match(/data-n-a-ts="([^"]+)"/) || [])[1];
    if (sg && ts) return { sg: sg, ts: ts };
  }
  return {};
}
function bingPick(items, title, source) {
  const tok = titleTokens(title);
  let best = '', bs = 0;
  items.forEach(function (r) {
    const m = String(r.link).match(/[?&]url=([^&]+)/), u = m ? decodeURIComponent(m[1]) : r.link;
    if (!/^https?:\/\//.test(u) || /bing\.com|msn\.com\/[a-z-]+\/news\/other/.test(u)) return;
    let sc = jaccard(tok, titleTokens(r.title.replace(/\s+[-|–]\s+[^-|–]+$/, '')));
    if (source && r.source && r.source.toLowerCase().indexOf(String(source).toLowerCase().slice(0, 6)) >= 0) sc += 0.15;
    if (sc > bs) { bs = sc; best = u; }
  });
  return bs >= 0.6 ? best : '';
}
function gnBatchPayload(id, ts, sg) {
  const inner = '["garturlreq",[["X","X",["X","X"],null,null,1,1,"US:en",null,1,null,null,null,null,null,0,1],"X","X",1,[1,1,1],1,1,null,0,0,null,0],"' + id + '",' + ts + ',"' + sg + '"]';
  return JSON.stringify([[['Fbv4je', inner, null, 'generic']]]);
}
function parseGnBatch(text) {
  try {
    const parts = String(text).split('\n\n');
    const arr = JSON.parse(parts[1] || parts[0].replace(/^\)\]\}'\s*/, ''));
    for (let i = 0; i < arr.length; i++) if (arr[i][0] === 'wrb.fr' && arr[i][2]) { const u = JSON.parse(arr[i][2])[1]; if (/^https?:\/\//.test(u)) return u; }
  } catch (e) {}
  const m = String(text).match(/https?:\\\\?\/\\\\?\/[^"\\]+/);
  return m ? m[0].replace(/\\\\?\//g, '/').replace(/\\/g, '') : null;
}
function decodeGnLocal(id) {
  try {
    let b = id.replace(/-/g, '+').replace(/_/g, '/'); while (b.length % 4) b += '=';
    const bytes = Utilities.base64Decode(b), str = bytes.map(function (x) { return String.fromCharCode(x & 255); }).join('');
    if (str.indexOf('AU_yqL') >= 0) return null;
    const m = str.match(/https?:\/\/[\x21-\x7e]+/);
    return m ? m[0].replace(/[\x00-\x1f\xd2\x01].*$/, '') : null;
  } catch (e) { return null; }
}
function jinaToArticle(text, url) {
  text = String(text || '');
  const title = ((text.match(/^Title:\s*(.+)$/m) || [])[1] || '').trim();
  const md = text.indexOf('Markdown Content:') >= 0 ? text.slice(text.indexOf('Markdown Content:') + 17) : text;
  const paras = [];
  let imgs = 0;
  md.split(/\n\s*\n/).forEach(function (blk) {
    blk = blk.trim(); if (!blk) return;
    const im = blk.match(/^!\[([^\]]*)\]\((https?:[^)\s]+)/);
    if (im) { if (imgs < 6 && !/logo|icon|avatar|sprite|pixel|\.svg/i.test(im[2])) { paras.push({ t: 'img', src: im[2], alt: im[1].slice(0, 200) }); imgs++; } return; }
    let x = blk.replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/[*_`]{1,3}/g, '').replace(/^>\s?/gm, '').replace(/\s+/g, ' ').trim();
    const h = blk.match(/^#{1,4}\s+(.+)/);
    if (h) { x = x.replace(/^#+\s*/, ''); if (x.length < 120 && x.length > 1 && normTitle(x) !== normTitle(title)) paras.push({ t: 'h', x: x }); return; }
    if (/^[-*+]\s|^\d+\.\s/.test(blk) && x.length < 80) return;            // navigation lists
    if (/^(=+|-+)$/.test(x) || BOILER.test(x)) return;
    if (x.length < 40 && !/[。！？」]$/.test(x)) return;
    if ((blk.match(/\]\(/g) || []).length > 3 && x.length < 200) return;     // link clouds
    paras.push({ t: 'p', x: x });
  });
  while (paras.length && paras[paras.length - 1].t !== 'p') paras.pop();
  return { title: title, site: '', desc: '', image: '', date: '', paras: paras.slice(0, 120), chars: paras.reduce(function (s, p) { return s + (p.t === 'p' ? p.x.length : 0); }, 0) };
}
function buildReaderResult(it, url, art, err) {
  const out = { ok: true, id: it.id, url: url || it.u, src: it.s, ty: it.ty, d: it.d, title: it.t, tj: it.tj || '', image: '', paras: [], partial: true, err: err || '' };
  if (art) {
    out.image = art.image || '';
    if (art.title && art.title.length > 8 && !/^(home|news|top)$/i.test(art.title)) out.title = art.title.replace(/\s+[|\-–—]\s+[^|\-–—]{2,40}$/, '');
    if (art.site) out.src = art.site;
    if (art.doi) out.doi = art.doi;
    if (art.desc && art.paras.length < 2) out.paras.push({ t: 'p', x: art.desc });
    out.paras = out.paras.concat(art.paras);
    out.partial = art.chars < 600;
    if (art.desc && art.paras.length >= 2 && it.ty === 'paper') out.lead = art.desc;
  }
  if (!out.paras.length && it.x) out.paras.push({ t: 'p', x: it.x });
  if (out.image && out.paras.some(function (p) { return p.t === 'img' && p.src === out.image; })) out.image = '';
  return out;
}
function vapid_() {
  const props = PropertiesService.getScriptProperties();
  let d = props.getProperty('VAPID_D'), pub = props.getProperty('VAPID_PUB');
  if (!d || !pub) {
    const seed = [Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid(), Date.now()].join('');
    const dd = P256.mod(P256.bytesToBig(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, seed)), P256.n - BI1) + BI1;
    const Q = P256.affine(P256.mul(dd, P256.G));
    d = dd.toString(16); pub = P256.b64u([4].concat(P256.bigTo32(Q[0]), P256.bigTo32(Q[1])));
    props.setProperty('VAPID_D', d); props.setProperty('VAPID_PUB', pub);
  }
  return { d: BigInt('0x' + d), pub: pub };
}
function vapidJwt_(aud) {
  const cache = CacheService.getScriptCache(), ck = 'jwt_' + hashId(aud);
  const hit = cache.get(ck); if (hit) return hit;
  const v = vapid_(), enc = function (o) { return Utilities.base64EncodeWebSafe(JSON.stringify(o)).replace(/=+$/, ''); };
  let sub = 'mailto:bme-radar@example.com';
  try { const em = Session.getEffectiveUser().getEmail(); if (em) sub = 'mailto:' + em; } catch (e) {}
  const input = enc({ typ: 'JWT', alg: 'ES256' }) + '.' + enc({ aud: aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: sub });
  const jwt = input + '.' + P256.signB64u(input, v.d);
  cache.put(ck, jwt, 6 * 3600);
  return jwt;
}
function sendPush_(s) {
  const aud = s.endpoint.match(/^https:\/\/[^\/]+/)[0];
  const r = UrlFetchApp.fetch(s.endpoint, { method: 'post', muteHttpExceptions: true, contentType: 'application/octet-stream', payload: '',
    headers: { TTL: '43200', Urgency: 'high', Authorization: 'vapid t=' + vapidJwt_(aud) + ', k=' + vapid_().pub } });
  const code = r.getResponseCode();
  return { ok: code >= 200 && code < 300, code: code, gone: code === 404 || code === 410, body: code >= 300 ? String(r.getContentText() || '').replace(/\s+/g, ' ').slice(0, 160) : '' };
}
const BI0 = BigInt(0);
const BI1 = BigInt(1);
const BI2 = BigInt(2);
const BI3 = BigInt(3);
const BI4 = BigInt(4);
const BI8 = BigInt(8);
const P256 = (function () {
  const p = BigInt('0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff');
  const n = BigInt('0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551');
  const G = [BigInt('0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296'), BigInt('0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5'), BI1];
  const mod = function (a, m) { const r = a % m; return r >= BI0 ? r : r + m; };
  const inv = function (a, m) { let lm = BI1, hm = BI0, low = mod(a, m), high = m; while (low > BI1) { const r = high / low; const nm = hm - lm * r, nw = high - low * r; hm = lm; lm = nm; high = low; low = nw; } return mod(lm, m); };
  const dbl = function (P) {
    if (!P || P[1] === BI0) return null;
    const X = P[0], Y = P[1], Z = P[2], YY = Y * Y % p, S = BI4 * X * YY % p, ZZ = Z * Z % p, M = BI3 * mod(X - ZZ, p) * (X + ZZ) % p;
    const X3 = mod(M * M - BI2 * S, p); return [X3, mod(M * (S - X3) - BI8 * YY * YY, p), BI2 * Y * Z % p];
  };
  const add = function (P, Q) {
    if (!P) return Q; if (!Q) return P;
    const Z1Z1 = P[2] * P[2] % p, Z2Z2 = Q[2] * Q[2] % p, U1 = P[0] * Z2Z2 % p, U2 = Q[0] * Z1Z1 % p;
    const S1 = P[1] * Q[2] % p * Z2Z2 % p, S2 = Q[1] * P[2] % p * Z1Z1 % p;
    if (U1 === U2) return S1 === S2 ? dbl(P) : null;
    const H = mod(U2 - U1, p), R = mod(S2 - S1, p), HH = H * H % p, HHH = H * HH % p, V = U1 * HH % p;
    const X3 = mod(R * R - HHH - BI2 * V, p); return [X3, mod(R * (V - X3) - S1 * HHH, p), H * P[2] % p * Q[2] % p];
  };
  const mul = function (k, P) { let R = null, Q = P; while (k > BI0) { if (k & BI1) R = add(R, Q); Q = dbl(Q); k >>= BI1; } return R; };
  const affine = function (P) { const zi = inv(P[2], p), zi2 = zi * zi % p; return [P[0] * zi2 % p, P[1] * zi2 % p * zi % p]; };
  const bytesToBig = function (b) { let h = ''; for (let i = 0; i < b.length; i++) h += ((b[i] & 255) + 256).toString(16).slice(1); return BigInt('0x' + (h || '0')); };
  const bigTo32 = function (x) { const h = x.toString(16).padStart(64, '0'), out = []; for (let i = 0; i < 64; i += 2) out.push(parseInt(h.substr(i, 2), 16)); return out; };
  const b64u = function (bytes) { return Utilities.base64EncodeWebSafe(bytes.map(function (x) { return x > 127 ? x - 256 : x; })).replace(/=+$/, ''); };
  const sha = function (str) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, str, Utilities.Charset.UTF_8); };
  const signB64u = function (msg, d) {
    const e = bytesToBig(sha(msg));
    for (let tries = 0; tries < 8; tries++) {
      const k = mod(bytesToBig(sha(Utilities.getUuid() + Utilities.getUuid() + msg + d.toString(16) + tries)), n - BI1) + BI1;
      const R = affine(mul(k, G)), r = mod(R[0], n); if (r === BI0) continue;
      const s = mod(inv(k, n) * (e + r * d), n); if (s === BI0) continue;
      return b64u(bigTo32(r).concat(bigTo32(s)));
    }
    throw new Error('sign failed');
  };
  return { p: p, n: n, G: G, mod: mod, mul: mul, affine: affine, bytesToBig: bytesToBig, bigTo32: bigTo32, b64u: b64u, signB64u: signB64u };
})();

