'use strict';
/* PDXRadar — reader for the feed built by gas/pdx/Code.gs */
const TEAM_ID='POR',TEAM_ABBR='POR';
const ESPN='https://site.api.espn.com/apis/site/v2/sports/basketball/nba';
const LS={cfg:'pdx-cfg-v1',feed:'pdx-feed-v1',read:'pdx-read-v1'};
const app=document.getElementById('app');
const st={view:'today',sub:null,feed:null,loading:false,err:'',msg:{},busy:'',cat:'pts',newsCat:'all',shotMode:'shots',teamMetric:'net',teamSub:'overview',luSort:'min',recMode:'franchise',sCat:'pts',live:null,liveAt:0,cache:{},pushSt:null,briefKey:''};
const H=36e5,WD=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function lsGet(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch(e){return d;}}
function lsSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function cfg(){const c=lsGet(LS.cfg,{});return{url:c.url||(window.PDX_CONFIG&&window.PDX_CONFIG.gasUrl)||'',pass:c.pass||'',push:c.push||null};}
function setCfg(k,v){const c=lsGet(LS.cfg,{});c[k]=v;lsSet(LS.cfg,c);}
const pad=n=>String(n).padStart(2,'0');
const ord=n=>{n=+n;const v=n%100;return n+((v>=11&&v<=13)?'th':['th','st','nd','rd'][n%10]||'th');};
const fmtD=ms=>{const d=new Date(ms);return `${d.getMonth()+1}/${d.getDate()}`;};
const fmtDW=ms=>{const d=new Date(ms);return `${WD[d.getDay()]} ${d.getMonth()+1}/${d.getDate()}`;};
const fmtT=ms=>{const d=new Date(ms);return `${pad(d.getHours())}:${pad(d.getMinutes())}`;};
const fmtWhen=ms=>ms?`${fmtD(ms)} ${fmtT(ms)}`:'—';
function ago(ms){const m=Math.round((Date.now()-ms)/60000);if(m<1)return'just now';if(m<60)return m+'m ago';const h=Math.round(m/60);if(h<24)return h+'h ago';return fmtD(ms);}
const money=v=>v==null?'—':v>=1e6?'$'+(Math.round(v/1e5)/10).toFixed(1)+'M':'$'+Math.round(v/1e3)+'K';
const pct=v=>v==null?'—':(+v).toFixed(1);
const num=v=>v==null?'—':(+v).toLocaleString();
const ICON={gear:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',refresh:'<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',back:'<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',ext:'<svg viewBox="0 0 24 24"><path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>'};

/* ---------- network ---------- */
function gasGet(params){const c=cfg();const u=new URL(c.url);Object.entries(params||{}).forEach(([k,v])=>{if(v!==''&&v!=null)u.searchParams.set(k,v);});u.searchParams.set('t',Date.now());
  return fetch(u.toString()).then(r=>r.json()).then(j=>{if(j.ok===false)throw new Error(j.error||'Could not load');return j;});}
async function post(body){const c=cfg();if(!c.url)throw new Error('GAS URL is not set');if(!c.pass)throw new Error('Passphrase is not set');
  let r;try{r=await fetch(c.url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(Object.assign({pass:c.pass},body))});}catch(e){throw new Error('Cannot reach GAS');}
  const j=await r.json();if(!j.ok)throw new Error(j.error==='auth'?'Wrong passphrase':j.error==='busy'?'An update is running. Try again in a moment':j.error||'Failed');return j;}
async function loadFeed(){const c=cfg();if(!st.feed)st.feed=lsGet(LS.feed,null);
  if(!c.url){render();return;}
  st.loading=true;st.err='';render();
  try{const j=await gasGet();if(!j.empty){j.fetchedAt=Date.now();st.feed=j;lsSet(LS.feed,j);}}
  catch(e){st.err=navigator.onLine===false?'Offline. Showing the last saved data':'Could not load. Check the URL in Settings';}
  st.loading=false;render();watchLive();}
async function getCached(key,params,maxAge){const hit=st.cache[key];if(hit&&Date.now()-hit.at<(maxAge||5*60e3))return hit.data;
  const data=await gasGet(params);st.cache[key]={at:Date.now(),data};return data;}

/* ---------- live game: the browser reads ESPN's public scoreboard while the app is open ---------- */
let liveTimer=null;
const etDay=ms=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(ms)).replace(/-/g,'');
function liveGame(){const f=st.feed;if(!f)return null;const now=Date.now();return (f.schedule||[]).find(g=>g.t-now<30*60e3&&now-g.t<4*H&&!(g.state==='post'&&g.pf!=null&&now-g.t>3.5*H))||null;}
function watchLive(){clearTimeout(liveTimer);const g=liveGame();if(!g){st.live=null;return;}pollLive(g);}
async function pollLive(g){let v=null;
  try{if(!g.espn){const r=await fetch(ESPN+'/scoreboard?dates='+etDay(g.t));const j=await r.json();const e=(j.events||[]).find(e=>(((e.competitions||[])[0]||{}).competitors||[]).some(c=>c.team&&c.team.abbreviation==='POR'));if(e)g.espn=e.id;}
    if(g.espn){const r=await fetch(ESPN+'/summary?event='+g.espn);v=parseLive(await r.json());v.brId=g.id;}}catch(e){}
  if(v){st.live=v;st.liveAt=Date.now();if(st.view==='today'||(st.view==='games'&&st.sub===g.id))render();}
  const state=v&&v.status&&v.status.state;
  if(state==='post'){liveTimer=setTimeout(loadFeed,10*60e3);return;}   // the full box score arrives from Basketball-Reference a bit later
  liveTimer=setTimeout(()=>{if(!document.hidden)pollLive(g);else liveTimer=null;},v?20e3:120e3);}
const MADE=s=>{const m=String(s||'').match(/(\d+)\s*-\s*(\d+)/);return m?[+m[1],+m[2]]:[0,0];};
function parseLive(j){const comp=((j.header||{}).competitions||[])[0]||{},stt=(comp.status||{}).type||{};
  const teams=(comp.competitors||[]).map(c=>({id:String(c.team.id),abbr:c.team.abbreviation,name:c.team.displayName,logo:((c.team.logos||[])[0]||{}).href||'',home:c.homeAway==='home',score:+c.score||0,s:{}}));
  const idMap={};teams.forEach(t=>{idMap[t.id]=t.abbr==='POR'?'POR':t.abbr;});teams.forEach(t=>t.id=idMap[t.id]);
  const by={};teams.forEach(t=>by[t.id]=t);
  ((j.boxscore||{}).teams||[]).forEach(bt=>{const t=by[idMap[String((bt.team||{}).id)]];if(!t)return;const s={};(bt.statistics||[]).forEach(x=>s[x.name]=x.displayValue);
    const fg=MADE(s['fieldGoalsMade-fieldGoalsAttempted']),ft=MADE(s['freeThrowsMade-freeThrowsAttempted']),tp=MADE(s['threePointFieldGoalsMade-threePointFieldGoalsAttempted']);
    t.s={fgm:fg[0],fga:fg[1],ftm:ft[0],fta:ft[1],tpm:tp[0],tpa:tp[1],oreb:+s.offensiveRebounds||0,dreb:+s.defensiveRebounds||0,tov:+(s.totalTurnovers!=null?s.totalTurnovers:s.turnovers)||0,reb:+s.totalRebounds||0,ast:+s.assists||0};});
  const box={};((j.boxscore||{}).players||[]).forEach(bp=>{const tid=idMap[String((bp.team||{}).id)],s0=(bp.statistics||[])[0]||{},keys=s0.keys||[];
    box[tid]=(s0.athletes||[]).map(a=>{const o={id:String(a.athlete.id),n:a.athlete.shortName||a.athlete.displayName,st:!!a.starter};if(a.didNotPlay||!(a.stats&&a.stats.length)){o.dnp=a.reason||'DNP';return o;}
      (a.stats||[]).forEach((v,i)=>{const k=keys[i];if(k==='minutes')o.min=+v||0;else if(k==='points')o.pts=+v||0;else if(k==='rebounds')o.reb=+v||0;else if(k==='assists')o.ast=+v||0;else if(k==='steals')o.stl=+v||0;else if(k==='blocks')o.blk=+v||0;else if(k==='turnovers')o.tov=+v||0;else if(k==='plusMinus')o.pm=+v||0;
        else if(k==='fieldGoalsMade-fieldGoalsAttempted')o.fg=v;else if(k==='threePointFieldGoalsMade-threePointFieldGoalsAttempted')o.tp=v;else if(k==='freeThrowsMade-freeThrowsAttempted')o.ft=v;});return o;});});
  const me=by[TEAM_ID],op=teams.find(t=>t.id!==TEAM_ID),poss=x=>x?x.fga-x.oreb+x.tov+0.44*x.fta:0;
  const p=me&&op?(poss(me.s)+poss(op.s))/2:0;
  const plays=(j.plays||[]).slice(-6).reverse().map(x=>({per:(x.period||{}).number,clk:(x.clock||{}).displayValue,txt:x.text,tid:idMap[String((x.team||{}).id||'')]||''}));
  return{ok:true,id:String((j.header||{}).id||''),status:{state:stt.state,completed:!!stt.completed,detail:stt.shortDetail||stt.detail||'',period:(comp.status||{}).period,clock:(comp.status||{}).displayClock},teams,box,ratings:p?{ortg:Math.round(1000*me.score/p)/10,drtg:Math.round(1000*op.score/p)/10,poss:Math.round(p)}:null,last:plays,at:Date.now()};}

/* ---------- shared pieces ---------- */
const sec=(t,s)=>`<div class="sec"><h2>${t}</h2>${s?`<small>${s}</small>`:''}</div>`;
function setupPanel(){return `<section class="panel"><h3>Connect a data source</h3><p class="note">Paste gas/pdx/Code.gs into a new GAS project, run setup, deploy it as a web app, then enter the URL and passphrase in Settings.</p><div class="row"><button class="btn pri" data-view="settings">Open Settings</button></div></section>`;}
const errHtml=()=>st.err?`<p class="msg bad">${esc(st.err)}</p>`:'';
function scoreCard(g,opts){opts=opts||{};const me=g.teams.find(t=>t.id===TEAM_ID)||g.teams[0],op=g.teams.find(t=>t!==me);if(!me||!op)return'';
  const home=me.home?me:op,away=me.home?op:me,live=g.status.state==='in',fin=g.status.state==='post';
  const sc=t=>`<span class="${fin?(t.score>=(t===home?away:home).score?'w':'l'):''}">${t.score}</span>`;
  const tm=t=>`<div class="tm"><img src="${esc(t.logo)}" alt="" onerror="this.style.visibility='hidden'"><b>${esc(t.abbr)}</b><span>${esc(t.name)}</span></div>`;
  const tops=(g.box&&g.box[TEAM_ID]||[]).filter(p=>!p.dnp).sort((a,b)=>(b.pts||0)-(a.pts||0)).slice(0,opts.n||4);
  return `<section class="card ${live?'':'dim'}" ${opts.click?`data-game="${esc(g.id)}" style="cursor:pointer"`:''}>
    <div class="ck"><b>${live?'LIVE':fin?'FINAL':'NEXT'}</b><span>${esc(opts.when||'')}</span></div>
    <div class="score">${tm(away)}<div class="pts n">${sc(away)}<i>-</i>${sc(home)}</div>${tm(home)}</div>
    <div class="status">${live?`<span class="live">${esc(g.status.detail||'')}</span>`:esc(g.status.detail||'')}</div>
    ${tops.length?`<ul class="tops"><li class="h"><b>POR</b><span>PTS</span><span>REB</span><span>AST</span></li>${tops.map(p=>`<li><b>${esc(p.n)}</b><span>${p.pts}</span><span>${p.reb}</span><span>${p.ast}</span></li>`).join('')}</ul>`:''}
    ${g.ratings?`<div class="kv">Off rating<b>${pct(g.ratings.ortg)}</b> Def rating<b>${pct(g.ratings.drtg)}</b>${live?'<em>in progress</em>':''}</div>`:''}
    ${live&&g.last&&g.last.length?`<ul class="tops">${g.last.slice(0,3).map(x=>`<li style="grid-template-columns:52px 1fr"><span style="text-align:left;font-size:13px;color:var(--dim)">${x.per}Q ${esc(x.clk)}</span><b style="font-weight:500;font-size:13px">${esc(x.txt)}</b></li>`).join('')}</ul>`:''}</section>`;}
const POR_LOGO='https://a.espncdn.com/i/teamlogos/nba/500/por.png';
const tmN=t=>`<div class="tm"><img src="${esc(t.logo)}" alt="" onerror="this.style.visibility='hidden'"><b>${esc(t.abbr)}</b><span>${esc(t.name)}</span></div>`;
function nextCard(n){if(!n)return'';const d=new Date(n.t);
  return `<section class="card dim"><div class="ck"><b>NEXT</b><span>${fmtDW(n.t)} ${fmtT(n.t)} JST</span></div>
    <div class="score">${tmN(n.home?n.opp:{abbr:'POR',name:'Portland',logo:POR_LOGO})}
      <div class="pts n" style="font-size:22px;color:var(--sub)">@</div>
      ${tmN(n.home?{abbr:'POR',name:'Portland',logo:POR_LOGO}:n.opp)}</div>
    <div class="status">${esc(n.venue||'')}${n.tv?' · '+esc(n.tv):''}${d-Date.now()<864e5&&d>Date.now()?' · in '+Math.max(1,Math.round((d-Date.now())/H))+'h':''}</div></section>`;}
function lastCardFromFeed(L){if(!L)return'';const g={id:L.id,teams:[{id:TEAM_ID,abbr:'POR',name:'Portland',logo:'https://a.espncdn.com/i/teamlogos/nba/500/por.png',home:L.home,score:L.pf},{id:L.opp.id,abbr:L.opp.abbr,name:L.opp.name,logo:L.opp.logo,home:!L.home,score:L.pa}],
  status:{state:'post',detail:(L.win?'Win':'Loss')+' · '+fmtDW(L.t)},box:{[TEAM_ID]:(L.box||[]).map(b=>({n:b.n,pts:b.pts,reb:b.reb,ast:b.ast}))},ratings:L.ratings};
  return scoreCard(g,{click:1,when:'Last game'});}

/* ---------- today ---------- */
function todayView(){const f=st.feed,c=cfg();if(!f)return `<div class="g">${!c.url?setupPanel():'<p class="empty">Loading…</p>'}${errHtml()}</div>`;
  const live=st.live&&st.live.status&&st.live.status.state!=='pre'?st.live:null,b=f.brief&&Date.now()-f.brief.at<20*H?f.brief:null;
  const conf=f.standing?(f.standing.conf==='west'?'West':'East'):'',inj=(f.roster||[]).filter(p=>p.inj);
  const R=f.ranks||{},rk=(k,lab)=>R[k]?`<div><small>${lab}</small><b class="n">${pct(R[k].v)}</b><em>${ord(R[k].r)}</em></div>`:'';
  return `<div class="g">${!c.url?setupPanel():''}${errHtml()}
    ${live?scoreCard(Object.assign({},live,{id:live.brId||live.id,box:live.box}),{click:1,when:'Updated '+fmtT(st.liveAt),n:5}):''}
    ${!live||live.status.state==='post'?lastCardFromFeed(f.last):''}
    ${b?`<section class="card brief"><div class="ck"><b>Morning brief</b><span>${fmtWhen(b.at)}</span></div>${b.headline?`<p class="bh">${esc(b.headline)}</p>`:''}<ul>${b.points.concat(b.players||[]).map(x=>`<li>${esc(x.text)}${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener">story</a>`:''}</li>`).join('')}</ul>${b.watch?`<p class="note">${esc(b.watch)}</p>`:''}</section>`:''}
    ${!live||live.status.state==='post'?nextCard(f.next)+previewBlock(f.preview):''}
    <div class="stand"><span class="big n">${f.record.w}-${f.record.l}</span><span>${conf?`<b>${ord(f.standing.seed)}</b> in the ${conf}`:''}</span><span>${f.games.length} games</span></div>
    <div class="rk">${rk('ortg','Off rating')}${rk('drtg','Def rating')}${rk('net','Net rating')}${rk('pace','Pace')}${rk('efg','eFG%')}${rk('oefg','Opp eFG%')}</div>
    <p class="note">Ratings are points per 100 possessions. Ranks are among ${(f.league||[]).length} teams, computed from every box score.</p>
    ${(f.milestones||[]).length?sec('Chasing records','Franchise totals')+`<ul class="rows ms">${f.milestones.slice(0,5).map(m=>`<li><button data-player="${esc(m.a)}" style="display:contents"><b>${esc(m.n)}　${ord(m.r)} in ${esc(m.catName)}</b><span>to pass ${esc(m.next.n)} (${num(m.next.v)})</span><em class="n">${num(m.next.gap)}<small>to go</small></em></button></li>`).join('')}</ul>`:''}
    ${inj.length?sec('Injuries')+`<ul class="rows">${inj.map(p=>`<li><button class="pl-row" data-player="${esc(p.id)}"><img src="${esc(p.head)}" alt="" loading="lazy"><div><b>${esc(p.name)}</b><span class="inj">${esc(p.inj.status)}${p.inj.detail?' · '+esc(p.inj.detail):''}</span></div><div class="st">${p.inj.ret?esc(p.inj.ret.slice(5).replace('-','/'))+'<small>est. return</small>':''}</div></button></li>`).join('')}</ul>`:''}
    ${sec('News','Latest first')}${newsList((f.news||[]).slice(0,6))}
    <div class="row" style="justify-content:center;margin-top:20px"><button class="btn" data-view="news">All news</button></div></div>`;}

/* ---------- games ---------- */
function gamesView(){const f=st.feed;if(!f)return '<div class="g"><p class="empty">Loading…</p></div>';
  if(st.sub)return gameDetailView(st.sub);
  const games=f.schedule||[];let h='',month='';
  const nextIdx=games.findIndex(g=>g.state!=='post');
  games.forEach((g,i)=>{const d=new Date(g.t),m=d.toLocaleString('en-US',{month:'long',year:'numeric'});if(m!==month){month=m;h+=`<div class="month">${m}</div>`;}
    const res=g.state==='post'?`<i class="${g.win?'w':''}">${g.win?'W':'L'}</i><span class="${g.win?'w':'l'}">${g.pf}-${g.pa}</span>`:g.state==='in'?'<i class="w">LIVE</i>':`<span style="font-size:14px;color:var(--sub)">${fmtT(g.t)}</span>`;
    h+=`<li ${i===nextIdx?'id="nextgame"':''}><button class="game-row" ${g.state==='pre'?'disabled style="cursor:default"':''} data-game="${esc(g.id)}"><div class="d n">${fmtD(g.t)}<small>${WD[d.getDay()]}</small></div>
      <div class="o"><span>${g.home?'vs':'@'}</span><img src="${esc(g.opp.logo)}" alt=""><b>${esc(g.opp.name||g.opp.abbr)}</b></div><div class="r n">${res}</div></button></li>`;});
  return `<div class="g">${sec('Schedule & results',`${f.record.w}-${f.record.l} · times in JST`)}<ul class="rows">${h}</ul></div>`;}
function gameDetailView(id){const d=st.cache['game:'+id]&&st.cache['game:'+id].data;const liveNow=st.live&&st.live.brId===id&&st.live.status.state==='in'?st.live:null;
  if(!d&&!liveNow){loadGame(id);return `<div class="g"><button class="back" data-back="1">${ICON.back}Schedule</button><p class="empty">Loading…</p></div>`;}
  const g=liveNow||d,me=g.teams.find(t=>t.id===TEAM_ID),op=g.teams.find(t=>t.id!==TEAM_ID);
  const boxT=(tid,label)=>{const rows=(g.box&&g.box[tid])||[];if(!rows.length)return'';
    return `${sec(label)}<div class="tw"><table class="t"><tr><th>Player</th><th>MIN</th><th>PTS</th><th>REB</th><th>AST</th><th>STL</th><th>BLK</th><th>TO</th><th>FG</th><th>3P</th><th>FT</th><th>+/-</th></tr>
      ${rows.map(p=>p.dnp?`<tr class="dnp"><td>${esc(p.n)}</td><td colspan="11" style="text-align:left;font-family:var(--sans);font-size:12px">${esc(p.dnp)}</td></tr>`:`<tr><td>${tid===TEAM_ID?`<button class="link" style="padding:0;color:var(--ink)" data-player="${esc(p.id)}">${esc(p.n)}</button>`:esc(p.n)}${p.st?'':' <small style="color:var(--dim)">bench</small>'}</td><td>${p.min||0}</td><td class="${p.pts>=20?'hi':''}">${p.pts||0}</td><td class="${p.reb>=10?'hi':''}">${p.reb||0}</td><td class="${p.ast>=10?'hi':''}">${p.ast||0}</td><td>${p.stl||0}</td><td>${p.blk||0}</td><td>${p.tov||0}</td><td>${esc(p.fg||'')}</td><td>${esc(p.tp||'')}</td><td>${esc(p.ft||'')}</td><td>${p.pm>0?'+':''}${p.pm||0}</td></tr>`).join('')}</table></div>`;};
  /* side-by-side comparison: POR | label | opponent, the better side is lit */
  const ts=(k,lab,f,lowGood)=>{if(!(me&&op&&me.s&&op.s))return'';const a=f(me.s),b=f(op.s),va=a.v,vb=b.v;const wa=lowGood?va<vb:va>vb,wb=lowGood?vb<va:vb>va;
    return `<li><span class="${wa?'w':''}">${a.t}</span><em>${lab}</em><span class="${wb?'w':''}">${b.t}</span></li>`;};
  const sh=(m,a)=>s=>({v:s[m]/(s[a]||1),t:`${s[m]}-${s[a]}<small>${pct(100*s[m]/(s[a]||1))}%</small>`}),cnt=k=>s=>({v:s[k]||0,t:String(s[k]||0)});
  const shots=(d&&d.shots)||[],mine=shots.filter(s=>s[4]===1);
  return `<div class="g"><button class="back" data-back="1">${ICON.back}Schedule</button>
    ${scoreCard(g,{when:g.venue||'',n:0})}
    ${lineScore(d,me,op)}${d&&d.flow?sec('Game flow','POR lead by minute')+flowChart(d.flow,op?op.abbr:''):''}
    ${me&&op&&me.s&&me.s.fga?sec('Team stats')+`<ul class="cmp"><li class="h"><span>POR</span><em></em><span>${esc(op.abbr)}</span></li>
      ${ts('fg','Field goals',sh('fgm','fga'))}${ts('tp','3-pointers',sh('tpm','tpa'))}${ts('ft','Free throws',sh('ftm','fta'))}
      ${ts('reb','Rebounds',cnt('reb'))}${ts('oreb','Off rebounds',cnt('oreb'))}${ts('ast','Assists',cnt('ast'))}${ts('tov','Turnovers',cnt('tov'),1)}${ts('stl','Steals',cnt('stl'))}${ts('blk','Blocks',cnt('blk'))}
      ${me.s.paint?ts('paint','Points in paint',cnt('paint')):''}${me.s.fast?ts('fast','Fast break pts',cnt('fast')):''}</ul>`:''}
    ${mine.length?sec('Shot chart','POR · this game')+court(mine.map(s=>[s[0],s[1],s[2],s[3]]),{mode:'shots'}):''}
    ${boxT(TEAM_ID,'POR box score')}${op?boxT(op.id,esc(op.abbr)+' box score'):''}
    ${g.last&&g.last.length?sec(liveNow?'Latest plays':'Scoring plays','Latest first')+`<ul class="rows">${g.last.map(x=>`<li style="padding:7px 0;font-size:13px"><span class="n" style="color:var(--dim);margin-right:8px">${x.per}Q ${esc(x.clk)}</span>${esc(x.txt)}</li>`).join('')}</ul>`:''}</div>`;}
async function loadGame(id){try{const d=await gasGet({v:'game',id});st.cache['game:'+id]={at:Date.now(),data:d};}catch(e){st.cache['game:'+id]={at:Date.now(),data:null};st.err='Could not load the game';}render();}

/* ---------- players ---------- */
function playersView(){const f=st.feed;if(!f)return '<div class="g"><p class="empty">Loading…</p></div>';
  if(st.sub)return playerView(st.sub);
  const ros=f.roster||[],payroll=ros.reduce((s,p)=>s+(p.salary||0),0);
  return `<div class="g">${sec('Roster',`${ros.length} players · payroll ${money(payroll)}`)}
    <ul class="rows">${ros.map(p=>`<li><button class="pl-row" data-player="${esc(p.id)}"><img src="${esc(p.head)}" alt="" loading="lazy">
      <div><b><em>${esc(p.jersey)}</em>${esc(p.name)}</b><span>${esc(p.pos)}${p.age?' · '+p.age:''} · ${money(p.salary)}${p.inj?` · <span class="inj">${esc(p.inj.status)}</span>`:''}</span></div>
      <div class="st">${p.avg&&p.avg.gp?`${pct(p.avg.pts)}<small>${pct(p.avg.reb)}R ${pct(p.avg.ast)}A</small>`:'<small>no games</small>'}</div></button></li>`).join('')}</ul>
    <p class="note">Season per-game averages (points, rebounds, assists). Salaries from ESPN contract data.</p></div>`;}
function playerView(id){const key='player:'+id,d=st.cache[key]&&st.cache[key].data;
  if(!d){getCached(key,{v:'player',id},10*60e3).then(render).catch(()=>{st.err='Could not load the player';render();});return `<div class="g"><button class="back" data-back="1">${ICON.back}Roster</button><p class="empty">Loading…</p></div>`;}
  const p=d.p,a=d.avg||{},adv=d.adv,c=p.contract;
  const rankRows=(d.ranks||[]).sort((x,y)=>x.r-y.r);
  return `<div class="g"><button class="back" data-back="1">${ICON.back}Roster</button>
    <div class="pp-h"><img src="${esc(p.head)}" alt=""><div><div class="no">#${esc(p.jersey||'')}</div><h2>${esc(p.name)}</h2><p>${[p.pos,p.age?'Age '+p.age:'',p.ht,p.wt,p.exp!=null?(p.exp?ord(p.exp+1)+' season':'Rookie'):'',p.birth].filter(Boolean).map(esc).join(' · ')}</p></div></div>
    ${p.inj?`<div class="injbox"><b>${esc(p.inj.status)}</b>${p.inj.detail?'　'+esc(p.inj.detail):''}${p.inj.ret?'　est. return '+esc(p.inj.ret):''}</div>`:''}
    ${sec('This season',a.gp?`${a.gp} games (${a.starts} starts)`:'Has not played yet')}
    ${a.gp?`<div class="grid4"><div><small>PTS</small><b>${pct(a.pts)}</b></div><div><small>REB</small><b>${pct(a.reb)}</b></div><div><small>AST</small><b>${pct(a.ast)}</b></div><div><small>MIN</small><b>${pct(a.min)}</b></div>
      <div><small>FG%</small><b>${pct(a.fg)}</b></div><div><small>3P%</small><b>${pct(a.tp)}</b></div><div><small>FT%</small><b>${pct(a.ft)}</b></div><div><small>TS%</small><b>${pct(a.ts)}</b></div>
      <div><small>STL</small><b>${pct(a.stl)}</b></div><div><small>BLK</small><b>${pct(a.blk)}</b></div><div><small>TO</small><b>${pct(a.tov)}</b></div><div><small>+/-</small><b>${a.pm>0?'+':''}${pct(a.pm)}</b></div></div>`:''}
    ${adv?sec('Advanced','Basketball-Reference · daily')+`<div class="grid4"><div><small>PER</small><b>${pct(adv.per)}</b></div><div><small>TS%</small><b>${adv.ts!=null?pct(adv.ts*100):'—'}</b></div><div><small>USG%</small><b>${pct(adv.usg)}</b></div><div><small>BPM</small><b>${pct(adv.bpm)}</b></div>
      <div><small>WS</small><b>${adv.ws!=null?adv.ws.toFixed(1):'—'}</b></div><div><small>WS/48</small><b>${adv.ws48!=null?adv.ws48.toFixed(3).replace(/^0/,''):'—'}</b></div><div><small>OBPM / DBPM</small><b style="white-space:nowrap">${pct(adv.obpm)}<span style="font-size:.6em;color:var(--dim)"> / </span>${pct(adv.dbpm)}</b></div><div><small>VORP</small><b>${pct(adv.vorp)}</b></div></div>`:''}
    ${d.shots.length?sec('Shooting',`${d.shots.length} shots this season`)+`<div class="seg"><button class="${st.shotMode==='shots'?'on':''}" data-shot="shots">Shot chart</button><button class="${st.shotMode==='zones'?'on':''}" data-shot="zones">Hot zones</button></div>`+court(d.shots,{mode:st.shotMode,zones:d.zones}):''}
    ${formBlock(d)}${impactBlock(d)}${eventsBlock(d)}
    ${sec('Contract & market value',c?`${c.years} yr${c.years===1?'':'s'} left`:'')}${contractBlock(d)}
    ${rankRows.length?sec('Franchise ranks','All-time with Portland')+`<ul class="rows ms">${rankRows.map(r=>`<li><b>${esc(r.name)}　${ord(r.r)} all-time</b><span>${num(r.v)}${r.next?` · ${num(r.next.gap)} behind ${esc(r.next.n)} (${num(r.next.v)})`:' · franchise leader'}</span><em class="n">${ord(r.r)}</em></li>`).join('')}</ul>`:''}
    ${d.logs.length?sec('Game log','Latest first')+`<div class="tw"><table class="t"><tr><th>Date</th><th>Opp</th><th>MIN</th><th>PTS</th><th>REB</th><th>AST</th><th>STL</th><th>BLK</th><th>FG</th><th>3P</th><th>+/-</th></tr>
      ${d.logs.map(l=>l.dnp?`<tr class="dnp"><td>${fmtD(l.d)}</td><td>${l.h?'vs':'@'} ${esc(l.o)}</td><td colspan="9" style="text-align:left;font-family:var(--sans);font-size:12px">${esc(l.dnp)}</td></tr>`:`<tr><td><button class="link" style="padding:0;color:var(--ink)" data-game="${esc(l.e)}">${fmtD(l.d)}</button></td><td style="font-family:var(--sans);font-size:12px">${l.w?'W':'L'} ${l.h?'vs':'@'} ${esc(l.o)}</td><td>${l.min}</td><td class="${l.pts>=25?'hi':''}">${l.pts}</td><td>${l.reb}</td><td>${l.ast}</td><td>${l.stl}</td><td>${l.blk}</td><td>${l.fgm}-${l.fga}</td><td>${l.tpm}-${l.tpa}</td><td>${l.pm>0?'+':''}${l.pm}</td></tr>`).join('')}</table></div>`:''}
    ${sec('News','Includes off-court stories')}${newsList(d.news)}</div>`;}
function contractBlock(d){const p=d.p,c=p.contract,vals=d.values||[];
  if(!c&&!vals.length)return '<p class="msg">No contract data yet</p>';
  const last=vals[vals.length-1]||{};
  let h=`<div class="grid4"><div><small>Salary</small><b>${money(c&&c.salary)}</b></div><div><small>Est. value</small><b>${money(last.v)}</b></div><div><small>Trade value</small><b>${money(c&&c.trade)}</b></div><div><small>Years left</small><b>${c&&c.years!=null?c.years:'—'}</b></div></div>`;
  const yrs=(p.contracts||[]).filter(x=>x.s);if(yrs.length>1)h+=`<p class="note" style="margin-top:12px">Salary by season</p>`+barChart(yrs.map(x=>({lab:`${String(x.y-1).slice(2)}-${String(x.y).slice(2)}`,v:x.s})),{fmt:money});
  if(vals.length)h+=`<p class="note" style="margin-top:12px">Estimated value vs salary</p>`+lineChart([{name:'Est. value',color:'var(--red)',pts:vals.filter(v=>v.v!=null).map(v=>[Date.parse(v.d),v.v])},{name:'Salary',color:'#9a9aa2',dash:1,pts:vals.filter(v=>v.s!=null).map(v=>[Date.parse(v.d),v.s])}],{fmt:money,date:1});
  h+=`<p class="note">Estimated value = this season's Win Shares scaled to 82 games × about ${money(d.wsValue)} per win (salary cap ${money(d.cap)} × 30 teams ÷ 1,230 wins). A rough guide, not an actual market price. Recorded daily.</p>`;
  return h;}

/* ---------- court, shots and hot zones ---------- */
function zoneOf(x,y,three){const dx=x-25,dy=y-4.75,d=Math.sqrt(dx*dx+dy*dy),ang=Math.atan2(dx,dy)*180/Math.PI;
  if(three||d>23.6){if(y<14)return dx<0?'C3_L':'C3_R';return ang<-22?'AB3_L':ang>22?'AB3_R':'AB3_C';}
  if(d<4)return'RA';if(Math.abs(dx)<=8&&y<=19)return'PAINT';return ang<-30?'MID_L':ang>30?'MID_R':'MID_C';}
const ZONE_C={RA:[25,3],PAINT:[25,12.5],MID_L:[8,10],MID_C:[25,20.5],MID_R:[42,10],C3_L:[1.7,10],C3_R:[48.3,10],AB3_L:[6,25],AB3_C:[25,32],AB3_R:[44,25]};
function heat(diff){if(diff==null)return '#202024';return diff>=6?'#e5383b':diff>=2?'#8e2b2d':diff>-2?'#383835':diff>-6?'#2b3f66':'#5b8def';}
function court(shots,o){const S=10,W=500,Hh=470,hx=250,hy=47.5,tx=x=>x*S,ty=y=>y*S;
  const lines=`<rect class="line" x="0" y="0" width="${W}" height="${Hh}"/><rect class="line" x="170" y="0" width="160" height="190"/><circle class="line" cx="250" cy="190" r="60"/><path class="line" d="M210 ${hy} A40 40 0 0 0 290 ${hy}"/>
    <line class="line" x1="220" y1="40" x2="280" y2="40"/><circle class="line" cx="${hx}" cy="${hy}" r="7.5"/><path class="line" d="M30 0 V140 A237.5 237.5 0 0 0 470 140 V0"/><path class="line" d="M190 470 A60 60 0 0 1 310 470"/>`;
  let body='';
  if(o.mode==='zones'){const zs={};(o.zones||[]).forEach(z=>zs[z.z]=z);
    /* zones drawn as shapes: wedges from the hoop clipped to inside / outside the 3pt line (same split as zoneOf) */
    const col=k=>{const z=zs[k];return heat(z&&z.a>=5&&z.pct!=null&&z.lg!=null?z.pct-z.lg:null);};
    const ray=(deg,y)=>{const r=deg*Math.PI/180;return (hx+Math.sin(r)*(y-hy)/Math.cos(r)).toFixed(1);};
    const IN='M30 0 V140 A237.5 237.5 0 0 0 470 140 V0 Z';
    body+=`<defs><clipPath id="zin"><path d="${IN}"/></clipPath><clipPath id="zout"><path clip-rule="evenodd" d="M0 0 H500 V470 H0 Z ${IN}"/></clipPath></defs>
      <g clip-path="url(#zout)"><polygon fill="${col('AB3_L')}" points="0,140 ${ray(-22,140)},140 ${ray(-22,470)},470 0,470"/><polygon fill="${col('AB3_C')}" points="${ray(-22,140)},140 ${ray(22,140)},140 ${ray(22,470)},470 ${ray(-22,470)},470"/><polygon fill="${col('AB3_R')}" points="${ray(22,140)},140 500,140 500,470 ${ray(22,470)},470"/>
        <rect fill="${col('C3_L')}" x="0" y="0" width="30" height="140"/><rect fill="${col('C3_R')}" x="470" y="0" width="30" height="140"/></g>
      <g clip-path="url(#zin)"><polygon fill="${col('MID_L')}" points="${hx},${hy} ${hx},0 0,0 0,470 ${ray(-30,470)},470"/><polygon fill="${col('MID_C')}" points="${hx},${hy} ${ray(-30,470)},470 ${ray(30,470)},470"/><polygon fill="${col('MID_R')}" points="${hx},${hy} ${hx},0 500,0 500,470 ${ray(30,470)},470"/>
        <path stroke="#0a0a0b" stroke-width="3" d="M${hx} ${hy} L${ray(-30,470)} 470M${hx} ${hy} L${ray(30,470)} 470M${hx} ${hy} V0"/>
        <rect fill="${col('PAINT')}" x="170" y="0" width="160" height="190"/><circle fill="${col('RA')}" cx="${hx}" cy="${hy}" r="40"/></g>
      <g clip-path="url(#zout)"><path stroke="#0a0a0b" stroke-width="3" d="M${ray(-22,140)} 140 L${ray(-22,470)} 470M${ray(22,140)} 140 L${ray(22,470)} 470M0 140H30M470 140H500"/></g>`;
    body+=lines;(o.zones||[]).forEach(z=>{if(!z.a)return;const c=ZONE_C[z.z];const edge=z.z==='C3_L'?'start':z.z==='C3_R'?'end':'';const lx=z.z==='C3_L'?4:z.z==='C3_R'?496:tx(c[0]);body+=`<text class="zl${edge?' sm':''}" style="${edge?'text-anchor:'+edge:''}" x="${lx}" y="${ty(c[1])}">${z.pct!=null?Math.round(z.pct)+'%':''}</text><text class="zs" style="${edge?'text-anchor:'+edge:''}" x="${lx}" y="${ty(c[1])+16}">${z.m}/${z.a}</text>`;});}
  else{body=lines+shots.map(s=>s[2]?`<circle class="made" cx="${tx(s[0])}" cy="${ty(s[1])}" r="6"/>`:`<path class="miss" d="M${tx(s[0])-5} ${ty(s[1])-5}l10 10M${tx(s[0])+5} ${ty(s[1])-5}l-10 10"/>`).join('');}
  const made=shots.filter(s=>s[2]).length;
  return `<div class="chart court"><svg viewBox="-4 -4 ${W+8} ${Hh+8}" role="img" aria-label="${o.mode==='zones'?'Hot zones':'Shot chart'}">${body}</svg></div>
    ${o.mode==='zones'?`<div class="scale"><span>Below league avg</span><i style="background:#5b8def"></i><i style="background:#2b3f66"></i><i style="background:#383835"></i><i style="background:#8e2b2d"></i><i style="background:#e5383b"></i><span>Above</span></div><p class="note" style="text-align:center">FG% and makes/attempts. Zones with fewer than 5 attempts stay uncolored. League average comes from every game this season.</p>`:
    `<p class="note" style="text-align:center"><span style="color:var(--red)">●</span> Made ${made}　<span style="color:#8a8a92">×</span> Missed ${shots.length-made}　FG ${pct(100*made/(shots.length||1))}%</p>`}`;}

/* ---------- charts ---------- */
function lineChart(series,o){o=o||{};const W=400,Hh=190,pl=8,pr=o.fmt?58:38,pt=12,pb=24;const all=series.flatMap(s=>s.pts);if(all.length<1)return '<p class="msg">No data yet</p>';
  let x0=Math.min(...all.map(p=>p[0])),x1=Math.max(...all.map(p=>p[0]));if(x0===x1){x0-=864e5;x1+=864e5;}
  let lo=Math.min(...all.map(p=>p[1])),hi=Math.max(...all.map(p=>p[1]));const padv=o.rank?Math.max(0.5,(hi-lo)*0.12):(hi-lo)*0.12||Math.abs(hi)*0.05||1;lo-=padv;hi+=padv;if(o.zero&&lo>0)lo=0;if(o.invert){[lo,hi]=[hi,lo];}
  const X=t=>pl+(t-x0)/(x1-x0)*(W-pl-pr),Y=v=>pt+(Hh-pt-pb)*(1-(v-lo)/(hi-lo));
  let g='';const a0=Math.min(lo,hi),a1=Math.max(lo,hi),stp=Math.max(1,Math.ceil((a1-a0)/4)),ticks=o.rank?Array.from({length:Math.floor(a1)-Math.ceil(a0)+1},(_,i)=>Math.ceil(a0)+i).filter(v=>(v-Math.ceil(a0))%stp===0):[0,1,2,3].map(k=>lo+(hi-lo)*k/3);for(const v of ticks){g+=`<line class="grid" x1="${pl}" x2="${W-pr}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}"/><text class="ax" x="${W-pr+6}" y="${(Y(v)+4).toFixed(1)}">${o.fmt?o.fmt(v):o.rank?ord(Math.round(v)):Math.round(v*10)/10}</text>`;}
  const xf=o.xfmt||fmtD;const lab=[x0,x1].map((t,i)=>`<text class="ax" x="${X(t)}" y="${Hh-6}" text-anchor="${i?'end':'start'}">${xf(t)}</text>`).join('');
  /* end labels: keep them apart when the lines finish close together */
  const ends=series.map(s=>{const p=s.pts.slice().sort((a,b)=>a[0]-b[0]);return p.length?Y(p[p.length-1][1])-8:null;});
  for(let i=1;i<ends.length;i++)for(let j=0;j<i;j++)if(ends[i]!=null&&ends[j]!=null&&Math.abs(ends[i]-ends[j])<14){ends[i]=ends[j]+(ends[i]>=ends[j]?14:-14);if(ends[i]<10)ends[i]=ends[j]+14;}
  const lines=series.map((s,si)=>{const p=s.pts.slice().sort((a,b)=>a[0]-b[0]);if(!p.length)return'';
    return (p.length>1?`<path d="${p.map((q,i)=>(i?'L':'M')+X(q[0]).toFixed(1)+' '+Y(q[1]).toFixed(1)).join(' ')}" fill="none" stroke="${s.color}" stroke-width="2.2" ${s.dash?'stroke-dasharray="5 4"':''} vector-effect="non-scaling-stroke"/>`:'')+
      p.map(q=>`<circle cx="${X(q[0]).toFixed(1)}" cy="${Y(q[1]).toFixed(1)}" r="${p.length>20?0:3.5}" fill="${s.color}"/>`).join('')+
      `<text x="${(X(p[p.length-1][0])-4).toFixed(1)}" y="${ends[si].toFixed(1)}" text-anchor="end" font-size="12" paint-order="stroke" stroke="var(--bg)" stroke-width="3" fill="${s.color}" font-weight="700">${esc(s.name)}</text>`;}).join('');
  const hits=all.length?series[0].pts.map(q=>`<rect x="${(X(q[0])-12).toFixed(1)}" y="${pt}" width="24" height="${Hh-pt-pb}" fill="transparent" data-tip="${xf(q[0])}" data-v="${series.map(s=>{const m=s.pts.find(z=>z[0]===q[0]);return m?s.name+' '+(o.fmt?o.fmt(m[1]):m[1]):'';}).filter(Boolean).join(' / ')}"/>`).join(''):'';
  return `<div class="chart" data-chart="1"><svg viewBox="0 0 ${W} ${Hh}" role="img">${g}${lab}${lines}${hits}</svg><div class="tip"></div></div>${series.length>1?`<div class="legend">${series.map(s=>`<span><i style="background:${s.color}"></i>${esc(s.name)}</span>`).join('')}</div>`:''}`;}
function barChart(items,o){const W=400,Hh=140,pt=18,pb=24,max=Math.max(...items.map(i=>i.v)),bw=(W)/items.length;
  return `<div class="chart"><svg viewBox="0 0 ${W} ${Hh}" role="img">${items.map((it,i)=>{const h=(Hh-pt-pb)*it.v/max,x=i*bw+bw*0.2,w=bw*0.6,y=Hh-pb-h;
    return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" fill="${i===0?'var(--red)':'#5a5a62'}"/><text class="ax" x="${(x+w/2).toFixed(1)}" y="${(y-5).toFixed(1)}" text-anchor="middle" style="fill:var(--ink)">${o.fmt(it.v)}</text><text class="ax" x="${(x+w/2).toFixed(1)}" y="${Hh-6}" text-anchor="middle">${esc(it.lab)}</text>`;}).join('')}</svg></div>`;}
function scatter(league){const W=400,Hh=300,p=28;if(league.length<2)return '<p class="msg">Not enough games yet</p>';
  const xs=league.map(t=>t.ortg),ys=league.map(t=>t.drtg),x0=Math.min(...xs)-2,x1=Math.max(...xs)+2,y0=Math.min(...ys)-2,y1=Math.max(...ys)+2;
  const X=v=>p+(v-x0)/(x1-x0)*(W-p-12),Y=v=>12+(v-y0)/(y1-y0)*(Hh-p-12);   // lower DRtg (better defence) at the top
  const ax=(xs.reduce((a,b)=>a+b,0)/xs.length),ay=(ys.reduce((a,b)=>a+b,0)/ys.length);
  let h=`<line class="grid" x1="${X(ax)}" x2="${X(ax)}" y1="12" y2="${Hh-p}"/><line class="grid" x1="${p}" x2="${W-12}" y1="${Y(ay)}" y2="${Y(ay)}"/>
    <text class="ax" x="${W-14}" y="24" text-anchor="end" style="fill:var(--sub)">good at both</text><text class="ax" x="${W-12}" y="${Hh-12}" text-anchor="end">Off rating (better →)</text><text class="ax" x="${p}" y="24">↑ Def rating (better)</text>`;
  league.slice().sort((a,b)=>(a.id===TEAM_ID)-(b.id===TEAM_ID)).forEach(t=>{const me=t.id===TEAM_ID;
    h+=`<circle cx="${X(t.ortg).toFixed(1)}" cy="${Y(t.drtg).toFixed(1)}" r="${me?8:5}" fill="${me?'var(--red)':'#5a5a62'}" stroke="var(--bg)" stroke-width="2"/><text x="${(X(t.ortg)+9).toFixed(1)}" y="${(Y(t.drtg)+4).toFixed(1)}" font-size="${me?14:12}" font-weight="${me?700:500}" fill="${me?'var(--ink)':'#8a8a92'}" font-family="Barlow Condensed,sans-serif">${esc(t.abbr)}</text>
      <rect x="${(X(t.ortg)-10).toFixed(1)}" y="${(Y(t.drtg)-10).toFixed(1)}" width="20" height="20" fill="transparent" data-tip="${esc(t.abbr)}" data-v="Off ${t.ortg} / Def ${t.drtg} / Net ${t.net>0?'+':''}${t.net}"/>`;});
  return `<div class="chart" data-chart="1"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="Offensive and defensive rating of every team">${h}</svg><div class="tip"></div></div>`;}

/* ---------- records ---------- */
function recordsView(){const mode=`<div class="filt">${[['franchise','Franchise'],['season','This season']].map(([k,n])=>`<button class="fb ${st.recMode===k?'on':''}" data-rmode="${k}">${n}</button>`).join('')}</div>`;
  if(st.recMode==='season')return `<div class="g">${mode}${seasonRecords()}</div>`;
  const k='leaders',d=st.cache[k]&&st.cache[k].data;
  if(!d){getCached(k,{v:'leaders'},10*60e3).then(render).catch(()=>{st.err='Could not load records';render();});return `<div class="g">${errHtml()}<p class="empty">Loading…</p></div>`;}
  if(!d.cats)return `<div class="g"><p class="empty">Records are not ready yet (GAS reads Basketball-Reference once a day)</p></div>`;
  const cat=d.cats[st.cat]||d.cats.pts,act=cat.active||[];
  const top=cat.top,actOut=act.filter(e=>e.r>top.length);
  return `<div class="g">${mode}<div class="filt">${Object.keys(d.cats).map(c=>`<button class="fb ${st.cat===c?'on':''}" data-cat="${c}">${esc(d.cats[c].name)}</button>`).join('')}</div>
    ${act.length?sec('Current players','Next to pass')+`<ul class="rows ms">${act.map(e=>`<li><button data-player="${esc(e.a)}" style="display:contents"><b>${esc(e.n)}　${ord(e.r)} all-time</b><span>${num(e.v)}${e.next?` · to pass ${esc(e.next.n)} (${num(e.next.v)})`:' · franchise leader'}</span><em class="n">${e.next?num(e.next.gap):'1st'}<small>${e.next?'to go':''}</small></em></button></li>`).join('')}</ul>`:''}
    ${sec('All-time '+esc(cat.name),'Career totals with Portland only')}
    <ul class="rows lb">${top.map(e=>`<li class="${e.a?'act':''}"><span class="r">${e.r}</span><span class="nm">${e.a?`<button class="link" style="padding:0;color:var(--ink);font-weight:700" data-player="${esc(e.a)}">${esc(e.n)}</button>`:esc(e.n)}<small>${esc(e.y)}</small></span><span class="v">${num(e.v)}</span></li>`).join('')}
      ${actOut.map(e=>`<li class="act"><span class="r">${e.r}</span><span class="nm">${esc(e.n)}</span><span class="v">${num(e.v)}</span></li>`).join('')}</ul>
    ${d.pending&&d.pending.length?`<p class="note">New this season, no Portland totals yet: ${d.pending.map(esc).join(', ')} (added once they play)</p>`:''}
    <p class="note">Basketball-Reference franchise totals (fetched ${fmtWhen(d.brAt)}) plus every box score since, updated after each game. Red rows are current players.</p></div>`;}

/* ---------- team ---------- */
function teamView(){const f=st.feed;if(!f)return '<div class="g"><p class="empty">Loading…</p></div>';
  const subs=`<div class="filt">${TSUBS.map(([k,n])=>`<button class="fb ${st.teamSub===k?'on':''}" data-tsub="${k}">${n}</button>`).join('')}</div>`;
  if(st.teamSub!=='overview')return `<div class="g">${subs}${teamExtra(st.teamSub)}</div>`;
  const R=f.ranks||{},hist=f.hist||[],league=(f.league||[]).slice();
  const metricBtn=[['net','Net'],['ortg','Off rating'],['drtg','Def rating'],['pace','Pace'],['efg','eFG%'],['tovp','TOV%'],['orbp','ORB%'],['oefg','Opp eFG%']];
  const mk=st.teamMetric,low=['drtg','tovp','oefg'].includes(mk),sorted=league.sort((a,b)=>low?a[mk]-b[mk]:b[mk]-a[mk]);
  const games=f.games||[];
  return `<div class="g">${subs}${sec('League ranks',`${league.length} teams · updated every game`)}
    <div class="tw"><table class="t"><tr><th>Stat</th><th>POR</th><th>Rank</th><th>League avg</th></tr>${Object.keys(R).map(k=>{const avg=league.length?league.reduce((s,t)=>s+(t[k]||0),0)/league.length:null;return `<tr><td>${esc(R[k].name)}</td><td>${pct(R[k].v)}</td><td class="${R[k].r<=5?'hi':''}">${R[k].r}</td><td>${avg!=null?pct(avg):'—'}</td></tr>`;}).join('')}</table></div>
    <p class="note">Off/Def rating = points scored/allowed per 100 possessions (possessions = FGA − ORB + TOV + 0.44 × FTA). For Def rating, TOV% and Opp eFG%, lower ranks higher.</p>
    ${sec('Offense vs defense','All teams')}${scatter(league)}
    ${hist.length?sec('Ratings over time','Season to date')+lineChart([{name:'Off rating',color:'var(--red)',pts:hist.map(h=>[Date.parse(h.d),h.m.ortg])},{name:'Def rating',color:'#c9c9cf',dash:1,pts:hist.map(h=>[Date.parse(h.d),h.m.drtg])}])+
      sec('Rank over time','Higher is better')+lineChart([{name:'Net',color:'var(--red)',pts:hist.map(h=>[Date.parse(h.d),h.r.net])},{name:'Defense',color:'#c9c9cf',dash:1,pts:hist.map(h=>[Date.parse(h.d),h.r.drtg])}],{invert:1,rank:1}):''}
    ${games.length?sec('Ratings by game')+lineChart([{name:'Offense',color:'var(--red)',pts:games.map(g=>[g.d,g.ortg])},{name:'Defense',color:'#c9c9cf',dash:1,pts:games.map(g=>[g.d,g.drtg])}]):''}
    ${sec('Rankings')}${(()=>{fixedCols=[['ortg','Off'],['drtg','Def'],['net','Net'],['pace','Pace']].filter(c=>c[0]!==mk);return'';})()}<div class="filt">${metricBtn.map(([k,n])=>`<button class="fb ${mk===k?'on':''}" data-metric="${k}">${n}</button>`).join('')}</div>
    <div class="tw"><table class="t"><tr><th>Team</th><th>GP</th><th style="color:var(--red2)">${esc((metricBtn.find(m=>m[0]===mk)||[])[1]||'')}</th>${fixedCols.map(c=>`<th>${c[1]}</th>`).join('')}</tr>
      ${sorted.map((t,i)=>`<tr class="${t.id===TEAM_ID?'me':''}"><td>${i+1}. ${esc(t.abbr)}</td><td>${t.g}</td><td class="hi">${mk==='net'&&t.net>0?'+':''}${pct(t[mk])}</td>${fixedCols.map(c=>`<td>${c[0]==='net'&&t.net>0?'+':''}${pct(t[c[0]])}</td>`).join('')}</tr>`).join('')}</table></div>
    ${standingsBlock(f.standings)}</div>`;}
let fixedCols=[];
function standingsBlock(s){if(!s||!(s.west||[]).length)return'';
  const tbl=(list,name)=>`${sec(name)}<div class="tw"><table class="t"><tr><th>Team</th><th>W</th><th>L</th><th>PCT</th><th>GB</th><th>STRK</th></tr>${list.map((t,i)=>`<tr class="${t.id===TEAM_ID?'me':''}"><td>${i+1}. ${esc(t.abbr)}</td><td>${t.w}</td><td>${t.l}</td><td>${esc(t.pct)}</td><td>${esc(t.gb)}</td><td>${esc(t.streak)}</td></tr>`).join('')}</table></div>`;
  return tbl(s.west,'Western Conference')+(s.east&&s.east.length?tbl(s.east,'Eastern Conference'):'');}


/* ---------- next opponent ---------- */
const sgn=v=>v==null?'—':(v>0?'+':'')+pct(v);
const updn=v=>v==null?'':v>0?'up':v<0?'dn':'';
function previewBlock(pv){if(!pv)return'';
  const better=(c,side)=>{const low=['drtg','tovp','oefg'].includes(c.k);const a=c.porR,b=c.oppR;return side==='por'?a<b:b<a;};
  const rows=pv.cmp.map(c=>`<tr><td>${esc(c.name)}</td><td class="${better(c,'por')?'hi':''}">${pct(c.por)} <small>${ord(c.porR)}</small></td><td class="${better(c,'opp')?'hi':''}">${pct(c.opp)} <small>${ord(c.oppR)}</small></td></tr>`).join('');
  return `${sec('Scouting '+esc(pv.abbr),pv.record?`${pv.record.w}-${pv.record.l}`:'')}
    ${pv.cmp.length?`<div class="tw"><table class="t cmp-t"><tr><th>Stat</th><th>POR</th><th>${esc(pv.abbr)}</th></tr>${rows}</table></div><p class="note">Ranks among ${pv.teams} teams. Lower is better for Def rating, TOV% and Opp eFG%.</p>`:''}
    ${pv.last.length?`<p class="lbl2">Last ${pv.last.length}</p><div class="chips">${pv.last.slice().reverse().map(g=>`<span class="chip ${g.w?'w':'l'}"><b>${g.w?'W':'L'}</b> ${g.h?'vs':'@'} ${esc(g.o)} ${g.pf}-${g.pa}</span>`).join('')}</div>`:''}
    ${pv.leaders.length?`<p class="lbl2">Their leaders</p><ul class="rows">${pv.leaders.map(p=>`<li class="kv2"><b>${esc(p.n)}</b><span class="n">${pct(p.pts)} <small>PTS</small> ${pct(p.reb)} <small>REB</small> ${pct(p.ast)} <small>AST</small></span></li>`).join('')}</ul>`:''}
    ${pv.inj&&pv.inj.length?`<p class="lbl2">Their injuries</p><ul class="rows">${pv.inj.map(p=>`<li class="kv2"><b>${esc(p.name)}</b><span class="inj">${esc(p.status)}${p.detail?' · '+esc(p.detail):''}</span></li>`).join('')}</ul>`:''}
    ${pv.h2h.length?`<p class="lbl2">Season series</p><div class="chips">${pv.h2h.map(g=>`<button class="chip ${g.win?'w':'l'}" data-game="${esc(g.id)}"><b>${g.win?'W':'L'}</b> ${fmtD(g.t)} ${g.pf}-${g.pa}</button>`).join('')}</div>`:''}`;}

/* ---------- game: line score and flow ---------- */
function lineScore(d,me,op){if(!d||!d.quarters||!me||!op)return'';const q=d.quarters,lab=i=>i<4?String(i+1):'OT'+(i>4?i-3:'');
  return `<div class="tw" style="margin-top:14px"><table class="t ls"><tr><th></th>${q.map((x,i)=>`<th>${lab(i)}</th>`).join('')}<th>T</th></tr>
    <tr class="me"><td>POR</td>${q.map(x=>`<td>${x[0]}</td>`).join('')}<td><b>${q.reduce((s,x)=>s+x[0],0)}</b></td></tr>
    <tr><td>${esc(op.abbr)}</td>${q.map(x=>`<td>${x[1]}</td>`).join('')}<td><b>${q.reduce((s,x)=>s+x[1],0)}</b></td></tr></table></div>`;}
function flowChart(flow,opp){const W=400,Hh=170,pl=4,pr=34,pt=10,pb=22,T=Math.max(48,flow[flow.length-1][0]);
  const ext=Math.max(5,...flow.map(p=>Math.abs(p[1])));const X=t=>pl+t/T*(W-pl-pr),Y=v=>pt+(Hh-pt-pb)*(1-(v+ext)/(2*ext)),y0=Y(0);
  let d=`M${X(0)} ${y0}`;flow.forEach((p,i)=>{if(i){d+=` H${X(p[0]).toFixed(1)} V${Y(p[1]).toFixed(1)}`;}});d+=` H${X(T)}`;
  const area=d+` V${y0} H${X(0)} Z`;const qs=[12,24,36].concat(T>48?[48]:[]).map(m=>`<line class="grid" x1="${X(m)}" x2="${X(m)}" y1="${pt}" y2="${Hh-pb}"/>`).join('');
  const hi=Math.max(...flow.map(p=>p[1])),lo=Math.min(...flow.map(p=>p[1]));
  return `<div class="chart"><svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="Score margin through the game"><defs><clipPath id="fUp"><rect x="0" y="0" width="${W}" height="${y0}"/></clipPath><clipPath id="fDn"><rect x="0" y="${y0}" width="${W}" height="${Hh}"/></clipPath></defs>${qs}
    <path d="${area}" fill="var(--red)" fill-opacity=".28" clip-path="url(#fUp)"/><path d="${area}" fill="#5b8def" fill-opacity=".28" clip-path="url(#fDn)"/>
    <path d="${d}" fill="none" stroke="var(--red)" stroke-width="1.6" clip-path="url(#fUp)"/><path d="${d}" fill="none" stroke="#5b8def" stroke-width="1.6" clip-path="url(#fDn)"/>
    <line x1="${pl}" x2="${W-pr}" y1="${y0}" y2="${y0}" stroke="var(--line2,#3a3a40)"/>
    <text class="ax" x="${W-pr+4}" y="${pt+8}">POR</text><text class="ax" x="${W-pr+4}" y="${Hh-pb}">${esc(opp)}</text>
    ${['Q1','Q2','Q3','Q4'].map((q,i)=>`<text class="ax" x="${X(i*12+6)}" y="${Hh-6}" text-anchor="middle">${q}</text>`).join('')}</svg></div>
    <p class="note" style="text-align:center">Largest lead: POR ${hi>0?'+'+hi:'—'} · ${esc(opp)} ${lo<0?'+'+(-lo):'—'}</p>`;}

/* ---------- player: form, splits, impact ---------- */
function statLine(arr){if(!arr.length)return null;const n=arr.length,s=k=>arr.reduce((a,l)=>a+(l[k]||0),0),fga=s('fga'),fta=s('fta');
  return{gp:n,pts:s('pts')/n,reb:s('reb')/n,ast:s('ast')/n,min:s('min')/n,fg:fga?100*s('fgm')/fga:null,tp:s('tpa')?100*s('tpm')/s('tpa'):null,ts:(fga+0.44*fta)?100*s('pts')/(2*(fga+0.44*fta)):null,pm:s('pm')/n};}
function formBlock(d){const all=d.logs.slice().sort((a,b)=>a.d-b.d),pl=all.filter(l=>!l.dnp);if(pl.length<2)return'';
  const S=statLine(pl),L10=statLine(pl.slice(-10)),L5=statLine(pl.slice(-5));
  const row=(n,x,base)=>`<tr><td>${n}</td>${['pts','reb','ast','min','fg','ts'].map(k=>{const v=x[k],b=base&&base[k];const c=base&&v!=null&&b!=null?(v-b>=(k==='fg'||k==='ts'?3:1.5)?'up':v-b<=-(k==='fg'||k==='ts'?3:1.5)?'dn':''):'';return `<td class="${c}">${pct(v)}</td>`;}).join('')}</tr>`;
  // rest: days since the team's previous game (DNPs count as team games)
  const rest=all.map((l,i)=>i?Math.round((l.d-all[i-1].d)/864e5):9);
  const sp=(name,f)=>{const a=pl.filter(f);const x=statLine(a);return x?`<tr><td>${name}</td><td>${x.gp}</td><td>${pct(x.pts)}</td><td>${pct(x.reb)}</td><td>${pct(x.ast)}</td><td>${pct(x.fg)}</td><td class="${updn(x.pm)}">${sgn(x.pm)}</td></tr>`:'';};
  const restOf=l=>rest[all.indexOf(l)];
  const trend=lineChart([{name:'PTS',color:'var(--red)',pts:pl.map(l=>[l.d,l.pts])},{name:'5-game avg',color:'#c9c9cf',dash:1,pts:pl.map((l,i)=>[l.d,Math.round(10*pl.slice(Math.max(0,i-4),i+1).reduce((a,x)=>a+x.pts,0)/Math.min(5,i+1))/10])}],{zero:1});
  return `${sec('Form','Recent games vs season')}<div class="tw"><table class="t"><tr><th></th><th>PTS</th><th>REB</th><th>AST</th><th>MIN</th><th>FG%</th><th>TS%</th></tr>${row('Season',S)}${row('Last 10',L10,S)}${row('Last 5',L5,S)}</table></div>
    <p class="note">Red is up and blue is down against the season average.</p>${trend}
    ${sec('Splits')}<div class="tw"><table class="t"><tr><th></th><th>GP</th><th>PTS</th><th>REB</th><th>AST</th><th>FG%</th><th>+/-</th></tr>
      ${sp('Home',l=>l.h)}${sp('Away',l=>!l.h)}${sp('Wins',l=>l.w)}${sp('Losses',l=>!l.w)}${sp('Starter',l=>l.st)}${sp('Bench',l=>!l.st)}${sp('Back-to-back',l=>restOf(l)<=1)}${sp('1+ days rest',l=>restOf(l)>1)}</table></div>`;}
function impactBlock(d){let h='';const o=d.onoff;
  if(o&&o.on&&o.on.min){h+=sec('On / off court',`${o.g} games · from play-by-play`)+`<div class="grid4"><div><small>Net on</small><b class="${updn(o.on.net)}">${sgn(o.on.net)}</b></div><div><small>Net off</small><b class="${updn(o.off.net)}">${sgn(o.off.net)}</b></div><div><small>Difference</small><b class="${updn(o.on.net!=null&&o.off.net!=null?o.on.net-o.off.net:null)}">${o.on.net!=null&&o.off.net!=null?sgn(o.on.net-o.off.net):'—'}</b></div><div><small>Minutes on</small><b>${pct(o.on.min)}</b></div>
    <div><small>Off rtg on</small><b>${pct(o.on.ortg)}</b></div><div><small>Def rtg on</small><b>${pct(o.on.drtg)}</b></div><div><small>Off rtg off</small><b>${pct(o.off.ortg)}</b></div><div><small>Def rtg off</small><b>${pct(o.off.drtg)}</b></div></div>
    <p class="note">Team points per 100 possessions with this player on and off the floor.</p>`;}
  const c=d.clutch;if(c&&(c.min||c.pts))h+=sec('Clutch','Last 5 min, within 5')+`<div class="grid4"><div><small>PTS</small><b>${c.pts}</b></div><div><small>FG</small><b>${c.fgm}-${c.fga}</b></div><div><small>3P</small><b>${c.tpm}-${c.tpa}</b></div><div><small>FT</small><b>${c.ftm}-${c.fta}</b></div><div><small>AST</small><b>${c.ast}</b></div><div><small>MIN</small><b>${pct(c.min)}</b></div></div>`;
  const pt=d.partners;if(pt&&(pt.to.length||pt.from.length)){const li=(a,arrow)=>a.map(x=>`<li class="kv2"><button class="link" style="padding:0;color:var(--ink)" data-player="${esc(x.id)}">${arrow} ${esc(x.n)}</button><span class="n">${x.c}</span></li>`).join('');
    h+=sec('Assist partners')+`<div class="two"><div><p class="lbl2">Assists to</p><ul class="rows">${li(pt.to,'→')||'<li class="kv2"><span>—</span></li>'}</ul></div><div><p class="lbl2">Assisted by</p><ul class="rows">${li(pt.from,'←')||'<li class="kv2"><span>—</span></li>'}</ul></div></div>`;}
  return h;}

/* ---------- team: lineups, clutch, history ---------- */
const TSUBS=[['overview','Overview'],['lineups','Lineups'],['clutch','Clutch'],['events','Play-by-play'],['history','History']];
function teamExtra(sub){const k='team',d=st.cache[k]&&st.cache[k].data;
  if(!d){getCached(k,{v:'team'},10*60e3).then(render).catch(()=>{st.err='Could not load team data';render();});return `${errHtml()}<p class="empty">Loading…</p>`;}
  if(sub==='lineups')return lineupsView(d);if(sub==='clutch')return clutchView(d);if(sub==='events')return teamEventsView(d);return historyView(d);}
function lineupsView(d){if(!d.lineups.length)return '<p class="empty">No play-by-play yet</p>';
  const by=st.luSort,list=d.lineups.filter(l=>by==='min'||l.min>=10).slice().sort((a,b)=>by==='net'?(b.net-a.net):b.min-a.min).slice(0,15);
  const last=n=>String(n).split(' ').slice(-1)[0];
  return `${sec('Five-man units',`${d.pbpGames} games`)}<div class="filt"><button class="fb ${by==='min'?'on':''}" data-lsort="min">Most used</button><button class="fb ${by==='net'?'on':''}" data-lsort="net">Best net (10+ min)</button></div>
    <div class="tw"><table class="t lu"><tr><th>Lineup</th><th>MIN</th><th>NET</th><th>OFF</th><th>DEF</th></tr>${list.map(l=>`<tr><td><span class="lu-n">${l.names.map(n=>esc(last(n))).join(' · ')}</span></td><td>${pct(l.min)}</td><td class="${updn(l.net)}">${sgn(l.net)}</td><td>${pct(l.ortg)}</td><td>${pct(l.drtg)}</td></tr>`).join('')}</table></div>
    <p class="note">Rebuilt from ESPN play-by-play substitutions. Ratings are points per 100 possessions; small samples swing a lot.</p>
    ${sec('On / off court','Team net rating')}<div class="tw"><table class="t"><tr><th>Player</th><th>MIN</th><th>ON</th><th>OFF</th><th>DIFF</th></tr>${d.onoff.map(x=>`<tr class="${x.cur?'':'dnp'}"><td><button class="link" style="padding:0;color:var(--ink)" data-player="${esc(x.id)}">${esc(x.n)}</button></td><td>${pct(x.onMin)}</td><td class="${updn(x.on.net)}">${sgn(x.on.net)}</td><td class="${updn(x.off.net)}">${sgn(x.off.net)}</td><td class="${updn(x.diff)}"><b>${sgn(x.diff)}</b></td></tr>`).join('')}</table></div>
    ${d.assists.length?sec('Assist pairs','Passer → scorer')+`<ul class="rows bars">${d.assists.slice(0,15).map(a=>`<li><span>${esc(a.fromN)} <i>→</i> ${esc(a.toN)}</span><em style="--w:${Math.round(100*a.n/d.assists[0].n)}%"></em><b class="n">${a.n}</b></li>`).join('')}</ul>`:''}`;}
function clutchView(d){const c=d.clutch;
  if(!c||!c.g)return `${sec('Clutch','Last 5 min of the 4th or OT, within 5')}<p class="empty">No clutch minutes yet this season</p>`;
  return `${sec('Clutch','Last 5 min of the 4th or OT, within 5')}<div class="grid4"><div><small>Record</small><b>${c.w}-${c.l}</b></div><div><small>Minutes</small><b>${pct(c.min)}</b></div><div><small>Net rating</small><b class="${updn(c.net)}">${sgn(c.net)}</b></div><div><small>Points</small><b>${c.pf}-${c.pa}</b></div>
      <div><small>Off rating</small><b>${pct(c.ortg)}</b></div><div><small>Def rating</small><b>${pct(c.drtg)}</b></div><div><small>Games</small><b>${c.g}</b></div><div></div></div>
    ${c.players.length?sec('Players in the clutch')+`<div class="tw"><table class="t"><tr><th>Player</th><th>MIN</th><th>PTS</th><th>FG</th><th>3P</th><th>FT</th><th>AST</th></tr>${c.players.map(p=>`<tr><td><button class="link" style="padding:0;color:var(--ink)" data-player="${esc(p.id)}">${esc(p.n)}</button></td><td>${pct(p.min)}</td><td>${p.pts}</td><td>${p.fgm}-${p.fga}</td><td>${p.tpm}-${p.tpa}</td><td>${p.ftm}-${p.fta}</td><td>${p.ast}</td></tr>`).join('')}</table></div>`:''}
    ${sec('Clutch games')}<ul class="rows">${d.games.filter(g=>g.clutch).sort((a,b)=>b.d-a.d).map(g=>`<li><button class="game-row" data-game="${esc(g.id)}"><div class="d n">${fmtD(g.d)}</div><div class="o"><span>${g.home?'vs':'@'}</span><b>${esc(g.opp)}</b></div><div class="r n"><i class="${g.win?'w':''}">${g.win?'W':'L'}</i><span class="${g.win?'w':'l'}">${g.pf}-${g.pa}</span></div></button></li>`).join('')}</ul>`;}
function historyView(d){const h=d.history||[];if(!h.length)return '<p class="empty">History loads with the daily Basketball-Reference update</p>';
  const yr=s=>+String(s).slice(0,4),pts=h.slice().reverse().map(r=>[yr(r.s),Math.round(1000*r.w/((r.w+r.l)||1))/10]);
  const titles=h.filter(r=>/won finals|champion/i.test(r.po)).length,po=h.filter(r=>r.po&&!/missed/i.test(r.po)).length;
  return `${sec('Franchise history',`${h.length} seasons`)}<div class="grid4"><div><small>Seasons</small><b>${h.length}</b></div><div><small>Playoffs</small><b>${po}</b></div><div><small>Titles</small><b>${titles}</b></div><div><small>All-time</small><b style="font-size:17px;white-space:nowrap">${h.reduce((s,r)=>s+r.w,0)}-${h.reduce((s,r)=>s+r.l,0)}</b></div></div>
    ${lineChart([{name:'Win %',color:'var(--red)',pts:pts}],{xfmt:v=>String(v),fmt:v=>Math.round(v)+'%'})}
    <div class="tw"><table class="t hist"><tr><th>Season</th><th>W-L</th><th>Playoffs</th><th>Coach</th></tr>${h.map(r=>`<tr class="${/won finals|champion/i.test(r.po)?'me':''}"><td>${esc(r.s)}</td><td>${r.w}-${r.l}</td><td class="tx">${esc(r.po||'—')}</td><td class="tx">${esc(r.coach)}</td></tr>`).join('')}</table></div>
    <p class="note">From Basketball-Reference, refreshed daily.</p>`;}


/* ---------- play-by-play counts: labels for every event the server counts ---------- */
const EV_FIXED={astd:'Assisted makes',unast:'Unassisted makes',ast:'Assists',and1:'And-ones',putback:'Putbacks',blk:'Blocks',blkd:'Shots blocked',stl:'Steals',drawn:'Fouls drawn',charge:'Charges drawn',
  'reb:off':'Offensive rebounds','reb:def':'Defensive rebounds','reb:team-off':'Team off. rebounds','reb:team-def':'Team def. rebounds','ft:m':'Free throws made','ft:a':'Free throws attempted','ft:tech:m':'Technical FTs made','ft:tech:a':'Technical FTs attempted',
  jump:'Jump balls taken',tech:'Technical fouls',flagrant:'Flagrant fouls',ejected:'Ejections',timeout:'Timeouts','viol:kicked ball':'Kicked balls'};
const SHOT_N={dunk:'Dunks',layup:'Layups',hook:'Hook shots',tip:'Tip-ins',jumper:'Jump shots',other:'Other shots'};
const cap=t=>String(t).charAt(0).toUpperCase()+String(t).slice(1);
function evLabel(k){if(EV_FIXED[k])return EV_FIXED[k];let m;
  if((m=k.match(/^shot:(\w+):(m|a)$/)))return (SHOT_N[m[1]]||cap(m[1]))+(m[2]==='m'?' made':' attempted');
  if((m=k.match(/^dist:([\w+-]+):(m|a)$/)))return (m[1]==='3pt'?'3-pointers':m[1]+' ft')+(m[2]==='m'?' made':' attempted');
  if((m=k.match(/^tov:(.+)$/)))return 'Turnovers: '+m[1];if((m=k.match(/^foul:(.+)$/)))return 'Fouls: '+m[1];if((m=k.match(/^viol:(.+)$/)))return 'Violations: '+m[1];return k;}
const EV_GROUP=k=>/^shot:|^dist:|^astd|^unast|^and1|^putback/.test(k)?'Scoring':/^ast$|^reb|^stl$|^blk$|^drawn$|^charge$|^jump$/.test(k)?'Hustle':/^tov:|^viol:|^blkd$/.test(k)?'Mistakes':/^foul:|^tech$|^flagrant$|^ejected$/.test(k)?'Fouls':'Other';
function sumKeys(c,re){return Object.keys(c||{}).filter(k=>re.test(k)).reduce((s,k)=>s+c[k],0);}
function eventsBlock(d){const c=d.ev;if(!c)return'';const gp=(d.avg&&d.avg.gp)||1;
  const kinds=['dunk','layup','hook','tip','jumper','other'].filter(k=>c['shot:'+k+':a']);
  const dist=['0-3','4-9','10-16','17+','3pt'].filter(k=>c['dist:'+k+':a']);
  const pctOf=(m,a)=>a?pct(100*(m||0)/a):'—';
  const tov=Object.keys(c).filter(k=>/^tov:/.test(k)).sort((a,b)=>c[b]-c[a]),fouls=Object.keys(c).filter(k=>/^foul:/.test(k)).sort((a,b)=>c[b]-c[a]),viol=Object.keys(c).filter(k=>/^viol:/.test(k)).sort((a,b)=>c[b]-c[a]);
  const made=sumKeys(c,/^shot:\w+:m$/),assisted=c.astd||0;
  const kv=(k,v)=>`<li class="kv2"><span>${esc(k)}</span><b class="n">${v}</b></li>`;
  return `${sec('Play-by-play profile','Counted from every play')}
    <div class="grid4"><div><small>Dunks</small><b>${c['shot:dunk:m']||0}</b></div><div><small>And-ones</small><b>${c.and1||0}</b></div><div><small>Putbacks</small><b>${c.putback||0}</b></div><div><small>Assisted</small><b>${made?Math.round(100*assisted/made)+'%':'—'}</b></div>
      <div><small>Charges drawn</small><b>${c.charge||0}</b></div><div><small>Fouls drawn</small><b>${c.drawn||0}</b></div><div><small>Kicked balls</small><b>${c['viol:kicked ball']||0}</b></div><div><small>Shots blocked</small><b>${c.blkd||0}</b></div></div>
    ${kinds.length?`<div class="tw"><table class="t"><tr><th>Shot type</th><th>FGM-A</th><th>FG%</th><th>Per game</th></tr>${kinds.map(k=>`<tr><td>${SHOT_N[k]}</td><td>${c['shot:'+k+':m']||0}-${c['shot:'+k+':a']}</td><td>${pctOf(c['shot:'+k+':m'],c['shot:'+k+':a'])}</td><td>${pct(c['shot:'+k+':a']/gp)}</td></tr>`).join('')}</table></div>`:''}
    ${dist.length?`<div class="tw"><table class="t"><tr><th>Distance</th><th>FGM-A</th><th>FG%</th><th>Share</th></tr>${dist.map(k=>`<tr><td>${k==='3pt'?'3-pointers':k+' ft'}</td><td>${c['dist:'+k+':m']||0}-${c['dist:'+k+':a']}</td><td>${pctOf(c['dist:'+k+':m'],c['dist:'+k+':a'])}</td><td>${Math.round(100*c['dist:'+k+':a']/Math.max(1,sumKeys(c,/^dist:.*:a$/)))}%</td></tr>`).join('')}</table></div>`:''}
    <div class="two"><div><p class="lbl2">Turnovers</p><ul class="rows">${tov.map(k=>kv(cap(k.slice(4)),c[k])).join('')||kv('None',0)}</ul></div><div><p class="lbl2">Fouls</p><ul class="rows">${fouls.map(k=>kv(cap(k.slice(5)),c[k])).join('')||kv('None',0)}</ul></div></div>
    ${viol.length?`<p class="lbl2">Violations</p><ul class="rows">${viol.map(k=>kv(cap(k.slice(5)),c[k])).join('')}</ul>`:''}`;}

/* ---------- records: this season inside the team ---------- */
const S_CATS=[['pts','Points'],['reb','Rebounds'],['ast','Assists'],['stl','Steals'],['blk','Blocks'],['tpm','3-pointers'],['shot:dunk:m','Dunks'],['and1','And-ones'],['putback','Putbacks'],['charge','Charges drawn'],['drawn','Fouls drawn'],['viol:kicked ball','Kicked balls'],['tov','Turnovers'],['tech','Technicals']];
function seasonRecords(){const k='team',d=st.cache[k]&&st.cache[k].data;const f=st.feed||{};
  if(!d){getCached(k,{v:'team'},10*60e3).then(render).catch(()=>{st.err='Could not load team data';render();});return `${errHtml()}<p class="empty">Loading…</p>`;}
  const box={};(f.roster||[]).forEach(p=>{if(p.avg&&p.avg.gp)box[p.id]={n:p.name,gp:p.avg.gp,pts:p.avg.pts*p.avg.gp,reb:p.avg.reb*p.avg.gp,ast:p.avg.ast*p.avg.gp,stl:p.avg.stl*p.avg.gp,blk:p.avg.blk*p.avg.gp,tov:p.avg.tov*p.avg.gp};});
  const ev={};(d.events||[]).forEach(x=>ev[x.id]=x);
  const val=(id,cat)=>{const c=(ev[id]||{}).c||{};if(cat==='tpm')return sumKeys(c,/^dist:3pt:m$/)||null;if(cat==='tov')return box[id]?Math.round(box[id].tov):sumKeys(c,/^tov:/);if(box[id]&&box[id][cat]!=null)return Math.round(box[id][cat]);return c[cat]||0;};
  const ids=Array.from(new Set(Object.keys(box).concat(Object.keys(ev))));
  const cat=st.sCat,rows=ids.map(id=>({id,n:(box[id]||{}).n||(ev[id]||{}).n||id,gp:(box[id]||{}).gp||(ev[id]||{}).gp||0,v:val(id,cat)})).filter(r=>r.v>0).sort((a,b)=>b.v-a.v);
  const team=d.teamEv||{};
  const all=Array.from(new Set(Object.keys(team.POR||{}).concat(Object.keys(team.OPP||{})))).sort((a,b)=>EV_GROUP(a).localeCompare(EV_GROUP(b))||evLabel(a).localeCompare(evLabel(b)));
  const leader=k=>{let best=null;(d.events||[]).forEach(x=>{const v=x.c[k]||0;if(v&&(!best||v>best.v))best={n:x.n,v};});return best;};
  return `<div class="filt">${S_CATS.map(([k,n])=>`<button class="fb ${cat===k?'on':''}" data-scat="${esc(k)}">${n}</button>`).join('')}</div>
    ${sec(esc((S_CATS.find(c=>c[0]===cat)||[0,evLabel(cat)])[1]),'Blazers this season')}${rows.length?`<ul class="rows lb">${rows.map((r,i)=>`<li class="${i===0?'act':''}"><span class="r">${i+1}</span><span class="nm"><button class="link" style="padding:0;color:var(--ink);font-weight:${i===0?700:500}" data-player="${esc(r.id)}">${esc(r.n)}</button><small>${r.gp} games · ${pct(r.v/Math.max(1,r.gp))} per game</small></span><span class="v">${num(r.v)}</span></li>`).join('')}</ul>`:'<p class="empty">Nothing yet</p>'}
    ${(d.highs||[]).length?sec('Season highs','Single game')+`<div class="tw"><table class="t"><tr><th>Stat</th><th>Player</th><th></th><th>Game</th></tr>${d.highs.map(h=>`<tr><td>${esc(h.name)}</td><td><button class="link" style="padding:0;color:var(--ink)" data-player="${esc(h.id)}">${esc(h.n)}</button></td><td class="hi">${h.v}</td><td><button class="link" style="padding:0;color:var(--sub)" data-game="${esc(h.e)}">${fmtD(h.d)} ${h.h?'vs':'@'} ${esc(h.o)}</button></td></tr>`).join('')}</table></div>`:''}
    ${all.length?sec('Every play-by-play count',`${d.pbpGames} games`)+`<div class="tw"><table class="t evt"><tr><th>Event</th><th>POR</th><th>OPP</th><th>Leader</th></tr>${all.map(k=>{const l=leader(k);return `<tr><td>${esc(evLabel(k))}</td><td>${(team.POR||{})[k]||0}</td><td>${(team.OPP||{})[k]||0}</td><td class="tx">${l?esc(String(l.n).split(' ').slice(-1)[0])+' <b>'+l.v+'</b>':'—'}</td></tr>`;}).join('')}</table></div><p class="note">Totals over every game read so far. Opponent counts are for the teams that played Portland.</p>`:''}`;}
function teamEventsView(d){const p=d.possession,t=d.teamEv||{POR:{},OPP:{}},g=d.pbpGames||1;
  const pg=(side,k)=>pct(((t[side]||{})[k]||0)/g),pk=(side,re)=>pct(sumKeys(t[side],re)/g);
  const row=(n,a,b,lowGood)=>{const x=+a,y=+b;return `<tr><td>${n}</td><td class="${(lowGood?x<y:x>y)?'hi':''}">${a}</td><td class="${(lowGood?y<x:y>x)?'hi':''}">${b}</td></tr>`;};
  return `${p?sec('Time of possession','Estimated from the play-by-play')+`<div class="grid4"><div><small>POR per game</small><b>${pct(p.por)}<span style="font-size:.55em;color:var(--dim)"> min</span></b></div><div><small>OPP per game</small><b>${pct(p.opp)}<span style="font-size:.55em;color:var(--dim)"> min</span></b></div><div><small>POR per possession</small><b>${pct(p.perPor)}<span style="font-size:.55em;color:var(--dim)"> s</span></b></div><div><small>OPP per possession</small><b>${pct(p.perOpp)}<span style="font-size:.55em;color:var(--dim)"> s</span></b></div></div>
    <p class="note">The ball changes hands on defensive rebounds, turnovers, made baskets and last free throws; the time between plays goes to the team with the ball. Player-level ball time needs camera tracking data, which is not public.</p>`:''}
    ${sec('Per game','POR vs opponents')}<div class="tw"><table class="t"><tr><th></th><th>POR</th><th>OPP</th></tr>
      ${row('Dunks',pg('POR','shot:dunk:m'),pg('OPP','shot:dunk:m'))}${row('Layups made',pg('POR','shot:layup:m'),pg('OPP','shot:layup:m'))}${row('And-ones',pg('POR','and1'),pg('OPP','and1'))}${row('Putbacks',pg('POR','putback'),pg('OPP','putback'))}
      ${row('Assisted makes',pg('POR','astd'),pg('OPP','astd'))}${row('Unassisted makes',pg('POR','unast'),pg('OPP','unast'))}${row('Steals',pg('POR','stl'),pg('OPP','stl'))}${row('Blocks',pg('POR','blk'),pg('OPP','blk'))}
      ${row('Turnovers',pk('POR',/^tov:/),pk('OPP',/^tov:/),1)}${row('Fouls',pk('POR',/^foul:/),pk('OPP',/^foul:/),1)}${row('Kicked balls',pg('POR','viol:kicked ball'),pg('OPP','viol:kicked ball'),1)}${row('Timeouts',pg('POR','timeout'),pg('OPP','timeout'))}</table></div>
    <p class="note">The full list of every counted event, with the Blazers leader for each, is under Records → This season.</p>`;}

/* ---------- news ---------- */
const NCATS=[['all','All'],['game','Games'],['move','Moves & contracts'],['injury','Injuries'],['off','Off-court'],['remix','Rip City Remix'],['other','Other']];
const CATN=Object.fromEntries(NCATS);
function newsList(items){if(!items||!items.length)return '<p class="empty">No news yet</p>';
  const ros={};((st.feed&&st.feed.roster)||[]).forEach(p=>ros[p.id]=p.short||p.name);
  return items.map(n=>`<article><div class="meta"><span class="src">${esc(n.s)}</span><span>${ago(n.d)}</span>${n.cat&&n.cat!=='other'?`<span class="k">${CATN[n.cat]}</span>`:''}${(n.who||[]).map(id=>ros[id]?`<span>${esc(ros[id])}</span>`:'').join('')}</div>
    <div><a class="ttl" href="${esc(n.u)}" target="_blank" rel="noopener" data-news="${esc(n.id)}">${esc(n.t)}</a>${n.x?`<div class="snip">${esc(n.x)}</div>`:''}</div>${n.im?`<img class="thumb" src="${esc(n.im)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">`:'<span></span>'}</article>`).join('');}
function newsView(){const f=st.feed;if(!f)return '<div class="g"><p class="empty">Loading…</p></div>';
  const list=(f.news||[]).filter(n=>st.newsCat==='all'||n.cat===st.newsCat);
  return `<div class="g"><div class="filt">${NCATS.map(([k,n])=>`<button class="fb ${st.newsCat===k?'on':''}" data-ncat="${k}">${n}</button>`).join('')}</div>${newsList(list)}
    <p class="note" style="margin-top:14px">From ESPN, Blazer's Edge, Hoops Rumors, Rip City Project, HoopsHype, Yahoo Sports, Blazersland and Google News (team and player names). Off-court stories are limited to what has been publicly reported.</p></div>`;}

/* ---------- settings ---------- */
const PTYPES=[['start','Tip-off'],['final','Final score and top performers'],['records','Records and franchise ranks'],['moves','Trades, injuries and contracts'],['brief','Morning brief']];
const isIOS=/iP(hone|ad|od)/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
function pushProblem(){if(isIOS&&!standalone)return 'On iPhone, use Safari Share → "Add to Home Screen", then open PDXRadar from the Home Screen to set this up.';if(!('serviceWorker' in navigator)||!('PushManager' in window))return 'This browser does not support notifications.';return '';}
function b64uToBytes(s){const b=atob(s.replace(/-/g,'+').replace(/_/g,'/')+'==='.slice((s.length+3)%4));return Uint8Array.from(b,ch=>ch.charCodeAt(0));}
async function pushEnable(types){const perm=await Notification.requestPermission();if(perm!=='granted')throw new Error('Notifications were not allowed. Allow them for PDXRadar in your device settings.');
  const reg=await navigator.serviceWorker.ready,{key}=await gasGet({v:'vapid'});let sub=await reg.pushManager.getSubscription();
  if(!sub){try{sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64uToBytes(key)});}catch(err){throw new Error('Could not subscribe ('+(err.name||'')+' '+(err.message||'')+')');}}
  await post({action:'push-sub',sub:sub.toJSON(),types,label:isIOS?'iPhone':/Android/.test(navigator.userAgent)?'Android':'PC'});setCfg('push',{endpoint:sub.endpoint,types});}
async function pushDisable(){const p=cfg().push;try{const reg=await navigator.serviceWorker.ready,sub=await reg.pushManager.getSubscription();if(sub)await sub.unsubscribe();}catch(e){}if(p)try{await post({action:'push-unsub',endpoint:p.endpoint});}catch(e){}setCfg('push',null);}
async function writeSwConf(){try{const c=await caches.open('pdx-conf');await c.put('./__conf',new Response(JSON.stringify({url:cfg().url}),{headers:{'Content-Type':'application/json'}}));}catch(e){}}
async function syncPrefs(){const c=cfg();if(!c.url||!c.pass)return;try{const j=await post({action:'prefs-get',endpoint:c.push&&c.push.endpoint});st.pushSt=j.push;st.briefKey=j.briefKey;if(st.view==='settings')render();}catch(e){}}
function settingsView(){const c=cfg(),f=st.feed||{},pp=c.push,prob=pushProblem(),s=st.pushSt;const msg=k=>st.msg[k]?`<p class="msg ${st.msg[k][1]?'bad':''}">${esc(st.msg[k][0])}</p>`:'';
  const perm='Notification' in window?Notification.permission:'';
  return `<div class="g">
  <section class="panel"><h3>Data source</h3><label class="lbl" for="s_url">PDXRadar GAS web app URL</label><input id="s_url" class="inp" data-cfg="url" inputmode="url" autocomplete="off" placeholder="https://script.google.com/macros/s/…/exec" value="${esc(c.url)}">
    <label class="lbl" for="s_pass">Passphrase</label><input id="s_pass" class="inp" type="password" data-cfg="pass" autocomplete="off" value="${esc(c.pass)}">
    <div class="row"><button class="btn pri" data-act="reload">Save and load</button><button class="btn" data-act="collect" ${st.busy?'disabled':''}>${st.busy==='collect'?'Updating…':'Update now'}</button></div>${msg('conn')}</section>
  <section class="panel"><h3>Notifications</h3>
    <dl class="facts"><dt>This device</dt><dd>${perm==='granted'?'Allowed':perm==='denied'?'Blocked (allow in device settings)':'Not asked yet'}</dd>${s?`<dt>Registered</dt><dd>${s.registered?'Yes':'No'}</dd><dt>Auto update</dt><dd>${s.tick?'Every 10 min':'Off (run setup in GAS)'}</dd>`:''}</dl>
    ${prob?`<p class="msg">${esc(prob)}</p>`:`${PTYPES.map(([k,n])=>`<label class="chk"><input type="checkbox" data-ptype="${k}" ${!pp||!pp.types||pp.types[k]!==false?'checked':''}> ${n}</label>`).join('')}
      <div class="row">${pp?`<button class="btn" data-act="push-test">Send a test</button><button class="btn" data-act="push-off">Turn off on this device</button>`:`<button class="btn pri" data-act="push-on" ${c.pass?'':'disabled'}>Get notifications on this device</button>`}</div>`}${msg('push')}</section>
  <section class="panel"><h3>Morning brief</h3><p class="note">A Claude scheduled task writes a short brief of the last game and news every morning. Copy the setup text below and send it to Claude.</p>
    <div class="row"><button class="btn" data-act="brief-copy" ${st.briefKey?'':'disabled'}>Copy setup text for Claude</button></div>${msg('brief')}</section>
  <section class="panel"><h3>Data status</h3><p class="note">Updated ${fmtWhen(f.updated)} · ${f.leagueGames||0} league games counted · records base ${fmtWhen(f.leadersAt)}</p>
    <table class="src-list">${(f.sources||[]).map(x=>`<tr><td>${esc(x.name||x.id)}</td><td class="r ${x.ok?'ok':'ng'}">${x.ok?(x.n!=null?'+'+x.n:'OK'):esc(x.error||'failed')}</td></tr>`).join('')}</table></section>
  <section class="panel"><h3>App version</h3><p class="note">If the app looks out of date, this clears saved files and loads the latest version.</p><div class="row"><button class="btn" data-act="hard-reload">Reload latest version</button></div></section></div>`;}

/* ---------- render ---------- */
const TABS=[['today','Today'],['games','Games'],['players','Players'],['records','Records'],['team','Team'],['news','News']];
function render(){const f=st.feed;const body={today:todayView,games:gamesView,players:playersView,records:recordsView,team:teamView,news:newsView,settings:settingsView}[st.view]();
  const y=scrollY,ae=document.activeElement&&document.activeElement.id;
  app.innerHTML=`<header><div class="g"><div class="hd"><h1>PDX<span>Radar</span></h1>${f&&f.record?`<span class="rec">${f.record.w}-${f.record.l}${f.standing?' · '+ord(f.standing.seed)+' '+(f.standing.conf==='west'?'West':'East'):''}</span>`:''}<span class="sp"></span>
    <button class="ib ${st.loading?'spin':''}" data-act="refresh" aria-label="Refresh">${ICON.refresh}</button><button class="ib ${st.view==='settings'?'on':''}" data-view="settings" aria-label="Settings">${ICON.gear}</button></div>
    <nav class="tabs">${TABS.map(([k,n])=>`<button class="tab ${st.view===k?'on':''}" data-view="${k}">${n}</button>`).join('')}</nav></div></header>${body}`;
  scrollTo(0,y);if(ae){const el=document.getElementById(ae);if(el)el.focus({preventScroll:true});}}
function go(view,sub){st.view=view;st.sub=sub||null;st.err='';render();scrollTo(0,0);if(sub)history.pushState({v:view,s:sub},'');}
addEventListener('popstate',e=>{if(document.getElementById('reader').hidden===false){closeReader();return;}const s=e.state||{};st.view=s.v||st.view;st.sub=s.s||null;render();});

app.addEventListener('click',async e=>{const t=e.target.closest('[data-view],[data-act],[data-game],[data-player],[data-back],[data-cat],[data-ncat],[data-metric],[data-shot],[data-news],[data-tsub],[data-lsort],[data-rmode],[data-scat]');if(!t)return;const d=t.dataset;
  if(d.news){e.preventDefault();openReader(d.news);return;}
  if(d.game){go('games',d.game);return;}
  if(d.player){go('players',d.player);return;}
  if(d.back){history.state&&history.state.s?history.back():go(st.view);return;}
  if(d.view){go(d.view);if(d.view==='games')setTimeout(()=>{const n=document.getElementById('nextgame');if(n)n.scrollIntoView({block:'center'});},30);if(d.view==='settings')syncPrefs();return;}
  if(d.cat){st.cat=d.cat;render();return;}
  if(d.ncat){st.newsCat=d.ncat;render();return;}
  if(d.metric){st.teamMetric=d.metric;render();return;}
  if(d.tsub){st.teamSub=d.tsub;render();return;}
  if(d.rmode){st.recMode=d.rmode;render();return;}
  if(d.scat){st.sCat=d.scat;render();return;}
  if(d.lsort){st.luSort=d.lsort;render();return;}
  if(d.shot){st.shotMode=d.shot;render();return;}
  const a=d.act;
  if(a==='refresh'){st.cache={};loadFeed();}
  else if(a==='reload'){st.msg={};writeSwConf();await loadFeed();st.msg.conn=st.err?[st.err,1]:['Connected'];syncPrefs();render();}
  else if(a==='collect'){st.busy='collect';st.msg.conn=['Updating (1–3 min)…'];render();try{await post({action:'refresh'});st.msg.conn=['Updated'];st.cache={};await loadFeed();}catch(err){st.msg.conn=[err.message,1];}st.busy='';render();}
  else if(a==='push-on'){st.msg.push=['Setting up…'];render();try{const types={};document.querySelectorAll('[data-ptype]').forEach(i=>types[i.dataset.ptype]=i.checked);await pushEnable(types);st.msg.push=['Notifications are on for this device'];syncPrefs();}catch(err){st.msg.push=[err.message,1];}render();}
  else if(a==='push-off'){await pushDisable();st.msg.push=['Notifications are off for this device'];render();}
  else if(a==='push-test'){try{await post({action:'push-test',endpoint:cfg().push.endpoint});st.msg.push=['Sent. It should arrive in a few seconds'];}catch(err){st.msg.push=[err.message,1];}render();}
  else if(a==='brief-copy'){const txt=`Set up a scheduled task that writes the PDXRadar morning brief every morning, in English.\nGAS URL: ${cfg().url}\nBrief key: ${st.briefKey}`;try{await navigator.clipboard.writeText(txt);st.msg.brief=['Copied. Paste it into a Claude chat and send'];}catch(err){st.msg.brief=['Could not copy:\n'+txt];}render();}
  else if(a==='hard-reload'){try{const ks=await caches.keys();await Promise.all(ks.filter(k=>k!=='pdx-conf').map(k=>caches.delete(k)));const rs=await navigator.serviceWorker.getRegistrations();await Promise.all(rs.map(r=>r.update().catch(()=>{})));}catch(err){}location.reload();}});
app.addEventListener('change',async e=>{const t=e.target,d=t.dataset;
  if(d.cfg){setCfg(d.cfg,t.value.trim());if(d.cfg==='url')writeSwConf();return;}
  if(d.ptype&&cfg().push){const types=Object.assign({},cfg().push.types||{});types[d.ptype]=t.checked;try{await pushEnable(types);st.msg.push=['Saved'];}catch(err){st.msg.push=[err.message,1];}render();}});
app.addEventListener('pointermove',e=>{const r=e.target.closest&&e.target.closest('[data-tip]'),ch=e.target.closest&&e.target.closest('[data-chart]');
  app.querySelectorAll('.tip').forEach(tp=>{if(!ch||!r||!ch.contains(tp)){tp.style.display='none';return;}const box=ch.getBoundingClientRect(),rb=r.getBoundingClientRect();
    tp.textContent=r.dataset.tip+'　'+r.dataset.v;tp.style.display='block';tp.style.left=Math.min(box.width-60,Math.max(60,rb.left-box.left+rb.width/2))+'px';tp.style.top=Math.max(20,rb.top-box.top)+'px';});});
app.addEventListener('pointerleave',()=>app.querySelectorAll('.tip').forEach(tp=>tp.style.display='none'),true);
document.addEventListener('visibilitychange',()=>{if(document.hidden)return;if(st.feed&&Date.now()-(st.feed.fetchedAt||0)>10*60e3)loadFeed();else watchLive();});

/* ---------- in-app reader ---------- */
const rdEl=document.getElementById('reader');
async function openReader(id){const n=((st.feed&&st.feed.news)||[]).find(x=>x.id===id)||(Object.values(st.cache).map(c=>c.data&&c.data.news).flat().filter(Boolean).find(x=>x&&x.id===id));if(!n)return;
  history.pushState({rd:id},'');document.documentElement.classList.add('rd-open');rdEl.hidden=false;rdEl.scrollTop=0;
  const bar=`<div class="rd-bar"><button class="rd-back" data-rd="close">${ICON.back}<span>Back</span></button><a class="ib" href="${esc(n.u)}" target="_blank" rel="noopener" aria-label="Original page">${ICON.ext}</a></div>`;
  const cached=lsGet(LS.read,{})[id];
  const show=(d,loading)=>{rdEl.innerHTML=bar+`<article class="rd-body" style="display:block;border:0"><p class="note">${esc(n.s)} · ${fmtWhen(n.d)}</p><h1>${esc((d&&d.title)||n.t)}</h1>${loading?'<p class="rd-note">Loading the article…</p>':''}
    ${(d&&d.paras||[]).map(p=>p.t==='img'?`<figure><img src="${esc(p.src)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.parentNode.remove()"></figure>`:p.t==='h'?`<h2>${esc(p.x)}</h2>`:`<p>${esc(p.x)}</p>`).join('')}${!loading&&!(d&&d.paras&&d.paras.length)?`<p class="rd-note">${esc((d&&d.err)||'Could not extract the article')}</p>`:''}</article>
    <div class="rd-foot">${d&&d.partial&&d.paras&&d.paras.length?'<p class="rd-note">Only part of the article could be extracted.</p>':''}<a class="btn" href="${esc((d&&d.url)||n.u)}" target="_blank" rel="noopener">Read on the original site</a></div>`;};
  if(cached){show(cached);return;}show(null,true);
  try{const d=await gasGet({v:'read',id});const c=lsGet(LS.read,{});c[id]=d;const ks=Object.keys(c);if(ks.length>30)delete c[ks[0]];lsSet(LS.read,c);if(!rdEl.hidden)show(d);}catch(e){show({err:'Could not extract the article'});}}
function closeReader(){rdEl.hidden=true;rdEl.innerHTML='';document.documentElement.classList.remove('rd-open');}
rdEl.addEventListener('click',e=>{const t=e.target.closest('[data-rd]');if(t&&t.dataset.rd==='close'){history.state&&history.state.rd?history.back():closeReader();}});

/* ---------- start ---------- */
(function(){const q=new URLSearchParams(location.search);if(q.get('g')){st.view='games';st.sub=q.get('g');}else if(q.get('p')){st.view='players';st.sub=q.get('p');}else if(q.get('n')){setTimeout(()=>openReader(q.get('n')),1500);}})();
render();loadFeed();writeSwConf();syncPrefs();
if('serviceWorker' in navigator&&location.protocol.startsWith('http')){const had=!!navigator.serviceWorker.controller;navigator.serviceWorker.register('./sw.js').then(r=>r.update()).catch(()=>{});
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(had)location.reload();});}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!rdEl.hidden){history.state&&history.state.rd?history.back():closeReader();}});
document.addEventListener('error',e=>{const t=e.target;if(t&&t.tagName==='IMG')t.style.visibility='hidden';},true);
