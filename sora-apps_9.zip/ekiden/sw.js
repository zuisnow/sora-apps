const C='ekiden-0ea3774a';
const FILES=['./','./index.html','./app.js','./config.js','./manifest.json','./icon-192.png','./icon-512.png','./icon-maskable.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(FILES.map(u=>new Request(u,{cache:'reload'})))));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('ekiden-')&&k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
/* network first so a new upload shows up at once; the cache is only for offline */
self.addEventListener('fetch',e=>{const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==self.location.origin)return;
  const req=r.mode==='navigate'?r:new Request(r.url,{cache:'no-cache',credentials:r.credentials});
  e.respondWith(fetch(req).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(c=>c.put(r,cp));}return res;}).catch(()=>caches.match(r,{ignoreSearch:true}).then(hit=>hit||caches.match('./index.html'))));});
